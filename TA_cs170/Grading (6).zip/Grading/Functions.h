/******************************************************************************/
/*!
\file   Functions.h
\author Josiah Goh
\par    email: goh.j\@digipen.edu
\par    DigiPen login: goh.j
\par    Course: CS170
\par    Lab 06
\date   02/03/2019
\brief  
    This file contains the declarations of the following functions for the
      templeted functions lab.
    Functions include:
    
    copy
    count
    display
    equal
    fill
    find
    min_element
    max_element
    remove
    replace
    sum
    swap
    swap_ranges
    
    Specific portions that gave you the most trouble: NONE
    
*/
/*****************************************************************************/

//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
    template <typename T1, typename T2> T2* copy (T1* begin, T1* end, T2* B);

    template <typename T> int count(T* begin, T* end, const T& B);

    template <typename T> void display(T *begin, T *end);

    template <typename T1, typename T2> bool equal(T1* begin, T1* end, T2* B);

    template <typename T> void fill (T* begin, T* end, const T& B);

    template <typename T1, typename T2> T1* find( T1* begin,  T1* end,  const T2& B);
    
    template <typename T> T* max_element(T* begin, T* end);
    
    template <typename T> T* min_element(T* begin, T* end);

    template <typename T> T* remove(T* begin, T* end, const T& B);

    template <typename T> void replace(T* begin, T* end, const T& rep, const T& lace);

    template <typename T> T sum(T* begin, T* end);

    template <typename T> void swap(T &left, T &right);

    template <typename T> void swap_ranges(T* begin, T* end, T* B);

    /* 
    *  Other template function declarations for count, remove, replace, etc.
    *  go here. Make sure all of your declarations are sorted in alphabetical
    *  order. This includes putting the swap function above in the proper
    *  position.
    *
    */ 

    #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
