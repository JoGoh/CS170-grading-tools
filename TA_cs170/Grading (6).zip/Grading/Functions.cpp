/******************************************************************************/
/*!
\file   Functions.cpp
\author Josiah Goh
\par    email: goh.j\@digipen.edu
\par    DigiPen login: goh.j
\par    Course: CS170
\par    Lab 06
\date   02/03/2019
\brief  
    This file contains the implementation of the following functions for the
      templeted functions lab.
    Functions include:
    
    copy
    count
    display
    equal
    fill
    find
    min_element
    max_element
    remove
    replace
    sum
    swap
    swap_ranges
    
    Specific portions that gave you the most trouble: NONE
    
*/
/*****************************************************************************/

#include <iostream> // cout, endl

/*****************************************************************************/
/*!
  \brief
    counts the number of elements in the array.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
  \param B
    second array.
    
  \return count
    the number of elements.
*/
/*****************************************************************************/
template <typename T>
int count(T* begin, T* end, const T& B)
{
    int count=0;
    while(begin!=end)
    {
        if(*begin==B)
        {
            count++;
        }
        begin++;
    }
    return count;
}

/*****************************************************************************/
/*!
  \brief
    copies the elements of one array to another.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
  
  \param B
    second array.
    
  \return B
    the end of the second array.
*/
/*****************************************************************************/
template <typename T1, typename T2> 
T2* copy (T1* begin, T1* end, T2* B)
{
     while(begin!=end)
     {
         *B=*begin;//assigning values to element
         B++;
         begin++;
     }
     return B;//end of second array  
}

/*****************************************************************************/
/*!
  \brief
    prints the elements of the array.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
*/
/*****************************************************************************/
template <typename T> 
void display(T *begin, T *end)
{
    if(begin!=end)
    {
        std::cout<<*begin;   //for first element
        begin++;
    }

    while(begin!=end)
    {
        std::cout<<", "<<*begin;
        begin++;
    }
    std::cout<<std::endl;
}
 
/*****************************************************************************/
/*!
  \brief
    compares the array lexicographicallly.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
  \param B
    second array.
    
  \return the result whether both arrays are equal or not (true or false).
  
*/
/*****************************************************************************/
template <typename T1, typename T2> 
bool equal(T1* begin, T1* end, T2* B)
{
    while(begin!=end)
    {
        if((*begin)!=(*B))
            return false;//not equal
        begin++;
        B++;
    }
    return true;//if it gets to here its equal

}   

/*****************************************************************************/
/*!
  \brief
    fills in the elements of the array with value of B.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
  \param B
    the value to be filled with.
*/
/*****************************************************************************/
template <typename T> 
void fill (T* begin, T* end, const T& B)
{
    while(begin!=end)
    {
        *begin=B;
        begin++;
    }
        
}

/*****************************************************************************/
/*!
  \brief
    find the position of the array in which value B is first occured.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
  \param B
    the value to find.
    
  \return begin
    position in which B occurs.
*/
/*****************************************************************************/
template <typename T1, typename T2> 
T1* find( T1* begin,  T1* end,  const T2& B)
{

    
    while(begin!=end)
    {
        if(*begin==B)
            return begin;
        begin++;
    }
    
    return begin;   
}

/*****************************************************************************/
/*!
  \brief
    finds the position of the highest value in the array.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
  \return max
    position of the highest element.
*/
/*****************************************************************************/
template <typename T> 
T* max_element(T* begin, T* end)
{
    T* max=begin;
    while(begin!=end)
    {
        if((*max)<(*begin))
        {
            max=begin;
        }
        begin++;
    }
    
    return max;
}

/*****************************************************************************/
/*!
  \brief
    finds the position of the lowest value in the array.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
  \return min
    position of the lowest element.
*/
/*****************************************************************************/
template <typename T> 
T* min_element(T* begin, T* end)
{
    T* min=begin;
    
    while(begin!=end)
    {
        if((*min)>(*begin))
        {
            min=begin;
        }
        begin++;
    }
    return min; 
}

/*****************************************************************************/
/*!
  \brief
    removes any element which has value B.
  
  \param begin
    pos of first element.
  
  \param end
    pos of one after last element.
    
  \param B
    value to remove.
    
  \return the new end of the array.
*/
/*****************************************************************************/
template <typename T> 
T* remove(T* begin, T* end, const T& B)
{
    T* space=begin;
    T* next=begin;
    
    while(next!=end)
    {//also guards begin == end clause
        if(*next!=B)//only increment space when B is not found
        {
            if(next!=space)//only when they are pointing to different elements
                *space=*next;
            space++;
        }
        
        next++;
    }
    
    return space;//return new end
}

/*****************************************************************************/
/*!
  \brief
    replace any elements with the same value of rep in the array with lace.
  
  \param begin
    pos of first element in the array.

  \param rep
   the element to replace.
   
  \param lace
   the element to replace to.
  
  \param end
    pos of one after the last element in the array.
*/
/*****************************************************************************/
template <typename T> 
void replace(T* begin, T* end, const T& rep, const T& lace)
{
    while(begin!=end)
    {
        if(*begin==rep)
        {
            *begin=lace;
        }
        begin++;
    }
}

/*****************************************************************************/
/*!
  \brief
    adds all the values of the elements in the array.
  
  \param begin
    pos of first element in the array.
  
  \param end
    pos of one after the last element in the array.
    
  \return sum
    the sum of elements.
*/
/*****************************************************************************/
template <typename T> 
T sum(T* begin, T* end)
{   
    T sum = T();
    
    while(begin!=end)
    {
        sum+=*begin;
        begin++;
    }
    return sum;
}
    
/*****************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/*****************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/*****************************************************************************/
/*!
  \brief
    swaps the elements of 2 arrays.
  
  \param begin
    pos of first element in the array.
  
  \param end
    pos of one after the last element in the array.
    
  \param B
    the second array.
*/
/*****************************************************************************/
template <typename T> 
void swap_ranges(T* begin, T* end, T* B)
{

    while(begin!=end)
    {
        swap(*begin, *B);
        begin++;
        B++;
    }
        
}
