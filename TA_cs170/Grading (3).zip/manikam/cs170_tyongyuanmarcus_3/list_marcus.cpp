/******************************************************************************/
/*!
\file	list.cpp 
\author	Tan Yong Yuan Marcus
\par 	email: t.yongyuanmarcus\@digipen.edu
\par 	CS 170 
\par	lab 03
\date 	01/2/19
\brief
	Includes reverse, sort and unique function.
*/
/******************************************************************************/ 

#include <iostream>
#include "list.h"

/***********************************************************************/
/*!
\fn 	swap(Node *a, Node *b)
\brief	
	Swaps the values of two nodes
\param *a, *b
	Value that the Node should hold
\return
	void(swap values)
*/
/***********************************************************************/

void swap (Node *a, Node *b) {
	int tmp;
	tmp = a->value;
	a->value = b->value;
	b->value = tmp;
}

/***********************************************************************/
/*!
\fn 	make_node(int value)
\brief	
	Creates a new node that contains a int data type and a 
	pointer that points to null
\param  value
	Value that the Node should hold
\return
	pointer pointing to the node.
*/
/***********************************************************************/

Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/***********************************************************************/
/*!
\fn 	print_list(Node const *list)
\brief	
	Prints the value in list
\param 	*list
	The pointer pointing to the list to be printed
\return
	The printed list
*/
/***********************************************************************/

void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/***********************************************************************/
/*!
\fn 	clear(Node *&list)
\brief	
	Deallocate space that was allocated by the list.
\param  *&list
	Reference of a pointer
\return
	Free the space used by the list
*/
/***********************************************************************/

void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/***********************************************************************/
/*!
\fn		count(Node const *list)
\brief	
	Count the number of nodes in the list
\param 	*list
	The pointer pointing to the list to be counted
\return
	The number of nodes in the list
*/
/***********************************************************************/

int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/***********************************************************************/
/*!
\fn 	push_back(Node *&list, int value)
\brief	
	Adds a new node that contains a new scanned value to the back of the
	list
\param 	*&list, value
	Reference of pointer pointing to the list and the scanned value.
\return
	Updates the current list.
*/
/***********************************************************************/

void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/***********************************************************************/
/*!
\fn 	push_front(Node *&list, int value)
\brief	
	Adds a new node that contains a new scanned value to the front of the
	list
\param 	*&list, value
	Reference of pointer pointing to the list and the scanned value.
\return
	Updates the current list.
*/
/***********************************************************************/

void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/***********************************************************************/
/*!
\fn 	reverse(Node *&list)
\brief	
	Reverse the list.
\param 	*&list
	Reference of pointer pointing to the list.
\return
	void(Reverse the input list.)
*/
/***********************************************************************/

// Reverse the order of the elements in the list
void reverse(Node *&list) { 
	Node *beforePtr = list;
	if (list != nullptr && list->next != 0) {
		Node *currPtr = beforePtr->next;
		if (currPtr->next != 0) {
			Node *afterPtr = currPtr->next;
			beforePtr->next = nullptr;
			
			while (afterPtr->next) {
				currPtr->next = beforePtr;
				beforePtr = currPtr;
				currPtr = afterPtr;
				afterPtr = afterPtr->next;
			}
			currPtr->next = beforePtr;
			afterPtr->next = currPtr;
			list = afterPtr;
		}
		else {
			currPtr->next = beforePtr;
			beforePtr->next = nullptr;
			list = currPtr;
		}
	}
}

/***********************************************************************/
/*!
\fn 	sort(Node *&list)
\brief	
	sort the list.
\param 	*&list
	Reference of pointer pointing to the list.
\return
	void(Sort the input list.)
*/
/***********************************************************************/

// Sort elements in the list
void sort(Node *&list) {
	Node *smallestPtr = list;
	if (smallestPtr->next != 0) {
		Node *sortPtr = smallestPtr->next;
		while (smallestPtr->next) {
			if (smallestPtr->value >= sortPtr->value) {
				swap(smallestPtr, sortPtr);
			}
			while (sortPtr->next) {
				sortPtr = sortPtr->next;
				if (smallestPtr->value >= sortPtr->value) {
					swap(smallestPtr, sortPtr);
				}
			}
			if (smallestPtr->value >= sortPtr->value) {
				swap(smallestPtr, sortPtr);
			}
			smallestPtr = smallestPtr->next;
			sortPtr = smallestPtr->next;
		}
	}
}

/***********************************************************************/
/*!
\fn 	unique(Node *&list)
\brief	
	Removes the duplicated values in the list
\param 	*&list
	Reference of pointer pointing to the list.
\return
	void(updates the list)
*/
/***********************************************************************/

// Remove duplicate values in a sorted list
void unique(Node *&list) {
	Node *uniqueNode = list;
	if (uniqueNode->next != 0) {
		Node *currPtr = uniqueNode->next;	
		Node *beforePtr;
		
		while (uniqueNode->next) {
			if (uniqueNode->value == currPtr->value) {
				uniqueNode->next = currPtr->next;
				delete currPtr;
				currPtr = uniqueNode->next;	
			}
			else {
				while (currPtr->next) {
					beforePtr = currPtr;
					currPtr = currPtr->next;
					if (uniqueNode->value == currPtr->value) {
						beforePtr->next = currPtr->next;
						delete currPtr;
						currPtr = beforePtr->next;
					}
				}
				if (uniqueNode->value == currPtr->value)
					delete currPtr;
				uniqueNode = uniqueNode->next;
				currPtr = uniqueNode->next;
			}
		}		
	}
}