/******************************************************************************/
/*!
\file  list.cpp
\author Shawn Tan
\par    email: zongweishawn.t\@digipen.edu
\par    digiPen login: zongweishawn.t
\par    Course: CS170
\par    Lab 03
\date   30/1/2019
\brief  
    The following functions implemented in list.cpp are 
    Node *make_node(int value)
    void print_list(Node const *list)
    void clear(Node *&list)
    int count(Node const *list)
    void push_back(Node *&list, int value)
    void push_front(Node *&list, int value)
    void reverse(Node *&list)
    void sort(Node *&list)
    void unique(Node *&list)
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
   /*!
      \brief
      MakeNode(int value) Creates node with value.
      
      \param value
       value input by the user
  
      \return
      pNode
    */
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
   /*!
      \brief
      PrintList(Node const *list) Prints the list. 
            
      \param list
      reference to the address of the list
    */
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
   /*!
      \brief
       Clear(Node *&list)Clears all nodes in the given list.
            
      \param list
       reference to the address of the list pointer
    */
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
   /*!
      \brief
      Count(Node const *list) count the number of nodes.
            
      \param list
       reference to the address of the list pointer
        
      \return
      count
    */
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/******************************************************************************/
   /*!
      \brief
        Push_back(Node *&list, int value) Creates and add a new node to the 
        end of the list.
            
      \param list
        reference to the address of the list pointer
        
      \param value
       input integer by the user
    */
/******************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/******************************************************************************/
   /*!
      \brief
      Push_front(Node *&list, int value) Creates and add a new node to the 
      front of the list.
            
      \param list 
        reference to the address of the list pointer
      \param value 
       input integer by the user
    */
/*****************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
/******************************************************************************/
   /*!
      \brief
       Reverse(Node *&list) Reverses all the given nodes in the list. 
            
      \param list
       reference to the address of the list pointer
    */
/******************************************************************************/
void reverse(Node* &list)
  {
  Node*temp1=NULL;
  Node*temp2=NULL;
  Node*temp=list;
    if(list==NULL)
    {
   if(list -> next == NULL)
      {
         return;
      }
    }

    while(temp!=NULL)
      {
       temp2=temp->next;
       temp->next=temp1;
       temp1=temp;
       temp=temp2;
      }
       list=temp1;
  }
/******************************************************************************/
   /*!
      \brief
       Sort(Node *&list) Sorts the given nodes in the list in ascending order.
            
      \param list
       reference to the address of the list pointer
    */
/******************************************************************************/
void sort(Node *&list)
{
    Node *temp1 = NULL; 
    Node *temp2 = NULL;
    int temp=0;
    
    
    if(list==NULL)
    {
       if(list->next==NULL)
        {
            return;
        }
    }
 for(temp1=list;temp1->next!=NULL;temp1=temp1->next)
 {
  for(temp2=temp1->next;temp2!=NULL;temp2=temp2->next)
     {
       if(temp1->value>temp2->value)
      {
          temp=temp1->value;
          temp1->value=temp2->value;
          temp2->value=temp;
      }
      }
 }
}
/******************************************************************************/
   /*!
      \brief
       Unique(Node *&list)Identifies and delete nodes with 
        the same repeated value of the nodes in the list. 
            
      \param list
       reference to the address of the list pointer
    */
/******************************************************************************/
void unique(Node *&list)
{
    Node *cNode = list;  
    Node *nextNode; 
    
    if(cNode == NULL)
    {
      return;
    }
    while(cNode -> next != NULL)
  {
      if(cNode -> value == cNode -> next -> value)
     {
         nextNode = cNode -> next -> next;
            delete(cNode -> next);
               cNode -> next = nextNode;
     }
           else cNode = cNode -> next;
 }
}