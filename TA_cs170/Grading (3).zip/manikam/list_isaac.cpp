/******************************************************************************/
/*!
\file  list.cpp
\author Isaac Tan Kwang Yeong
\par    email: t.kwangyeongisaac\@digipen.edu
\par    DigiPen login: t.kwangyeongisaac
\par    Course: CS170
\par    Lab 3
\date   1/26/2019 
\brief  
    The following functions implemented in list.cpp allows to
    (1) pushes a node to the end of the linked list, 
    (2) pushes a node to the front of the linked list 
    (3) clears all nodes in the linked list
    (4) counts the total number of nodes in the linked list
    (5) Reverses the nodes in the given linked list
    (6) sort the given nodes in ascending order
    (7) finds repeated node values in the list and deletes it. 
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
   /*!
      \brief
        The following function allocates memory and set members of 
        the struct node.
            
      \param value
        value - takes in an int value from main.cpp.
        
      \return pNode
        Returns the pNode value back, which is the address of the node
        created
    */
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
   /*!
      \brief
       The following function sends the list value to std::cout.
            
      \param list
        the list takes in a pointer to a node.
    */
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
   /*!
      \brief
        The following function will clear all nodes in the given linked list.
            
      \param list
        The Points to the head node of the given linked list.
    */
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
   /*!
      \brief
        The following function counts the number of nodes in the
        linked list.
            
      \param list
        list - list points to the head node of the linked list.
        
      \return count
        Returns the number of nodes in the linked list.
    */
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;     
  }
  return count;
}
/******************************************************************************/
   /*!
      \brief
        The following function will create and add a new node to the end of the 
        linked list.
            
      \param list 
        The reference to the pointer (list), which points at the head node.
        
      \param value
        It takes in the given value by the user.The value is assigned to 
        the newly created node.
    */
/******************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
   /*!
      \brief
        The following function will create and add a new node to the front of 
        the linked list.
            
      \param list 
        list - reference to the pointer (list), which points at the head node.
        
      \param value
        It takes in the given value by the user. The value is assigned to 
        the newly created node.
    */
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
/******************************************************************************/
   /*!
      \brief
        The following function will reverse all the given nodes in the linked
        list. 
            
      \param list
        list - reference to the pointer (list), which points at the head node.
    */
/******************************************************************************/
void reverse(Node *&list) {
     if(list == nullptr || list->next == nullptr){
     return;}

    Node *Prev = nullptr;
    Node *Current = nullptr;
    Node *Next = nullptr;
    Current = list;
    while(Current != nullptr){
        Next = Current->next;
        Current->next = Prev;
        Prev = Current;
        Current = Next;
    }

    list = Prev;
}
/******************************************************************************/
   /*!
      \brief
        The following function will sort the given nodes in the linked list 
        in ascending order.
            
      \param list
        The reference to the pointer (list), which points at the head node.
    */
/******************************************************************************/
void sort(Node *&list) {
    
    Node *Cnode = nullptr;
    Node *Nnode = nullptr;
    int temp;
    
    if (list == nullptr || list->next == nullptr){
    return;
    }
    
for(Cnode = list; Cnode->next!= nullptr; Cnode=
 Cnode->next) {
     for(Nnode=Cnode->next; Nnode!= nullptr; Nnode=
     Nnode->next) {
        if(Cnode->value > Nnode->value){
             temp = Cnode->value;
             Cnode->value = Nnode->value;
             Nnode->value = temp;
         }
     }
    
 }
}   
/******************************************************************************/
   /*!
      \brief
        The following function will uniqely identify and delete nodes with 
        the same repeated value of the nodes in the given linked list. 
            
      \param list
        The reference to the pointer (list), which points at the head node.
    */
/******************************************************************************/
void unique(Node* &list) {

    Node *Cnode = list;
    Node *Nnode = nullptr;
    Node *Tnode = nullptr;
    
    if (list == nullptr || list->next == nullptr){
    return;
    }
    
for(Cnode = list; Cnode->next!= nullptr; Cnode=
 Cnode->next) {
     for(Nnode=Cnode->next; Nnode!= nullptr; Nnode=
     Nnode->next) {
        if(Cnode->value == Cnode->next->value) {
            Tnode = Cnode->next;
            Cnode->next = Tnode->next;
            delete Tnode;
        }
     }
 }
            
}   
    
    
    
    
    
    
    
    