/******************************************************************************/
/*!
\file list.cpp
\author Toh Zhi Hao
\par email: t.zhihao\@digipen.edu
\par DigiPen login: t.zhihao
\par Course: CS170L
\par Lab 03 
\date 01/02/2019
\brief
Reverse, sort and remove duplicate values in a linked list
*/
/******************************************************************************/

#include <iostream>
#include "list.h"

/******************************************************************************/
/*!
\brief
This function is used to make a new node
\param  value
new value in the new node
\return
pNode
*/
/******************************************************************************/
//!< Allocate memory and set members
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/******************************************************************************/
/*!
\brief
This function is used to print out all the nodes values
\param  *list
Pointer pointing at the starting node
\return
void
*/
/******************************************************************************/
//!< Prints all of the nodes values
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/******************************************************************************/
/*!
\brief
This function is used to clear all the nodes in the linked list
\param  *&list
Pointer pointing at the starting node
\return
void
*/
/******************************************************************************/
//!< Clear all the nodes
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/******************************************************************************/
/*!
\brief
This function is to return the number of nodes in the list
\param  *list
Pointer pointing at the starting node
\return
count
*/
/******************************************************************************/
//!< Count the number of nodes in the list
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/******************************************************************************/
/*!
\fn push_back
\brief
This function is to push the nodes to the back of the list
\param  *&list,value
Pointer pointing at the starting node
\return
void
*/
/******************************************************************************/
//!< Push the nodes to the back of the list
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
/*!
\fn push_front
\brief
This function is to push the nodes to the front of the list
\param  *&list, value
Pointer pointing at the starting node
\return
void
*/
/******************************************************************************/
//!< Push the nodes to the front of the list
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
/*!
\fn reverse
\brief
This function is to reverse the order of the elements in the list
\param  *&list
Pointer pointing at the starting node
\return
void
*/
/******************************************************************************/
//!< Reverse the order of the elements in the list
void reverse(Node *&list) {
    
    Node *previous = nullptr;
    Node *current = list;
    Node *next = list;
    
    while(current != NULL)
    {
        next = current->next;
        current->next = previous;
        previous = current;
        current = next;
    }
    list = previous;
}

/******************************************************************************/
/*!
\fn sort
\brief
This function is to sort the elements in the list
\param  *&list
Pointer pointing at the starting node
\return
void
*/
/******************************************************************************/
//!< Sort elements in the list      
void sort(Node *&list) {
    
    Node *temp = list;
    int dump;
    
    if(temp == NULL)
    {
        return;
    }
    
    while(temp != NULL)
    {
        Node *temp2 = temp->next;
        
        while(temp2!= NULL)
        {
            if(temp->value > temp2->value)
            {
                dump = temp->value;
                temp->value = temp2->value;
                temp2->value = dump;
                temp2 = temp2->next;
            }
            else
            {
                temp2 = temp2->next;
            }
        }
        temp = temp->next;  
    }
}
    

/******************************************************************************/
/*!
\fn unique
\brief
This function is to remove duplicate values in a sorted listt
\param  *&list
Pointer pointing at the starting node
\return
void
*/
/******************************************************************************/
//!< Remove duplicate values in a sorted list
void unique(Node *&list) {
    
    Node *current = list;
    Node *newptr = nullptr;
    
    if(list == NULL)
    {
        return;
    }
    
    while(current->next != NULL)
    {
        if(current->value == current->next->value)
        {
            newptr = current->next->next;
            delete current->next;
            current->next = newptr;
        }
        
        else
        {
            current = current->next;
        }
    }
}
            
        







