/**********************************************************************/
/*!
\file list.cpp
\author EDWIN GOH WEI LE
\par email: weileedwin.goh\@digipen.edu
\par DigiPen login: weileedwin.goh
\par Course: CS170L
\par Lab 03
\date 31/1/2019 by 1630
\brief
*The following functions implemented in list.cpp allows to
(1) Reverse node order / values inside the nodes, 
(2) Sort the values / nodes in ascending order
(3) Remove duplicate values / nodes after sorting.
*/
/**********************************************************************/
#include <iostream>
#include "list.h"

/**********************************************************************/
/*!
      
      \brief
        To create new node
            
      \param value
        value - takes in an int value from main.cpp.
        
      \return pNode
        Returns the pNode value back, which is the address of the node
        created
	*/
/**********************************************************************/

Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/**********************************************************************/
   /*!
      \fn print_list
        PrintList
      \brief
        The following function prints out the number of nodes in
        the list
            
      \param Nodes values
        values - values in the list
        
      \return Void
    */
/**********************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/**********************************************************************/
   /*!
      \fn clear
        Clear Nodes
   
      \brief
        The following function deletes all the nodes in the list
            
      \param
        Pointers
        
      \return
        Void
    */
/**********************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/**********************************************************************/
   /*!
      \fn count
        Count Nodes
      \brief
        The following function count the number of nodes in
        the list
            
      \param
        Count 
        
      \return count 
        Returns the count value of the nodes
    */
/**********************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/*********************************************************************/
   /*!
      \fn push_back
        push_back
   
      \brief
        The following function adds a node to the end of the list
            
      \param
        Pointers
        
      \return
        Void
    */
/**********************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/*********************************************************************/
   /*!
      \fn push_front
        push_front
   
      \brief
        The following function adds a node to the front of the list
            
      \param
        Pointers
        
      \return
        Void
    */
/**********************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/**********************************************************************/
   /*!
      \fn reverse
        reverse nodes
   
      \brief
        The following function reverse all the nodes in the list
            
      \param
        Pointers, user's input
        
      \return
        Void
    */
/**********************************************************************/
void reverse(Node* &list)
{
    Node *current = list;
    Node *prev = NULL, *next = NULL;
    
    while(current != NULL)
    {
        next = current -> next;
        current -> next = prev;
        prev = current;
        current = next;
    }
    list = prev;
}

/**********************************************************************/
   /*!
      \fn sort
        Sorting
   
      \brief
        The following function sorts all the nodes in ascending order
        in the list
            
      \param
        Pointers, temporary int
        
      \return
        Void
    */
/**********************************************************************/
void sort(Node* &list)
{
    Node *pStart = list;
    int tmp = 0;
    
    if(list == NULL)    
    {
        return;
    }
    
    while(pStart != NULL)
    {
        Node *pLoop = pStart -> next;
        while(pLoop != NULL)
        {
            if(pStart -> value > pLoop -> value)
            {
                tmp = pStart -> value;
                pStart -> value = pLoop -> value;
                pLoop -> value = tmp;
                pLoop = pLoop -> next;
            }
            else
            {
                pLoop = pLoop -> next;
            }
        }
            pStart = pStart -> next;
    }
    return;
}

/**********************************************************************/
   /*!
      \fn unique
        Unique
   
      \brief
        The following function removes all the duplicate values in the
        the nodes in the list
            
      \param
        Pointers
        
      \return
        Void
    */
/**********************************************************************/
void unique(Node* &list)
// Remove duplicate values in a sorted list
{
    Node *pStart = list;
    Node *tmp = list;
    
    if(pStart == NULL)
    {
        return;
    }
        while(pStart -> next != NULL)
        {
            if(pStart -> value == pStart -> next -> value)
            {
                tmp = pStart -> next -> next;
                delete (pStart -> next);
                pStart -> next = tmp;
            }
            else
            {
                pStart = pStart -> next;
            }
        }
}

// g++ list.cpp main.cpp -ansi -pedantic -Wall -Werror -Wextra -std=c++11