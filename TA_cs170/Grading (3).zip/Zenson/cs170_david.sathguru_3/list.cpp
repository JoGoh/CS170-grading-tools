/******************************************************************************/
/*!
\file  list.cpp
\author David Sathguru
\par    email: david.sathguru\@digipen.edu
\par    DigiPen login: david.sathguru
\par    Course: CS170
\par    Lab 3
\date   2/1/2019
\brief  
    The following functions implemented in list.cpp allows to(1) Reverse the order of the elements in the list 
	(2) Sort elements in the list (3) Remove duplicate values in a sorted list
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
   /*!
      \brief
        The following function allocates memory and set members of 
        the struct node.
            
      \param value
        value - takes in an int value from main.cpp.
        
      \return pNode
        Returns the pNode value back, which is the address of the node
        created
    */
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
   /*!
      \brief
       The following function sends the list value to std::cout.
            
      \param 
        list - takes in a pointer to a node.
    */
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
   /*!
      \brief
       The following function delete Node.
            
      \param list
         - takes in a pointer to a node.
    */
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
   /*!
      \brief
        The following function after assigning the next value to list,
        it will increment count by 1.
            
      \param list
         - takes in a pointer to a node.
        
      \return count
        Returns the count value back.
    */
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/******************************************************************************/
   /*!
      \brief
        The following function will push nodes starting from the last node
            
      \param list
         - takes in a pointer to a node.
        
      \param value
         - takes in the given value by the user.The value is assigned to 
        the newly created node.
    */
/******************************************************************************/

void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next ;
    pCurrNode->next = pNewNode;
  }  
}
/******************************************************************************/
   /*!
      \brief
        The following function will push nodes starting from the first node
            
      \param list 
        list - Points to the head node of the given linked list.
        
      \param value
        value - takes in the given value by the user.The value is assigned to 
        the newly created node.
    */
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
/******************************************************************************/
   /*!
      \brief
       The following function will reverse the order of the elements in the list
            
      \param list
         - Points to the head node of the given linked list.
    */
/******************************************************************************/
void reverse(Node *&list){
    if(!list) return;
    Node* prev = nullptr;
    Node* next = nullptr;
    Node* curr = list;
    
    while(curr != nullptr){
        next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    list = prev;
           
} 
/******************************************************************************/
   /*!
      \brief
       The following function sort element from the list.
            
      \param list
        - Points to the head node of the given linked list.
    */
/******************************************************************************/
void sort(Node *&list)
{
    if(!list)return;
    Node*Next = list;
    Next = list->next;
    Node*Prev = list;
    int tem,counter =1;
    while(counter)
    {
      counter =0;
          while(Next!= nullptr)
          {
            if(Prev->value > Next->value)
            {
                tem = Prev->value;
                Prev->value = Next->value;
                Next->value = tem;
                Next = Next->next;
                counter++;
            }
            else
            {
                Next=Next->next;
            }
            
          } 
                Prev = Prev->next;
                if(Prev == nullptr)break;
                Next = Prev->next;
    }
}
/******************************************************************************/
   /*!
      \brief
       The following function remove duplicate values in a sorted list
            
      \param list
        - Points to the head node of the given linked list.
    */
/******************************************************************************/
void unique(Node *&list)
{
    Node* Prev;
    if(!list)return;
    Node*Curr =list;
    Node*tem;
    
    while(Curr->next != nullptr)
    {
        Prev = Curr;
        Curr = Curr->next;
        if(Curr->value == Prev->value)
        {
            tem = Curr;
            Curr= Curr->next;
            delete tem;
            Prev->next = Curr;
			Curr = Prev;
        }
    
    
    }
}
    
    
   

   
    





    
    