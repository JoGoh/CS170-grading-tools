/************************************************************************/
/*!
\file   list.cpp
\author Ho Chang Ming
\par    email: changming.h\@digipen.edu
\par    DigiPen login: changming.h
\par    course: CS 170
\par    lab02
\date   01/02/2019
\brief 
 This program works with basic linked list with various functions.
*/
/************************************************************************/
#include <iostream>
#include "list.h"
/************************************************************************/
/*!
 \fn Node *make_node(int value) 
 \brief
 Make a new node.
 \param value 
 \return pNode
*/
/************************************************************************/
Node *make_node(int value) {
	Node *pNode = new Node;
	pNode->value = value;
	pNode->next = nullptr;  
	return pNode;
}
/************************************************************************/
/*!
 \fn print_list(Node const *list) 
 \brief
 Prints all of the nodes values.
 \param list 
 \return Nil
*/
/************************************************************************/
void print_list(Node const *list) 
{
	while (list) 
	{
		std::cout << list->value << " ";
		list = list->next;
	}
	std::cout << std::endl;   
}
/************************************************************************/
/*!
 \fn clear(Node *&list) 
 \brief
 Frees (deletes) all of the nodes in the list.
 \param list 
 \return Nil
*/
/************************************************************************/
void clear(Node *&list) 
{
  Node *pCurrNode = list;
  while (pCurrNode)
	{
		list = pCurrNode->next;
		delete pCurrNode;
		pCurrNode = list;
	}
  list=nullptr;
}
/************************************************************************/
/*!
 \fn count(Node const *list) 
 \brief
 Returns the number of nodes in the list.
 \param list 
 \return Nil
*/
/************************************************************************/
int count(Node const *list) 
{
	int count = 0;
	while (list) 
	{
		count++;
		list = list->next;
	}
	return count;
}
/************************************************************************/
/*!
 \fn push_back(Node *&list, int value) 
 \brief
 Adds a node to the end of the list.
 \param list, value 
 \return Nil
*/
/************************************************************************/
void push_back(Node *&list, int value)
 {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else
	{
		while (pCurrNode->next)
			pCurrNode = pCurrNode->next;
			pCurrNode->next = pNewNode;
	}  
}
/************************************************************************/
/*!
 \fn push_front(Node *&list, int value) 
 \brief
 Adds a node to the front of the list.
 \param list, value 
 \return Nil
*/
/************************************************************************/
void push_front(Node *&list, int value) 
{
	Node *pNewNode = make_node(value);
	pNewNode->next = list;
	list = pNewNode;  
}
/************************************************************************/
/*!
 \fn reverse(Node *&list) 
 \brief
 Reverses the nodes in the list.
 \param list 
 \return Nil
*/
/************************************************************************/
void reverse(Node *&list)
{
    Node *next=NULL;
    Node *prev=NULL;
    Node *ptr=list;
    if (list == nullptr) 
        return; 
    while(ptr!=NULL)
	{
		next= ptr->next;
		ptr->next=prev;
		prev=ptr;
		ptr=next;
    }
    list=prev;
}
/************************************************************************/
/*!
 \fn sort(Node *&list) 
 \brief
 Sorts the nodes in the list.
 \param list 
 \return Nil
*/
/************************************************************************/
void sort(Node *&list)
{

    int times = count(list);
    for (int i = 0; i < times; i++)
		{
        Node* current = list;
        while (current != nullptr &&
                     current->next != nullptr) {
            if (current->value > current->next->value) {
                int tmp = current->value; 
                current->value = current->next->value;
                current->next->value = tmp;
            }
            current = current->next;
        }
    }
}
/************************************************************************/
/*!
 \fn unique(Node *&list) 
 \brief
 Remove duplicates in the list.
 \param list 
 \return Nil
*/
/************************************************************************/
void unique(Node *&list){
    
	Node *pcurr = list;
	Node *nex;
	while (pcurr && (nex = pcurr->next)){
	if (pcurr->value == nex->value) 
		{
        pcurr->next = nex->next;
        delete nex;
		} 
    else
		{
        pcurr = pcurr->next;
		}
    }
    
}

        

    
    