/******************************************************************************/
/*!
\file  list.cpp
\author ANDRIANUS TEO
\par	email: andrianus.teo\@digipen.edu
\par	Course: CS170
\par	Lab 3
\date	01/02/2019 
\brief	
	The following functions implemented in list.cpp:
	(1) make a Node
	(2) Print the contect inside a List
	(3) Clear the memory of of the lists that is being create
	(4) Count the number of Nodes
	(5) Reverses the nodes in the list
	(6) sort the given nodes in ascending order
	(7) finds repeated node that has values in the list and deletes it
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

/******************************************************************************/
   /*!
      \fn Node *make_node(int value)
      
	  \brief
		This following function allocates memory and set members of 
		the struct node.
			
	  \param value
		value - takes in an int value from main.cpp.
		
	  \return pNode
		Returns the pNode value back, which is the address of the node
		created
	*/
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
   /*!
      \fn void print_list(Node const *list)
      
	  \brief
	   This following function sends the list value to std::cout.
			
	  \param *list
		list - takes in a pointer to a node.
      
      \return void
	*/
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
   /*!
      \fn void clear(Node *&list)
      
	  \brief
		This function will clear all nodes in the list.
			
	  \param *&list
		list - Points to the head of the list.
              
      \return void
	*/
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
   /*!
      \fn int count(Node const *list)
      
	  \brief
		This function counts the number of nodes in the list.
			
	  \param *list
		list - Points to the head of the list.
		
	  \return count
		Returns the number of nodes in the list.
	*/
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/******************************************************************************/
   /*!
      \fn void push_back(Node *&list, int value)
      
	  \brief
		This function will create and add a new node to the end of the list.
			
	  \param *&list,value
		list - 
		
	  \return void
	*/
/******************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/******************************************************************************/
   /*!
      \fn void push_front(Node *&list, int value)
      
	  \brief
		This function will create and add a new node to the front of the list.
			
	  \param *&list,value
		list - Points to the head of the list.
        value - takes in the given value by the user. The value is assigned to 
        the newly created node.
		
	  \return void
	*/
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
   /*!
      \fn void reverse(Node *&list)
      
      \brief
        This function will reverse all the given nodes in the list. 
            
      \param *&list
        list - Points to the head of the list.
    */
/******************************************************************************/
void reverse(Node *&list){
	Node *previousNode = NULL;
	Node *currentNode = list;
	Node *nextNode = NULL;
	
	if(list == NULL)
    {
		if(list -> next == NULL)
        {
            return;
        }
	}
    
	while(currentNode != NULL)
    {
		nextNode = currentNode -> next;
		currentNode -> next = previousNode;
		previousNode = currentNode;
		currentNode = nextNode;
	}
	list = previousNode;
}

/******************************************************************************/
   /*!
      \fn void sort(Node *&list)
      
      \brief
        This function will sort the given nodes in the list in ascending order.
            
      \param *&list
        list - Points to the head of the list.
    */
/******************************************************************************/
void sort(Node *&list) {
	Node *currNode;
	Node *nextNode;
	int temp;
	
	if(list == NULL)
    {
		if(list -> next == NULL)
        {
            
            return;
        }
	}
    
	for(currNode = list; currNode -> next != NULL; currNode = currNode -> next)
    {
		for(nextNode = currNode -> next; nextNode != NULL; nextNode = nextNode -> next)
        {
			if(currNode -> value > nextNode -> value)
			{
			temp = currNode -> value;
			currNode -> value = nextNode -> value;
			nextNode -> value = temp;
			}
		}
	}

}

/******************************************************************************/
   /*!
      \fn void unique(Node *&list)
   
      \brief
        This function will identify and delete nodes with 
        the same repeated value of the nodes in the given list. 
            
      \param *&list
        list - Points to the head of the list.
    */
/******************************************************************************/
void unique(Node *&list) {
    Node *currentNode = list;
	Node *nextNode;	
	
	if(currentNode == NULL)
    {
        return;
    }
    
	while(currentNode -> next != NULL)
    {
		if(currentNode -> value == currentNode -> next -> value)
        {
			nextNode = currentNode -> next -> next;
			delete(currentNode -> next);
			currentNode -> next = nextNode;
		}
		else
        {
            currentNode = currentNode -> next;
        }
	}
}