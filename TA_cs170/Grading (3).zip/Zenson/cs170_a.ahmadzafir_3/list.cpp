
/******************************************************************************/
/*!
\file   list.cpp
\author Ahmad Faruq bin Ahmad Zafir
\par    email: a.ahmadzafir@\digipen.edu
\par    DigiPen login: a.ahmadzafir 
\par    Course: CS170
\par    Lab 3
\date   1st February 2019 1800
\brief  This file decides which inputs are to be added to the front
        and to the end of the linkedlist by their value using functions push_back, push_front. 
        It also frees the memory allocated for the data structure using clear. In Addition
        to this, this file also reverses the nodes in the linked list with reverse, sorts
		the nodes in the linked list in ascending order based on the value and unique thats
		deletes the nodes with repeated values.
*/
/******************************************************************************/

#include <iostream>
#include "list.h"


/******************************************************************************/
   /*!
        
      \brief
        The following function allocates memory and set members of 
        the struct node.
            
      \param value
        takes in an int value from main.cpp.
        
      \return pNode
        Returns the pNode value back, which is the address of the node
        created
    */
/******************************************************************************/

Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/******************************************************************************/
   /*!
      
      
      \brief
       Prints the members of the list in the order assigned 
            
      \param list
       Node const *list is a pointer to a node

    */
/******************************************************************************/

void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}


/******************************************************************************/
   /*!
        
      
      \brief
       Frees the memory allocated for the data structure
            
      \param list
       Pointer to the head of a node
        
      
    */
/******************************************************************************/


void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/******************************************************************************/
   /*!
        
      \brief
       Counter for the number of nodes in the linked list
            
      \param list
        Node const *list is a pointer to a node
        
      \return int
        Returns the integer value of the number of nodes in the linked list
      
    */
/******************************************************************************/


int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}


/******************************************************************************/
   /*!
        
      
      \brief
       Adds a new input member to the end of the linked list
            
      \param list
       Points to the first node of the linked list
       
      \param value
       the value stored in a node
        
      
    */
/******************************************************************************/

void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
   /*!
        
      
      \brief
       Adds a new input member to the front of the linked list
            
      \param list
       Points to the first node of the linked list
       
      \param value
       the value stored in a node
        
      
    */
/******************************************************************************/

void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
   /*!
        
      
      \brief
       Reverses the order of the nodes in the linked list
            
      \param list
      Points to the first node of the linked list

      
    */
/******************************************************************************/

void reverse(Node* &list)
{
     Node *currentnode = list; 
	 if (currentnode == NULL)
	 {
		 return;
	 }
	else
	{		
	 Node *nextnode = NULL;
	 Node *prevnode = NULL;
	 
	 while(currentnode!=NULL)
	 {
		 nextnode=currentnode->next;
		 currentnode->next = prevnode;
		 prevnode = currentnode;
		 currentnode = nextnode;
	 }
	 
	 list=prevnode;
	}
} 

/******************************************************************************/
   /*!
        
      
      \brief
       Sorts the nodes in ascending order based on the value they store
            
      \param list
       Points to the first node of the linked list

      
    */
/******************************************************************************/


void sort(Node* &list)
{
		
	for(Node *currentnode = list; currentnode!=NULL; currentnode = currentnode ->next)
	{	
		for(Node *tempnode = currentnode->next ; tempnode!=NULL; tempnode = tempnode ->next)
		{
		int a = currentnode->value;
		int b = tempnode->value;
		if (a>b)
		{
			tempnode->value = a;
			currentnode->value =b;
	
		}
		}
		
	}		
	


}


/******************************************************************************/
   /*!
        
      
      \brief
       Deletes nodes that have values that are repeated
            
      \param list
       Points to the first node of the linked list

      
    */
/******************************************************************************/


void unique(Node* &list)
{
	Node *currentnode = list;
	if(currentnode==NULL)
	{
		return;
	}
	
	for(; currentnode!=NULL; currentnode = currentnode ->next)
	{	
		int a = currentnode->value;

		for(Node *tempnode = currentnode->next; tempnode!=NULL;)
		{
			
		int b = tempnode->value;
		Node*temp2node = tempnode;
		
		if (a==b)
		{
			tempnode=tempnode->next;
			currentnode->next=tempnode;
			delete temp2node;
		}
		else
		{
			tempnode=tempnode->next;
		}
		
		}
	}
}


