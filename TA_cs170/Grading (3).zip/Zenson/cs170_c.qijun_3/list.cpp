/******************************************************************************/
/*!
\file list.cpp
\author Chua Qi Jun
\par email: c.qijun@digipen.edu
\par DigiPen login: c.qijun
\par Course: CS170C
\par Lab 03
\date 01/02/2019
\brief   
    The following functions implemented in list.cpp allows to(1) Make a new 
    node with the input value (2) Print out the updated list (3) Delete all 
    nodes in the list (4) Count the number of node in the list (5) Add the 
    value to the end of the list (6) Add the value to the front of the list 
    (7) Reverse the arrangement of the value in the list (8) Sort the value 
    in ascending order (9) Delete repeated values and will only have a unique
    number in the list
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
    /*!
      \brief
        This function is to make a new node

      \param value
        Takes in a value

      \return pNode
        return pNode value(address) back to main file
*/
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
   /*!
      \brief
        This function is to print out the rearranged Node list value

      \param list
        Takes in a pointer to a node 
*/
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
   /*!
      \brief
        This function is to delete the list 

      \param list
        Takes in a pointer to a node 
*/
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
   /*!
      \brief
        This function is to count the number of list(value the user input) it has.

      \param list
        Takes in a pointer to a node 

      \return count
        Return the count value back to main
*/
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/******************************************************************************/
   /*!
      \brief
        This function is to add the value to the end of the list

      \param list
        Points to the first node of the list

      \param value
        Takes in a value
*/
/******************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/******************************************************************************/
   /*!
      \brief
        This function is to add the value to the front of the list

      \param list
        Points to the first node of the list

      \param value
        Takes in a value
*/
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;
}
/******************************************************************************/
   /*!
      \brief
        This function is to reverse the order of the list

      \param list
        Points to the first node of the list
*/
/******************************************************************************/
void reverse(Node* &list) {
  Node *pCurr1Node = list;
  Node *pCurr2Node = list;
  Node *OriginalNode = list;
  int number = count(list);
  int value1, value2;
  for(int i=0; i<number/2; i++) {
    value1 = pCurr1Node->value;
    for(int j=0; (j<(number-i-1)); j++) {
      pCurr2Node = pCurr2Node->next;
    }
    value2 = pCurr2Node->value;
    pCurr1Node->value = value2;
    pCurr2Node->value = value1;
    pCurr1Node = pCurr1Node->next;
    pCurr2Node = OriginalNode;
  }
}
/******************************************************************************/
   /*!
      \brief
        This function is to sort the value in the list in ascending order

      \param list
        Points to the first node of the list
*/
/******************************************************************************/
void sort(Node* &list) {
  Node *pCurr1Node = list;
  Node *OriginalNode = list;
  int number = count(list);
  int i, j, tmp;
  for (j=0; j<number-1; j++) {
    for (i=0; i<number-j-1; i++) {
      if (pCurr1Node->value > (pCurr1Node->next)->value) {
        tmp = pCurr1Node->value;
        pCurr1Node->value = (pCurr1Node->next)->value;
        (pCurr1Node->next)->value = tmp;
        }
        pCurr1Node = pCurr1Node->next;
      }
      pCurr1Node = OriginalNode;
  }
}
/******************************************************************************/
   /*!
      \brief
        This function is delete repeated value in the list

      \param pList
        Points to the first node of the list
*/
/******************************************************************************/
void unique(Node* &list) {
  Node *pCurrNode = list;
  Node *TempNode = list;
  Node *DelNode = list;
  while(pCurrNode->next) {
    if((pCurrNode->next)->value == pCurrNode->value) {
       DelNode = pCurrNode->next;
       TempNode = DelNode->next;
       pCurrNode->next=TempNode;
       delete DelNode;
    }
    else {
    pCurrNode = pCurrNode->next;
    }
  }
}