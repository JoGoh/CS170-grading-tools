/******************************************************************************/
/*!
\file list.cpp
\author Afrina Saragih Binte Reiman Saragih
\par email: a.reimansaragih\@digipen.edu
\par DigiPen login: a.reimansaragih
\par Course: CS170L
\par Lab 03
\date 01/02/2019
\brief
    This is a program to make a node, push a node to either the front or back
    of the list, returns the number of nodes in the list, frees(deletes) all of 
    the nodes in th elist, prints all of the nodes values, reverses the order
    of the elements in the lists, sorts the elements in the list and remove
    duplicate values in a sorted list.
*/
/******************************************************************************/

#include <iostream>
#include "list.h"

/******************************************************************************/
   /*!
      \brief
        The following function allocates memory and set members of 
        the struct node.
            
      \param value
        value - takes in an int value from main.cpp.
        
      \return pNode
        Returns the pNode value back, which is the address of the node
        created
    */
/******************************************************************************/
// Allocate memory and set members
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/******************************************************************************/
   /*!
      \brief
       The following function sends the list value to std::cout.
            
      \param list
        list - takes in a pointer to a node.
    */
/******************************************************************************/

// Prints all of the nodes values
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/******************************************************************************/
   /*!
      \brief
        The following function will clear all nodes in the given linked list.
            
      \param list
        list - Points to the head node of the given linked list.
    */
/******************************************************************************/

// Frees (deletes) all of the nodes in the list
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/******************************************************************************/
   /*!
      \brief
        The following function after assigning the next value to list,
        it will increment count by 1.
            
      \param list
        list - takes in a pointer to a node.
        
      \return count
        Returns the count value back.
    */
/******************************************************************************/

// Returns the number of nodes in the list
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/******************************************************************************/
   /*!
      \brief
        The following function will create and add a new node to the end of the 
        linked list.
            
      \param list 
        list - Points to the head node of the given linked list.
        
      \param value
        value - takes in the given value by the user.The value is assigned to 
        the newly created node.
    */
/******************************************************************************/

// Push a node to the back of the list
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
   /*!
      \brief
        The following function will create and add a new node to the front of 
        the linked list.
            
      \param list 
        list - Points to the head node of the given linked list.
        
      \param value
        value - takes in the given value by the user. The value is assigned to 
        the newly created node.
    */
/******************************************************************************/

// Push a node to the front of the list
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
   /*!
      \brief
        The following function will the order of the nodes.
            
      \param list 
        list - Points to the head node of the given linked list.
    */
/******************************************************************************/

// Reverse the order of the elements in the list
void reverse(Node* &list){
    
    Node *temp = list;
    Node *temp1 = nullptr;
    Node *temp2 = nullptr;
    
    if(temp == NULL)
    {
        return;
    }
    
    while(temp != NULL)
    {
        temp1 = temp -> next;
        temp -> next = temp2;
        temp2 = temp;
        temp = temp1;
    }
        list = temp2;
    }

/******************************************************************************/
   /*!
      \brief
        The following function will sort(arrange) the order of the elements in
        the list.
            
      \param list 
        list - Points to the head node of the given linked list.
    */
/******************************************************************************/

// Sort elements in the list
void sort(Node* &list){
    Node *sort1 = list;
    
    
    
    int temp = 0;
    
    
    
    if(list == NULL)
    {
        return;
    }
    

    while(sort1 != nullptr)
    {
        Node *sort2 = sort1 -> next;
        while(sort2 != nullptr)
        {
            if(sort1 -> value > sort2 -> value)
            {   
                
                temp = sort2 -> value;
                sort2 ->value = sort1 -> value;
                sort1 -> value = temp;
                sort2 = sort2 -> next;
            }
            
            else
            {
                sort2 = sort2 -> next;
            }
        }
        sort1 = sort1 -> next;
    }
}

/******************************************************************************/
   /*!
      \brief
        The following function will delete duplicate values in a sorted list.
            
      \param list 
        list - Points to the head node of the given linked list.
    */
/******************************************************************************/

// Remove duplicate values in a sorted list
void unique(Node* &list){
    Node *unique1 = list;
    Node *unique2 =list;
    Node *middle = list;
    
    
    
    if(list == NULL)
    {
        return;
    }
   
    while(unique1 -> next != NULL)
    {
        if(unique1 -> value == unique1 -> next -> value)
        {
            middle = unique1 -> next;
            unique2 = unique1 -> next -> next;
            delete middle;
            unique1 -> next = unique2;
            middle = unique1;
        }
        
        else
        {
            unique1 = unique1 -> next;
        }
    }
    
}