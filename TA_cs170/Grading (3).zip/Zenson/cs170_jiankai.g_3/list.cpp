/******************************************************************************/
/*!
\file list.cpp
\author Giam Jian Kai
\par email: jiankai.g\@digipen.edu
\par DigiPen login: jiankai.g
\par Course: CS170L
\par Lab 03
\date 27/01/2019
\brief
This file contains functions used for manipulating linked list. With functions
used previously in lab 1 and 2 and addition of new and more advanced functions to apply
, namely; reverse, sort and unique.
*/
/******************************************************************************/

#include <iostream>
#include "list.h"
/******************************************************************************/
/*!
\fn FunctionName: make_node
\brief
creates new node
\param parameter1: int value
this is the int number that is to be added into new node
\return pNode
returns the address of the node that was created
*/
/******************************************************************************/

Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/******************************************************************************/
/*!
\fn FunctionName: print_list
\brief
prints the all the numbers in choosen list in order.
\param parameter1: Node const *list
contains the address of the head node; the first node of the choosen list
\return 
no return
*/
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/******************************************************************************/
/*!
\fn FunctionName: clear
\brief
deletes all nodes of the choosen list, deleting one node at a time.
\param parameter1: Node *&list
contains the address of the head node; the first node of the choosen list
\return 
no return
*/
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/******************************************************************************/
/*!
\fn FunctionName: count
\brief
counts how many nodes are in the choosen list
\param parameter1: Node const *list
contains the address of the head node; the first node of the choosen list
\return 
returns the number of nodes in choosen list
*/
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/******************************************************************************/
/*!
\fn FunctionName: push_back
\brief
adds a new node to the end of list
\param parameter1: Node *&list
contains the address of the head node; the first node of the choosen list
\param parameter2: int value
this is the number that is to be added to the list
\return 
no return
*/
/******************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
/*!
\fn FunctionName: push_front
\brief
adds a new node to the front of list
\param parameter1: Node *&list
contains the address of the head node; the first node of the choosen list
\param parameter2: int value
this is the number that is to be added to the front of the list
\return 
no return
*/
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
/*!
\fn FunctionName: reverse
\brief
Reverse the order of the elements in the list
\param parameter1: Node *&list
contains the address of the head node; the first node of the choosen list
\return 
no return
*/
/******************************************************************************/
// Reverse the order of the elements in the list
void reverse(Node *&list)
{   
    std::cout<<"ok\n";
    Node* prev= nullptr;
    Node* current=list;
    Node* next= nullptr;
    
    //pointing each node to the opposite direction, one by one
    while(current!=nullptr)
    {
        next=current->next;
        current->next=prev;
        prev=current;
        current=next;
    }
    list=prev; //pointing head node to the tail
}

/******************************************************************************/
/*!
\fn FunctionName: reverse
\brief
Sort elements in the list
\param parameter1: Node *&list
contains the address of the head node; the first node of the choosen list
\return 
no return
*/
/******************************************************************************/
// Sort elements in the list
void sort(Node *&list)
{
    int tmp=0;
    
    //loop once for evey existing element
    for(int cycle=count(list);cycle>0;cycle--)
    {
        Node* current=list;
        Node* next=list->next;
        
        //check for nodes with smaller values 
        do{
            if(current->value>next->value)//place smaller value node in front
        {
            tmp=current->value;         // by swapping
            current->value=next->value;
            next->value=tmp;
        }
        current=current->next;
        next=next->next;
        }while(current->next!=nullptr); 
    }
}

/******************************************************************************/
/*!
\fn FunctionName: unique
\brief
Remove duplicate values in a sorted list
\param parameter1: Node *&list
contains the address of the head node; the first node of the choosen list
\return 
no return
*/
/******************************************************************************/
// Remove duplicate values in a sorted list
void unique(Node *&list)
{   
    int unq=0;
    Node* current = list;
    Node* cmpnext = list;
    Node* cmpprev = list;
    
    //loop once for evey existing element
    for(int cycle=count(list);cycle>0;cycle--)
    {
        unq=current->value;
        cmpprev=current;
        cmpnext=current->next;
        
        //loop to check for repeated values
        while(cmpnext)
        {   
            if(unq==cmpnext->value)//delete value
            {
                cmpprev->next=cmpnext->next;
                delete cmpnext;
                cmpnext=cmpprev->next;//point cmpnext to the incoming node
                cycle--;
            }
            else    //point to next nodes for checking
            {
                cmpprev=cmpnext;
                cmpnext=cmpnext->next;
            }
            
        }
        current=current->next; //point to next element for checking 
    }

}

