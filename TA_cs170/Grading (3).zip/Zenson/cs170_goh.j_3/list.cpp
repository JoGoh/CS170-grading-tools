/******************************************************************************/
/*!
\file   list.cpp
\author Josiah Goh
\par    email: goh.j\@digipen.edu
\par    DigiPen login: goh.j
\par    Course: CS170
\par    Lab 03
\date   26/1/2019
\brief  
    This file contains the implementation of the following functions for the
      linked list lab.
    Functions include:
        push_back
        push_front
        count
        clear
        print_list
        reverse
        sort
        unique
 
 

  Specific portions that gave you the most trouble: NONE

  
*/
/*****************************************************************************/
#include <iostream>//cout , endl
#include "list.h"
#define LARGEST_INT 2147483647//largest integer
/*****************************************************************************/
/*!
  \brief
    Creates a new node.
    Allocate memory and set members.

  \param value
    The value of the node.

  \return pNode
   the pointer to the new node.  

*/
/*****************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/*****************************************************************************/
/*!
  \brief
    Prints the linked list.
    Prints all of the nodes values

  \param list
    the linked list.

*/
/*****************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/*****************************************************************************/
/*!
  \brief
  Frees (deletes) all of the nodes in the list.


  \param list
    The linked list.

*/
/*****************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/*****************************************************************************/
/*!
  \brief
    Counts number of nodes in list.
    & Returns the number of nodes in the list

  \param list
    The linked list.

  \return count
  the number of nodes in the list
  

*/
/*****************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/*****************************************************************************/
/*!
  \brief
   Push a node to the back of the list

  \param list
    The linked list.
  
  \param value
  The value of the node.
  
  
*/
/*****************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/*****************************************************************************/
/*!
  \brief
   Push a node to the front of the list

  \param list
    The linked list.
  
  \param value
  The value of the node.
  
  
*/
/*****************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
 
/*****************************************************************************/
/*!
  \brief
   Reverse the order of the elements in the list
  
  \param list
    The linked list.

*/
/*****************************************************************************/
 void reverse(Node* &list)
{   
    Node *Head=list;
    Node *reversed=NULL;
    Node *temp=NULL;
    if (!list)
    {//checking if list is empty
        return;
    }
    
        
    while(Head!=NULL)
    {    
        temp=Head->next;   //saves info on the next node
        Head->next=reversed; //shifts pointer
        reversed=Head; 
        Head=temp;
    }
    list=reversed;//points list to the reversed

} 

/*****************************************************************************/
/*!
  \brief
   Sort elements in the list in ascending order based on value
  \param list
    The linked list.

*/
/*****************************************************************************/
void sort(Node *&list)
{  
    
    Node *head=list;  
    Node *second = head;
    Node *shift = list;
    int tmp =0;
    int min=LARGEST_INT;

    
    if(!list) 
       return;
   
    while(head)
    {  
        min = LARGEST_INT;//set first to compare

        for(second=head;second;second=second->next)
        {    
            if( min > second->value )
            {
                min = second->value;//update min 
            }
        }
        for(shift=head;shift;shift=shift->next)
        {//rapid shifting values to front 
            if(shift->value == min)
            {
                
                tmp = head->value;
                head->value = shift->value;
                shift->value = tmp; 
                head = head->next;
                //after swapped, move on while discluding prev min
      
            }
        }
    }
}

/*****************************************************************************/
/*!
  \brief
   Remove duplicate values in a sorted list  
   
  \param list
    The linked list.

*/
/*****************************************************************************/
void unique(Node *&list)
{   
   
    Node *head=list;
    Node *second=list;
    Node *temp=list;
    
    if(!list)
       return;

    sort(list);//to sort first in-case sort not called
    
    head = list; 

    while (head->next != NULL) //so it doesnt do it indefinitely
    {   
        second = head->next;
            
        if (head->value == second->value) 
        {       
            temp  = head->next; 
            head->value  = temp->value;//updates that specific node
            head->next  = temp->next;
            delete temp;//deletes temp storage
              
        } 
        else
        head = head->next;//advance only when never change

    } 

}
    
    

    
    