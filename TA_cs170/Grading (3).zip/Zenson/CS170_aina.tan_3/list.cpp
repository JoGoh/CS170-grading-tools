/*************************************************************************/ 
/*!
\file       list.cpp
\author(s)  Aina Tan
\par        email:  aina.tan\@digipen.edu
\par        CS170
\par        Lab 3
\date       2/1/2019
\brief
    The following functions implemented in list.cpp allows to(1) Push a node to 
    to the end of the linked list, (2) Push a node to the front of the linked 
    list, (3) Reverse position of nodes in the linked list, (4) sort the node in
    linked list in ascending list (5) Find and delete nodes that appears more 
    than once in the linked list
*/
/**************************************************************************/

#include <iostream>
#include "list.h"

/***********************************************************************/
/*

      \brief
        The following function allocates memory and set members of 
        the struct node.
            
      \param value
        value - takes in an int value from main.cpp.
        
      \return pNode
        Returns the pNode value back, which is the address of the node
        created
 
 */
/***********************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/***********************************************************************/
/*

      \brief
       The following function sends the list value to std::cout.
            
      \param list
        list - takes in a pointer to a node.
 
 */
/***********************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/***********************************************************************/
/*

      \brief
        The following function will delete all nodes in the given linked list.
            
      \param list
        list - Points to the head node of the given linked list.
 
 */
/***********************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/***********************************************************************/
/*

      \brief
        The following function after assigning the next value to list,
        it will increment count by 1.
            
      \param list
        list - takes in a pointer to a node.
        
      \return count
        Returns the count value back.
 
 */
/***********************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/***********************************************************************/
/*

      \brief
        The following function will create and add a new node to the end of the 
        linked list.
            
      \param List 
        pList - Points to the head node of the given linked list.
        
      \param value
        value - takes in the given value by the user.The value is assigned to 
        the newly created node.
 
 */
/***********************************************************************/
// Adds a node to the end of the list
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/***********************************************************************/
/*

     \brief
        The following function will create and add a new node to the front of 
        the linked list.
            
      \param List 
        pList - Points to the head node of the given linked list.
        
      \param value
        value - takes in the given value by the user. The value is assigned to 
        the newly created node.
 
 */
/***********************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/***********************************************************************/
/*

     \brief
        The following function will reverse the linked list.
        The front will be the end, vice versa.
            
      \param List 
        pList - Points to the head node of the given linked list.
 
 */
/***********************************************************************/
// Reverse the order of the elements in the list
void reverse(Node *&list){
    Node *curr_ptr = list;
    Node *prv_ptr = nullptr;
    Node *next_ptr = nullptr;
    
    while (curr_ptr != nullptr)
    {
        next_ptr = curr_ptr->next;
        curr_ptr->next = prv_ptr;
        prv_ptr=curr_ptr;
        curr_ptr=next_ptr;
    }
    
    list = prv_ptr;     
            
}

/***********************************************************************/
/*

     \brief
        The following function will sort the linked list in ascending order.
            
      \param List 
        pList - Points to the head node of the given linked list.
 
 */
/***********************************************************************/
// Sort elements in the list
void sort(Node *&list){
        
    Node *i;
    Node *j;
        
    for(i = list; i->next != nullptr; i = i->next)
    {
        for(j = i->next; j != nullptr; j = j->next)
        {
            if ( (i->value) > (j->value) )
            {
                int store;
                store = i->value;
                i->value = j->value;
                j->value = store;
            }
        }

    }
}

/***********************************************************************/
/*

     \brief
        The following function delete numbers that appear more than once
        in the linked list.
            
      \param List 
        pList - Points to the head node of the given linked list.
 
 */
/***********************************************************************/
// Remove duplicate values in a sorted list
void unique(Node *&list){
    sort(list);
    
    Node *tmp_ptr = list;
    Node *store;
    
    while(tmp_ptr != nullptr && tmp_ptr->next != nullptr)
    {
        if (tmp_ptr->value == (tmp_ptr->next)->value)
        {
            store = (tmp_ptr->next)->next;
            
            if (store == nullptr)
            {
                tmp_ptr->next = nullptr;
                break;
            }
            
            tmp_ptr->next = store;
        }
        
        if(tmp_ptr->value != tmp_ptr->next->value)
        {
        tmp_ptr = tmp_ptr->next;
        }
    }
}
