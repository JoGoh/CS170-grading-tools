/**************************************************************************
\file    list.cpp
\author      Lucas Tan
\par email    juihunglucas.tan@digipen.edu
\par Course:      CS170
\par Lab 3
\par due date :   2/1/2019
\par Brief Description:  
This program places a series of values into a linked list
**************************************************************************/

#include <iostream>
#include "list.h"

/******************************************************************************/
/*! 
 
  \brief Allocates memory to a node. 
  \param value Value to place in node
  \return     
  Returns a node containing the specified value.
*/ 
/******************************************************************************/ 
Node *make_node(int value)
{
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/******************************************************************************/
/*! 
 
  \brief Prints all values in a linked list
  \param list Pointer to first value in linked list
*/ 
/******************************************************************************/
void print_list(Node const *list)
{
  while (list)
  {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/******************************************************************************/
/*! 
 
  \brief Clears a linked list from memory
  \param list pointer to linked list
*/ 
/******************************************************************************/ 
void clear(Node *&list)
{
  Node *pCurrNode = list;
  while (pCurrNode)
  {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/******************************************************************************/
/*! 
 
  \brief Finds the length of a linked list
  \param list Pointer to first value in linked list
  \return number of nodes of linked list
*/ 
/******************************************************************************/ 
int count(Node const *list)
{
  int count = 0;
  while (list)
  {
    count++;
    list = list->next;
  }
  return count;
}

/******************************************************************************/
/*! 
 
  \brief Adds a value to the end of a linked list
  \param list pointer to linked list
  \param value Value to add
*/ 
/******************************************************************************/ 
void push_back(Node *&list, int value)
{
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else
  {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
/*! 
 
  \brief Adds a value to the front of a linked list
  \param list pointer to linked list
  \param value Value to add
*/ 
/******************************************************************************/ 
void push_front(Node *&list, int value)
{
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
/*! 
 
  \brief Reverses a linked list
  \param list pointer to linked list
*/ 
/******************************************************************************/ 
void reverse(Node* &list)
{
  Node* newlist = list;
  
  Node *pCurrNode = list-> next;
  newlist -> next = nullptr;
  while (pCurrNode)
  {
    Node* temp = pCurrNode;
    pCurrNode = pCurrNode-> next;
    
    temp->next = newlist;
    newlist = temp;
  }
  list=newlist;
}

/******************************************************************************/
/*! 
 
  \brief Removes any duplicate values in a linked list
  \param list pointer to linked list
*/ 
/******************************************************************************/ 
void unique(Node* &list)
{
   
  Node *ptr1, *ptr2, *dup; 
  ptr1 = list; 
  
  while (ptr1 != nullptr && ptr1->next != nullptr) 
  { 
    ptr2 = ptr1; 

    while (ptr2->next != nullptr) 
    { 
      if (ptr1->value == ptr2->next->value) 
      { 
        // we found a duplicate
        dup = ptr2->next; 
        ptr2->next = ptr2->next->next; 
        delete(dup); 
      } 
      else // leave it
        ptr2 = ptr2->next; 
    } 
    ptr1 = ptr1->next; 
  }
}

/*****************************************************************************/
/*! 
 
  \brief Merges two linked lists, putting that with the smaller value in front
  \param front pointer to first linked list
  \param back pointer to second linked list
*/ 
/*****************************************************************************/ 
Node* merge(Node* front, Node* back)
{
  if (front == nullptr)
    return back;
  if (back == nullptr)
    return front;
  
  Node* result = nullptr;
  
  if (front->value <= back->value)
  {
    result = front;
    result->next = merge(front->next, back);
    return result;
  }
  result = back;
  result->next = merge(front, back->next);
  return result;
}

/*****************************************************************************/
/*! 
 
  \brief Splits a linked list into two equal halves
  \param head linked list to split
  \param front pointer to first linked list (to return)
  \param back pointer to second linked list (to return)
*/ 
/*****************************************************************************/ 
void split(Node* head, Node* &front, Node* &back)
{
  Node* fast = head->next;
  Node* slow = head;
  while (fast != nullptr)
  {
    fast = fast ->next;
    if (fast != nullptr) 
    {
      fast = fast->next;
      slow = slow->next;
    }
  }
  front = head;
  back = slow->next;
  slow->next = nullptr;         
}

/*****************************************************************************/
/*! 
 
  \brief Sorts a linked list in ascending order, using a 
  \param list pointer to linked list
*/ 
/*****************************************************************************/ 
void sort (Node* &list)
{
	Node* head = list;
  
  if (list == nullptr || list->next == nullptr) // < 2 values? nothing to sort
    return;
  if (list->next->next == nullptr) // only 2 values? then do not split
  {
    if (list->value > list->next->value)
    {
      std::swap(list->value, list->next->value);
      return;
    }
  }
  
  Node* front;
  Node* back;
  split(head, front, back);
  
  sort(front);
  sort(back);
  list = merge(front, back);
}