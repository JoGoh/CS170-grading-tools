/******************************************************************************/
/*!
\file cs170_vector.h
\author Koh Joon Yee Marcus
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: cs170
\par Lab : 07
\date 15/07/2019
\brief
This file contains the implementation of the following functions for Lab 06
Functions include:
vector default constructor <br>
vector Copy constructor <br>
vector Copy assignment <br>
vector destructor <br>
vector Custom Constructor<br>
<br>empty
<br>size
<br>capacity
<br>allocations
<br>push_front
<br>push_back
<br>pop_front
<br>pop_back
<br>insert
<br>erase
<br>clear
<br>grow
<br>Operator Overloads:
<br> operator[]
<br> operator+
<br> operator+=

\par Hours spent on this assignment: 2

*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef vector_H
#define vector_H
////////////////////////////////////////////////////////////////////////////////

#include <iomanip>
#include <iostream>
namespace cs170
{
    template<typename T>
    class vector
    {
    public:
/******************************************************************************/
 /**
   \brief
      This is the default constructor for the vector and it initializes the
      private members of the class which are the store_array, the vec_size and
      the cap.
 */
/******************************************************************************/
vector():
store_array{0},
vec_size{0},
cap{0}
{
}

/******************************************************************************/
/**
  \brief
   This is a custom constructor that takes in an array of the templated typedef
      and a value of type size_t as the array size and constructs a new vector
      with the given parameters.
*/
/******************************************************************************/
vector( T * array, const size_t sz):
    store_array{nullptr},
    vec_size{sz},
    cap{1}
{
    int count = 0;
    for(int i = sz ; i!=0; i/=2)
    {
        count++;
    }
    while(count--)
    {
        cap *=2;
    }
    store_array = new T[cap];
    for(unsigned int i = 0; i<vec_size ; i++)
    {

        store_array[i] = array[i];
    }
}

/******************************************************************************/
/**
  \brief
     This is the destructor for vector and it deletes any memory allocated for
     the store_array.
*/
/******************************************************************************/
        ~vector()
        {
			vec_size = 0;
			cap = 0;
            delete[] store_array;
            store_array = nullptr;
        }

/******************************************************************************/
/**
  \brief
     This is the copy constructor for the vector. Copies the store_array into
     a new array.
  \param
   const vector & rhs - where rhs is a reference to the vector on the right
   hand side of the copy operation. It represents the vector that is to be
   copied.
*/
/******************************************************************************/
        vector(const vector& rhs)
        {
            vec_size = rhs.vec_size;
            cap = rhs.cap;
            store_array = new T[cap];
            for(unsigned int i = 0; i<vec_size ; i++)
            {
                store_array[i] = rhs.store_array[i];
            }
        }

/******************************************************************************/
/**
  \brief
     This is the copy assignment for the vector. Assigns the vector on the
     right-hand-side of the operation to the vector on the left-hand-side
  \param
   const vector & rhs - where rhs is a reference to the vector on the right
   hand side of the copy operation. It represents the vector that is to be
   copied and assigned into the left-hand-side of the operation.
*/
/******************************************************************************/
        vector& operator=(const vector &rhs)
        {
            if(store_array ==rhs.store_array)
                return *this;

            if(store_array != nullptr)
            {
                delete[] store_array;
            }

            vec_size = rhs.vec_size;
            cap = rhs.cap;
            store_array = new T[cap];

            for(unsigned int i = 0; i<vec_size ; i++)
            {
                store_array[i] = rhs.store_array[i];
            }
            return *this;
        }


/******************************************************************************/
/**
  \brief
     This function simply checks if the array is empty(i.e size ==0) and
     returns true if it is empty, else function returns false.
  \return
     True if empty, else returns false.
*/
/******************************************************************************/
        bool empty() const
        {
            return(vec_size == 0);
        }

/******************************************************************************/
/**
  \brief
     This function is a getter function that returns the size of the vector.
  \return
     vec_size is returned as tpye size_t
*/
/******************************************************************************/
        size_t size() const
        {
            //This is simply a getter function
            //only return what it wants
            return vec_size;
        }

/******************************************************************************/
/**
  \brief
     This function is a getter function that returns the capicity of the vector
  \return
     cap is returned which is the capacity of the current vector
*/
/******************************************************************************/
        size_t capacity() const
        {
            //This is simply a getter function
            //only return what it wants
            return cap;
        }


/******************************************************************************/
/**
  \brief
     This function takes in an templated value and inserts that value to the
     front of the store_array.
  \param
   num - an value of templated type representing the number to be inserted to
   the front of the list.
  \return
    void
*/
/******************************************************************************/
        void push_front(T num)
        {
            grow();
            //First element is the num
            //The rest move back
            for(unsigned int i = vec_size; i>0 ; i--)
            {
                store_array[i] = store_array[i-1] ;
            }
            store_array[0] = num;
            vec_size++;
        }


/******************************************************************************/
/**
  \brief
     This function takes in an integer value and inserts that value to the back
     of the store_array.
  \param
   num - an value of templated type T representing the number to be inserted to
   the back of the list.
  \return
    void
*/
/******************************************************************************/
        void push_back(T num)
        {
            //first check if there is enough space to push back
            grow();
            //Make next element outside of vector equal to value
            store_array[vec_size] = num;
            //increase vector size accordingly
            vec_size++;
        }

/******************************************************************************/
/**
  \brief
     This function removes the front-most element in the store_array

  \return
    void
*/
/******************************************************************************/
        void pop_front()
        {
            //Move everything to one space in front
            for(unsigned int i = 0; i<vec_size ; i++)
            {
                store_array[i] = store_array[i+1];
            }
            vec_size--;
        }

/******************************************************************************/
/**
  \brief
     This function removes the last element from the store_array
  \return
    void
*/
/******************************************************************************/
        void pop_back()
        {
            if(vec_size == 0)
                return;
            else
                --vec_size;
        }

/******************************************************************************/
/**
  \brief
     This function inserts a given value of templated type into the given
     position (pos) of the store_array.
  \param
    num - templated type passed in
  \param
    pos - position at which the value is to be inserted into the array.
  \return
    void
*/
/******************************************************************************/
void insert( size_t pos , T num)
{
    grow();
    for(size_t i = vec_size; i >pos ; i--)
    {
        store_array[i] = store_array[i-1];
    }
    store_array[pos] = num;
    ++vec_size;
}

/******************************************************************************/
/**
  \brief
     This function inserts a given value of templated type into the given
     position (pos) of the store_array.
  \param
    number - a number of templated type to be removed from the array

  \return
    void
*/
/******************************************************************************/
void erase(const size_t pos)
{
	if (pos < vec_size)
	{
		//Shift values 1 to the left
		for (size_t i = pos; i < vec_size - 1; ++i)
		{
			store_array[i] = store_array[i + 1];
		}
		--vec_size;
	}
}

/******************************************************************************/
/**
  \brief
     This function simply doubles the capacity of the vector when the capacity
     is reached
  \return
     void
*/
/******************************************************************************/
void grow()
{
    if(cap == 0)
    {
        cap = 1;
		delete[] store_array;
        store_array = new T[cap];

    }
    else if(vec_size >= cap)
    {
        cap*=2;
        T * tmp  = new T[vec_size];

        for(unsigned int i=0; i< vec_size; i++)
            tmp[i] = store_array[i];
        delete[] store_array;

        store_array = new T[cap];
        for(unsigned int i=0; i< vec_size; i++)
            store_array[i] = tmp[i];
        delete[] tmp;
    }
}

/******************************************************************************/
/**
  \brief
     This function simply sets the size and capacity of the vector to 0.
  \return
     void
*/
/******************************************************************************/
void clear()
{
    vec_size = 0;
}

/******************************************************************************/
/**
  \brief
     This operator overload allows the store_array to return the values
     stored in it.
  \return
     void
*/
/******************************************************************************/
T& operator[](size_t index) const
{
    if(index >= vec_size)
    {
        std::cout
            << "Attempting to access index " << index << "."
            << " The vec_size of the array is " << vec_size
            << ". Aborting...\n";
        std::abort();
    }
    return store_array[index];
}

/******************************************************************************/
/**
  \brief
     This operator overload adds performs compound addition between 2 vectors
  \return
     void
*/
/******************************************************************************/
void operator+=(const vector & rhs)
{
    for(unsigned int i= 0 ; i <rhs.vec_size; i++)
    {
        push_back(rhs.store_array[i]);
    }
}

    private:
        /* The dynamically allocated array. */
        T *store_array;

        /* The number of elements in the array. */
        size_t vec_size;

        /* The allocated size of the array also known as the capacity. */
        size_t cap;


        /* Makes sure the subscript or position is valid.
           Aborts the program if it is invalid. */
        void check_bounds(size_t index) const;

        /* Grows the array when necessary, by doubling its size when not empty.
           Sizes of the array: 0, 1, 2, 4, 8, 16, ... . */


    };
}                               // namespace cs170
#endif                          // vector_H


/******************************************************************************/
/**
  \brief
     This operator overload adds performs addition between 2 vectors and returns
     an Rvalue vector
  \return
     void
*/
/******************************************************************************/
template <typename T>
cs170::vector<T> operator+(const cs170::vector<T> &x, const cs170::vector<T> &y)
{
    cs170::vector<T> newvector(x);
    cs170::vector<T> addingvector(y);
    for(unsigned int i =0 ; i< y.size(); i++)
    {
        newvector.push_back(addingvector[i]);
    }
    return newvector;
}




/******************************************************************************/
/**
  \brief
     A print function template that will print out a templated vector.
  \return
     void
*/
/******************************************************************************/
template<typename T>
void Print(const cs170::vector<T> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}


/******************************************************************************/
/**
  \brief
     A specialised template from Print to take in unsigned chars and print
     out the results in the correct format
  \return
     void
*/
/******************************************************************************/
template<>
void Print<unsigned char>(const cs170::vector<unsigned char> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << static_cast<unsigned short>(array[i]) << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}


/******************************************************************************/
/**
  \brief
     A specialised template from Print to take in doubles and print
     out the results in the correct format
  \return
     void
*/
/******************************************************************************/
template<>
void Print<double>(const cs170::vector<double> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << std::left << std::setw(7) << std::setprecision(5)
            << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}

/******************************************************************************/
/**
  \brief
     A specialised template from Print to take in floats and print
     out the results in the correct format
  \return
     void
*/
/******************************************************************************/
template<>
void Print<float>(const cs170::vector<float> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout  << std::setw(5) << std::setprecision(3) << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}