/******************************************************************************/
/*!
\file main.cpp
\author Choong Xue Ting 
\par email: xueting.choong\@digipen.edu
\par DigiPen login: xueting.choong
\par Course: CS170
\par Lab 07
\date 15/07/2019
\brief
    This file consists of the functions for vectors.
*/
/******************************************************************************/

#include <iostream>
#include <iomanip> 
#include <string> 

namespace cs170
{
    template <typename T>
    
    class vector
    {
        public:
/******************************************************************************/
/*!
        \brief
        Default constructor.
*/
/******************************************************************************/
        vector () : count(0), cty(0)
        {
            items = new T[cty];
        }
        
/******************************************************************************/
/*!
        \brief
        Copy constructor.
        
        \param a
        Vector to copy.
*/
/******************************************************************************/
        vector (const vector &a) : count(a.count), cty(a.cty)
        {
            items = new T[cty];
            for(int i=0; i < count; i++)
            {
                items[i] = a.items[i];
            }
        }

/******************************************************************************/
/*!
        \brief
        Destructor to delete allocated memory.
*/
/******************************************************************************/
        ~vector()
        {
            delete[] items;
        }

/******************************************************************************/
/*!
        \brief
        Push new elements to the back.
        
        \param z
        Element to be pushed back.
*/
/******************************************************************************/
        void push_back (const T &z)
        {
            if(cty == 0)
            {
                cty++;
                items = new T[cty];
            }
            
            else if(count >= cty)
            {
                cty *= 2;
                items2 = new T[cty];
                for(int i=0; i < count; i++)
                {
                    items2[i] = items[i];
                }
                
                delete[] items;
                items = items2;
            }
            
            items[count] = z;
            count++;
            
        }

/******************************************************************************/
/*!
        \brief
        Pop the vector.
*/
/******************************************************************************/
        void pop_back()
        {
            count--;
        }

/******************************************************************************/
/*!
        \brief
        Determine whether vector is empty.
        
        \return
        Return 1 if empty, otherwise return 0.
*/
/******************************************************************************/
        int empty() const
        {
            return (count == 0);
        }
        
/******************************************************************************/
/*!
        \brief
        Erase the given position.
        
        \param i
        Element position.
*/
/******************************************************************************/
        void erase(T i)
        {
            int a = 0; 
            int b = 0;
            items2 = new T[cty];
            
            for(; a < count; a++)
            {
                if(a != i)
                {
                    items2[b++] = items[a];
                }
            }
            
            count--;
            delete[] items;
            items = items2;
        }

/******************************************************************************/
/*!
        \brief
        Insert into the vector.
        
        \param pos
        Position of the vector to be inserted.
        
        \param num
        Value of the inserted element.
*/
/******************************************************************************/
        void insert(int pos, const T num)
        {
            int a = 0;
            int b = 0;
            if(count >= cty)
                cty*=2;
            
            items2 = new T[cty];
            
            for(; b <= count;)
            {
                if(pos != b)
                    items2[b++] = items[a++];
                else
                    items2[b++] = num;
            }
            count++;
            delete[] items;
            items = items2;
        }

/******************************************************************************/
/*!
        \brief
        Clear the array.
*/
/******************************************************************************/
        void clear()
        {
            count = 0;
        }

/******************************************************************************/
/*!
        \brief
        Size of vector.
        
        \return count
*/
/******************************************************************************/
        unsigned int size() const
        {
            return count;
        }

/******************************************************************************/
/*!
        \brief
        Capacity of vector.
        
        \return cty
*/
/******************************************************************************/   
        int capacity() const
        {
            return cty;
        }

/******************************************************************************/
/*!
        \brief
        Subscript operator.
        
        \param i
        Position of the array.
        
        \return
        Reference the const element.
*/
/******************************************************************************/
        // line 125
        T &operator [](size_t i) const
        {
            return items[i];
        }

/******************************************************************************/
/*!
        \brief
        Subscript operator.
        
        \param i
        Position of the array.
        
        \return
        Reference the element.
*/
/******************************************************************************/
        T &operator [](size_t i) 
        {
            return items[i];
        }

/******************************************************************************/
/*!
        \brief
        Operator overloading =.
        
        \param a
        Reference of the vector to be copied.
*/
/******************************************************************************/
        // line 247
        void operator =(const vector &a)
        {
            for(int i=0; i < count; i++)
                items[i] = a.items[i];
        }
        
        private:
        
        int count;
        int cty;
        T *items;
        T *items2;
    };

/******************************************************************************/
/*!
    \brief
    Prints all elements in the vector.
        
    \param arr
    Reference to be printed.
*/
/******************************************************************************/
    template <typename T>
    void Print (const cs170::vector<T> &arr)
    {
        for(unsigned i = 0; i < arr.size(); i++)
        {
            std::cout << arr[i] << "  ";
        }
        std::cout << "(size=" << arr.size() << ", capacity="
        << arr.capacity() << ")";
        std::cout << std::endl;
    }    

/******************************************************************************/
/*!
    \brief
    Prints all elements in the vector of type unsigned char.
        
    \param arr
    Reference to be printed.
*/
/******************************************************************************/
    template<>
    void Print (const cs170::vector<unsigned char> &arr)
    {
        for(unsigned i = 0; i < arr.size(); i++)
        {
            std::cout << +arr[i] << "  ";
        }
        std::cout << "(size=" << arr.size() << ", capacity="
        << arr.capacity() << ")";
        std::cout << std::endl;
    }

/******************************************************************************/
/*!
    \brief
    Prints all elements in the vector of type double.
        
    \param arr
    Reference to be printed.
*/
/******************************************************************************/
    template<>
    void Print (const cs170::vector<double> &arr)
    {
        for(unsigned i = 0; i < arr.size(); i++)
        {    std::cout << std::setw(9) << std::left << std::setprecision(5)
            << arr[i];
        }
        std::cout << "(size=" << arr.size() << ", capacity="
        << arr.capacity() << ")";
        std::cout << std::endl;
    }

/******************************************************************************/
/*!
    \brief
    Prints all elements in the vector of type float.
        
    \param arr
    Reference to be printed.
*/
/******************************************************************************/
    template<>
    void Print (const cs170::vector<float> &arr)
    {
        for(unsigned i = 0; i < arr.size(); i++)
        {
            std::cout << std::setw(5) << std::setprecision(3) << float (arr[i])
            << "  ";
        }
        std::cout << "(size=" << arr.size() << ", capacity="
        << arr.capacity() << ")";
        std::cout << std::endl;
    }
}