/******************************************************************************/
/*! 
\file   cs170_vector.h
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 07
\date   08/7/2019 
\brief  Templated vector
*/ 
/******************************************************************************/
#include <iostream>
#include <iomanip>
#include <string>

namespace cs170
{
  template <typename T>
  class vector
  {
    T* content;
    size_t sz;
    size_t cap;

/******************************************************************************/
/*!   
  This is helper function that allocate more dynamic memory for the vector.
*/ 
/******************************************************************************/
    void grow()
    {
      if(cap)
      {
        cap *= 2;
        T *tmp = new T[cap];
        for(size_t i = 0; i < sz; ++i)
          tmp[i] = content[i];
        delete[] content;
        content = nullptr;
        content = tmp;
      }
      else
      {
        cap = 1;
        delete[] content;
        content = nullptr;
        content = new T[cap];
      }
    }
    
  public:
/******************************************************************************/
/*!   
  This function is a Default constructor.
    It constructs an object representing a zero value. 
*/ 
/******************************************************************************/
    vector() :content(nullptr),sz(0), cap(0){}

/******************************************************************************/
/*!   
  This function is a Copy constructor.
    Constructs an object by copying a value from another object.
 
  \param rhs      
  The object that will be copied
*/ 
/******************************************************************************/
    vector(const vector &rhs) : sz(rhs.sz), cap(rhs.cap)
    {
      content = new T[cap];
      for (size_t i = 0; i != rhs.sz; i++)
        *(content+i) = *(rhs.content+i);
    }

/******************************************************************************/
/*!   
  This function is a Destructor.
    It deallocate any memory allocated to prevent memory leak 
*/ 
/******************************************************************************/
    ~vector()
    { 
      delete[] content;
      content = nullptr;
    }

/******************************************************************************/
/*!   
  This function overloads the subscript operator [] that takes in a position,
    the position will looks through the vector to find what is in that space.
 
  \param position     
  position looks through the vector to find what is in that memory space.
*/ 
/******************************************************************************/
    T& operator[](const size_t &position) const
    {
      if (position < cap)
        return content[position];
      std::abort();
    }

/******************************************************************************/
/*!   
  This function overloads an assignment operator = 
    , it copies all values of an object into another object.
 
  \param rhs      
  The object that will be copied
*/ 
/******************************************************************************/
    vector& operator= (const vector &rhs)
    {
      cap = rhs.cap;
      sz = rhs.sz;
      T *tmp = new T[cap];
      for (size_t i = 0; i != sz; i++)
      {
        tmp[i] = rhs.content[i];
      }
      delete[] content;
      content = tmp;
      tmp = nullptr;
      return *this;
    }

/******************************************************************************/
/*!   
  This function clear the contents in the array.
*/ 
/******************************************************************************/
    void clear()
    {
      for (; sz != 0 ; --sz)
        content[sz] = 0;
      content[sz] = 0;
    }

/******************************************************************************/
/*!   
  This function check if the vector is empty, without modifying any value.
*/ 
/******************************************************************************/
    bool empty()
    {
      return (sz == 0);
    }

/******************************************************************************/
/*!   
  This function erase the value in a specified position of the vector

    \param position
    position represent the location to erase an value
*/ 
/******************************************************************************/
    void erase(const size_t &position)
    {
      if (sz > position)
      {
        for (size_t i = position ; i+1 < sz ; ++i)
          content[i] = content[i+1];
        content[sz] = 0;
        --sz;
      }
    }

/******************************************************************************/
/*!   
  This function insert a value into a specified position of the vector

  \param position
   A index that cannot be modified to represent the location to insert an value
  
  \param value
   A value that cannot be modified to be pushed into the vector
*/ 
/******************************************************************************/
    void insert(const size_t &position ,const T &value )
    {
      if (sz == cap)
        grow();  
      for (size_t i = sz; i != position ; --i)
        content[i] = content[i-1];
      content[position] = value;
      ++sz;
    }

/******************************************************************************/
/*!   
  This function puts an value at the end of the vector.
 
  \param value
    A value that cannot be modified to be pushed into the vector
*/ 
/******************************************************************************/
    void push_back(const T &value)
    {
      if (sz == cap)
        grow();  
      content[sz] = value;
      ++sz;
    } 

/******************************************************************************/
/*!   
  This function removes a value from the end of the vector.
*/ 
/******************************************************************************/
    void pop_back()
    {
      content[sz-1] = T{};
      --sz;
    }

/******************************************************************************/
/*!   
  This function is gets the private variable sz , without modifying it.
*/ 
/******************************************************************************/
    size_t size() const
    {
      return sz;
    }

/******************************************************************************/
/*!   
  This function is gets the private variable cap , without modifying it.
*/ 
/******************************************************************************/
    size_t capacity() const
    {
      return cap;
    }

  };

/******************************************************************************/
/*!   
  A print function template that will print out a templated vector.
 
  \param vec      
  The vector to be printed out
*/ 
/******************************************************************************/
  template<typename T>
  void Print(const T& vec)
  {
    for (size_t i=0 ; i != vec.size() ; ++i)
      std::cout << vec[i] << "  ";
    std::cout << "(size=" << vec.size()
              << ", capacity=" << vec.capacity() 
              << ")" << std::endl;
  } 

/******************************************************************************/
/*!   
  An explicit template specialization of float for print template.
 
  \param vec      
  The vector to be printed out
*/ 
/******************************************************************************/
  template<>
  void Print(const vector<float> &vec)
  {
    for (size_t i=0 ; i != vec.size() ; ++i)
    {    
      std::cout << std::setw(5) 
                << std::setprecision(3) 
                << vec[i]
                << "  ";
    }
    std::cout << "(size=" << vec.size()
              << ", capacity=" << vec.capacity()
              << ")" << std::endl;
  }

/******************************************************************************/
/*!   
  An explicit template specialization of double for print template.
 
  \param vec      
  The vector to be printed out
*/ 
/******************************************************************************/
  template<>
  void Print(const vector<double> &vec)
  {
    for (size_t i=0 ; i != vec.size() ; ++i)
    {    
      std::cout << std::left
                << std::setw(10)
                << std::setprecision(5)
                << vec[i] << "  ";
    }
    std::cout << "(size=" << vec.size()
              << ", capacity=" << vec.capacity() 
              << ")" << std::endl;
  }

/******************************************************************************/
/*!   
  An explicit template specialization of unsigned char for print template.
 
  \param vec      
  The vector to be printed out
*/ 
/******************************************************************************/
  template<>
  void Print(const vector<unsigned char> &vec)
  {
    for (size_t i=0 ; i != vec.size() ; ++i)
      std::cout << static_cast<int>(vec[i]) << "  ";
    std::cout << "(size=" << vec.size()
              << ", capacity=" << vec.capacity() 
              << ")" << std::endl;
  }

}