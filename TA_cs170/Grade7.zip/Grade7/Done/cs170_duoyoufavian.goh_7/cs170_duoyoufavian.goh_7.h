/*****************************************************************************/
/*!
\file cs170_vector.h
\author Favian Goh
\par email: duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 07
\date 15/07/2019
\brief
  This file contains definition of the following class members & functions:
  
  vector()                                 - default constructor
  ~vector()                                - destructor
  capacity()                               - returns cap
  clear()                                  - clears data of object
  vector(const vector &temp)               - conversion constructor
  pop_back()                               - pop number from back of array
  push_back()                              - push number to back of array
  empty()                                  - check if array is empty
  erase()                                  - erase number from position
  insert()                                 - insert number at position
  size()                                   - returns length
  operator[]()                             - subscript operator overload []
  operator=()                              - assignment operator overload =
  print()                                  - prints out elements in array
                                             depending on parameters
                                             
*/
/*****************************************************************************/

#ifndef CS170_VECTOR_H
#define CS170_VECTOR_H

#include <iomanip> //setprecison

namespace cs170
{
  
template <typename T> class vector
{
  
  private:
      int cap;      //allocated size of the array
      int length;   //The number of elements in the array
      T *array;     //dynamically allocated array
      T *newArray;
      
  public:

/*****************************************************************************/
/*!
\brief
    Default Constructor
*/
/*****************************************************************************/

vector(): cap(0), length(0) //init cap and length to 0
{
    array = new T[cap]; //allocate memory for array
}

/*****************************************************************************/
/*!
\brief  
    Conversion Constructor
*/
/*****************************************************************************/

vector (const vector &temp): cap(temp.cap), length(temp.length)
{
  int a = 0;
  array = new T[cap]; //allocate memory for array
  
  while(a != length)
  {
      array[a] = temp.array[a]; //copy all elements from array to temp.array
      ++a;
  }
}

/*****************************************************************************/
/*!
\brief  
    Deconstructor
*/
/*****************************************************************************/

~vector()
{
    delete[] array; //delete allocated memory for array
}

int capacity() const
{
    return cap; 
}

void clear()
{
    length = 0;
}

/*****************************************************************************/
/*!
  \brief
    pop number from back of array
*/
/*****************************************************************************/

void pop_back()
{
    --length; //decrement length
}

/*****************************************************************************/
/*!
  \brief
    push value to back of array, increase the length/size 
    and capacity
  
  \param value
    number to be added
*/
/*****************************************************************************/
 
void push_back (T value)
{
    int a = 0;
    
    if (cap == 0)
    {
        ++cap;
        delete[] array; 
        array = new T[cap];
    }
    
    else if(length >= cap) //check if length is larger than array's capacity
    {
        cap *= 2;          //double size of capacity
        newArray = new T[cap]; //new memory for newArray
        
        while(a != length)
        {
          newArray[a] = array[a]; //copy from array to newArray
          ++a;
        }
        
        delete[] array; //delete array
        array = newArray; //array point to newArray
    }
    
    array[length] = value;
    ++length;
    
}

/*****************************************************************************/
/*!
  \brief
    check if array is empty
   
  \return 1
    returns 1 if it's true

  \return 0
    returns 0 if it's false  
*/
/*****************************************************************************/

bool empty ()
{
    if(length == 0) //check if length is zero
    {
        return 1; //one if true
    }
    
    return 0; //zero if false
}

/*****************************************************************************/
/*!
  \brief
    erase number from specific position
  
  \param position
    position of the index to be deleted
  
*/
/*****************************************************************************/

void erase (size_t position)
{
    int a = 0, b = 0;
    newArray = new T[cap]; //new memory for newArray
    
    while(a != length)
    {
      if(a != static_cast<int> (position))
      {
          newArray[b] = array[a];
          ++b;
      }
      ++a;
    }
    
    delete[] array;
    array = newArray;
    --length;
}

/*****************************************************************************/
/*!
  \brief
    insert value at specific position
  
  \param position
    position of the index to be inserted
  
  \param value
    value to be inserted at specific position
*/
/*****************************************************************************/

void insert (int position, T value)
{
    int a = 0, b = 0;
    
    if(cap <= length) //checks if cap is smaller than length
        cap *= 2;     //double cap
      
    ++length;
    newArray = new T[cap]; //new memory for newArray
    
    while(a != length)
    {
      if(position != a)
      {
        newArray[a] = array[b];
        ++b;
      }
      else
        newArray[a] = value;
      a++;
    }
    
    delete[] array;
    array = newArray;

}

/*****************************************************************************/
/*!
  \brief
    overloaded [] operator
    
  \param a
    a is the index for the array
    
  \return
    returns the reference of that index of the array
*/
/*****************************************************************************/

T& operator[] (size_t a) const
{
    return array[a];
}

/*****************************************************************************/
/*!
  \brief
    overloaded = operator
    
  \param temp
    temp is the reference of assigned array
*/
/*****************************************************************************/

void operator= (const vector &temp)
{
    int a = 0;
    
    while(a != temp.length)
    {
        array[a] = temp.array[a];
        ++a;
    }
}

/*****************************************************************************/
/*!
  \brief
    returns length
*/
/*****************************************************************************/

unsigned size () const
{
    return length;
}
 
};

/*****************************************************************************/
/*!
  \brief
    prints all elements in the array, capacity and size/length
    
  \param temp
    the reference to the array to print
*/
/*****************************************************************************/

template <typename T>
void Print(const vector<T>& temp)
{
  
    for (unsigned i = 0; i < temp.size(); i++)
    {
      std::cout << temp[i] << "  "; //print array
    }
    
    //formatted output for size/length and capacity
    std::cout << "(size=" << temp.size()<< "," << " " << "capacity="
    << temp.capacity() << ")"; 
    
    std::cout << std::endl;
    
}

/*****************************************************************************/
/*!
  \brief
    prints all elements in the array of data type float, capacity and
    size/length
    
  \param temp
    the reference to the array to print
*/
/*****************************************************************************/

template <>
void Print (const cs170::vector<float>& temp)
{
    //print array
    for (unsigned i = 0; i < temp.size(); i++)
    {
      std::cout << std::setw(5) << std::setprecision(3)
      << float (temp[i]) <<"  ";
    }
    
    //formatted output for size/length and capacity
    std::cout << "(size=" << temp.size()<< "," << " " << "capacity="
    << temp.capacity() << ")";
    
    std::cout << std::endl; 
}

/*****************************************************************************/
/*!
  \brief
    prints all elements in the array of data type unsigned char, capacity and
    size/length
    
  \param temp
    the reference to the array to print
*/
/*****************************************************************************/

template <>
void Print(const cs170::vector<unsigned char>& temp)
{
    //print array
    for (unsigned i = 0; i < temp.size(); i++)
    {
      std::cout << +temp[i] << "  ";
    }
    
    //formatted output for size/length and capacity
    std::cout << "(size=" << temp.size() << "," << " " << "capacity="
    << temp.capacity() << ")";
    
    std::cout << std::endl;
}

/*****************************************************************************/
/*!
  \brief
    prints all elements in the array of data type double, capacity and
    size/length
    
  \param temp
    the reference to the array to print
*/
/*****************************************************************************/

template <>
void Print(const cs170::vector<double>& temp)
{
    //print array
    for (unsigned i = 0; i < temp.size(); i++)
    {
        std::cout << std::setw(9) << std::left << std::setprecision(5)
        << temp[i];
    }
    
    //formatted output for size/length and capacity
    std::cout << "(size=" << temp.size() << "," << " " << "capacity="
    << temp.capacity() << ")";
    
    std::cout << std::endl;
}

}

#endif