#pragma once

/*****************************************************************************/
/*!
\file vector.h

\author Chua Lip Ming
\par email:
   l.chua.a\@digipen.edu

\par DigiPen login:
   l.chua

\par Course:
   cs170

\par Lab #7

\date 14/07/2019

\brief
This file contains definitions of data members, member functions and external
functions for a vector class. 

Functions include:
vector()
vector(const T*, const size_t&)
vector(vector &)
~vector()
size()
capacity()
empty()
push_back()
pop_back()
insert()
operator= ()
operator[]()
push_front()
pop_front()
erase()
clear()
operator+=()
check_bounds()
grow()
operator+()
Print()

\par Hours spent on this assignment:
   5 hours

\par Specific portions that gave you the most trouble:
   Converting some parts of the vector class, and its member functions to
   template functions.
*/
/*****************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef VECTOR_H
#define VECTOR_H
////////////////////////////////////////////////////////////////////////////////
#include <iomanip> // std::setw, std::setprecision, std::left

namespace cs170
{
  template<typename T>
  class vector
  {
  public:
    /** @brief Default constructor that initialises a new vector object with a
           size and capacity of zero, whilst also creating a new T-type
           array.
    */
    vector()
    {
      vec_size = 0;

      cap = 0;

      store_array = new T[cap];
    }

    /** @brief Parameterized constructor that initialises a new vector object
           with the specified size, whilst also creating a new array with
           the same elements as that of the T-type array passed in.

      @param array - The pointer to the first element in an array, whose
               elements are to be copied into the new vector object.

      @param size - The reference to the specified size that the new vector
              object is to be of.
    */
    vector(const T *array, size_t size)
    {
      vec_size = 0;

      cap = 0;

      store_array = new T[cap];

      for (size_t i = 0; i < size; i++)
        push_back(array[i]);

    }

    /** @brief Copy constructor that performs a deep-copy of the input vector
           object's values into a newly-created vector object, with the same
           size, capacity and T-type array.

      @param copyVec - The reference to the vector to be copied from.
    */
    vector(const vector &copyVec)
    {
      vec_size = copyVec.vec_size;

      cap = copyVec.cap;

      store_array = new T[cap];

      for (size_t i = 0; i < cap - 1; i++)
        store_array[i] = copyVec.store_array[i];

    }

    /** @brief Destructor that deallocates memory used by the vector object's
           storage array of T-type values.
    */
    ~vector()
    {
      delete[] store_array;

      store_array = nullptr;
    }

    /** @brief Getter function for the vector object's size, which is the amount
           of elements stored in its T-type array.

      @return The vector's size (amount of elements stored in its T-type
          array).
    */
    size_t size() const
    {
      return vec_size;
    }

    /** @brief Getter function for the vector object's capacity, which is the
          size of its T-type array.

      @return The vector's capacity (size of its T-type array).
    */
    size_t capacity() const
    {
      return cap;
    }

    /** @brief Checks if the vector object is empty (has a size of zero).

      @return The state of the vector object being empty - true if its size is
          zero, and false if it is non-zero.
    */
    bool empty() const
    {
      return (vec_size == 0);
    }

    /** @brief Adds a new element of a specified value to the back of the vector
           object.

      @param val - The value to be added into the vector object.
    */
    void push_back(T val)
    {
      grow();
      store_array[vec_size] = val;
	  vec_size++;
    }

    /** @brief Removes an element from the back of the vector object.
    */
    void pop_back()
    {
      if(!empty())
        vec_size--;
    }

    /** @brief Inserts a new element of a specified value into a specified
           position in the vector object.

      @param pos - The position in the vector in which to insert the specified
             value.

      @param val - The value to be added into the vector object.
    */
    void insert(size_t pos, T val)
    {
      check_bounds(pos);

      vec_size++;

      if (vec_size > cap)
        grow();

      for (size_t i = cap - 1; i > pos; i--)
        store_array[i] = store_array[i - 1];

      store_array[pos] = val;
    }
    
    /** @brief Overloading of the "=" (assignment) operator, which performs a
           deep-copy of the right-hand side vector object's values into the
           vector object of the left-hand side, for copy assignment.

      @param rhs - A reference to the vector object on the right-hand side of
            the operator.

      @return A reference to the left-hand side vector object, after the
          deep-copy has been performed.
    */
    vector& operator= (const vector &rhs)
    {
      if (store_array == rhs.store_array)
        return *this;
      else
      {
        vec_size = rhs.vec_size;

        cap = rhs.cap;

        if (store_array != nullptr)
          delete[] store_array;

        store_array = new T[cap];

        for (size_t i = 0; i < vec_size; i++)
          store_array[i] = rhs.store_array[i];

        return *this;
      }
    }
    
    /** @brief Overloading of the "[]" (subscript) operator, which accesses the
           vector object's T-type array at the specified index.

      @param index - The index of the vector object's T-type array, to be
               accessed.

      @return A reference to the vector object's T-type array element.
    */
    T& operator[] (size_t index) const
    {
      check_bounds(index);

      return store_array[index];
    }

    /** @brief Adds a new element of a specified value to the front of the
           vector object.

      @param val - The value to be added into the vector object.
    */
    void push_front(T val)
    {
      if (vec_size + 1 > cap)
        grow();

      for (size_t i = vec_size; i > 0; i--)
        store_array[i] = store_array[i - 1];

      store_array[0] = val;

      vec_size++;
    }

    /** @brief Removes an element from the front of the vector object.
    */
    void pop_front()
    {
      for (size_t i = 0; i < vec_size - 1; i++)
        store_array[i] = store_array[i + 1];

      store_array[vec_size - 1] = 0;

      vec_size--;
    }

    /** @brief Erase the first discovered element of a specified value from
           the vector object.

      @param val - The value of the element to be removed from the vector
             object.
    */
    void erase(T val)
    {	  
	  if (!empty())
	  {
		for (size_t i = val; i < vec_size; ++i)
		  store_array[i] = store_array[i + 1];
		vec_size--;
	  }
    }

    /** @brief Clears the size and capacity of a vector.
    */
    void clear()
    {
      vec_size = 0;
    }

    /** @brief Overloading of the "+=" (addition-assignment) operator, which
           concatenates the elements of a vector into another, resulting in
           the vector on the left-hand side of the operator holding all of
           the elements held by both vectors previously.

      @param y - The vector on the right-hand side of the operator, which is
             to have its elements stored in the left-hand side vector.

      @return A reference to the left-hand side vector object, which is the
          result of the vector addition.
    */
    vector& operator+=(const vector &y)
    {
      for (size_t i = 0; i < y.size(); i++)
        push_back(y[i]);

      return *this;
    }

  private:
    /** @brief The dynamically allocated array for the vector that stores
           objects of type T.
    */
    T *store_array;

    /** @brief The number of elements in the array.
    */
    size_t vec_size;

    /** @brief The allocated size of the array also known as the capacity.
    */
    size_t cap;

    /** @brief Checks if the given index is out-of-bounds with regards to the
           vector object's size.

      @param index - The index value to be checked against the vector object's
               size.
    */
    void check_bounds(size_t index) const
    {
      // Do not check for (index < 0) because size_t is always unsigned.
      if (index >= vec_size )
      {
        std::cout
          << "Attempting to access index " << index << "."
          << " The vec_size of the array is " << vec_size
          << ". Aborting...\n";
        std::abort();
      }
    }

    /** @brief Doubles the vector object's T-type array size when necessary,
           along with the capacity of vector object.
    */
    void grow()
    {
      // Increase the capacity by doubling it, or setting it to 1 (if cap is 0)
      if (cap == 0)
        cap = 1;
      else if (this->vec_size >= this->cap)
        cap *= 2;

      // Create a new temporary array (for the assignment of values)
      T *new_store_array = new T[cap];

      // Copy the original array's elements over into the temp array
      for (size_t i = 0; i < vec_size; i++)
        new_store_array[i] = store_array[i];

      if (store_array != nullptr)
        delete[] store_array;

      store_array = new T[cap];

      // Copy the temp array's elements back into the original array 
      for (size_t i = 0; i < (cap - 1); i++)
        store_array[i] = new_store_array[i];

      delete[] new_store_array;
    }
  };
}                               // namespace cs170
#endif                          // VECTOR_H


/** @brief Overloading of the "+" (addition) operator, which concatenates the
       elements of two vectors, and returns a new vector which holds all of
       the elements of its operands.

  @param x - The vector on the left-hand side of the operator, which is to
         to have its elements be stored in the resulting vector.

  @param y - The vector on the right-hand side of the operator, which is
         to have its elements be stored in the resulting vector.

  @return A vector object, which is the result of the vector addition.
*/
template<typename T>
cs170::vector<T> operator+(const cs170::vector<T> &x, const cs170::vector<T> &y)
{
  cs170::vector<T> newVec = x;

  for (size_t i = 0; i < y.size(); i++)
    newVec.push_back(y[i]);

  return newVec;
}

/** @brief Prints out the elements contained within a vector, as well as it's
       size and capacity as well.

  @param array - The vector that is to have its contents and details printed
           out.
*/
template<typename T>
void Print(const cs170::vector<T> &array)
{
  for (size_t i = 0; i < array.size(); ++i)
    std::cout << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/** @brief Prints out the elements contained within a vector of floats, as well
       as it's size and capacity as well.

  @param array - The vector of floats, that is to have its contents and
           details printed out.
*/
template<>
void Print(const cs170::vector<float> &array)
{
  // Set the precision (significant digits) of the float
  std::cout << std::setprecision(3);

  for (size_t i = 0; i < array.size(); ++i)
    std::cout << std::setw(5) << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/** @brief Prints out the elements contained within a vector of doubles, as well
       as it's size and capacity as well.

  @param array - The vector of doubles, that is to have its contents and
           details printed out.
*/
template<>
void Print(const cs170::vector<double> &array)
{
  // Set the precision (significant digits) of the double
  std::cout << std::setprecision(5);

  for (unsigned i = 0; i < array.size(); ++i)
    std::cout << std::setw(7) << std::left << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/** @brief Prints out the elements contained within a vector of unsigned chars,
       as well as it's size and capacity as well.

  @param array - The vector of unsigned chars, that is to have its contents
           and details printed out.
*/
template<>
void Print(const cs170::vector<unsigned char> &array)
{
  for (size_t i = 0; i < array.size(); ++i)
    std::cout << static_cast<int>(array[i]) << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}