/******************************************************************************/
/*! 
  \file cs170_vector.h
  \author Lau Jan Wei, Joshua
  \par email: janweijoshua.lau\@digipen.edu
  \par DigiPen login: janweijoshua.lau
  \par Course: CS170
  \par Lab 07
  \date 15/07/2019
  \brief
This file contains the implementation of the following functions for Lab 07.
Functions include:
1) constructor
2) spacecount
3) constructor with params
4) copy constructor
5) copy assignment
6) destructor
7) clear
8) size
9) capacity
10) push_back
11) pop_back
12) empty
13) insert
14) subscript operator
15) erase
16) remove
17) check_bounds
18) grow
19) Print for type T
20) Print for type int
21) Print for type float
22) Print for type double
23) Print for type unsigned char

Hours spent on this Lab assignment: 12
Specific portions that gave you the most trouble:
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef vector_H
#define vector_H
////////////////////////////////////////////////////////////////////////////////

#include <iomanip>
#include <iostream>

namespace cs170
{
    template<typename T>
    class vector
    {
    public:
/******************************************************************************/
/*!
  \brief
    initialise vector
*/
/******************************************************************************/
      vector() : store_array(nullptr), vec_size(0), cap(0){}
/******************************************************************************/
/*!
  \brief
    count the amount of space to new
  
  \param size
    size is the limit
*/
/******************************************************************************/
      int spacecount(unsigned int size)
      {
        while(size > cap)
          cap = cap?cap*2:1;
        return cap;
      }
/******************************************************************************/
/*!
  \brief
    initialise vector with parameters
  
  \param ia
    Array pointer
    
  \param size
    size of vector
*/
/******************************************************************************/
      vector<T>(T* ia, unsigned int size) : vec_size(size), cap(0)
      {
        store_array = new T[spacecount(size)];
        for(unsigned int i = 0; i < size; ++i)
        {
          store_array[i] = ia[i];
        }
      }
/******************************************************************************/
/*!
  \brief
    Copies into a brand new vector
  
  \param rhs
    vector& rhs is the vector type on the right hand side
*/
/******************************************************************************/
      vector(const vector& rhs) : vector(rhs.store_array, rhs.vec_size){}
/******************************************************************************/
/*!
  \brief
    Creates a brand new copy and deletes the old one
  
  \param rhs
    vector& rhs for the vector type on the right hand side for copying
*/
/******************************************************************************/
      vector& operator=(const vector& rhs)
      {
        if(&store_array == &rhs.store_array)
          return *this;
        delete[] store_array;
        store_array = new T[rhs.cap];
        vec_size = rhs.vec_size;
        cap = rhs.cap;
        for(size_t i = 0; i < vec_size; i++)
        {
          store_array[i] = rhs.store_array[i];
        }
        return *this;
      }
/******************************************************************************/
/*!
  \brief
    destructs allocated memory in store_array
*/
/******************************************************************************/
      ~vector()
      {
        delete[] store_array;
        store_array = nullptr;
      }
/******************************************************************************/
/*!
  \brief
    clears the array
*/
/******************************************************************************/
      void clear()
      {
        vec_size = 0;
      }
/******************************************************************************/
/*!
  \brief
    gets the size of the vector
*/
/******************************************************************************/
      size_t size() const
      {
        return vec_size;
      }
/******************************************************************************/
/*!
  \brief
    gets the capacity of the vector
*/
/******************************************************************************/
      size_t capacity() const
      {
        return cap;
      }
/******************************************************************************/
/*!
  \brief
    Checks if there is enough capacity to store an additional element
    and inserts a value at the back if there is, otherwise expand the capacity
    by 2 times
  
  \param value
    int value to be inserted into the back of the vector
*/
/******************************************************************************/
      void push_back(T value)
      {
        if(vec_size == cap)
          grow();
        store_array[vec_size++] = value;
      }
/******************************************************************************/
/*!
  \brief
    decreases the size of the vector
*/
/******************************************************************************/
      void pop_back()
      {
        --vec_size;
      }
/******************************************************************************/
/*!
  \brief
    Checks if the vector is empty
*/
/******************************************************************************/
      bool empty()
      {
        if(vec_size)
          return false;
        return true;
      }
/******************************************************************************/
/*!
  \brief
    inserts a value into a specific position and push back all other
    elements after the specified position to make space for it
  
  \param position
    size_t position is the given position to be inserted into the vector
    
  \param value
    T value is the value to be inserted into the position
*/
/******************************************************************************/
      void insert(size_t position, T value)
      {
        check_bounds(position);
        if(vec_size == cap)
          grow();
        for(size_t vecs = vec_size; vecs > position; --vecs)
        {
            store_array[vecs] = store_array[vecs-1];
        }
        if(vec_size >= position)
          store_array[position] = value;
        else
          return;
        ++vec_size;
      }
/******************************************************************************/
/*!
  \brief
    the use of subscript operator to access specific compartments of
    the vector array pointed by store_array
  
  \param element
    size_t element is the element number that is supposed to be accessed
*/
/******************************************************************************/
      T& operator[](size_t element) const
    {
      check_bounds(element);
      return store_array[element];
    }
/******************************************************************************/
/*!
  \brief
    erase the specific position being set and covering up any gaps
  
  \param position
    size_t position is the given position to be erased in the vector
*/
/******************************************************************************/
      void erase(size_t position)
      {
        check_bounds(position);
        for(size_t pos = position; pos < vec_size; ++pos)
        {
          store_array[pos] = store_array[pos+1];
        }
        --vec_size;
      }
/******************************************************************************/
/*!
  \brief
    remove the specific position being set and covering up any gaps
  
  \param value
    value  to be removed in the vector
*/
/******************************************************************************/
      void remove(T value)
      {
        for(int i = 0; i < vec_size; ++i)
        {
          if(store_array[i] == value)
            erase(i);
        }
      }

    private:
      /* The dynamically allocated array. */
      T *store_array;
      
      /* The number of elements in the array. */
      size_t vec_size;
      
      /* The allocated size of the array also known as the capacity. */
      size_t cap;
/******************************************************************************/
/*!
  \brief
    Checks if the index given is outside the vector space (safeguard)
  
  \param index
    size_t index to check if the given position is out of bounds
*/
/******************************************************************************/
      void check_bounds(size_t index) const
      {
        // Do not check for (index < 0) because size_t is always unsigned.
        if (index >= vec_size)
        {
          std::cout
            << "Attempting to access index " << index << "."
            << " The vec_size of the array is " << vec_size
            << ". Aborting...\n";
          std::abort();
        }
      }
/******************************************************************************/
/*!
  \brief
    provides sufficient capacity for the vector
*/
/******************************************************************************/
      void grow()	
      {
        /*
           Double the dynamic array size when necessary
           The capacity of the array is doubled after this function.
           Also, but the "new" array has the same contents as before
           after  calling this private member function.
         */
        if(cap == 0)
        {
         ++cap;
         store_array = new T[cap]();
        }
         
        else
        {
          cap *= 2;
          T *new_array = new T[cap]();
          for(size_t i = 0; i < vec_size; ++i)
          {
            new_array[i] = store_array[i];
          }
          delete[] store_array;
          store_array = new_array;
        }
      }
    };
}                               // namespace cs170
#endif                          // vector_H
/******************************************************************************/
/*!
  \brief
    A print function template that will print out a templated vector.
  
  \param &array
    Array to be printed
*/
/******************************************************************************/
template<typename T>
void Print(const cs170::vector<T> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
      std::cout << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
  \brief
    A print function template that will print out a type int vector.
  
  \param &array
    Array to be printed
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<int> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
      std::setw(-3);
      std::cout << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
  \brief
    A print function template that will print out a type float vector.
  
  \param &array
    Array to be printed
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<float> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
      std::cout << std::setw(5) << std::setprecision(3) << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
  \brief
    A print function template that will print out a type double vector.
  
  \param &array
    Array to be printed
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<double> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
      std::cout << std::left <<std::setw(7) << std::setprecision(5) 
      << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
  \brief
    A print function template that will print out a type unsigned char vector.
  
  \param &array
    Array to be printed
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<unsigned char> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
      std::setprecision(3);
      std::setw(7);
      std::cout << static_cast<int>(array[i]) << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}