/******************************************************************************/
/*!
\file               cs170_vector.h
\author             Eu Shee Kei
\par email:         sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course:        CS170
\par Lab:           7
\date               15/07/2019
\brief
This file contains the implementation of the following function templates for
the vector assignment.
*/
/******************************************************************************/
#include <iomanip>     // setw, setprecision, left
#include <iostream>    // cout, endl

namespace cs170
{
  template <typename T>
  class vector
  {
  private:
    T *items;                       ///< array of items in vector
    size_t vec_size;                ///< size of vector
    size_t vec_capacity;            ///< capacity of vector

    /**************************************************************************/
    /*!
    \fn     void grow()
    \brief  doubles the size of the array if array size has reached maximum 
            capacity. if capacity is zero, create new array.
    \return void
    */
    /**************************************************************************/
    void grow()
    {
      // if there is no array, assign head to new array of capacity 1.
      if (vec_capacity == 0)
      {
        items = new T[++vec_capacity];
        return;
      }

      // create new array of double capacity
      T *new_items = new T[vec_capacity + vec_capacity];
      vec_capacity += vec_capacity;

      for (size_t count = 0; count < vec_size; ++count)
        new_items[count] = items[count];

      if (items)
      {
        delete[] items;
        items = new_items;
      }

      new_items = nullptr;
    }

  public:
    /**************************************************************************/
    /*!
    \fn     vector()
    \brief  default constructor
    */
    /**************************************************************************/
    vector()
      : items(nullptr)
      , vec_size(0)
      , vec_capacity(0)
    {
    }

    /**************************************************************************/
    /*!
    \fn     vector(const vector<T>& vec)
    \brief  copy constructor
    \param
    */
    /**************************************************************************/
    vector(const vector<T>& vec)
    {
      items = new T[vec.capacity()];
      for(size_t i = 0; i < vec.size(); ++i)
        items[i] = vec[i];
      vec_size = vec.size();
      vec_capacity = vec.capacity();
    }

    /**************************************************************************/
    /*!
    \fn     ~vector()
    \brief  destructor
    */
    /**************************************************************************/
    ~vector()
    {
      if (items != nullptr)
        delete[] items;
    }
    
    /**************************************************************************/
    /*!
    \fn     size_t size() const
    \brief  accessor for size of vector
    \return size_t
    */
    /**************************************************************************/
    size_t size() const
    {
      return vec_size;
    }

    /**************************************************************************/
    /*!
    \fn     size_t capacity() const
    \brief  accessor for capacity of vector
    \return size_t
    */
    /**************************************************************************/
    size_t capacity() const
    {
      return vec_capacity;
    }

    /**************************************************************************/
    /*!
    \fn     void push_back(const T& item)
    \brief  add an object to the beginning of the array
    \param  item    a reference to a read-only object
    \return void
    */
    /**************************************************************************/
    void push_back(const T& item)
    {
      if (vec_size == vec_capacity)
        grow();

      items[vec_size++] = item;
    }

    /**************************************************************************/
    /*!
    \fn     void pop_back()
    \brief  remove the last object in the array
    \return void
    */
    /**************************************************************************/
    void pop_back()
    {
      if (vec_size != 0)
        --vec_size;
    }

    /**************************************************************************/
    /*!
    \fn     bool empty()
    \brief  check is vector is empty
    \return bool    if size is zero, return true. else, return false
    */
    /**************************************************************************/
    bool empty()
    {
      return vec_size == 0;
    }

    /**************************************************************************/
    /*!
    \fn     void erase(size_t position)
    \brief  erase an object at a specified position
    \param  position    position at which item is to be removed
    \return void
    */
    /**************************************************************************/
    void erase(size_t position)
    {
      if (position > vec_size)
        return;

      for (size_t i = position; i < vec_size; ++i)
        items[i] = items[i + 1];

      --vec_size;
    }

    /**************************************************************************/
    /*!
    \fn     void insert(size_t position, const T& item)
    \brief  insert an object into a specified position in the vector
    \param  position    position for object to be place, starting from zero
    \param  item        a reference to an object to be inserted
    \return void
    */
    /**************************************************************************/
    void insert(size_t position, const T& item)
    {
      if (position < 0 || position > vec_size)
        return;

      if (vec_size == vec_capacity)
        grow();

      for (size_t i = vec_size; i > position; --i)
        items[i] = items[i - 1];

      items[position] = item;
      ++vec_size;
    }

    /**************************************************************************/
    /*!
    \fn     void clear()
    \brief  clear the vector.
    \return void
    */
    /**************************************************************************/
    void clear()
    {
      vec_size = 0;
    }

    /**************************************************************************/
    /*!
    \fn     template<typename T2> T& operator[](T2& position) const
    \brief  subscript operator to access vector items
    \param  position      a reference to a position
    \return T&            a reference to an object
    */
    /**************************************************************************/
    template<typename T2>
    T& operator[](T2& position) const
    {
      return items[position];
    }

    /**************************************************************************/
    /*!
    \fn     vector<T>& operator=(const vector<T>& rhs)
    \brief  copy assignment operator for a vector
    \param  rhs         a vector
    \return vector<T>   a reference to a vector
    */
    /**************************************************************************/
    vector<T>& operator=(const vector<T>& rhs)
    {
      if (this != &rhs)
      {
        if (items)
          delete items;
        items = new T[rhs.capacity()];
        for (size_t i = 0; i < rhs.size(); ++i)
          items[i] = rhs[i];
        vec_size = rhs.size();
        vec_capacity = rhs.capacity();
      }

      return *this;
    }
  };
  
  /****************************************************************************/
  /*!
  \fn     template<typename T> void Print(cs170::vector<T> vec)
  \brief  template for printing a vector
  \param  vec     a vector
  \return void
  */
  /****************************************************************************/
  template<typename T>
  void Print(cs170::vector<T> vec)
  {
    for (size_t i = 0; i < vec.size(); ++i)
      std::cout << vec[i] << "  ";
    std::cout << "(size="      << vec.size() 
          << ", capacity=" << vec.capacity()
          << ")"           << std::endl;
  }

  /****************************************************************************/
  /*!
  \fn     template<> void Print(cs170::vector<float> vec)
  \brief  specialised template for printing a vector of floats
  \param  vec     a vector of floats
  \return void
  */
  /****************************************************************************/
  template<>
  void Print(cs170::vector<float> vec)
  {
    for (size_t i = 0; i < vec.size(); ++i)
      std::cout << std::setw(5) << std::setprecision(3) << vec[i] << "  ";
    std::cout << "(size="      << vec.size() 
              << ", capacity=" << vec.capacity() 
              << ")"           << std::endl;
  }

  /****************************************************************************/
  /*!
  \fn     template<> void Print(cs170::vector<double> vec)
  \brief  specialised template for printing a vector of doubles
  \param  vec     a vector of doubles
  \return void
  */
  /****************************************************************************/
  template<>
  void Print(cs170::vector<double> vec)
  {
    for (size_t i = 0; i < vec.size(); ++i)
      std::cout << std::setw(9) << std::setprecision(5) << std::left << vec[i];
    std::cout << "(size="      << vec.size()
              << ", capacity=" << vec.capacity()
              << ")"           << std::endl;
  }

  /****************************************************************************/
  /*!
  \fn     template<> void Print(cs170::vector<unsigned char> vec)
  \brief  specialise template for printing a vector of unsigned chars
  \param  vec     a vector of unsigned chars
  \return void
  */
  /****************************************************************************/
  template<>
  void Print(cs170::vector<unsigned char> vec)
  {
    for (size_t i = 0; i < vec.size(); ++i)
      std::cout << static_cast<int>(vec[i])  << "  ";
    std::cout << "(size="      << vec.size()
              << ", capacity=" << vec.capacity()
              << ")"           << std::endl;
  }
}