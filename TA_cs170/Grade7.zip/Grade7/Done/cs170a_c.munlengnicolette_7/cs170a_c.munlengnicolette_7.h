/*************************************************************************/
/*!
\file cs170_vector.h
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: cs170
\par Lab #7
\date 13/07/2019
\brief
This file contains the template class of vectors. The vector class
is used to encapsulate a dynamic array of type values.
Functions include:
check_bounds
grow
vector constructor
vector copy constructor
vector assignment operator
vector destructor
size
capacity
push_back
push_front
pop_back
pop_front
insert
remove
[] Subscript
operator +
operator +=
print

Hours spent on this assignment: 6 hrs
Specific portions that gave you the most trouble: grow and insert
*/
/*************************************************************************/


///////////////////////////////////////////////////////////////////////////
#ifndef VECTOR_H
#define VECTOR_H
///////////////////////////////////////////////////////////////////////////

#include <iostream>			// std::cout
#include <iomanip>

namespace cs170
{
  template<typename T>
  class vector
  {
  public:
    /*********************************************************************/
    /*!
      \brief
        Default constructor for class vector to initialise members.
    */
    /*********************************************************************/
    vector() :
      vec_size(0),
      cap(0),
      store_array(new T[cap])
    {
    }
    
    /*********************************************************************/
    /*!
      \brief
        Copy constructor for vector.
      
      \param rhs
        The pointer of right hand side object of type vector.
    */
    /*********************************************************************/
    vector(const vector &rhs)
    {
      // Initialisation
      vec_size = rhs.vec_size;              // copy rhs vec_size
      cap = rhs.cap;                        // copy rhs cap
      store_array = new T[cap];             // create store_array based on cap
      // Deep copy store_array values
      for (size_t i = 0; i < vec_size; ++i)
        store_array[i] = rhs.store_array[i];
    }
    
    /*********************************************************************/
    /*!
      \brief
        Parameterized constructor for vector.
      
      \param rhs
        T type on the right-hand side.
      
      \param size
        Size of the vector.
    */
    /*********************************************************************/
    vector(const T *rhs, size_t size)
    {
      // Initialisation
      vec_size = 0;                 // Initialise vec_size to 0
      cap = 0;                      // Initialise cap to 0
      store_array = new T [cap];    // create store_array based on cap
      // Set elements rhs elements
      for (size_t i = 0; i < size; i++)
        push_back(rhs[i]);
    }
    
    /*********************************************************************/
    /*!
      \brief
        Operator = for vector.
      
      \param rhs
        The pointer of right hand side object of type vector.
    */
    /*********************************************************************/
    vector &operator=(const vector &rhs)
    {
      // Check if the store_array are the same
      if(store_array == rhs.store_array)
        return *this;                 // Return pointer to this
      else
      {
        vec_size = rhs.vec_size;
        cap = rhs.cap;
        
        if (store_array != nullptr)  // Check for empty store_array
          delete[] store_array;
        
        store_array = new T [cap];   // Set new cap
        
        // Deep copy rhs store_array values
        for (size_t i = 0; i < vec_size; i++)
          store_array[i] = rhs.store_array[i];
        
        return *this;           // Return pointer to this
      }
    }
    
    /*********************************************************************/
    /*!
      \brief
        Destructor for vector.
    */
    /*********************************************************************/
    ~vector()
    {
      delete[] store_array;         // Delete store_array
      store_array = nullptr;        // set store_array to nullpointer
    }
    
    /*********************************************************************/
    /*!
      \brief
        Gets the private member vec_size.
    */
    /*********************************************************************/
    size_t size() const
    {
      return vec_size;               // Return vector size
    }
    
    /*********************************************************************/
    /*!
      \brief
        Gets the private member cap.
    */
    /*********************************************************************/
    size_t capacity() const
    {
      return cap;                   // Return capacity
    }

    /*********************************************************************/
    /*!
      \brief
        Checks if store_array is empty.
    */
    /*********************************************************************/
    bool empty() const
    {
      return (vec_size == 0);       // Return true or false
    }
    
    /*********************************************************************/
    /*!
      \brief
        Clears the array, vector size and capacity.
    */
    /*********************************************************************/
    void clear()
    {
      vec_size = 0;                 // Set vector size to 0
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function puts an integer at the end of the vector.
      
      \param value
        The value to be added at the end of the vector.
    */
    /*********************************************************************/
    void push_back(T value)
    {
      // Check if added value will exceed current cap
      if (vec_size + 1 > cap)
        grow();                             // Resize store_array
      vec_size++;                           // Increase vec_size
      store_array[vec_size - 1] = value;    // Set last element to value
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function puts an integer at the front of the vector.
      
      \param value
        The value to be added at the front of the vector.
    */
    /*********************************************************************/
    void push_front(T value)
    {
      // Check if added value will exceed current cap
      if (vec_size + 1 > cap)
        grow();                             // Resize store_array
      
      // Shift all elements back by 1
      for (size_t i = vec_size; i > 0; i--)
        store_array[i] = store_array[i - 1];
      
      vec_size++;                // Increase vec_size
      store_array[0] = value;    // Set first element to value
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function removes a value from the end of the vector.
    */
    /*********************************************************************/
    void pop_back()
    {
      --vec_size;                  // Decrease vec_size
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function removes a value from the front of the vector.
    */
    /*********************************************************************/
    void pop_front()
    {
      --vec_size;                   // // Decrease vec_size
      // shift the values down the array
      for (size_t i = 0; i < vec_size; ++i)
        store_array[i] = store_array[i + 1];
      
      store_array[vec_size - 1] = static_cast<T>(0);
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function given an number and position, inserts the
        element into the correct position. The position count begins
        from zero. The index cannot be larger than current vector.
        
      \param index
        The index specifying the position the number is to be added.
        
      \param value
        The value to be added at the specified position.
    */
    /*********************************************************************/
    void insert(size_t index, T value)
    {
      check_bounds(index);                  // Check if index is out of bounds
      ++vec_size;
      // Check if vec_size exceed current cap
      if (vec_size > cap)
        grow();                             // Resize store_array
      
      // Find index position
      for (size_t i = cap - 1; i > index; i--)
        store_array[i] = store_array[i - 1];
      
      // Add value into index position
      store_array[index] = value;
    }
    
    void erase(size_t pos)
    {
      check_bounds(pos);           // Check if pos is out of bounds
      // Find and erase element at position
      for (size_t i = pos; i < vec_size; i++)
        store_array[i] = store_array[i + 1];
      
      --vec_size;                  // Decrease vec_size
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function overrides the [] subscript operator.
        
      \param index
        The index specifying the position to return the value in
        that specified position.
    */
    /*********************************************************************/
    T &operator[](size_t index) const
    {
      check_bounds(index);           // Check if index is out of bounds
      return store_array[index];     // return value at index position
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function overloads the operator +=.
      
      \param rhs
        The vector on the right-hand side of the operator.
    */
    /*********************************************************************/
    vector operator+=(const vector &rhs)
    {
      vector tmp(*this);            // Create a temp array copying this
      delete [] store_array;        // Delete this store_array
      vec_size += rhs.vec_size;     // Set vector size
      cap += rhs.cap;               // Set capacity

      store_array = new T[cap];     // Create a new store_array of T
      
      // Loop through to copy first array
      for (size_t i = 0; i < tmp.vec_size; ++i)
        store_array[i] = tmp.store_array[i];
      
      // Loop through to copy second array
      for (size_t i = 0; i < rhs.vec_size; ++i)
        store_array[tmp.vec_size + i] = rhs.store_array[i];
      
      return *this;                 // Return pointer to this
    }
    
    /*********************************************************************/
    /*!
      \brief
        This function removes the element at the given specific position.
        
      \param value
        The value to be removed in the array.
    */
    /*********************************************************************/
    void remove(T value)
    {
      // Loop through array to find value
      for (size_t i = 0; i < vec_size - 1; ++i)
      {
        // found value
        if (store_array[i] == value)
          store_array[i] = store_array[i + 1];
      }
      
      store_array[vec_size - 1] = 0;
      --vec_size;                   // Decrease vector size
    }
    
  private:
    /******************** Private members variables **********************/
		/* The number of elements in the array. */
		size_t vec_size;
		
		/* The allocated size of the array also known as the capacity. */
		size_t cap;
    
    /* The dynamically allocated array. */
		T *store_array;
    /********************* Private member functions **********************/

		/*********************************************************************/
    /*!
      \brief
        Checks to see if the index is smaller than vector size
        
      \param index
        The index of the array.
    */
    /*********************************************************************/
		void check_bounds(size_t index) const
    {
      // Do not check for (index < 0) because size_t is always unsigned.
      if (index >= vec_size)
      {
        std::cout
          << "Attmpting to access index " << index << "."
          << " The vec_size of the array is " << vec_size
          << ". Aborting...\n";
        std::abort();
      }
    }

    /*********************************************************************/
    /*!
      \brief
        Double the dynamic array size when necessary
        The capacity of the array is doubled after this function.
        Also, but the "new" array has the same contents as before,
        after calling this private member function.
    */
    /*********************************************************************/
		void grow()
    {
      // Check for empty vector
      if(cap == 0)
        cap = 1;
      else
        cap *= 2;                          // double the capacity size
      
      // Create a new temporary array (for the assignment of values)
      T *tmp_array = new T [cap];

      // Copy the original array's elements over into the temp array
      for (size_t i = 0; i < vec_size; i++)
        tmp_array[i] = store_array[i];

      if(store_array != nullptr)           // clear store_array
        delete[] store_array;
        
      store_array = new T[cap];            // assign new cap

      // copy tmp array back into store_array
      for (size_t i = 0; i < vec_size; ++i)
        store_array[i] = tmp_array[i];
      
      delete[] tmp_array;
    }
  };
}                               // namespace cs170
#endif                          // VECTOR_H


/*********************************************************************/
/*!
  \brief
    This function overloads the operator +.
  
  \param x
    The vector on the left-hand side of the operator.
    
  \param y
    The vector on the right-hand side of the operator.
*/
/*********************************************************************/
template <typename T>
cs170::vector<T> operator+(const cs170::vector<T> &x,
                           const cs170::vector<T> &y)
{
  cs170::vector<T> result(x);      // Create a vector copying vector x
  result += y;                     // add new vector and vector y
  
  return result;                   // return result
}

/*********************************************************************/
/*!
  \brief
    A print function template that will print out a templated vector.
  
  \param array
    The array to be printed.
*/
/*********************************************************************/
// 
template<typename T>
void Print(const cs170::vector<T> &array)
{
  for (unsigned i = 0; i < array.size(); ++i)
    std::cout << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/*********************************************************************/
/*!
  \brief
    A specialised print function template that will print out a 
    float templated vector.
  
  \param array
    The float array to be printed.
*/
/*********************************************************************/
template <>
void Print<float>(const cs170::vector<float> &array)
{
  // Set the precision
  std::cout << std::setprecision(3);

  for (unsigned i = 0; i < array.size(); ++i)
    std::cout << std::setw(5) << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/*********************************************************************/
/*!
  \brief
    A specialised print function template that will print out a 
    double templated vector.
  
  \param array
    The double array to be printed.
*/
/*********************************************************************/
template <>
void Print<double>(const cs170::vector<double> &array)
{
  // Set the precision
  std::cout << std::setprecision(5);
  
  for (unsigned i = 0; i < array.size(); ++i)
    std::cout << std::left << std::setw(7) << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/*********************************************************************/
/*!
  \brief
    A specialised print function template that will print out a 
    unsigned char templated vector.
  
  \param array
    The unsigned char array to be printed.
*/
/*********************************************************************/
template <>
void Print<unsigned char>(const cs170::vector<unsigned char> &array)
{
  for (unsigned i = 0; i < array.size(); ++i)
    std::cout << static_cast<unsigned>(array[i]) << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}