/******************************************************************************/ 
/*! 
 \file   cs170_vector.h
 \author Chong Huey Jia
 \par    email: hueyjia.chong\@digipen.edu 
 \par    DigiPen login: hueyjia.chong 
 \par    Course: CS170L 
 \par    Lab 07
 \date   8/07/2011 
 \brief     This is a vector class
*/ 
/******************************************************************************/


#include<iomanip>
#include<iostream>

namespace cs170
{
	template<typename T>
	class vector
	{
	public:
/******************************************************************************/ 
/*! 
	\fn vector()

	\brief 
		This function is a default constructor to create an array
*/
/******************************************************************************/	
		vector():
				store_array{nullptr},
				vec_size{0},
				cap{0}
		{}
/******************************************************************************/ 
/*! 
	\fn vector(const vector& rhs)

	\brief 
		This function is a copy constructor 
		it copies over everything that is being created by doing a deep copy
*/
/******************************************************************************/			
		vector(const vector& rhs):
				store_array{new T[rhs.cap]},
				vec_size{rhs.vec_size},
				cap{rhs.cap}
		{
			for(size_t i = 0; i < cap; ++i)
			{
				store_array[i] = rhs.store_array[i];
			}
		}
/******************************************************************************/ 
/*! 
	\fn vector& operator=(const vector& rhs)

	\brief 
		This function is a conversion constructor 
		by creating a temp array
		storing the things in the rhs by doing a deep copy
		deleting the new array and making the array equal to temp
	
	\return the all the things in vector
*/
/******************************************************************************/		
		vector& operator=(const vector& rhs)
		{
			T* temp = new T[rhs.cap];
			
			for(size_t i = 0; i < rhs.cap; ++i)
			{
				temp[i] = rhs.store_array[i];
			}
			
			delete[] store_array;
			store_array = temp;
			
			vec_size = rhs.vec_size;
			cap = rhs.cap;
			
			return *this;
		}
/******************************************************************************/ 
/*! 
	\fn ~vector()

	\brief 
		This function is to destroy the allocated memory
*/
/******************************************************************************/	
		~vector()
		{
			delete[] store_array;
			store_array = nullptr;
		}
/******************************************************************************/ 
/*! 
	\fn size_t size() const

	\brief 
		This function is to check the value of vec_size
		
	\return the number of vec_size
*/
/******************************************************************************/		
		size_t size() const
		{
			return vec_size;
		}
/******************************************************************************/ 
/*! 
	\fn size_t capacity() const

	\brief 
		This function is to check the value of cap
		
	\return the number of cap
*/
/******************************************************************************/			
		size_t capacity() const
		{
			return cap;
		}
/******************************************************************************/ 
/*! 
	\fn bool empty()

	\brief 
		This function is to check if vec_size is 0
		
	\return either true if vec_size is equal 0
*/
/******************************************************************************/		
		bool empty()
		{
			return (vec_size == 0);
		}
/******************************************************************************/ 
/*! 
	\fn void push_back(T value)

	\brief 
		This function is to check if cap is equal to 0, or if the size is equal 
		to cap, cap will need to grow double
		it store the value in the array and the vec_size will increase by one.
*/
/******************************************************************************/			
		void push_back(T value)
		{
			if((cap == 0) || (size() == capacity()))
			{
				grow();
			}
			
			store_array[vec_size] = value;
			vec_size += 1;
		}
/******************************************************************************/ 
/*! 
	\fn void pop_back()

	\brief 
		This function is to remove the last value in the array by reducing the
		vec_size if it is not an empty array
*/
/******************************************************************************/		
		void pop_back()
		{
			if(empty())
			{
				return;
			}
			
			vec_size -= 1;
		}
/******************************************************************************/ 
/*! 
	\fn void erase(size_t position)

	\brief 
		This function is to remove the value at the position.
		if the array is not empty, the value after the position will all be 
		shift to remove the value at position.
		vec_size will reduce by 1.
*/
/******************************************************************************/	
		
		void erase(size_t position)
		{
			check_bounds(position);
			
			for(size_t i = position; i < vec_size; ++i)
			{
				store_array[i] = store_array[i + 1];
			}
			
			vec_size -= 1;
		}
/******************************************************************************/ 
/*! 
	\fn void insert(size_t position, T value)

	\brief 
		This function is to insert a value at the position.
		if vec_size is lesser than cap, it will increase by one.
		if vec_size is equal to cap, cap will need to grow double.
		from the value at position to the value at vec_size, it will all be 
		shifted to make space for the value to be inserted at the position.
*/
/******************************************************************************/	
		
		void insert(size_t position, T value)
		{
			check_bounds(position);
			
			if(vec_size < cap)
			{
				vec_size += 1;
			}
			
			else
			{
				grow();
				vec_size += 1;
			}
			
			for(size_t i = vec_size; i > position; --i)
			{
				store_array[i] = store_array[i - 1];
			}
			store_array[position] = value;
		}
/******************************************************************************/ 
/*! 
	\fn T& operator[](size_t position) const

	\brief 
		This function is to make an subscript operator.
		
	\return the value of position in the array
*/
/******************************************************************************/	
		
		T& operator[](size_t position) const
		{
			check_bounds(position);
			return store_array[position];
		}
/******************************************************************************/ 
/*! 
	\fn void clear()

	\brief 
		This function is to clear all the value in the array
*/
/******************************************************************************/		
		void clear()
		{
			for(size_t i = 0; i < vec_size; --i)
			{
				store_array[i] = 0;
			}
			
			vec_size = 0;
		}
		
	private:
		T *store_array;
		
		size_t vec_size;
		
		size_t cap;
/******************************************************************************/ 
/*! 
	\fn void check_bounds(size_t index) const

	\brief 
		This function is to make sure the index is not more than the size of the 
		array.
*/
/******************************************************************************/		
		void check_bounds(size_t index) const
		{
			if (index >= vec_size)
			{
				std::cout
					<< "Attempting to access index " << index << "."
					<< " The vec_size of the array is " << vec_size
					<< ". Aborting...\n";
				std::abort();
			}
		}
/******************************************************************************/ 
/*! 
	\fn void grow()

	\brief 
		This function is to increase the cap by 2 times.
		if the cap is 0, the cap will be increase by 1.
		creating a new array to store the values in the old array, with the new
		amount of cap
		deleting the old array, and letting the old array equal to temp.
*/
/******************************************************************************/		
		void grow()
		{
			cap = cap * 2;
			
			if(cap == 0)
			{
				cap += 1;
			}
			
			T* temp = new T[cap];
			for(size_t i = 0; i < vec_size; ++i)
			 {
				 temp[i] = store_array[i];
			 }
			 delete[] store_array;
			 
			 store_array = temp;
		}
	};
}

template<typename T>
void Print(const cs170::vector<T> &array)
{
	for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}

template<>
void Print(const cs170::vector<unsigned char> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << +array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}

template<>
void Print(const cs170::vector<float> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << std::setw(5) << std::setprecision(3) << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
template<>
void Print(const cs170::vector<double> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << std::setprecision(5) << std::setw(7) << std::left << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}