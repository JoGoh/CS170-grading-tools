/******************************************************************************/ 
/*!
\file cs170_vector.h
\author Samuel Chee
\par email: chee.k\@digipen.edu
\par DigiPen login: chee.k 
\par Course: CS170 
\par Lab #8
\date 26/02/2019<br>
\brief
This file contains the implementation of the following functions 
for the vector template assignment.
Functions include:
Vector();<br>
Vector(const Vector & rhs);<br>
Vector(T lhs[], int size);<br>
void clear();<br>
Vector& operator=(const Vector& rhs);<br>
~vector();<br>
size_t size()const;<br>
size_t capacity()const;<br>
void push_back(T const value);<br>
void pop_back();<br>
bool empty();<br>
void insert(T const value,size_t pos );<br>
int& operator[](const size_t rhs)const;<br>
Vector& operator+=(const Vector& rhs);<br>
int allocations() const;<br>
void check_bounds(size_t index) const;<br>
void grow();<br>
CS170::Vector<T> operator+(const CS170::Vector<T> &x, const CS170::Vector<T> &y);<br>
void Print(const CS170::Vector<T> &array);<br>
void Print(const CS170::Vector<unsigned char> &array);<br>
void Print(const CS170::Vector<double> &array);<br>
void Print(const CS170::Vector<float> &array);<br>

Hours spent on this assignment: 6 hours<br>
Specific portions that gave you the most trouble: 
*/
/******************************************************************************/ 
#include <iomanip>
#include <iostream>
#include <string>
#include <cstdlib>              // atoi
namespace cs170
{
    template<typename T>
    class vector
    {
        
        /* The dynamically allocated array. */
        T *store_array;
        
        /* The number of elements in the array. */
        size_t vec_size;
        
        /* The allocated size of the array also known as the capacity. */
        size_t cap;
        

        
        
        //Private Functions
/******************************************************************************/
/*!
    \brief
        grow function dynamically enlarges an array as required, checking
        size against capacity and increasing as required and allocating once 
        per call.
    
    \return void

*/
/******************************************************************************/	
        /* Grows the array when necessary, by doubling its size when not empty.
           Sizes of the array: 0, 1, 2, 4, 8, 16, ... . */
        void grow()
        {
            /*
           Double the dynamic array size when necessary
           The capacity of the array is doubled after this function.
           Also, but the "new" array has the same contents as before
           after  calling this private member function.
         */
            //Check if need to grow
            if(cap<vec_size)
            {
                while(cap<vec_size)
                {
                    if(cap!=0)
                        cap*=2;
                    else
                        cap++;
                }
            }
            else
            {
                return;
            }
            T* temp=store_array;
            store_array= new T[cap];

            if(vec_size>1&& temp!=nullptr)
            {
                    //Assigning old values
                    for(size_t i=0;i<vec_size-1;i++)
                    {
                        store_array[i]=temp[i];
                    }
            }
            
            //Deleting old array
            delete []temp;
        }
    
/******************************************************************************/
/*!
    \brief
        check_bounds function checks current size to given size
        and determines if it is out of bounds.
        
    \param index
        Given size to check

    \return void	
*/
/******************************************************************************/	
        /* Makes sure the subscript or position is valid.
           Aborts the program if it is invalid. */
        void check_bounds(size_t index) const
        {
            // Do not check for (index < 0) because size_t is always unsigned.
            if (index >= vec_size)
            {
                std::cout
                    << "Attempting to access index " << index << "."
                    << " The vec_size of the array is " << vec_size
                    << ". Aborting...\n";
                std::abort();
            }
        }
        
        
    public:
    //Default Constructor
/******************************************************************************/
/*!
    \brief
        Constructs a Vector of template type representing a zero value
*/
/******************************************************************************/	
        vector()
        {
        store_array=nullptr;
        vec_size=0;
        cap=0;
        }

/******************************************************************************/
/*!
    \brief
        Takes in a Vector and copies it to construct a Vector of templated type

    \param rhs
        Vector to be used as reference.
*/
/******************************************************************************/			
        //Copy Constructor
        vector(const vector& rhs)
        {
        vec_size= rhs.vec_size;//Copies vector size
        cap= rhs.cap;//Copies capacity
        store_array= new T[cap];//Allocate memory
        for (unsigned int count=0;count<vec_size;count++)
            {
                //Copy array element values
                store_array[count]=rhs.store_array[count];
            }
        }

/******************************************************************************/
/*!
    \brief
        Takes in an array of templated typede
        and an integer size and constructs a vector

    \param lhs
        Array of values to be used to initialise the stored array
        
    \param size
        The size of the array passed in, used to initialise vector size
*/
/******************************************************************************/			
        //Constructor taking in an array of size integers
        vector(T lhs[], size_t size)
        {

            vec_size = size;//Initialise size
            store_array=nullptr;//Set pointer to null
            cap=0;//Set capacity to 0
            grow();//Grow capacity and allocate array
            for(size_t count =0; count<size;count++)
            {
                //Initialise array 
                store_array[count]=lhs[count];
            }
        }
/******************************************************************************/
/*!
    \brief
        Operator overload to assign values from referenced object to 
        target object.

    \param rhs
        Referenced object to have its values assigned
        
    \return Vector&
        Reference to object.
        
*/
/******************************************************************************/					
        //Assignment Operator Overload
        vector& operator=(const vector& rhs)
        {
        vec_size= rhs.vec_size;
        cap= rhs.cap;
        T* temp= new T[cap];//Allocate memory based on templated type
        for (unsigned int count=0;count<vec_size;count++)
            {
                //Copy element values
                temp[count]=rhs.store_array[count];
            }
        if(store_array!=nullptr)//Guard against nullptr
            delete [] store_array;
        store_array=temp;
        return *this;
        }

/******************************************************************************/
/*!
    \brief
        Function clears all data of the vector

*/
/******************************************************************************/			
        void clear()
        {
            vec_size=0;
        }
        /******************************************************************************/
/*!
    \brief
        Destroys object and deallocates memory.
*/
/******************************************************************************/		
        //Destructor
        ~vector()
        {
            
        if(store_array!=nullptr)
            delete [] store_array;

        }
/******************************************************************************/
/*!
    \brief
        Function returns the current size of vector
*/
/******************************************************************************/				
        //Function to return size
        size_t size()const
        {
            return vec_size;
        }
/******************************************************************************/
/*!
    \brief
        Function returns the capacity of vector
*/
/******************************************************************************/			
        //Function to return capacity
        size_t capacity()const
        {
            return cap;
        }
/******************************************************************************/
/*!
    \brief
        push_back function puts an integer at the end of the vector

    \param value
        value of templated type to be placed at end of vector
        
    \return void

        
*/
/******************************************************************************/	
        //Function to add an integer to back of vector
        void push_back(T const value)
        {
        vec_size++;
        grow();
        store_array[vec_size-1]=value;
        }
        
        void push_front(T const value)
        {
            vec_size++;//Increase size
            grow();//Check if capacity is enough
            
            for(unsigned int i =0; i<vec_size;i++)
                //Pushing all values in store_array by one
                store_array[vec_size-i-1]=store_array[vec_size-i-2];
                
            store_array[0]=value;//Assigning value to first position
            
        }
/******************************************************************************/
/*!
    \brief
        pop_back function removes an integer from the end of the vector
    
    \return void
        
*/
/******************************************************************************/
        //Function to remove an integer from back of vector
        void pop_back()
        {
        vec_size--;
        }
/******************************************************************************/
/*!
    \brief
        empty function returns true if the vector is empty
        
    \return bool
        
*/
/******************************************************************************/
        //Function to check if vector is empty
        bool empty()const
        {
        return !vec_size;
        }
/******************************************************************************/
/*!
    \brief
        insert function adds an integer at specified position in vector
    
    \param value
        value to be placed in vector
        
    \param pos
        position in vector 
        
    \return void

        
*/
/******************************************************************************/
        //Function to insert certain value at specified position in vector
        void insert(size_t pos,T const value)
        {
            
        //Check if out of bounds
        check_bounds(pos);
        /*if(pos==0)
        {
            push_front(value);
            return;
        }*/
        vec_size++;
        grow();
        for(unsigned int count=0;count<vec_size-pos;count++)
            //Shift all values after pos down by 1 position
            store_array[vec_size-count-1]=store_array[vec_size-count-2];
        //Assign value to pos
        store_array[pos]=value;
        }
/******************************************************************************/
/*!
    \brief
        erase function removes an integer from specified position in vector
    
    \param pos
        Position in vector to remove integer.
        
    \return void	
*/
/******************************************************************************/		
    void erase(size_t pos)
    {
        //Check if out of bounds
        check_bounds(pos);	
        for(size_t count=0;count<vec_size-pos;count++)
        {
            //Shift all values after pos up by 1
            store_array[pos+count]=store_array[pos+count+1];
        }
        vec_size--;
    }
/******************************************************************************/
/*!
    \brief
        operator overload for subscript operator

    \param rhs
        Specific element of position rhs
        
    \return int&
        Reference to specific element of templated type
        
*/
/******************************************************************************/			
        //Operator overload for subscript operator
        T& operator[](const size_t rhs)const
        {	
            check_bounds(rhs);
            return(store_array[rhs]);
        }
};
}
/******************************************************************************/
/*!
    \brief
        Print function to print out templated vector, depending on specialised
        types.

    \param array
        Reference to Vector of template type
        
    \return void
*/
/******************************************************************************/
// A print function template that will print out a templated Vector.
template<typename T>
void Print(const cs170::vector<T> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
    \brief
        Print function to print out vector of unsigned chars

    \param array
        Reference to Vector of unsigned chars
        
    \return void
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<unsigned char> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << static_cast<unsigned int>(array[i]) << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
    \brief
        Print function to print out vector of doubles

    \param array
        Reference to Vector of doubles
        
    \return void
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<double> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout<<std::left;
        std::cout << std::setprecision(5)<<std::setw(7)<<array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
    \brief
        Print function to print out vector of floats

    \param array
        Reference to Vector of floats
        
    \return void
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<float> &array)
{
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << std::setprecision(3)<<std::setw(5)<<array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
