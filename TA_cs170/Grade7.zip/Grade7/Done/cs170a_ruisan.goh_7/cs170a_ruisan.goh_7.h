/******************************************************************************/
/*! 
\file   cs170_vector.h 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 07
\date   15/07/2019 
\brief
     This is file contains the templated function definition in cs170_vector.h.
*/ 
/******************************************************************************/
#include <iostream>
#include <cstdlib> 
#include <iomanip>

namespace cs170
{
  template <typename T>
  class vector
  {
    T* storage;
    size_t vecsize = 0;
    size_t cap = 0;
    /**************************************************************************/
    /*! 
    \fn          void checkbounds(size_t index) const
    \brief       checks if the index is out of bounds
    \param       index
    \return      nothing
    */ 
    /**************************************************************************/
    void checkbounds(size_t index) const
    {
      if (index >= vecsize) std::abort();
    }
    /**************************************************************************/
    /*! 
    \fn          void grow()
    \brief       expands the array by 1 if empty, else double the original 
                 storage and copy all the previous data over
    \return      nothing
    */ 
    /**************************************************************************/
    void grow()
    {
      if (cap == 0) 
      { 
        cap = 1;
        storage = new T[cap];
      }
      else
      {
        cap *= 2;
         T *tempt = new T[cap];
        for (size_t count = 0; count < vecsize-1; count++)
        tempt[count] = storage[count];
        delete[] storage;
        storage = tempt;
      }
    }
    public:
      /************************************************************************/
      /*! 
      \fn          vector()
      \brief       default constructor
      \return      nothing
      */ 
      /************************************************************************/
      vector(): storage{ nullptr }, vecsize{ 0 }, cap{ 0 }
      {
      }
      /************************************************************************/
      /*! 
      \fn          vector(const vector& vec)
      \brief       copy constructor
      \return      nothing
      */ 
      /************************************************************************/
      vector(const vector& vec)
      {
        cap = vec.cap;
        vecsize = vec.vecsize;
        T*temp = new T[cap];
        for (size_t i = 0; i < vecsize; ++i) temp[i] = vec.storage[i];
        storage = temp;
      }
      /************************************************************************/
      /*! 
      \fn          ~vector()
      \brief       destructor
      \return      nothing
      */ 
      /************************************************************************/
      ~vector()
      {
        delete[] storage;
      }
      /************************************************************************/
      /*! 
      \fn          size_t size() const
      \brief       gets vecsize
      \return      vecsize
      */ 
      /************************************************************************/
      size_t size() const
      {
        return vecsize;
      }
      /************************************************************************/
      /*! 
      \fn          size_t capacity() const
      \brief       gets capacity
      \return      cap
      */ 
      /************************************************************************/
      size_t capacity() const
      {
        return cap;
      }
      /************************************************************************/
      /*! 
      \fn          bool empty()
      \brief       checks if vecsize == 0
      \return      true if empty, false if not
      */ 
      /************************************************************************/
      bool empty()
      {
        return !vecsize;
      }
      /************************************************************************/
      /*! 
      \fn          T& operator[](size_t i)
      \brief       returns the value os the number at position i in the array
      \param       i
      \return      storage[i]
      */ 
      /************************************************************************/
      T& operator[](size_t i)
      {
        checkbounds(i);
        return storage[i];
      }
      /************************************************************************/
      /*! 
      \fn          const T& operator[](size_t i) const
      \brief       returns the value os the number at position i in the array
      \param       i
      \return      storage[i]
      */ 
      /************************************************************************/
      const T& operator[](size_t i) const
      {
        checkbounds(i);
        return storage[i];
      }
      /************************************************************************/
      /*! 
      \fn          void push_back(T num)
      \brief       adds a number to the back of the array
      \param       num
      \return      nothing
      */ 
      /************************************************************************/
      void push_back(T num)
      {
        if (vecsize++ == cap) grow();
        storage[vecsize - 1] = num;
      }
      /************************************************************************/
      /*! 
      \fn          void pop_back()
      \brief       "removes" a number from the back of the array
      \return      nothing
      */ 
      /************************************************************************/
      void pop_back()
      {
        --vecsize;
      }
      /************************************************************************/
      /*! 
      \fn          void erase(size_t pos)
      \brief       "removes" a number at the specified position
      \param       pos
      \return      nothing
      */ 
      /************************************************************************/
      void erase(size_t pos)
      {
        checkbounds(pos);
        //remove the number at that pos by shifting the array down
        for (size_t i = pos; i < vecsize; ++i) storage[i] = storage[i + 1];
        vecsize--;
      }
      /************************************************************************/
      /*! 
      \fn          void insert(size_t pos, T num)
      \brief       inserts a number at the specified position
      \param       pos
      \param       num
      \return      nothing
      */ 
      /************************************************************************/
      void insert(size_t pos, T num)
      {
        if (vecsize++ == cap) grow();
        checkbounds(pos);
        //make space for the new number
        for (size_t i = vecsize - 1; i > pos; --i) storage[i] = storage[i - 1];
        storage[pos] = num;
      }
      /************************************************************************/
      /*! 
      \fn          vector& operator=(const vector& vec)
      \brief       equal operator
      \param       vec
      \return      vector
      */ 
      /************************************************************************/
      vector& operator=(const vector& vec)
      {
        cap = vec.cap;
        vecsize = vec.vecsize;
        T*temp = new T[cap];
        for (size_t i = 0; i < vecsize; ++i) temp[i] = vec.storage[i];
        delete[] storage;
        storage = temp;
        return *this;
      }
      /************************************************************************/
      /*! 
      \fn          void clear() 
      \brief       "clears" the vector
      \return      nothing
      */ 
      /************************************************************************/
      void clear() 
      {
        vecsize = 0;
      }
  };
}
/******************************************************************************/
/*! 
\fn          void Print(const cs170::vector<T>& vec)
\brief       prints all the vetors
\return      nothing
*/ 
/******************************************************************************/
template <typename T>
void Print(const cs170::vector<T>& vec)
{
  for (size_t i = 0; i < vec.size(); ++i) std::cout << vec[i] << "  ";
  std::cout << "(" << "size=" << vec.size() 
            << ", " << "capacity=" << vec.capacity() 
            << ")" << std::endl;
}
/******************************************************************************/
/*! 
\fn          void Print<float>(const cs170::vector<float>& vec)
\brief       prints all the vetors (specific to float)
\return      nothing
*/ 
/******************************************************************************/
template <>
void Print<float>(const cs170::vector<float>& vec)
{
  std::cout << std::setprecision(3);
  for (size_t i = 0; i < vec.size(); ++i) 
    std::cout << std::setw(5) << vec[i] << "  ";
  std::cout << "(" << "size=" << vec.size() 
            << ", " << "capacity=" 
            << vec.capacity() << ")" << std::endl;
}
/******************************************************************************/
/*! 
\fn          void Print<unsigned char>(const cs170::vector<unsigned char>& vec)
\brief       prints all the vetors (specific to unsigned char)
\return      nothing
*/ 
/******************************************************************************/
template <>
void Print<unsigned char>(const cs170::vector<unsigned char>& vec)
{
  for (size_t i = 0; i < vec.size(); ++i) 
    std::cout << static_cast<unsigned>(vec[i]) << "  ";
  std::cout << "(" << "size=" << vec.size() 
            << ", " << "capacity=" << vec.capacity() 
            << ")" << std::endl;
}
/******************************************************************************/
/*! 
\fn          void Print<double>(const cs170::vector<double>& vec)
\brief       prints all the vetors (specific to double)
\return      nothing
*/ 
/******************************************************************************/
template <>
void Print<double>(const cs170::vector<double>& vec)
{
  std::cout << std::setprecision(5);
  for (size_t i = 0; i < vec.size(); ++i) 
    std::cout << std::setw(8)<< std::left << vec[i] << " ";
  std::cout << "(" << "size=" << vec.size() 
            << ", " << "capacity=" 
            << vec.capacity() << ")" << std::endl;
}