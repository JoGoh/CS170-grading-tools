/*****************************************************************************/
/*! 
\file   cs170_vector.h 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 07
\date   15/07/2019
\brief     
This program contains the functionalities required to create a custom
vector class template.
*/ 
/*****************************************************************************/

///////////////////////////////////////////////////////////////////////////////
#ifndef CS170_VECTOR_H
#define CS170_VECTOR_H
///////////////////////////////////////////////////////////////////////////////

#include <iomanip>
#include <iostream>

namespace cs170
{
    template<typename T>
    class vector
    {
		    T *curr_vec;      // Pointer to the vector
		    size_t vec_size;  // Current size of the vector
		    size_t vec_cap;   // Size of the vector's capacity

/*****************************************************************************/
/*!

    \fn increase_vec_cap
 
    \brief
    This private member function will increase the vector's capacity size
    by a magnitude of 2 so that this function is not called every single
    time we need to expand the vector. 

*/ 
/*****************************************************************************/
    void increase_vec_cap()
		{
			if (vec_cap)
			{
				vec_cap*=2;  // Expand cap by twice the size
				T* new_vec = new T[vec_cap];  // Allocates memory for new vec
        
				for(unsigned int i = 0; i < vec_cap / 2; i++)
					new_vec[i] = curr_vec[i];  // Copies the old vec into new vec
        
				delete[] curr_vec;  // Delete the old vector
				curr_vec = new_vec; // Change the pointer
			}
			else
			{
				curr_vec = new T[1];  // cap size is 0, create new vec
				vec_cap = 1;  // set cap size to 1
			}
		}
    
    public:
      vector():
        vec_size{0},
        vec_cap{0}
      {
        curr_vec = nullptr;
      }


/*****************************************************************************/
/*!

      \brief
      This is a destructor that frees the vector
      
*/ 
/*****************************************************************************/
      ~vector()
      {
        delete[] curr_vec;
      }

/*****************************************************************************/
/*!

      \brief
      This is a copy constructor for the input vector
      
      \param rhs
		  Vector to be copied from
      
*/ 
/*****************************************************************************/
      vector(const vector<T> &rhs):vec_size{rhs.size()}, 
                                   vec_cap{rhs.vec_capacity()}
      {
        curr_vec = new T[rhs.vec_capacity()];
        
        // Loops through every single element in the vector and copies it
        for(unsigned int i = 0; i < rhs.vec_capacity(); i++) 
          curr_vec[i] = rhs.curr_vec[i];
      }

/*****************************************************************************/
/*!

      \brief
      This is a conversion constructor for the vector
      
      \param
		   input_vec - Pointer to the vector
       size - Size of the vector
      
*/ 
/*****************************************************************************/
      vector(const T* input_vec, const size_t size):vector()
      {
        // Loop through the vector
        for(unsigned int i = 0; i < size; i++)
          push_back(input_vec[i]);
      }

/*****************************************************************************/
/*!

      \brief
      This is the operator overload subscript "[]" for the vector
      
      \param
		   pos - position of the element in the vector
       
      \return
      Returns the value from the element
      
*/ 
/*****************************************************************************/
      T& operator[](const size_t pos) const
      {
        return curr_vec[pos];
      }

/*****************************************************************************/
/*!

      \brief
      This is the operator overload "=" assignment for the vector
      
      \param
		   rhs - the vector to be assigned from
       
*/ 
/*****************************************************************************/
      vector<T>& operator=(const vector<T> &rhs)
      {
        vec_size = rhs.size();  // Size of RHS vector
        vec_cap = rhs.vec_capacity();  // Cap of RHS vector
        T* new_vec = new T[rhs.vec_capacity()];  // New temporary vector
        
        for(unsigned int i = 0; i < rhs.vec_capacity(); i++)
          new_vec[i] = rhs.curr_vec[i];  // Copies the vector over
        
        delete[] curr_vec;  // Delete the old vector
        curr_vec = new_vec;  // Re-assign pointer
        
        return *this;  // Returns reference to the LHS vector
      }
      
/*****************************************************************************/
/*!

      \brief
      This is the operator overload "+=" assignment for the vector
      
      \param
		   rhs - the vector to be assigned from
       
*/ 
/*****************************************************************************/      
      vector<T>& operator+=(const vector<T> &rhs)
      {
        size_t total_size = vec_size + rhs.vec_size;
        
        while(total_size > vec_cap)
          increase_vec_cap();
        
        // Loop through the vector
        for(unsigned int i = vec_size, j = 0; i < total_size; i++)
        {
          curr_vec[i] = rhs.curr_vec[j];
          ++j;
        }

        vec_size = total_size;
        
        return *this;
      }

/*****************************************************************************/
/*!
      \brief
      Returns value of vec_size
      
      \return
      vec_size - Size of the vector
*/
/*****************************************************************************/
      size_t size() const
      {	
        return vec_size;
      }

/*****************************************************************************/
/*!
      \brief
      Returns value of vec_cap
      
      \return
      vec_size - Capacity of the vector
*/
/*****************************************************************************/
      size_t vec_capacity() const
      {
        return vec_cap;
      }

/*****************************************************************************/
/*!
      \brief
      Returns true or false depending if the vec_size is empty
      
      \return
      bool - true or false
*/
/*****************************************************************************/
      bool empty() const
      {
        if (vec_size)
          return false;
        return true;
      }

/*****************************************************************************/
/*!

      \fn push_back
   
      \brief
      This member function will add a new value to the back of the vector.
      
      \param
      value - value to be added

*/ 
/*****************************************************************************/
      void push_back(const T value)
      {
        if (vec_size >= vec_cap)
          increase_vec_cap();
          
        curr_vec[vec_size] = value;
        ++vec_size;
      }
      
/*****************************************************************************/
/*!

      \fn push_front
   
      \brief
      This member function will add a new value to the front of the vector.
      
      \param
      value - value to be added

*/ 
/*****************************************************************************/
      void push_front(const T value)
      {
        if (vec_size >= vec_cap)
          increase_vec_cap();
        
        // Loop through the vector
        for(unsigned int i = vec_size + 1; i > 0; i--)
          curr_vec[i] = curr_vec[i-1];
          
        curr_vec[0] = value;
        ++vec_size;
      }

/*****************************************************************************/
/*!

      \fn pop_back
   
      \brief
      Pops a number from the back of the vector.

*/ 
/*****************************************************************************/
      void pop_back()
      {
        if(!empty())
        {
          --vec_size;
        }
      }
      
/*****************************************************************************/
/*!

      \fn pop_front
   
      \brief
      Pops a number from the front of the vector.

*/ 
/*****************************************************************************/
      void pop_front()
      {	
        if(!empty())
        {
          // Loop through the vector
          for(unsigned int i = 0; i < vec_size; i++)
            curr_vec[i] = curr_vec[i+1];
            
          --vec_size;
        }
      }

/*****************************************************************************/
/*!

      \fn insert
   
      \brief
      This member function will insert a value at the specified position
      in the vector
      
      \param
      pos - element position of the vector
      value - value to be added at the position

*/ 
/*****************************************************************************/
      void insert(const int pos, const T value)
      {
        if(pos < 0)
          return;
        
        if (vec_size >= vec_cap)
          increase_vec_cap();
        
        for(int i = vec_size; i >= pos; i--)
          curr_vec[i] = curr_vec[i-1];
          
        curr_vec[pos] = value;
        ++vec_size;
      }

/*****************************************************************************/
/*!

      \fn erase
   
      \brief
      This member function will erase the value at the specified position
      in the vector
      
      \param
      pos - element position of the vector

*/ 
/*****************************************************************************/
      void erase(const size_t pos)
      {
        // Loop through the vector
        for(size_t i = pos; i < vec_size; i++)
          curr_vec[i] = curr_vec[i+1];
        --vec_size;
      }

/*****************************************************************************/
/*!

      \fn remove
   
      \brief
      This member function will remove the specified value from the vector
      
      \param
      value - value to be removed from the vector

*/ 
/*****************************************************************************/
      void remove(const T value)
      {	
      // Loop through the vector
        for (unsigned int i = 0;i < vec_size; i++)
          if(curr_vec[i] == value) // If a match is found
          {
            erase(i); // Erase it
            break;
          }
      }

/*****************************************************************************/
/*!

      \fn clear
   
      \brief
      This member function will reset the vec_size of the vector

*/ 
/*****************************************************************************/
      void clear()
      {
        vec_size = 0;
      }
    };
}

/*****************************************************************************/
/*!

\brief
This operator overload "+" will add two vectors, lhs and rhs by concatonating
their vectors together. 

*/ 
/*****************************************************************************/
template<typename T>
const cs170::vector<T> operator+(const cs170::vector<T> &lhs, 
                                 const cs170::vector<T> &rhs)
{
	cs170::vector<T> result(lhs); // create vector object 
	result += rhs;  // add the two vectors
  
	return result;  // return the added vector
}

/*****************************************************************************/
/*!

\brief
This template function will print the vector in the correct format.

\param
input_vec - vector to be printed

*/
/*****************************************************************************/
template<typename T>
void Print(const cs170::vector<T> &input_vec)
{
    for (unsigned int i = 0; i < input_vec.size(); ++i)
        std::cout << input_vec[i] << "  ";
    
    std::cout << "(size=" << input_vec.size() << ", " << "capacity=" 
    << input_vec.vec_capacity() << ")" << std::endl;
}

/*****************************************************************************/
/*!

\brief
This specialized template function will handle double vectors.

\param
input_vec - vector to be printed

*/
/*****************************************************************************/
template<>
void Print<double>(const cs170::vector<double> &input_vec)
{
    // Loop through and set the width & precision according to the output
    for (unsigned int i = 0; i < input_vec.size(); ++i)
    {
      std::cout << std::setw(7) << std::left << std::setprecision(5)
      << input_vec[i] << "  ";
    }
    
    std::cout << "(size=" << input_vec.size() << ", " << "capacity="
    << input_vec.vec_capacity() << ")" << std::endl;
}

/*****************************************************************************/
/*!

\brief
This specialized template function will handle float vectors.

\param
input_vec - vector to be printed

*/
/*****************************************************************************/
template<>
void Print<float>(const cs170::vector<float> &input_vec)
{
    // Loop through and set the width & precision according to the output
    for (unsigned int i = 0; i < input_vec.size(); ++i)
      std::cout << std::setw(5) << std::setprecision(3) << input_vec[i] << "  ";
      
    std::cout
        << "(size=" << input_vec.size() << ", " << "capacity=" 
        << input_vec.vec_capacity() << ")" << std::endl;
}

/*****************************************************************************/
/*!

\brief
This specialized template function will handle unsigned chars vectors.

\param
input_vec - vector to be printed

*/
/*****************************************************************************/
template<>
void Print<unsigned char>(const cs170::vector<unsigned char> &input_vec)
{
    // Loop through and cast the char to unsigned
    for (unsigned int i = 0; i < input_vec.size(); i++)
      std::cout << static_cast<unsigned>(input_vec[i]) << "  ";
    
    std::cout << "(" << "size=" << input_vec.size() << ", " << "capacity=" 
    << input_vec.vec_capacity() << ")" << std::endl;
}

#endif  // CS170_VECTOR_H