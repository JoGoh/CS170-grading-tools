/******************************************************************************/ 
/*! 
\file cs170_vector.h
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 07
\date 13/07/2019 
\brief This file contains the declaration and definititons of the following 
functions for CS170 Lab 7: Class Templates
\par Classes include:
<br> vector
\par Constructors/Destructors include:
<br>vector() default constructor
<br>~vector() default destructor
<br>vector(array, size) conversion constructor
<br>vector(vec) copy constructor
\par Overloaded operators include
<br>Subscript operator
<br>Equal operator
\par Functions include
<br>push_back
<br>pop_back
<br>empty
<br>erase
<br>insert
<br>clear
<br>size
<br>capacity
<br>front

\par Hours spent on this assignment: 5 hours
\par Specific portions that gave you the most trouble: Ensuring const is
	applied when neccessary
*/ 
/******************************************************************************/
#include <iostream> //cout
#include <iomanip> //setprecision, setw
namespace cs170
{
	template <typename T>
	class vector
	{
		//Vector head
		T* the_vector;
		//Size of current vector
		size_t vec_size;
		//Max capacity of current vector
		size_t cap;
		
		//Grows the vector to increase its max capacity
		void grow();
		
	public:
		//Default constructor
		vector();
		//Default destructor
		~vector();
		//Conversion constructor
		vector(const T* vec, const size_t size);
		//Copy constructor
		vector(const vector<T> &rhs);
		
		//Overloaded subscript operator
		T& operator[](int index) const;
		//Overloaded equal operator
		void operator=(const vector& rhs);
		
		//Pushes value to back of vector
		void push_back(const T& value);
		//Removes value at back of vector
		void pop_back();
		//Checks if vector is empty
		bool empty() const;
		//Erases item at given position
		void erase(const size_t& pos);
		//Inserts a value into given position
		void insert(const size_t& index, const T& value);
		//Empties the vector, does not change capacity
		void clear();
		//Gets size of 
		size_t size() const;
		//Gets capacity of vector
		size_t capacity() const;
		//Gets the vector itself
		T* front() const;
	};
}

namespace cs170
{
/******************************************************************************/
/*!
	\brief
		Function to grow vector into bigger capacity. If cap ==0, grow to 1,
		else grow by increasing its size by a multiple of 2
*/
/******************************************************************************/
template <typename T>
void vector<T>::grow()
{
	if (cap == 0)
	{
		cap = 1;
		delete[] the_vector;
		the_vector = new T[cap];
	}
	else
	{
		cap *= 2;
		T* temp = new T[cap];
		for (unsigned i = 0; i < vec_size; ++i)
			temp[i] = the_vector[i];
		delete[] the_vector;
		the_vector = temp;
	}
}
/******************************************************************************/
/*!
	\brief
		Default constructor of vector. Creates an empty vector
*/
/******************************************************************************/
template <typename T>
vector<T>::vector()
	:the_vector{nullptr}, vec_size{0}, cap{0}
{
}
/******************************************************************************/
/*!
	\brief
		Default destructor of vector. Deletes all stored memory and resets
		vec_size and cap
*/
/******************************************************************************/
template <typename T>
vector<T>::~vector()
{
	vec_size = 0;
	cap = 0;
	delete[] the_vector;
}
/******************************************************************************/
/*!
	\brief
		Conversion constructor, taking in a T* and size to create a vector
		
	\param vec
		The new values to construct a vector with
		
	\param size
		The size of the new vector
*/
/******************************************************************************/
template <typename T>
vector<T>::vector(const T* vec, const size_t size)
	:the_vector{nullptr}, vec_size{size}, cap{0}
{
	the_vector = new T[0];
	while (cap < vec_size)
		grow();
	
	for (size_t i = 0; i < vec_size; ++i)
	{
		the_vector[i] = vec[i];
	}
}
/******************************************************************************/
/*!
	\brief
		Copy constructor for vector
		
	\param rhs
		The other vector to copy into this vector
*/
/******************************************************************************/
template <typename T>
vector<T>::vector(const vector<T> &rhs)
	:the_vector{new T[rhs.cap]}, vec_size{rhs.vec_size}, cap{rhs.cap}
{
	for (size_t i = 0; i < vec_size; ++i)
	{
		the_vector[i] = rhs.the_vector[i];
	}
}
/******************************************************************************/
/*!
	\brief
		Overloaded subscript operator. Gets back the reference position of the 
		item in the vector.
		
	\param index
		The index position to get back
*/
/******************************************************************************/
template <typename T>
	T& vector<T>::operator[](int index) const
	{
		return the_vector[index];
	}
/******************************************************************************/
/*!
	\brief
		Overloaded equal operator. Copies values over dynamically from the rhs
		vector
*/
/******************************************************************************/
template <typename T>
void vector<T>::operator=(const vector& rhs)
{
	vec_size = rhs.vec_size;
	cap = rhs.cap;
	T* tmp_array = new T[cap];
	for (unsigned i = 0; i < vec_size; ++i)
	{
		tmp_array[i] = rhs.the_vector[i];
	}
	delete[] the_vector;
	the_vector = tmp_array;
}
/******************************************************************************/
/*!
	\brief
		Pushes a new value to the back of the vector
		
	\param value
		The value to push into the vector
*/
/******************************************************************************/
template <typename T>
void vector<T>::push_back(const T& value)
{
	if (vec_size >= cap)
		grow();
	the_vector[vec_size] = value;
	++vec_size;
}
/******************************************************************************/
/*!
	\brief
		Pops the backmost value in the vector
*/
/******************************************************************************/
template <typename T>
void vector<T>::pop_back()
{
	--vec_size;
}
/******************************************************************************/
/*!
	\brief
		Checks if the vector is empty. Return true if yes, false if no.
*/
/******************************************************************************/
template <typename T>
bool vector<T>::empty() const
{
	return (vec_size == 0) || (the_vector == nullptr);
}
/******************************************************************************/
/*!
	\brief
		Erases a value at given position in the vector
		
	\param pos
		The position of the item to be erased
*/
/******************************************************************************/
template <typename T>
void vector<T>::erase (const size_t& pos)
{
	//Checks if out of bounds
	if (pos < vec_size)
	{
		//Shift values 1 to the left
		for (unsigned i = pos; i < vec_size - 1; ++i)
		{
			the_vector[i] = the_vector[i + 1];
		}
		--vec_size;
	}
}
/******************************************************************************/
/*!
	\brief
		Inserts a value at given position with given value
		
	\param pos
		The position to insert in the new value
	
	\param value
		The value to insert into the vector
*/
/******************************************************************************/
template <typename T>
void vector<T>::insert (const size_t& pos, const T& value)
{
	//Check if within bounds
	if (pos < vec_size)
	{
		//If vec_size is maxed, grow
		if (vec_size >= cap)
			grow();
		
		//Shift all values 1 to the right
		for (unsigned i = vec_size; i > pos; --i)
		{
			the_vector[i] = the_vector[i-1];
		}
		the_vector[pos] = value;
		++vec_size;
	}
}
/******************************************************************************/
/*!
	\brief
		Empties the vector. Does not reset capacity or array
*/
/******************************************************************************/
template <typename T>
void vector<T>::clear()
{
	vec_size = 0;
}

/******************************************************************************/
/*!
	\brief
		Getter function to get size of vector
*/
/******************************************************************************/
template <typename T>
size_t vector<T>::size() const
{
	return vec_size;
}
/******************************************************************************/
/*!
	\brief
		Getter function to get capacity of vector
*/
/******************************************************************************/
template <typename T>
size_t vector<T>::capacity() const
{
	return cap;
}
/******************************************************************************/
/*!
	\brief
		Getter function to get front of vector
*/
/******************************************************************************/
template <typename T>
T* vector<T>::front() const
{
	return the_vector;
}
}
/******************************************************************************/
/*!
	\brief
		Default template Print for vector. Prints out for all template values if
		no special cases
		
	\param vec
		Vector the print out
*/
/******************************************************************************/
template <typename T>
void Print(const cs170::vector<T> &vec)
{
	for (unsigned i = 0; i < vec.size(); ++i)
	{
		std::cout << vec[i] << "  ";
	}
		std::cout
				<< "("
				<< "size=" << vec.size()
				<< ", "
				<< "capacity=" << vec.capacity()
				<< ")"
				<< std::endl;
}
/******************************************************************************/
/*!
	\brief
		Unsigned char Print for vector. Prints out all unsigned chars as unsigned
		ints
		
	\param vec
		Vector the print out
*/
/******************************************************************************/
template <>
void Print(const cs170::vector<unsigned char> &vec)
{
	for (unsigned i = 0; i < vec.size(); ++i)
	{
		std::cout << static_cast<unsigned int>(vec[i]) << "  ";
	}
	std::cout
			<< "("
			<< "size=" << vec.size()
			<< ", "
			<< "capacity=" << vec.capacity()
			<< ")"
			<< std::endl;
}
/******************************************************************************/
/*!
	\brief
		Float Print for vector. Prints out float values in vector with width 5
		and precision 3
		
	\param vec
		Vector the print out
*/
/******************************************************************************/
template <>
void Print(const cs170::vector<float> &vec)
{
	for (unsigned i = 0; i < vec.size(); ++i)
	{
		std::cout << std::setw(5) << std::setprecision(3) 
			<< vec[i] << "  ";
	}
	std::cout
			<< "("
			<< "size=" << vec.size()
			<< ", "
			<< "capacity=" << vec.capacity()
			<< ")"
			<< std::endl;
}
/******************************************************************************/
/*!
	\brief
		Double Print for vector. Prints out double values in vector with width 7,
		precision 5 and pushed to left.
		
	\param vec
		Vector the print out
*/
/******************************************************************************/
template <>
void Print(const cs170::vector<double> &vec)
{
	for (unsigned i = 0; i < vec.size(); ++i)
	{
		std::cout << std::setw(7) << std::setprecision(5) << std::left
			<< vec[i] << "  ";
	}
	std::cout
			<< "("
			<< "size=" << vec.size()
			<< ", "
			<< "capacity=" << vec.capacity()
			<< ")"
			<< std::endl;
}