/*****************************************************************************/
/*!
\file cs170_vector.h
\author Benjamin Julian M. Larin
\par email:
b.larin\@digipen.edu
\par DigiPen login:
b.larin
\par Course:
CS170-A
\par Lab #7
\date 15/07/2019
\brief This file contains the implementation of the following functions for
the Lab #7.

\par Class Member Functions include:
  vector();
  vector(const vector& rhs);
  vector(const T* array, size_t size);
  ~vector();
  size();
  capacity();
  operator[]();
  operator=();
  push_back();
  pop_back(T num);
  empty();
  erase(size_t pos);
  insert(size_t pos, T num);

\par Additional funtions:
  multiple Print() for each type

\par Hours spent on this assignment:
  12 hrs

\par Specific portions that gave you the most trouble:
  Figuring out which functions do I need.
  Print()

*/
/*****************************************************************************/
//////////////////////////////////////////////////////////////////////////
#ifndef CS170_VECTOR_H
#define CS170_VECTOR_H
//////////////////////////////////////////////////////////////////////////
#include <iomanip>
#include <iostream>

namespace cs170
{
  template<typename T> 
  class vector
  {
  private:
    /* The dynamically allocated array. */
    T *store_array;

    /* The number of elements in the array. */
    size_t vec_size;

    /* The allocated size of the array also known as the capacity. */
    size_t cap;

    /* Grows the array when necessary, by doubling its size when not empty.
    Sizes of the array: 0, 1, 2, 4, 8, 16, ... . */
    void grow()
    {
      //check if capacity is 0 then make a new size 1 array
      if (this->cap == 0)
      {
        this->cap = 1;
        //destroy the original array
        delete[] this->store_array;
        this->store_array = new T[this->cap];
      }
      //check if vec_size is more than or equal the capacity size
      else if (this->vec_size >= this->cap)
      {
        //double the capacity
        cap *= 2;

        //make a temporary array with the same size as the original one so we 
        //can store the contents
        T *tmp_arr = new T[cap];

        for (size_t i = 0; i < this->vec_size; ++i)
          tmp_arr[i] = this->store_array[i];

        //destroy the original array
        delete[] this->store_array;

        //create an array with the new doubled capacity
        store_array = new T[cap];

        //transfer back the contents
        for (size_t i = 0; i < this->vec_size; ++i)
          store_array[i] = tmp_arr[i];

        //destroy temporary array
        delete[] tmp_arr;
      }
    }

  public:
/*****************************************************************************/
  /** Default Constructor
  */
/*****************************************************************************/
    vector() : store_array{ nullptr }, vec_size{ 0 }, cap{ 0 }
    {}

/*****************************************************************************/
  /** Copy Constructor
      @param rhs - object to copy
  */
/*****************************************************************************/
    vector(const vector& rhs) : vec_size{ rhs.vec_size }, cap{ rhs.cap }
    {
      this->store_array = new T[this->cap];
      for (size_t i = 0; i < this->vec_size; ++i)
        this->store_array[i] = rhs.store_array[i];
    }

/*****************************************************************************/
  /** Overloaded Constructor
      @param array - the other array
      @param size - the other array's size
  */
/*****************************************************************************/
    vector(const T* array, size_t size) : store_array{ nullptr }, 
      vec_size{ 0 }, cap{ 0 }
    {
      for (size_t i = 0; i < size; ++i)
        push_back(array[i]);
    }

/*****************************************************************************/
  /** Destructor
  */
/*****************************************************************************/
    ~vector()
    {
      if(this->store_array != nullptr)
        delete[] this->store_array;
      this->store_array = nullptr;
    }

    /* Returns the size of the vector
       @return vec_size
    */
    size_t size() const
    {
      return this->vec_size;
    }

    /* Returns the capacity of the vector
       @return cap
    */
    size_t capacity() const
    {
      return this->cap;
    }

 /*****************************************************************************/
  /* Overloaded '[]' operator. The subscript operator.
      @param index - size of the array
      @return the array with size index
  */
/*****************************************************************************/
    T& operator[](const size_t &index) const
    {
      return this->store_array[index];
    }
/*****************************************************************************/
  /* Overloaded '=' operator. Our assignment operator.
      @param rhs - reference to the operand at the right hand side
      @return this object
  */
/*****************************************************************************/
    vector& operator=(const vector &rhs)
    {
      //check if already the same then return
      if (this->store_array == rhs.store_array)
        return *this;

      //delete old data
      if (this->store_array != nullptr)
      {
        delete[] this->store_array;
        this->store_array = nullptr;
      }

      this->vec_size = rhs.size();
      this->cap = rhs.capacity();

      this->store_array = new T[this->cap];

      for (size_t i = 0; i < this->vec_size; ++i)
        this->store_array[i] = rhs.store_array[i];

      return *this;
    }
/*****************************************************************************/
  /* Grows the array then adds a new number at the end.
      @param num - the number to add in the array
  */
/*****************************************************************************/
    void push_back(T num)
    {
      if(this->vec_size >= this->cap)
        grow();
      this->store_array[this->vec_size] = num;
      ++this->vec_size;
    }

/*****************************************************************************/
  /* Removes the number from from the back
  */
/*****************************************************************************/
    void pop_back()
    {
      if (!empty())
        --this->vec_size;
    }

/*****************************************************************************/
  /* Returns true if list is empty else, false.
      @return bool
  */
/*****************************************************************************/
    bool empty()
    {
      return this->vec_size == 0 ? true : false;
    }

/*****************************************************************************/
  /* Removes the number that matches the given parameter
      @param pos - the position to remove at
  */
/*****************************************************************************/
    void erase(size_t pos)
    {
      if (pos >= this->vec_size || pos < 0)
        return;

      for (size_t i = pos; i < this->vec_size; ++i)
        this->store_array[i] = this->store_array[i + 1];

      pop_back();
    }

/*****************************************************************************/
    /* Inserts the number passed in at the speified position.
       @param pos - position to store the number
       @param num - the number to be inserted
    */
/*****************************************************************************/
    void insert(size_t pos, T num)
    {
      if (pos >= vec_size || pos < 0)
        abort();
      
      if (vec_size >= cap)
        grow();

      for (size_t i = this->vec_size; i > pos; --i)
        this->store_array[i] = this->store_array[i - 1];

      this->store_array[pos] = num;

      ++this->vec_size;
    }

/*****************************************************************************/
    /* Clears the vec_size
    */
/*****************************************************************************/
    void clear()
    {
      this->vec_size = 0;
    }
  };
}

#endif              // CS170_VECTOR_H

/*****************************************************************************/
  /* A print function template that will print out a template Vector.
      @param array - stores the vector array
   */
/*****************************************************************************/
template<typename T>
void Print(const cs170::vector<T> &array)
{
  for (size_t i = 0; i < array.size(); ++i)
    std::cout << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}


/*****************************************************************************/
  /* A print function template that will print out a template unsigned char
     Vector.
     @param array - stores the vector array
  */
/*****************************************************************************/
template<>
void Print(const cs170::vector<unsigned char> &array)
{
  for (size_t i = 0; i < array.size(); ++i)
    std::cout << static_cast<int>(array[i]) << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/*****************************************************************************/
  /* A print function template that will print out a template double Vector.
     @param array - stores the vector array
  */
/*****************************************************************************/
template<>
void Print(const cs170::vector<double> &array)
{
  // Set the precision to 5 digits
  std::cout << std::setprecision(5);

  for (unsigned i = 0; i < array.size(); ++i)
    std::cout << std::setw(7) << std::left << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}

/*****************************************************************************/
  /* A print function template that will print out a template float Vector.
     @param array - stores the vector array
  */
/*****************************************************************************/
template<>
void Print(const cs170::vector<float> &array)
{
  // Set the precision to 3 digits
  std::cout << std::setprecision(3);

  for (size_t i = 0; i < array.size(); ++i)
    std::cout << std::setw(5) << array[i] << "  ";

  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}