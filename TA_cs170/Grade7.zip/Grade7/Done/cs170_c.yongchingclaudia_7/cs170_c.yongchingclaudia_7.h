/******************************************************************************/
/*!
\file cs170_vector.h 
\author Chan Yong Ching Claudia 
\par email: c.yongchingclaudia\@digipen.edu 
\par DigiPen login: c.yongchingclaudia 
\par Course: CS170 
\par Lab #7
\date 15/07/2019 
\brief This file contains the implementation of the following functions for the 
vector assignment. This file contains the templates of a type vector,  
templates for default printing and specialised templates for printing float,
double and unsigned char. The Vector class contains its maxiumum capacity, its 
current size and also a pointer to its array. The templates allows different 
types to add or remove elements in and to its array.
Functions include: 
vector()
~vector()
Vector(T* arr, size_t size)
Vector(const Vector<T> &rhs)
Vector & operator=(const Vector<T> & rhs)
void check_bounds(const size_t index) const
void grow()
size_t size() const
size_t cap() const
T* array() const
T& operator[](const size_t index)
T operator[](const size_t index) const
void pop_front()
void pop_back()
void push_back(const T x)
bool empty() const
void erase(const T pos)
void insert(const size_t pos, const T val)
void clear()
void Print(const Vector<T> &array)
void Print(const Vector<unsigned char> &array)
void Print(const Vector<float> &array)
void Print(const Vector<double> &array)

Hours spent on this assignment: 20
Specific portions that gave you the most trouble: insert, grow, push_back
*/
/******************************************************************************/ 

#include <iomanip>

namespace cs170
{
    template <typename T>
    class vector
    {
        size_t _size;
        size_t _cap;
        T * _array;
    public:
    
/******************************************************************************/
/*!
*\brief         default constructor, sets all members variable to 0 and nullptr
*/
/******************************************************************************/

        vector(): _size{0}, _cap{0}, _array{nullptr} 
        {

        }

/******************************************************************************/
/*!
*\brief         default destructor, delete the array if there is one
*/
/******************************************************************************/

        ~vector()
        {
            if (_array!= nullptr)
                delete[] _array;
        }

/******************************************************************************/
/*!
*\brief         conversion constructor that takes in an array for initialisation

*\param         arr - array used for initialisation

*\param         size - size of the array
*/
/******************************************************************************/

        vector(T* arr, size_t size): _size{0}, _cap{0}, _array{nullptr}
        {
            for (size_t x = 0; x < size; x++)
                push_back(arr[x]);
        }

/******************************************************************************/
/*!
*\brief         conversion constructor that takes in a vector for initialisation

*\param         rhs - vector used for initialisation
*/
/******************************************************************************/

        vector(const vector<T> &rhs): _size{rhs._size}, _cap{rhs._cap}, 
                                      _array{nullptr}
        {
            _array = new T [_cap];
            for (size_t x = 0; x < _size; x++)
                _array[x] = rhs._array[x];
        }

/******************************************************************************/
/*!
*\fn            Vector & operator=(const Vector<T> & rhs)

*\brief         copy assignment operator, overloads the = sign and takes in a
                vector for initialisation

*\param         rhs - vector used for initialisation
*/
/******************************************************************************/

        vector & operator=(const vector<T> & rhs)
        {
            if (&rhs != &(*this))
            {
                _cap = rhs._cap;
                _size = rhs._size;
                if (_array!=nullptr)
                    delete[] _array;
                _array = new T [_cap];
                for (size_t x = 0; x < _size; x++)
                    _array[x] = rhs._array[x];
                //return *this;
            }
            return *this;
        }

/******************************************************************************/
/*!
*\fn            size_t size() const

*\brief         used to retrive the vec_size
                
*\return        returns vec_size which is the size of the vector               
*/
/******************************************************************************/

        size_t size() const
        {
            return _size;
        }

/******************************************************************************/
/*!
*\fn            size_t cap() const

*\brief         used to retrive the cap
                
*\return        returns cap which is the capacity of the vector               
*/
/******************************************************************************/

        size_t cap() const
        {
            return _cap;
        }

/******************************************************************************/
/*!
*\fn            T* array() const

*\brief         used to retrive the store_array
                
*\return        returns store_array which is the pointer to the array
*/
/******************************************************************************/

        T* array() const
        {
            return _array;
        }

/******************************************************************************/
/*!
*\fn            void check_bounds(const size_t index) const

*\brief         used to check if the position to be called is within the size
                of the exisiting array. if it is not, abort.
                
*\param         index - location to check 
*/
/******************************************************************************/

        void check_bounds(const size_t index) const
        {
            // Do not check for (index < 0) because size_t is always unsigned.
            if (index > _size)
            {
                std::cout
                << "Attempting to access index " << index << "."
                << " The vec_size of the array is " << _size
                << ". Aborting...\n";
                std::abort();
            }
        }

/******************************************************************************/
/*!
*\fn            void grow()

*\brief         used to increase the size of the capacity and size of array. 
                if capacity is empty at first, increase to one. after that every 
                call will double the size of the capacity. by calling the 
                function, a new array that is twice the size will be created and
                all the values in the old array will be copied over before the
                old array is deleted
*/
/******************************************************************************/

        void grow()
        {
            if (_cap==0)
            {
                _cap+=1;
                _array = new T [_cap];
            }
            else
            {
                _cap*=2;
                T * tmp = new T [_cap];
                for (size_t x = 0; x < _size; x++)
                tmp[x] = _array[x];
                delete [] _array;
                _array = tmp;
            }
        }

/******************************************************************************/
/*!
*\fn            T& operator[](const size_t index)

*\brief         used to insert a number into the array at a specific location

*\param         index - location to check 

*\return        returns value inside the array at the specific position
*/
/******************************************************************************/

        T& operator [](const size_t index)
        {
            check_bounds(index);
            return _array[index];
        }

/******************************************************************************/
/*!
*\fn            T operator[](const size_t index) const

*\brief         used to check what is inside a specific location

*\param         index - location to check 

*\return        returns value inside the array at the specific position
*/
/******************************************************************************/

        T operator[](const size_t index) const
        {
            check_bounds(index);
            return _array[index];

        }

/******************************************************************************/
/*!
*\fn            void pop_front()

*\brief         used to remove the first element of the array
*/
/******************************************************************************/

        void pop_front()
        {
            if (_size==1)
            {
                _size--;
                return;
            }
            else
            {
                 for (size_t x = 0; x < _size-1; x++)
                    _array[x]=_array[x+1];
                _size--;
                return;
            }
        }

/******************************************************************************/
/*!
*\fn            void pop_back()

*\brief         used to remove the last element of the array
*/
/******************************************************************************/

        void pop_back()
        {
            if (empty())
                return;
            _size--;
        }

/******************************************************************************/
/*!
*\fn            void push_back(T x)

*\param         x - value to be added to the array

*\brief         used to insert an element at the end of the array
*/
/******************************************************************************/

        void push_back(T x)
        {
            if (_size >= _cap)
                grow();
            _array[_size] = x;
            _size++;
        }
        
/******************************************************************************/
/*!
*\fn            bool empty() const

*\brief         used to check if the array is empty

*\return        returns true is array is empty, false if it is not
*/
/******************************************************************************/
    

        bool empty() const
        {
            if (_size > 0)
                return false;
            return true;
        }

/******************************************************************************/
/*!
*\fn            void erase(const T pos)

*\brief         used to remove an element of at position pos

*\param         pos - position to be checked and removed
*/
/******************************************************************************/

        void erase(const T pos)
        {
            T * start = _array;
            T * end = _array + _size;
            int count = pos;

            if (pos==0)
            {
                pop_front();
            }
            else
            {
                while(count)
                {
                    count--;
                    start++;
                }
                while(start<end)
                {
                    *start = *(start+1);
                    start++;
                }
                _size--;
            }
        }

/******************************************************************************/
/*!
*\fn            void insert(const size_t pos, const T val)

*\brief         used to insert a new value in the array at a specific posisition

*\param         pos - location to insert the new value

*\param         val - value to be added
*/
/******************************************************************************/

        void insert(const size_t pos, const T val)
        {
            check_bounds(pos);
            if (_size >= _cap)
              grow();
            _size++;
            T* curr = _array+pos;
            T* last = _array + _size-1;
            T* prev = last-1;
            for (; last > curr; last--, prev--)
                *last = *prev;
            *last = val;
        }

/******************************************************************************/
/*!
*\fn            void clear()

*\brief         used to clear the array by setting its vector size to 0 and
                creating an empty array ready to be used any time
  */
/******************************************************************************/

        void clear()
        {
            _size = 0;
            delete [] _array;
            _array = new T [0];
        }
    };

/******************************************************************************/
/*!
*\fn            void Print(const Vector<T> &array)

*\brief         default template for printing

*\param         array - the array that needs to be printed
*/
/******************************************************************************/

    template<typename T>
    void Print(const vector<T> &array)
    {
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.cap()
        << ")"
        << std::endl;
    }

/******************************************************************************/
/*!
*\fn            void Print(const Vector<unsigned char> &array)

*\brief         specialised template for printing unsigned char

*\param         array - the array that needs to be printed
*/
/******************************************************************************/

    template<>
    void Print(const vector<unsigned char> &array)
    {
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << static_cast<unsigned int>(array[i]) << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.cap()
        << ")"
        << std::endl;
    }

/******************************************************************************/
/*!
*\fn            void Print(const Vector<float> &array)

*\brief         specialised template for printing float

*\param         array - the array that needs to be printed
*/
/******************************************************************************/

    template<>
    void Print(const vector<float> &array)
    {
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << std::setprecision(3) << std::setw(5) << (array[i]) <<"  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.cap()
        << ")"
        << std::endl;
    }

/******************************************************************************/
/*!
*\fn            void Print(const Vector<double> &array)

*\brief         specialised template for printing double

*\param         array - the array that needs to be printed
*/
/******************************************************************************/

    template<>
    void Print(const vector<double> &array)
    {
    for (unsigned i = 0; i < array.size(); ++i)
    {
        std::cout << std::setprecision(5) << std::setw(7) 
                    << std::left << array[i] <<"  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.cap()
        << ")"
        << std::endl;
    }

}