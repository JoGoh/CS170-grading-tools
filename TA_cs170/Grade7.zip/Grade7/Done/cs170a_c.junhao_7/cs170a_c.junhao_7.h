/******************************************************************************/
/*!
\file               cs170_vector.h
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab07
\par Course:        CS170
\date:              14/07/2019
\brief
        This file contains the implementations of the following
        functions for the Lab07.
        
Functions include:
		grow
		vector
        constructor
		copy constructor
		destructor
		size
		push_back
		pop_back
		empty
		erase
		insert
		operator[]
		operator=
		clear
		Print
		
Hours spent on this assignment: 8hr
Specific portions that gave you the most trouble: Print
*/
/******************************************************************************/

#include <iostream>  //cout, endl
#include <iomanip>   //setw

namespace cs170
{
  template<typename T>
  class vector;
  
  template<typename T>
  void Print(vector<T> curr_Vector);
  
    template<typename T>
    class vector
    {
        private:
			size_t vec_size = 0;
			size_t cap = 0;
			T* vec_start = nullptr;
            
            void grow();
            
        public:
            vector();                       //User - Defined Constructor
            vector(const vector& rhs);      //User - Defined Copy Constructor
			~vector();                      //User - Defined Destructor
            
            size_t size() const;
      
            void push_back(T value);        //Test Push
            void pop_back();                //Test Pop
			bool empty() const;
            void erase(unsigned int);       //Test Remove
            void insert(unsigned int, T);   //Test Insert
      
            T& operator[](unsigned int) const;           //Test Subscript
            vector<T>& operator=(const vector<T>& rhs);  //Assignment Operator
      
            void clear();           //Clear - Remove everything from vector
            
            friend void Print<T>(vector);//Display everything within the vector
      
    };  //End of class vector definition
  
/******************************************************************************/
/*!
\brief           Increase the capacity of the vector
*/
/******************************************************************************/
  template<typename T>
  void vector<T>::grow()
  {
      size_t newCap = 0; //Local capacity
      
    //Checks size of current cap, before expanding.
    if(cap == 0)
      newCap = 1;
    else
      newCap = cap * 2;

    //Creating the new vector.
    T* newArray = new T[newCap];

    size_t newVec = 0; //New empty vec_size

    //Deep Copying
    for(size_t i = 0; i < cap; ++i)
    {
      newArray[i] = vec_start[i];
      ++newVec;
    }

    //Replacing Original vector with the new vector.
    delete[] vec_start;
    vec_start = newArray;
    vec_size = newVec;
    cap = newCap;
  }

/******************************************************************************/
/*!
\brief  User-defined default constructor
*/
/******************************************************************************/
  template<typename T>
  vector<T>::vector()
         :vec_size{0},
          cap{0},
          vec_start{nullptr}
  {
  }
  
/******************************************************************************/
/*!
\brief   Copy Constructor
*/
/******************************************************************************/
  template<typename T>
  vector<T>::vector(const vector& rhs)
         :vec_size{rhs.vec_size},
          cap{rhs.cap},
		  vec_start{new T[rhs.cap]}
  {
    for(size_t i = 0; i < rhs.cap; ++i)
    {
      vec_start[i] = rhs.vec_start[i];
    }
  }
  
/******************************************************************************/
/*!
\brief    Destructor
*/
/******************************************************************************/
  template<typename T>
  vector<T>::~vector()
  {
    
    delete[] vec_start;
    vec_start = nullptr;
    vec_size = 0;
    cap = 0;
  }
/******************************************************************************/
/*!
\brief           Retrieves the size of the vector
\return vec_size The amount of elements in the vector
*/
/******************************************************************************/
  template<typename T>
  size_t vector<T>::size() const
  {
    return vec_size;
  }
/******************************************************************************/
/*!
\brief           Pushes the value into the back of the vector
\param  value	 The value to place into the vector
*/
/******************************************************************************/
 template<typename T>
 void vector<T>::push_back(T value)
 {
    if((vec_size + 1) > cap)
        grow();
    
    vec_start[vec_size] = value;
    ++vec_size;
 }   
 
/*****************************************************************************/
/*!
\brief   Removes the value at the end of the vector
*/
/******************************************************************************/
  template <typename T>
  void vector<T>::pop_back()
  {
    vec_start[vec_size-1] = T{};
    --vec_size;
  }
  
/******************************************************************************/
/*!
\brief          Checks if the vector is empty
\return true - vector is empty
        false - vector is not empty
*/
/******************************************************************************/
  template<typename T>
  bool vector<T>::empty() const
  {
    if (vec_size)
      return false;
    else
      return true;
  }

  
/*****************************************************************************/
/*!
\brief     Removes an element from the vector.
\param pos The position to remove the element from.
*/
/******************************************************************************/
  template<typename T>
  void vector<T>::erase(unsigned int pos)
  {
	if(pos >= vec_size)
	{
		std::abort();
	}  
	  
    if(pos <= vec_size)
    {
      //Push everything forward
      for(unsigned int i = pos; i < vec_size; ++i)
      {
        vec_start[i] = vec_start[i+1];
      }
      --vec_size;
    }
  }
  
/*****************************************************************************/
/*!
\brief       Insert a value into a position given by the user.
\param pos   The position to insert the value with
\param value The value to insert into the vector with
*/
/******************************************************************************/
  template<typename T>
  void vector<T>::insert(unsigned int pos, T value)
  {
	if(pos >= (vec_size) )
	{
		std::abort();
	}

    if( (vec_size + 1 ) > cap)
    {
      grow();
    }
	
    //Push everything backwards.
    for(unsigned int i = vec_size; i > pos; --i)
    {
      vec_start[i] = vec_start[i-1];
    }
    vec_start[pos] = value;
    ++vec_size;
  }

/******************************************************************************/
/*!
\brief      	       Subscript Operator Overload
\param   pos  		   The position to retrieve from the vector  
\return  vec_start+1   Returns an Int as per what the vector stores.
*/
/******************************************************************************/
  template<typename T>
  T& vector<T>::operator[](unsigned int pos)const
  {
	if(pos >= vec_size)
	{
		std::abort();
	}
	
    unsigned int i = 0;
    while(i < pos)
    {
      ++i;
    }
    return *(vec_start + i);
  }

/******************************************************************************/
/*!
\brief          Assignment Operator Overload
\param    rhs   The vector to copy from
\return   *this Returns a vector that is copied from the parsed in.
*/
/******************************************************************************/
  template<typename T>
  vector<T>& vector<T>::operator=(const vector<T>& rhs)
  {
    if(vec_start == rhs.vec_start && vec_size == rhs.vec_size)
      return *this;
    
    delete[] vec_start;
    vec_size = rhs.vec_size;
    cap = rhs.cap;
    vec_start = new T[rhs.cap];

    for(size_t i = 0; i < rhs.vec_size; ++i)
    {
      vec_start[i] = rhs.vec_start[i];
    }

    return *this;
  }
  
/******************************************************************************/
/*!
\brief  Clears all value from the vector, retains the capacity.
*/
/******************************************************************************/
  template<typename T>
  void vector<T>::clear()
  {
    size_t tempSize = vec_size;
    
    for(size_t i = 0; i < tempSize; ++i)
    {
      vec_start[i] = T{};  //Reset it to 0
     --vec_size; //Reduce its size
    }
  }
  
/******************************************************************************/
/*!
  \brief               Adds the value to the end of the vector (T Type)
  \param  curr_Vector  The array to copy from.
*/
/******************************************************************************/
	template<typename T>
    void Print(vector<T> curr_Vector)
    {
     for(unsigned i = 0; i < curr_Vector.vec_size; ++i)
     {
        std::cout << curr_Vector[i] << "  ";
     }

    std::cout << "(size=" << curr_Vector.vec_size;
    std::cout << ", capacity=" << curr_Vector.cap << ")" << std::endl;
    }
	
/******************************************************************************/
/*!
  \brief               Adds the value to the end of the vector (Float)
  \param  curr_Vector  The array to copy from.
*/
/******************************************************************************/
  template<>
  void Print(vector<float> curr_Vector)
  {
     for(unsigned i = 0; i < curr_Vector.vec_size; ++i)
     {
       std::cout << std::setw(5);
       std::cout << std::setprecision(3) << curr_Vector[i] << "  ";
     }
    std::cout << "(size=" << curr_Vector.vec_size;  
    std::cout << ", capacity=" << curr_Vector.cap << ")" << std::endl;
  }
  
/******************************************************************************/
/*!
  \brief               Adds the value to the end of the vector (unsigned char)
  \param  curr_Vector  The array to copy from.
*/
/******************************************************************************/
  template<>
  void Print(vector<unsigned char> curr_Vector)
  {
     for(unsigned i = 0; i < curr_Vector.vec_size; ++i)
     {
        std::cout << std::setprecision(3);
        std::cout << (unsigned int)curr_Vector[i] << "  ";
     }

    std::cout << "(size=" << curr_Vector.vec_size;
    std::cout << ", capacity=" << curr_Vector.cap << ")" << std::endl;
  }

/******************************************************************************/
/*!
  \brief               Adds the value to the end of the vector (double)
  \param  curr_Vector  The array to copy from.
*/
/******************************************************************************/
  template<>
  void Print(vector<double> curr_Vector)
  {
     for(unsigned i = 0; i < curr_Vector.vec_size; ++i)
     {
         std::cout << std::setw(9) << std::setfill(' ');
         std::cout << std::left << std::setprecision(5) << curr_Vector[i];
     }

    std::cout << "(size=" << curr_Vector.vec_size;
    std::cout << ", capacity=" << curr_Vector.cap << ")" << std::endl;
  }
} //End of namespace cs170













