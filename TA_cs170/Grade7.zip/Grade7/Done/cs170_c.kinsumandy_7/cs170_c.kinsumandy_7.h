/******************************************************************************/ 
/*!
\file cs170_vector.h 
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par Lab #7
\date 07/09/2019
\brief This file contains the implementation of the following functions for
CS170 (lab 07).
Functions include:
vector (Default)
vector (Copy)
vector (Overloaded)
~vector
grow
check_bounds
size
capacity
operator[]
operator=
push_back
pop_back
empty
insert
erase
Print function templates
 
Hours spent on this assignment: 10 hr
Specific portions that gave you the most trouble: trying to match the output
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef VECTOR_H
#define VECTOR_H
////////////////////////////////////////////////////////////////////////////////

#include <iomanip>
#include <iostream>

namespace cs170
{
    template<typename T>
    class vector
    {
    public:
        /**********************************************************************/
        /*!
          \brief vector
            Default Constructor. To initialise all the data members 
            in the class
            
          \return
            No return type
        */
        /**********************************************************************/
        vector()
            : val_array(nullptr)
            , vec_size(0)
            , cap(0)
        {}
        /**********************************************************************/
        /*!
          \brief vector
            Overloaded Constructor. To initialise all the data members as
            desired value in the class

          \param array
            The desired value for the vector
            
          \param N
            The desired size for the vector
    
          \return
            No return type
        */
        /**********************************************************************/
        vector(const T *array, size_t N)
            : val_array(nullptr)
            , vec_size(0)
            , cap(0)
        {
            // Allocate memory
            for (size_t i = 0; i < N; ++i)
                push_back(array[i]);
        }
        /**********************************************************************/
        /*!
          \brief vector
            Copy Constructor. To copy all the data members from another class
            to this class
            
          \param rhs
            The desired class to be copied
    
          \return
            No return type
        */
        /**********************************************************************/
        vector(const vector& rhs)
            : vec_size(rhs.vec_size)
            , cap(rhs.cap)
        {
            // Allocate memory
            val_array = new T[cap];

            // Copy data
            for (size_t i = 0; i < vec_size; ++i)
                val_array[i] = rhs.val_array[i];
        }
        /**********************************************************************/
        /*!
          \brief operator=
            Operator =. To copy all the data members from another class
            to this class

          \param rhs
            The desired class to be copied
    
          \return vector&
        */
        /**********************************************************************/
        vector& operator=(const vector& rhs)
        {
            // Check if it's the same class
            if (val_array == rhs.val_array)
                return *this;

            // Copy all the value from another vector class
            this->vec_size = rhs.vec_size;
            this->cap = rhs.cap;

            // Delete the previous store array
            if (val_array != nullptr)
                delete[] val_array;

            // Allocate memory and copy all the value
            val_array = new T[cap];
            for (size_t i = 0; i < vec_size; ++i)
                this->val_array[i] = rhs.val_array[i];
            
            return *this;
        }
        /**********************************************************************/
        /*!
          \brief ~vector
            Destructor. To destroy all the memory allocated

          \return 
            No return type
        */
        /**********************************************************************/
        ~vector()
        {
            // Delete array
            delete[] val_array;
        }
        /**********************************************************************/
        /*!
          \brief size
            To return the size of the vector

          \return size_t
        */
        /**********************************************************************/
        size_t size() const
        {
            return vec_size;
        }
        /**********************************************************************/
        /*!
          \brief capacity
            To return the capacity of the vector

          \return size_t
        */
        /**********************************************************************/
        size_t capacity() const
        {
            return cap;
        }
        /**********************************************************************/
        /*!
          \brief operator[]
            To return the desired index from the vector
            
          \param index
            The desired index use for the vector

          \return T&
        */
        /**********************************************************************/
        T& operator[](size_t index) const
        {
            // Check if the index is out of bound
            check_bounds(index);
            
            // Return value at index
            return val_array[index];
        }
        /**********************************************************************/
        /*!
          \brief empty
            To check if the vector is empty
            
          \return bool
        */
        /**********************************************************************/
        bool empty()
        {
            return (vec_size == 0);
        }
        /**********************************************************************/
        /*!
          \brief push_back
            To add another value into the vector
            
          \param val
            The desired value for the vector
            
          \return void
        */
        /**********************************************************************/        
        void push_back(T val)
        {
            // Check if the size of the class is bigger than capacity
            // and increase the capacity
            if (vec_size >= cap)
                grow();
            
            // Add value into the value array and increment the size
            val_array[vec_size] = val;
            ++vec_size;
        }
        /**********************************************************************/
        /*!
          \brief insert
            To insert another value into the vector at the desired position

          \param pos
            The desired position for the vector to be inserted
            
          \param val
            The desired value for the vector
            
          \return void
        */
        /**********************************************************************/
        void insert(size_t pos, T val)
        {
            // Check if the index is out of bound
            check_bounds(pos);
            
            // Check if the size of the class is bigger than capacity
            if (vec_size >= cap)
                grow();

            // Push back all the values after the desired position
            for (size_t i = vec_size; i > pos; --i)
                val_array[i] = val_array[i - 1];

            // Add the value into the desired position
            val_array[pos] = val;
            ++vec_size;
        }
        /**********************************************************************/
        /*!
          \brief pop_back
            To remove one vector from the back
            
          \return void
        */
        /**********************************************************************/
        void pop_back()
        {
            // If the class is not empty, decrease the size
            if (!empty())
                --vec_size;
        }
        /**********************************************************************/
        /*!
          \brief clear
            To reset the vec_size
            
          \return void
        */
        /**********************************************************************/    
        void clear()
        {
            // Reset the variables
            vec_size = 0;
        }
        /**********************************************************************/
        /*!
          \brief erase
            To remove the vector from the desired position

          \param pos
            The desired position for the vector to be deleted
            
          \return void
        */
        /**********************************************************************/
        void erase(size_t pos)
        {
            // If the class is not empty, decrease the size
            if (!empty())
            {
                // Check if the index is out of bound
                check_bounds(pos);
            
                // Move all of the value forward after the position
                for (size_t i = pos; i < vec_size; ++i)
                    val_array[i] = val_array[i + 1];

                // Decrease the size
                --vec_size;
            }
        }
        
        
    private:
    
        T* val_array;
        size_t vec_size;
        size_t cap;

        /**********************************************************************/
        /*!
          \brief grow
            To make sure the subscript or position is valid.
            Aborts the program if it is invalid.
        
          \param index
            The desired index for the
          
          \return void
        */
        /**********************************************************************/
        void check_bounds(size_t index) const
        {
            // Do not check for (index < 0) because size_t is always unsigned.
            if (index >= vec_size)
                std::abort();
        }
        /**********************************************************************/
        /*!
          \brief grow
            To double the vector size when necessary, to increment the capacity
            of the vector by twice after calling this function
            
          \return void
        */
        /**********************************************************************/
        void grow()
        {
            // If cap is zero, create 1 array size
            if (cap == 0)
            {
                ++cap;
                val_array = new T[cap];
                return;
            }

            // Store the number into the temp storage
            T* TempStorage = new T[vec_size];
            for (size_t i = 0; i < vec_size; ++i)
                TempStorage[i] = val_array[i];

            // Delete old memory
            delete[] val_array;

            // Increase cap
            cap *= 2;

            // Create a new array size
            val_array = new T[cap];
            
            // Retrieve back the number from temp storage
            for (size_t i = 0; i < vec_size; ++i)
                val_array[i] = TempStorage[i];

            // Delete all of the temp storage
            delete[] TempStorage;
        }
        
    };
}                               // namespace cs170
#endif                          // VECTOR_H

/******************************************************************************/
/*!
  \brief Print
    General print template 
    
  \param array
    The vector's reference to be printed
            
  \return void
*/
/******************************************************************************/
template<typename T>
void Print(const cs170::vector<T> &array)
{
    for (size_t i = 0; i < array.size(); ++i)
    {
        std::cout << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
  \brief Print
    Specialized print template for unsigned char
    
  \param array
    The vector's value to be printed
            
  \return void
*/
/******************************************************************************/
template <>
void Print(const cs170::vector<unsigned char> &array)
{
    for (size_t i = 0; i < array.size(); ++i)
    {
        std::cout << static_cast<int>(array[i]) << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
  \brief Print
    Specialized print template for double
    
  \param array
    The vector's value to be printed
            
  \return void
*/
/******************************************************************************/
template <>
void Print(const cs170::vector<double> &array)
{
    for (size_t i = 0; i < array.size(); ++i)
    {
        std::cout << std::setprecision(5);
        std::cout << std::setw(7) << std::left << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}
/******************************************************************************/
/*!
  \brief Print
    Specialized print template for float
    
  \param array
    The vector's value to be printed
            
  \return void
*/
/******************************************************************************/
template <>
void Print(const cs170::vector<float> &array)
{
    for (size_t i = 0; i < array.size(); ++i)
    {
        std::cout << std::setprecision(3);
        std::cout << std::setw(5) << array[i] << "  ";
    }
    std::cout
        << "("
        << "size=" << array.size()
        << ", "
        << "capacity=" << array.capacity()
        << ")"
        << std::endl;
}