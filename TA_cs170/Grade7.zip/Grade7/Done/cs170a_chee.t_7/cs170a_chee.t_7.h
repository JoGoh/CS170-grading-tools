/******************************************************************************/
/*!
\file cs170_vector.h
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: cs170
\par Lab 07
\date 8/07/2019
\brief
This file contains the implementation of the following functions for
Lab 7.

Functions include:
vector()
~vector()
vector(const vector&)
vector& operator=(const vector&)
T& operator[] (const int) const
size_t capacity() const
void clear()
bool empty()
void erase(int)
void insert(int, T)
void pop_back()
void push_back(T)
size_t size() const
void check_bounds(size_t index) const
void grow()

Hours spent on this assignment: 3
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef vector_H
#define vector_H
////////////////////////////////////////////////////////////////////////////////

#include <iomanip>
#include <iostream>

namespace cs170
{
  template <typename T>
  class vector
  { 
  public:
    // Constructor/Destructor
    vector();
    ~vector();
    vector(const vector&);
    
    // Operator overloads
    vector& operator=(const vector&);
    T& operator[] (const int) const;
    
    // Regular functions
    size_t capacity() const;
    void clear();
    bool empty();
    void erase(int);
    void insert(int, T);
    void pop_back();
    void push_back(T);
    size_t size() const;
    
  private:
    // Private variables
    size_t cap;
    size_t vec_size;
    T* list;
    
    // Private member functions
    void check_bounds(size_t index) const;
    void grow();
  };
  
  /******************************************************************************/
  /*!
  \brief Constructor to initialize all values to zero and nullptr
  
  \fn vector<T>::vector()
  */
  /******************************************************************************/
  
  template <typename T>
  vector<T>::vector() :
  cap{ 0 },
  vec_size{ 0 },
  list{ nullptr }
  { }
  
  /******************************************************************************/
  /*!
  \brief Destructor to delete and set all values to zero and nullptr
  
  \fn vector<T>::~vector()
  */
  /******************************************************************************/
  template <typename T>
  vector<T>::~vector()
  {
    if (list) delete[] list;
    cap = 0;
    vec_size = 0;
  }
  
  /******************************************************************************/
  /*!
  \brief Copy Constructor for vector(vector)
  
  \fn vector<T>::vector(const vector &vector)
  */
  /******************************************************************************/
  template <typename T>
  vector<T>::vector(const vector &vector) :
  cap{ vector.cap },
  vec_size{ vector.vec_size },
  list{ new T[vector.cap] }
  {
    for (size_t i = 0; i < vec_size; ++i)
    {
      list[i] = vector.list[i];
    }
  }
  
  /******************************************************************************/
  /*!
  \brief Assignment Operator for vector = vector
  
  \fn vector<T>& vector<T>::operator=(const vector &vector)
  
  \param vector
    Source vector to perform deep copy to left side of = operator
  
  \return vector<T>&
    Returns a reference to instance of vector
  */
  /******************************************************************************/
  template <typename T>
  vector<T>& vector<T>::operator=(const vector &rhs)
  {
    cap = rhs.cap;
    vec_size = rhs.vec_size;
    T* temp = new T[cap];
    for (size_t i = 0; i < vec_size; ++i)
    {
      temp[i] = rhs.list[i];
    }
    
    if (list) delete[] list;
    list = temp;
    return *this;
  }
  
  /******************************************************************************/
  /*!
  \brief Operator overload for vector[], first checks ifgiven position is within 
  bounds, if it is not, abort. If it is, return reference to element at position
  
  \fn T& vector<T>::operator[](const int position) const
  
  \param position
    Position to return element at position
  
  \return T&
    Returns a reference to element within vector
  */
  /******************************************************************************/
  template <typename T>
  T& vector<T>::operator[] (const int position) const
  {
    check_bounds(static_cast<size_t>(position));
    return list[position];
  }
  
  /******************************************************************************/
  /*!
  \brief Function to return current max capacity
  
  \fn size_t vector<T>::capacity() const
  
  \return size_t
    Returns the capacity of vector
  */
  /******************************************************************************/
  template <typename T>
  size_t vector<T>::capacity() const
  {
    return cap;
  }
  
  /******************************************************************************/
  /*!
  \brief Function that sets vector size to zero, keeping the capacity
  for future use purposes

  \fn void vector<T>::clear()
  */
  /******************************************************************************/
  template <typename T>
  void vector<T>::clear()
  {
    vec_size = 0;
  }
  
  /******************************************************************************/
  /*!
  \brief Function to check if vector is empty by returning boolean, if it's empty
  function returns true
  
  \fn bool vector<T>::empty()
  
  \return bool
    Returns true if vector is empty/vector size is 0
  */
  /******************************************************************************/
  template <typename T>
  bool vector<T>::empty()
  {
    return !vec_size;
  }
  
  /******************************************************************************/
  /*!
  \brief Function to remove a single value at a specified position in
  the vector
  
  \fn void vector<T>::erase(int position)
  
  \param position
    Given position to remove the element at
  */
  /******************************************************************************/
  template <typename T>
  void vector<T>::erase(int position)
  {
    check_bounds(static_cast<size_t>(position));
    for (size_t i = static_cast<size_t>(position); i < vec_size; ++i)
    {
      list[i] = list[i+1];
    }
    --vec_size;
  }
  
  /******************************************************************************/
  /*!
  \brief Function to insert a given data at a specified position in
  the vector
  
  \fn void vector<T>::insert(int position, T data)
  
  \param position
    Given position to insert data at
    
  \param data
    Given data to insert at position
  */
  /******************************************************************************/
  template <typename T>
  void vector<T>::insert(int position, T data)
  {
    check_bounds(static_cast<size_t>(position));
    if (cap == vec_size) grow();
    for (int i = vec_size++; i > position; --i)
    {
      list[i] = list[i-1];
    }
    list[position] = data;
  }
  
  /******************************************************************************/
  /*!
  \brief Function to remove a single value from the back of vector
  
  \fn void vector<T>::pop_back()
  */
  /******************************************************************************/
  template <typename T>
  void vector<T>::pop_back()
  {
    --vec_size;
  }
  
  /******************************************************************************/
  /*!
  \brief Function to add new value to the back of vector, grows the
  vector capacity if necessary
  
  \fn void vector<T>::push_back(T data)
  
  \param data
    Given data to add to back of vector
  */
  /******************************************************************************/
  template <typename T>
  void vector<T>::push_back(T data)
  {
    if (cap == vec_size) grow();
    list[vec_size++] = data;
  }
  
  /******************************************************************************/
  /*!
  \brief Function to return current size
  
  \fn size_t vector<T>::size() const
  
  \return size_t
    Returns the current size of vector
  */
  /******************************************************************************/
  template <typename T>
  size_t vector<T>::size() const
  {
    return vec_size;
  }
  
  /******************************************************************************/
  /*!
  \brief Private function to check if certain index is within bounds of current
  vector. If it is not within bounds, aborts the program
  
  \fn void vector<T>::check_bounds(size_t index) const
  
  \param index
    Given position to check
  */
  /******************************************************************************/
  template <typename T>
  void vector<T>::check_bounds(size_t index) const
  {
    if (index >= vec_size)
    {
      std::cout 
      << "Index given is not within range. "
      << "Aborting...\n";
      std::abort();
    }
  }
  
  /******************************************************************************/
  /*!
  \brief Function to double the capacity of the vector, if capacity is
  zero increase capacity to 1, else multiply capacity by 2. Create new static
  array with increased capacity and copies over data from old vector. Then
  deallocates old vector
  
  \fn void vector<T>::grow()
  */
  /******************************************************************************/
  template <typename T>
  void vector<T>::grow()
  {
    if (cap == 0)
    {
      cap = 1;
      if (list) delete[] list;
      list = new T[cap];
    }
    else
    {
      cap *= 2;
      T* temp = list;
      list = new T[cap];
      for (size_t i = 0; i < vec_size; ++i) list[i] = temp[i];
      delete[] temp;
    }
  }
}                               // namespace cs170
#endif                          // vector_H

/******************************************************************************/
/*!
\brief A print function template that will print out a templated vector.

\fn void Print(const cs170::vector<T> &array)
*/
/******************************************************************************/
template<typename T>
void Print(const cs170::vector<T> &array)
{
  for (unsigned i = 0; i < array.size(); ++i)
  {
    std::cout << array[i] << "  ";
  }
  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}
  
/******************************************************************************/
/*!
\brief Specialized print function template for vectors containing (float)s

\fn void Print(const cs170::vector<float>& array)
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<float>& array)
{
  for (unsigned i = 0; i < array.size(); ++i)
  {
    std::cout << std::setw(5);
    std::cout << std::setprecision(3);
    std::cout << array[i] << "  ";
  }
  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}
  
/******************************************************************************/
/*!
\brief Specialized print function template for vectors containing (double)s

\fn void Print(const cs170::vector<double>& array)
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<double>& array)
{
  for (unsigned i = 0; i < array.size(); ++i)
  {
    std::cout << std::setw(7) << std::left;
    std::cout << std::setprecision(5);
    std::cout << array[i] << "  ";
  }
  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}
  
/******************************************************************************/
/*!
\brief Specialized print function template for vectors containing 
(unsigned char)s

\fn void Print(const cs170::vector<unsigned char>& array)
*/
/******************************************************************************/
template<>
void Print(const cs170::vector<unsigned char>& array)
{
  for (unsigned i = 0; i < array.size(); ++i)
  {
    std::cout << static_cast<int>(array[i]) << "  ";
  }
  std::cout
    << "("
    << "size=" << array.size()
    << ", "
    << "capacity=" << array.capacity()
    << ")"
    << std::endl;
}