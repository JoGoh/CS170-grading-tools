/*****************************************************************************/
/*!
\file cs170_vector.h
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
07
\par Date:
09 July 2019
\par Brief:

	This file contains the implementation of the following functions
	for CS170 Lab 07 - Class Templates

	Functions given: \n
	
	\n
	Functions written: \n 
	void grow(); \n
	vector(); \n
	~vector(); \n
	vector(const T* vec, const size_t size); \n
	vector(const vector<T>& rhs); \n
	vector<T>& operator=(const vector<T>& rhs); \n
	T& operator[](size_t index) const; \n
	void push_back(const T& item); \n
	void pop_back(); \n
	size_t size() const; \n
	size_t capacity() const; \n
	bool empty() const; \n
	void clear(); \n
	void erase(const size_t& pos); \n
	void insert(const size_t& pos, const T& item); \n
	template \<typename T\> 
	void Print(const cs170::vector<T>& vec); \n
	template \<\>
	void Print(const cs170::vector<unsigned char>& vec); \n
	template \<\>
	void Print(const cs170::vector<float>& vec); \n
	template \<\>
	void Print(const cs170::vector<double>& vec); \n
	
	
	\n 
	Hours spent on this assignment: 
	3.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/

#include <iostream> //cout
#include <iomanip> //setprecision, setw

namespace cs170 {
	
	template <typename T>
	class vector {
	
		private:

			size_t vec_size;
			size_t vec_capacity;
			T* store_array;
			
			/************************************************************************/
			/*!
				\brief Grows the vector.
				Double the vector capacity. 
				If the current capacity is 0, set it to 1. 
				Copy the smaller vector over to the new, 
				double sized vector and remove the smaller one.
			*/
			/************************************************************************/
			void grow() {
				
				if (vec_capacity == 0) {
					vec_capacity = 1;
					delete[] store_array;
					store_array = new T[vec_capacity];
				}
				else {
					vec_capacity *= 2; //update capacity			
					T* temp_array = new T[vec_capacity];
					for (size_t i = 0; i < vec_size; ++i) {
						temp_array[i] = store_array[i];
					}	
					delete[]store_array;	
					store_array = temp_array;	//move to temp array
				}
			} //end grow
			
		public:
			/************************************************************************/
			/*!
				\brief Default Constructor.
				Sets vector size and capacity to 0, the head of vector to nullptr.
			*/
			/************************************************************************/
			vector():
				vec_size(0),
				vec_capacity(0),
				store_array(nullptr) {
			}
			
			/************************************************************************/
			/*!
				\brief Default Destructor.
			*/
			/************************************************************************/
			~vector() {
				delete[] store_array;
			}
			
			/************************************************************************/
			/*!
				\brief Conversion Constructor.
				
				\param vec
					Pointer to the T* to be converted.
				\param size
					Size of the vector.
			*/
			/************************************************************************/
			vector(const T* vec, const size_t size):
				vec_capacity(0),
				store_array(nullptr), 
				vec_size(size) {

				store_array = new T[0];
				while (vec_capacity < vec_size) {
					grow();
				}
				
				for (size_t i = 0; i < vec_size; ++i) {
					store_array[i] = vec[i];
				}
				
			} //end conversion costructor
			
			/************************************************************************/
			/*!
				\brief Copy Constructor.
				
				\param rhs
					Reference to the vector to be copied from.
			*/
			/************************************************************************/
			vector(const vector<T>& rhs):
				vec_size(rhs.vec_size), 
				vec_capacity(rhs.vec_capacity),
				store_array(new T[rhs.vec_capacity]) {
					
				for (size_t i = 0; i < vec_size; ++i) {
					store_array[i] = rhs.store_array[i];
				}
			} //end copy constructor
			
			/************************************************************************/
			/*!
				\brief Assignment operator overload.
				
				\param rhs
					Reference to the vector containing items to be assigned.
			*/
			/************************************************************************/
			vector<T>& operator=(const vector<T>& rhs) {
				
				if (this == &rhs) { //self assignment check
					return *this;
				}
				
				vec_size = rhs.vec_size;
				vec_capacity = rhs.vec_capacity;
				T* temp_array = new T[vec_capacity];
				
				for (size_t i = 0; i < vec_size; ++i) {
					temp_array[i] = rhs.store_array[i];
				}
				delete[] store_array;
				store_array = temp_array;
				
				return *this;
			} //end assignment op overload
			
			
			/************************************************************************/
			/*!
				\brief [] operator overload.
				Returns an item from the vector at a given index if it is within
				bounds. Return the 0th element otherwise.
				
				\param index
					Index of the item.
				\retval store_array[index]
					Returns the item at given index.
			*/
			/************************************************************************/
			T& operator[](size_t index) const {
				if (index < vec_size) {
					return store_array[index];
				}
				return store_array[0];
			}
			
			/************************************************************************/
			/*!
				\brief Pushes item to the back of vector.
				Pushes an item to the end of the vector, 
				if there is no more capacity, call grow() to double the vector's
				capacity.
				
				\param item
					Item to be pushed.
			*/
			/************************************************************************/
			void push_back(const T& item) {
				
				if (vec_size >= vec_capacity) {
					grow();
				}
				store_array[vec_size] = item;
				++vec_size; 
			} //end push_back
			
			/************************************************************************/
			/*!
				\brief Removes item at the end of vector.
			*/
			/************************************************************************/
			void pop_back() {
				--vec_size;
			} //end pop_back
			
			/************************************************************************/
			/*!
				\brief Returns the size of vector.
				
				\retval vec_size
					Size of the vector.
			*/
			/************************************************************************/
			size_t size() const {
				return vec_size;
			}
			
			/************************************************************************/
			/*!
				\brief Returns the capacity of vector.
				
				\retval vec_capacity
					Capacity of the vector.
			*/
			/************************************************************************/
			size_t capacity() const {
				return vec_capacity;
			}
			
			/************************************************************************/
			/*!
				\brief Checks if vector is empty.
				Returns true if vector is empty i.e. 0 size or no values.
				
				\return true
					Return true if vector is empty.
				\return false
					Return false if vector is populated.
			*/
			/************************************************************************/
			bool empty() const {
				return ((vec_size == 0) || (store_array == nullptr));
			}
			
			/************************************************************************/
			/*!
				\brief Clears the vector.
				This does not reset the capacity or memory allocated.
			*/
			/************************************************************************/
			void clear() {
				vec_size = 0;
			}
			
			/************************************************************************/
			/*!
				\brief Erase item from vector.
				Given a position in the vector, erases the item at given position.
				
				\param pos
					The given position.
			*/
			/************************************************************************/
			void erase(const size_t& pos) {
				
				if (pos < vec_size) {
					//Shift values 1 to the left
					for (size_t i = pos; i < vec_size - 1; ++i) {
						store_array[i] = store_array[i + 1];
					}
					--vec_size;
				}
			} //end erase
			
			/************************************************************************/
			/*!
				\brief Insert item into vector.
				Given a position in the vector, inserts the item at given position.
				
				\param pos
					The given position.
				\param item
					The item to be inserted.
			*/
			/************************************************************************/
			void insert(const size_t& pos, const T& item) {
			
				if (pos < vec_size) {

					if (vec_size >= vec_capacity) {
						grow();
					}
					
					for (size_t i = vec_size; i > pos; --i)
					{
						store_array[i] = store_array[i-1];
					}
					store_array[pos] = item;
					++vec_size;
				}			
			} //end insert
			
	}; //end class vector
} //end namespace cs170


/*****************************************************************************/
/*!
	\brief Templated function to print a vector.
	Prints vectors of type T in ascending order.

	\param vec
		Reference of the vector to be printed.
*/
/*****************************************************************************/
template <typename T>
void Print(const cs170::vector<T>& vec) {
	
	for (size_t i = 0; i < vec.size(); ++i) {
		std::cout << vec[i] << "  ";
	}
	std::cout
		<< "("
		<< "size=" << vec.size()
		<< ", "
		<< "capacity=" << vec.capacity()
		<< ")"
		<< std::endl;
}

/*****************************************************************************/
/*!
	\brief Template specialization of Print for unsigned char.
	Prints vectors of type unsigned char in ascending order.

	\param vec
		Reference of the vector to be printed.
*/
/*****************************************************************************/
template <>
void Print(const cs170::vector<unsigned char>& vec) {
	for (size_t i = 0; i < vec.size(); ++i) {
		std::cout << static_cast<unsigned int>(vec[i]) << "  ";
	}
	std::cout
		<< "("
		<< "size=" << vec.size()
		<< ", "
		<< "capacity=" << vec.capacity()
		<< ")"
		<< std::endl;
}

/*****************************************************************************/
/*!
	\brief Template specialization of Print for float.
	Prints vectors of type float in ascending order.

	\param vec
		Reference of the vector to be printed.
*/
/*****************************************************************************/
template <>
void Print(const cs170::vector<float>& vec) {
	for (size_t i = 0; i < vec.size(); ++i) {
		std::cout << std::setw(5) << std::setprecision(3) << vec[i] << "  ";
	}
	std::cout
		<< "("
		<< "size=" << vec.size()
		<< ", "
		<< "capacity=" << vec.capacity()
		<< ")"
		<< std::endl;
}

/*****************************************************************************/
/*!
	\brief Template specialization of Print for double.
	Prints vectors of type double in ascending order.

	\param vec
		Reference of the vector to be printed.
*/
/*****************************************************************************/
template <>
void Print(const cs170::vector<double>& vec) {
	for (size_t i = 0; i < vec.size(); ++i) {
		std::cout << std::setw(7) << std::setprecision(5) << std::left
		<< vec[i] << "  ";
	}
	std::cout
		<< "("
		<< "size=" << vec.size()
		<< ", "
		<< "capacity=" << vec.capacity()
		<< ")"
		<< std::endl;
}