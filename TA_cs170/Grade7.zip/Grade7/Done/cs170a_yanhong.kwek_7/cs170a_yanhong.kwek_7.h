/******************************************************************************/
/*!
\file cs170_vector.h
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 07
\date 15/07/2019
\brief
Header file of a template functions for a vector class.
*/
/******************************************************************************/
///////////////////////////////////////////////////////////////////////////////
#ifndef cs170_vector_H
#define cs170_vector_H
///////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <cstdlib>
#include <iomanip>
#include <typeinfo>

namespace cs170
{
    template <typename T>
    class vector
    {
        public:
        
/******************************************************************************/
/*!
    \brief
    Default constructor for vector.
*/
/******************************************************************************/
            // Default constructor
            vector(): array(nullptr), v_size(0), v_capacity(0) {} 

/******************************************************************************/
/*!
    \brief
    The copy constructor that initializes to parameters.
  
    \param rhs
    The vector to be copied.
*/
/******************************************************************************/
            vector<T> (const vector &rhs)// Copy constructor
            :array(nullptr), v_size(rhs.v_size), v_capacity(rhs.v_capacity)
            {
                array = new T [rhs.v_capacity]();
                for(unsigned int i=0; i < rhs.v_size; i++)
                {
                    array[i] = rhs.array[i];
                }
            }

/******************************************************************************/
/*!
    \brief
    The destructor for vector.
*/
/******************************************************************************/
            ~vector() // Destructor
            {
                delete[] array;
                array = nullptr;
                v_size = 0;
                v_capacity = 0;
            }

/******************************************************************************/
/*!
    \brief
    It gets the number of elements that can be held in the array.
  
    \return
    The number of elements that can be held in the array.
*/
/******************************************************************************/
            unsigned capacity() const
            {
                return v_capacity;
            }

/******************************************************************************/
/*!
    \brief
    It removes all elements in given vector.
*/
/******************************************************************************/
            void clear()
            {
                while (v_size)
                {
                pop_back();
                }
            }

/******************************************************************************/
/*!
    \brief
    To checks if vector is empty.
   
    \return
    Returns true if size is 0, else false.
*/
/******************************************************************************/
            bool empty() const
            {
                return (v_size == 0);
            }
      
/******************************************************************************/
/*!
    \brief
    Erases an item at a specified position.
    
    \param position
    The position of the object to be erased.
*/
/******************************************************************************/
            void erase(unsigned position)
            {
                if (position > v_size)
                {
                    return;
                }
                else if (position == v_size)
                {
                    pop_back();
                }
                else
                {
                    for(unsigned i = position; i < v_size; i++)
                    {
                        array[i] = array[i + 1];
                    }
                    v_size--;
                }
            }

/******************************************************************************/
/*!
    \brief
    The following function inserts a given value at a specified 
    position in the vector.
  
    \param value
    The value to be inserted.
    
    \param position
    The position in the vector to be inserted.
*/
/******************************************************************************/
            void insert(const unsigned& position, const T& value)
            {
                // Check boundary of index being inserted
                check_bounds(position); 
                
                // Pre-increase array if neccessary to avoid losing data
                if((v_size + 1) > v_capacity)
                {
                    increase();
                }
        
                // If inserting at the front
                if(position == 0)
                {
                    // Shift data
                    for(unsigned int i = (v_size - 1); i > position; i--)
                    {
                        array[i + 1] = array[i];
                    }
                    array[1] = array[0];  // Move over the first element
                    array[0] = value;     // Insert value
                    v_size++;             // Increment size
                }
                else
                {
                    // Shift data to the right after inserted position
                    for(unsigned int i = (v_size - 1); i >= position; i--)
                    {
                        array[i + 1] = array[i];
                    }
                    array[position] = value;  // Insert value
                    v_size++;                 // Increment size
                }
            }
      
/******************************************************************************/
/*!
    \brief
    The following function removes data at the back of the vector.
*/
/******************************************************************************/
            void pop_back()
            {
                if(v_size == 0)
                {
                    return;
                }
                else
                {
                    v_size--;
                }
            }

/******************************************************************************/
/*!
    \brief
    The following function inserts a data at the back of the vector.
    
    \param value
    The value to be inserted.
*/
/******************************************************************************/
            void push_back(const T& value)
            {
                if(v_size == v_capacity)   // If full, increase
                {
                    increase();
                }
                if(empty())
                {
                    array[0] = value; // Insert in front
                    v_size++;             // Increment size counter
                    return;
                }
                array[v_size] = value;  // Not empty, insert at back
                v_size++;               // Increment size counter
            }

/******************************************************************************/
/*!
    \brief
    It returns the number of elements stored in the array.
  
    \return
    The number of elements in the array.
*/
/******************************************************************************/
            unsigned size() const
            {
                return v_size;
            }

/******************************************************************************/
/*!
    \brief
    The Assignment operator overload.
  
    \param rhs
    The vector to be used in assignment.
  
    \return
    A reference to the left hand operand once it has been assigned.
*/
/******************************************************************************/
            vector<T>& operator= (const vector& rhs)
            {
                if(this == &rhs)  // check for self assignment
                {
                    return *this;
                }
                // rhs is smaller than lhs so it will fit inside lhs
                if(rhs.v_capacity <= this->v_capacity)
                {
                    for(unsigned int i = 0; i < rhs.v_size; i++)
                    {
                        array[i] = rhs.array[i];
                    }
                    v_size = rhs.v_size;
                    return *this;
                }
                else  // If rhs is larger than lhs
                {
                    clear();  // Clear lhs
                    // Re-allocate lhs to the size needed
                     array = new T[rhs.v_size];
                    // Set capacity to size of rhs
                    v_capacity = rhs.v_size;
                    // Push back data from rhs
                    for(unsigned int i = 0; i < rhs.v_size; i++)
                    {
                        push_back(rhs.array[i]);
                    }
                    return *this; // return lhs
                }
            }
      
/******************************************************************************/
/*!
    \brief
    The subscript overload for rvalues.
  
    \param index
    The index to get data from.
    
    \return
     The integer contained at passed index.
*/
/******************************************************************************/
            const T& operator[](unsigned index) const
            {
                check_bounds(index);
                return array[index];
            }

/******************************************************************************/
/*!
    \brief
    The subscript overload to lvalues.
  
    \param index
    The index to get data from.
  
    \return
    The integer contained at passed index as a reference.
*/
/******************************************************************************/
            T& operator[](unsigned index)
                {
                    check_bounds(index);
                    return array[index];
                }
      
            private:
                  T* array;         // The dynamically allocated array
                  unsigned v_size;      // The number of elements in the array
                  unsigned v_capacity;   // The allocated size of the array
      
/******************************************************************************/
/*!
    \brief
    To checks the boundary of the index.
  
    \param index
    The index to be accessed.
*/
/******************************************************************************/
            void check_bounds(unsigned index) const
            {
                if (index >= v_size)
                {
                    std::abort();
                }
            }
      
/******************************************************************************/
/*!
    \brief
    To increases the capacity of array.
*/
/******************************************************************************/
            void increase()
            {
                v_capacity = (v_capacity) ? v_capacity * 2 : 1;  
                // Double the capacity
                T* growth = new T [v_capacity]; // Allocate new array
                // If original array is not empty copy existing data
                for(unsigned int i = 0; i < v_size; i++)
                {
                    growth[i] = array[i];
                }
                delete[] array;
                array = growth;   // Move pointer to new array
            }
    };
  
/******************************************************************************/
/*!
    \brief
    A Template Print Function to print out a templated vector.
    
    \param rp
    The vector to be printed
*/
/******************************************************************************/
    template <typename T>
    void Print(const vector<T>& rp)
    {
        for (unsigned i = 0; i < rp.size(); i++)
        {
             std::cout << rp[i] << "  ";
        }
        std::cout << "(size=" << rp.size()<< "," << " " << "capacity=" 
        << rp.capacity() << ")"; 
        std::cout << std::endl;
    }
  
/******************************************************************************/
/*!
    \brief
    The following function is a specialised Template Print Function to 
    print out a templated vector of unsigned char.
    
    \param rp
    The vector to be printed
*/
/******************************************************************************/
    template <>
    void Print(const cs170::vector<unsigned char>& rp)
    {
        for (unsigned i = 0; i < rp.size(); i++)
        {
            std::cout << +rp[i] << "  ";
        }
        std::cout << "(size=" << rp.size() << "," << " " << "capacity="
        << rp.capacity() << ")";
        std::cout << std::endl;
    }
  
/******************************************************************************/
/*!
    \brief
    The following function is a specialised Template Print Function to 
    print out a templated vector of float.
    
    \param rp
    The vector to be printed
*/
/******************************************************************************/
    template <>
    void Print (const cs170::vector<float>& rp)
    { 
        for (unsigned i = 0; i < rp.size(); i++)
        { 
            std::cout << std::setw(5) << std::setprecision(3)
            << float (rp[i]) <<"  ";
        } 
        std::cout << "(size=" << rp.size()<< "," << " " << "capacity=" 
        << rp.capacity() << ")"; 
        std::cout << std::endl; 
    }
  
/******************************************************************************/
/*!
    \brief
    The following function is a specialised Template Print Function to 
    print out a templated vector of double.
    
    \param rp
    The vector to be printed
*/
/******************************************************************************/
    template <>
    void Print(const cs170::vector<double>& rp)
    {
        for (unsigned i = 0; i < rp.size(); i++)
        {
            std::cout << std::setw(9) << std::left << std::setprecision(5)
            << rp[i];
        }
        std::cout << "(size=" << rp.size() << "," << " " << "capacity="
        << rp.capacity() << ")";
        std::cout << std::endl;
    }
} // namespace cs170
#endif // cs170_vector_H