/**************************************************************************************************************/
/*!
\file   cs170_vector.h
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 07
\date   15/6/2019
\brief
  Definition of template vector class
*/
/**************************************************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef CS170_VECTOR_H
#define CS170_VECTOR_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream>
#include <iomanip>

/**************************************************************************************************************/
/*!
  \namespace cs170
  \brief Namespace that contains the class vectors and the overloaded operators
*/
/**************************************************************************************************************/
namespace cs170 {

/**************************************************************************************************************/
/*!
  \class vector
  \brief Template Class Representing a Vector. Holds many simple functions like push back and erasing elements.
*/
/**************************************************************************************************************/
template<typename T>
class vector {

	//! Pointer to the Beginning the array
	T* pBegin;
	//! Pointer to the End of the array
	T* pEnd;
	//! Array the Vector represents
	T* v_array;
	//! Value of the capacity of the vector
	size_t v_capacity;
	//! Value of the size of the vector
	size_t v_size;
	
	/**************************************************************************************************************/
	/*!
	  \fn void grow()

	  \brief Allocate more memory (increase capacity) by deleting the previous valarray and replacing it with a new
	   array
	*/
	/**************************************************************************************************************/
	void grow()
	{
		//Temp array to temporarily store data
		T* temparray = nullptr;

		if (v_capacity == 0) {
			// If capacity is 0, turn into one
			v_capacity = 1;
			return;
		}
		else {
			//Increase the capacity
			v_capacity *= 2;
			temparray = new T[v_capacity];	
		}

		//Copy the array, get the end and the beginning of the vector
		pEnd = copy(temparray, v_array, pEnd);
		pBegin = temparray;

		//Delete the array
		delete[] v_array;

		//Set the temporary data into a permanent array
		v_array = temparray;
	}

	/**************************************************************************************************************/
	/*!
	  \fn T* copy(T* copy_begin , T const* ori_begin, T* const ori_end)
	  
	  \brief Deep copies the value of one array to another
	  
	  \param copy_begin Pointer to the beginning of the new array that holds the copied values

	  \param ori_begin Pointer to the beginning of the original array that is copied

	  \param ori_end Pointer to the end of the original array that is copied

	  \return Returns a Pointer to the end of the copied array.
	*/
	/**************************************************************************************************************/
	T* copy(T* copy_begin , T const* ori_begin, T* const ori_end) {
		
		T* currentv = copy_begin;
		T const* currentv2 = ori_begin;
		//Iterates through the vector
		while (currentv2 != ori_end) {
			//Copies the value of original into copy
			*currentv = *currentv2;

			currentv++;
			currentv2++;
		}

		//Return the new end of the copied array
		return currentv;
	}
	
public:


	/**************************************************************************************************************/
	/*!
	  \fn vector()

	  \brief Default constructor for the array
	*/
	/**************************************************************************************************************/
	vector() : v_capacity(0), v_size(0) {
		//creates a "dummy" array
		v_array = new T[1];

		//Define beginning and end of the vector (they are the same pointer as this array is supposedly "empty")
		pBegin = v_array;
		pEnd = v_array;
	}

	/**************************************************************************************************************/
	/*!
	  \fn vector(const vector<T>& v2)

	  \brief Copy constructor that deep copies another array

	  \param v2 Vector to be copied
	*/
	/**************************************************************************************************************/
	vector(const vector<T>& v2) : v_capacity(v2.v_capacity), v_size(v2.v_size) {
		//Creates a new array
		v_array = new T[v2.v_capacity];

		//Copies the values of the original array and puts the values into this array
		pEnd = copy(v_array, v2.v_array, v2.pEnd);
		pBegin = v_array;
	}


	/**************************************************************************************************************/
	/*!
	  \fn ~vector()

	  \brief Destructor for the array
	*/
	/**************************************************************************************************************/
	~vector() {
		delete[] v_array;
	}


	/**************************************************************************************************************/
	/*!
	  \fn bool empty() const 

	  \brief Checks if the function is empty

	  \return Returns a boolean, true is empty, false if not
	*/
	/**************************************************************************************************************/
	bool empty() const {
		return !v_size;
	}

	/**************************************************************************************************************/
	/*!
	  \fn void push_back(const T& element)

	  \brief Pushes another element into the back of the list

	  \param element element added to the back the array
	*/
	/**************************************************************************************************************/
	void push_back(const T& element) {
		//If there is no more capacity to hold the elements, increase the capacity
		if (v_capacity == v_size) {
			grow();
		}
		
		//Add the element to the end of the list
		*pEnd = element;

		//Increase the size of the list
		++pEnd;
		++v_size;
	}

	/**************************************************************************************************************/
	/*!
	  \fn void pop_back()

	  \brief Pops out (Delete) the last element in the array of the vector.  Program will be aborted if the vector
	  is empty with nothing to pop_back
	*/
	/**************************************************************************************************************/
	void pop_back() {

		//Check if the vector is empty
		if (v_capacity == 0 || v_size == 0) {
			std::abort();
		}

		--pEnd;
		--v_size;
	}

	/**************************************************************************************************************/
	/*!
	  \fn void erase(const unsigned int pos)

	  \brief Erases an element at a specified position (unsigned int). If position is larger than vector size,
	  program is aborted

	  \param pos Position of the wanted element in the array of the vector (unsigned int)
	*/
	/**************************************************************************************************************/
	void erase(const unsigned int pos) {
		
		//If the position is larger than the size of the array
		if (pos > (v_size-1)) {
			std::abort();
		}
		
		//Iterate through the vector
		T* pCurr = (pBegin + pos);
		while (pCurr != pEnd) {
			//Assign the next value to this pointer, overriding the value to be deleted
			*pCurr = *(pCurr + 1);

			++pCurr;
		}

		//Decrease the size of the vector
		pEnd = (pCurr - 1);
		--v_size;
	}

	/**************************************************************************************************************/
	/*!
	  \fn void insert(const unsigned int pos, const T& element)

	  \brief Inserts an element into the array of the vector at the given position. If position is larger than vector size,
	  program is aborted

	  \param pos Position of the array of the vector (unsigned int) in which the element may be inserted

	  \param element Refrence to the element that must be added to the array of the vector
	*/
	/**************************************************************************************************************/
	void insert(const unsigned int pos, const T& element) {
		
		if (pos > (v_size - 1)) {
			std::abort();
		}
		
		//If there is no more capacity to hold the elements, increase the capacity
		if (v_capacity == v_size) {
			grow();
		}

		T* pCurr = (pBegin + pos);
		
		//Temp storage to store values
		T temp = *pCurr;
		T temp2;
		
		//Assign the new value into the position
		*pCurr = element;
		++pCurr;

		while (pCurr != pEnd) {
			//Temp2 stores current val
			temp2 = *pCurr;
			//The current pointer gets assigned to Temp (which stores the previous val)
			*pCurr = temp;
			//Stores the Temp2 value into Temp
			temp = temp2;
			++pCurr;
		}

		//Ensure that the last node is accounted for
		*pCurr = temp;

		//Increase the size of the array
		++v_size;
		++pEnd;
	}

	/**************************************************************************************************************/
	/*!
	  \fn size_t size() const

	  \brief Returns the size of the vector

	  \return Returns the size of the vector (size_t)
	*/
	/**************************************************************************************************************/
	size_t size() const {
		return v_size;
	}

	/**************************************************************************************************************/
	/*!
	  \fn void clear()

	  \brief Clears the vector of any elements
	*/
	/**************************************************************************************************************/
	void clear() {
		pBegin = pEnd;
		v_size = 0;
	}

	/**************************************************************************************************************/
	/*!
	  \fn T& operator [](const unsigned int pos)

	  \brief Non-const Member Function Overloading the Subscript Operator,
	  used to directly get a value from the array of the vector. Can be used for assignment

	  \param pos Position of the wanted element in the array of the vector (int)

	  \return Returns a reference to the specified element.
	*/
	/**************************************************************************************************************/
	T& operator [](const unsigned int pos) {
		return v_array[pos];
	}

	/**************************************************************************************************************/
	/*!
	  \fn const T& operator [](const unsigned int pos) const

	  \brief Const Member Function Overloading the Subscript Operator,
	  used to directly get a value from the array of the vector. Can only be used for access

	  \param pos Position of the wanted element in the array of the vector

	  \return Returns a reference to the specified element.
	*/
	/**************************************************************************************************************/
	const T& operator [](const unsigned int pos) const {
		return v_array[pos];
	}

	/**************************************************************************************************************/
	/*!
	  \fn void operator=(const vector<T>& v2)

	  \brief Member Operator Overloaded Assignment function

	  \param v2 Other vector that this vector is assigned to.
	*/
	/**************************************************************************************************************/
	void operator=(const vector<T>& v2) {

		//Assign the capacity and size
		v_capacity = v2.v_capacity;
		v_size = v2.v_size;

		//Temp array to temporarily store data
		T* temp_array = new T[v2.v_capacity];

		//Fills the temp array with the data
		pEnd = copy(temp_array, v2.v_array, v2.pEnd);

		//Delete the original and replace it with the temp
		delete[] v_array;
		v_array = temp_array;

		pBegin = v_array;

	}

	//Operator Overloaded function to print vector data
	template <typename U>
	friend std::ostream& operator<<(std::ostream& os, const cs170::vector<U>& v);

};	//End of vector class

/**************************************************************************************************************/
/*!
  \fn template<typename T> std::ostream& operator<<(std::ostream& os, const cs170::vector<T>& v)

  \brief Overloaded Operator that prints out the elements in the array

  \param os Reference to an ostream object

  \param v Refrence to the vector object to print

  \return Returns a reference to the ostream object
*/
/**************************************************************************************************************/
template<typename T>
std::ostream& operator<<(std::ostream& os, const cs170::vector<T>& v) {
	//If the array is empty, dont try to print array
	if (v.v_capacity != 0 && v.v_size != 0) {
		T* currentv = v.pBegin;
		//Iterates and prints through all elements in the vectors
		while (currentv != v.pEnd) {
			os << *currentv << "  ";
			++currentv;
		}
	}

	os << "(size=" << v.v_size << ", capacity=" << v.v_capacity << ")" ;
	return os;
}

/**************************************************************************************************************/
/*!
  \fn template<> std::ostream& operator<<(std::ostream& os, const cs170::vector<unsigned char>& v)

  \brief Specialisation(unsigned char) of Overloaded Operator that prints out the elements in the array

  \param os Reference to an ostream object

  \param v Refrence to the vector object to print

  \return Returns a reference to the ostream object
*/
/**************************************************************************************************************/
template<>
std::ostream& operator<<(std::ostream& os, const cs170::vector<unsigned char>& v) {
	//If the array is empty, dont try to print array
	if (v.v_capacity != 0 && v.v_size != 0) {
		unsigned char* currentv = v.pBegin;
		//Iterates and prints through all elements in the vectors
		while (currentv != v.pEnd) {
			//cast the char* into an int
			os << static_cast<unsigned int>(*currentv) << "  ";
			++currentv;
		}
	}

	os << "(size=" << v.v_size << ", capacity=" << v.v_capacity << ")" ;
	return os;
}

/**************************************************************************************************************/
/*!
  \fn template<> std::ostream& operator<<(std::ostream& os, const cs170::vector<float>& v)

  \brief Specialisation of Overloaded Operator that prints out the elements in the array (float)

  \param os Reference to an ostream object

  \param v Refrence to the vector object to print

  \return Returns a reference to the ostream object
*/
/**************************************************************************************************************/
template<>
std::ostream& operator<<(std::ostream& os, const cs170::vector<float>& v) {
	//If the array is empty, dont try to print array
	if (v.v_capacity != 0 && v.v_size != 0) {
		float* currentv = v.pBegin;
		//Iterates and prints through all elements in the vectors
		while (currentv != v.pEnd) {
			os << std::setw(5) << std::setprecision(3) << (*currentv) << "  ";
			++currentv;
		}
	}

	os << "(size=" << v.v_size << ", capacity=" << v.v_capacity << ")";
	return os;
}

/**************************************************************************************************************/
/*!
  \fn template<> std::ostream& operator<<(std::ostream& os, const cs170::vector<double>& v)

  \brief Specialisation of Overloaded Operator that prints out the elements in the array (double)

  \param os Reference to an ostream object

  \param v Refrence to the vector object to print

  \return Returns a reference to the ostream object
*/
/**************************************************************************************************************/
template<>
std::ostream& operator<<(std::ostream& os, const cs170::vector<double>& v) {
	//If the array is empty, dont try to print array
	if (v.v_capacity != 0 && v.v_size != 0) {
		double* currentv = v.pBegin;
		//Iterates and prints through all elements in the vectors
		while (currentv != v.pEnd) {
			os << std::setw(9) << std::left << std::setprecision(5) << (*currentv);
			++currentv;
		}
	}

	os << "(size=" << v.v_size << ", capacity=" << v.v_capacity << ")";
	return os;
}

} //End of Namespace cs170


/**************************************************************************************************************/
/*!
  \fn template<typename U> void Print(const cs170::vector<U>& v)

  \brief Prints out the vector

  \param v vector to be printed
*/
/**************************************************************************************************************/
template<typename U>
void Print(const cs170::vector<U>& v) {
	std::cout << v << std::endl;
}





#endif                          // CS170_VECTOR_H