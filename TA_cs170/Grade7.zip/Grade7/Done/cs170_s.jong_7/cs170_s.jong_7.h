/******************************************************************************/
/*!
\file Point.cpp
\author Jong Sze kuan Melvin
\par email: s.jong\@digipen.edu
\par DigiPen login: s.jong
\par Course: CS170a
\par Lab 07
\date 8/07/2019
\brief
 This files contain functions
*/
/******************************************************************************/
#ifndef CS170_VECTOR_H
#define CS170_VECTOR_H
#include <iostream>
#include <iomanip>
#include <cstdlib>

namespace cs170
{
  template <typename T> class vector
  {
    public:
        vector();  //default constructor
        ~vector();
        vector(const vector &copy);
        
        void clear();
        bool empty() const;
        void erase(const int &pos);
        void insert(const int &pos, const T &tmp);
        T pop_back(void);
        void push_back(const T tmp);
        
        unsigned int size() const {return siz;}
        unsigned int capacity() const {return cap;}
        void expandcapacity();
        
        T& operator[](const int &tmp){return array[tmp];}
        const T& operator[](const int &tmp) const {return array[tmp];}
        T& operator=(const vector& copy);
        
    private:
       T *array;
       int siz;
       int cap;
  };
/******************************************************************************/
/*!
  \brief
   Default constructor that creates vector class with size, 
   capacity and pointer.
*/
/******************************************************************************/  
  template<typename T>
  vector<T>::vector(): array(new T [cap]), siz(0), cap(0) {}
/******************************************************************************/
/*!
  \brief
   The destructor to delete memory allocated for the vector.
*/
/******************************************************************************/  
  template<typename T>
  vector<T>::~vector()
  {
    delete[] array;
    array = nullptr;
    siz = 0;
    cap = 0;
  }
/******************************************************************************/
/*!
  \brief
   Copy constructor.
  \param copy
   copy a object that need to be copy.
*/
/******************************************************************************/    
  template<typename T>
  vector<T>::vector(const vector &copy)
  {
    siz = copy.siz;
    cap = copy.cap;
    if (cap == 0) array = nullptr;
    else array = new T [cap];
    for (int i = 0; i < siz; i++) array[i] = copy.array[i];
  }
/******************************************************************************/
/*!
  \brief
   Clear the vector and set the size to zero.
*/
/******************************************************************************/    
  template<typename T>
  void vector<T>::clear()
  {
    siz = 0;
  }
/******************************************************************************/
/*!
  \brief
   Return true or false based on whether vector is empty.
*/
/******************************************************************************/    
  template<typename T>
  bool vector<T>::empty() const
  {
    return (siz == 0);
  }
/******************************************************************************/
/*!
  \brief
   Erase the value at a given position.
  \param copy
   pos is the position where value is erased.
*/
/******************************************************************************/    
  template<typename T>
  void vector<T>::erase(const int &pos)
  {
    for (int i = pos; i < siz -1; i++)
    {
      array[i] = array[i+1];
    }
    --siz;
  }
/******************************************************************************/
/*!
  \brief
   Insert the given value at given position.
   
  \param pos
   pos is the position where value is inserted.
   
  \param tmp
   tmp is value inserted.
*/
/******************************************************************************/    
  template<typename T>
  void vector<T>::insert(const int &pos, const T &tmp)
  {
    if (siz == cap) expandcapacity();
    for (int i = (siz -1); i >= pos; i--)
    {
      array[i+1] = array[i];
    }
    array[pos] = tmp;
      ++siz;
  }
/******************************************************************************/
/*!
  \brief
   Pops an element from the vector.
*/
/******************************************************************************/   
  template <typename T>
  T vector<T>::pop_back(void)
  {
    return array[--siz];
  }
/******************************************************************************/
/*!
  \brief
   insert a value at the end of vector.
   
  \param tmp
   tmp is the number to be inserted at the end of array.
*/
/******************************************************************************/    
  template<typename T>
  void vector<T>::push_back(const T tmp)
  {
    if (siz == cap) expandcapacity ();
    array[siz++] = tmp;
  }
/******************************************************************************/
/*!
  \brief
    Dynamically expend the capacity when needed. 
    The capacity double after function call.
*/
/******************************************************************************/    
  template<typename T>
  void vector<T>::expandcapacity()
  {
    if (cap == 0) cap = 1;
    else cap = cap * 2;
    T *exp = new T[cap];
    for(int i = 0; i < siz ; i++) exp[i] = array[i];
    if (array != nullptr) delete[] array;
    array = exp;
  }
/******************************************************************************/
/*!
  \brief
   Create a new vector with the given reference of the vector.
   
  \param copy
   copy is reference to vector and used to initialize the new vector.
*/
/******************************************************************************/    
  template<typename T>
  T& vector<T>::operator=(const vector& copy)
  {
    if (this != &copy)
    {
      if ( array != nullptr )
      {
        delete[] array;
        this->siz = copy.siz;
        this->cap = copy.cap;
        array = (cap == 0) ? nullptr : new T [this->cap];
      }
    }
    return *array;
  }
}
/******************************************************************************/
/*!
  \brief
   Print function for all datatypes.
*/
/******************************************************************************/  
template<typename T>
void Print(const cs170::vector<T> &tmp)
{
  for (unsigned i = 0; i < tmp.size(); i++)
  std::cout << tmp[i] << " ";
  std::cout << "(size=" << tmp.size()<< "," << " " << "capacity="
  << tmp.capacity() << ")";
  std::cout << std::endl;
}
/******************************************************************************/
/*!
  \brief
   Print function for float datatypes.
*/
/******************************************************************************/  
template<>
void Print(const cs170::vector<float> &tmp)
{
  for (unsigned i = 0; i < tmp.size(); i++)
  {
    std::cout << std ::setw(5) << std::setprecision(3)
    << float (tmp[i]) << " ";
  }
  std::cout << "(size=" << tmp.size()<< "," << " " << "capacity="
  << tmp.capacity() << ")";
  std::cout << std::endl;
}
/******************************************************************************/
/*!
  \brief
   Print function for unsigned char datatypes.
*/
/******************************************************************************/  
template<>
void Print(const cs170::vector<unsigned> &tmp)
{
  for (unsigned i = 0; i < tmp.size(); i++)
  std::cout << tmp[i] << " ";
  std::cout << "(size=" << tmp.size()<< "," << " " << "capacity="
  << tmp.capacity() << ")";
  std::cout << std::endl;
}
/******************************************************************************/
/*!
  \brief
   Print function for double datatypes.
*/
/******************************************************************************/  
template<>
void Print(const cs170::vector<double> &tmp)
{
  for (unsigned i = 0; i < tmp.size(); i++)
  std::cout << std::setw(9) << std::left << std::setprecision(5)
  << tmp[i];
  std::cout << "(size=" << tmp.size()<< "," << " " << "capacity="
  << tmp.capacity() << ")";
  std::cout << std::endl;
}
#endif