
/******************************************************************************/
/*!
\file   list.cpp
\author Ahmad Faruq bin Ahmad Zafir
\par    email: a.ahmadzafir@\digipen.edu
\par    DigiPen login: a.ahmadzafir 
\par    Course: CS170
\par    Lab 2
\date   25 January 2019 1630
\brief  This file decides which inputs are to be added to the front
        and to the end of the linkedlist by their value using functions AddToFront, AddToEnd. 
        It also frees the memory allocated for the data structure using FreeList. In Addition
        to this, this file also finds, inserts and deletes nodes based on the input values through
        functions Find and Insert and Delete respectively and it holds the function Concat which 
        Concatenates two lists together.
 
*/
/******************************************************************************/

#include <iostream>
#include <iomanip>
#include "list.h"

/******************************************************************************/
   /*!
        
      \brief
        The following function allocates memory and set members of 
        the struct node.
            
      \param value
        takes in an int value from main.cpp.
        
      \return pNode
        Returns the pNode value back, which is the address of the node
        created
    */
/******************************************************************************/

Node *MakeNode(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;

  return pNode;
}

/******************************************************************************/
   /*!
      
      
      \brief
       Prints the members of the list in the order assigned 
            
      \param list
        Node const *list is a pointer to a list of nodes
        

    */
/******************************************************************************/

void PrintList(Node const *list) {
  while (list) {
    std::cout << std::setw(4) << list->value;
    list = list->next;
  }
  std::cout << std::endl;
}

/******************************************************************************/
   /*!
        
      \brief
       Counter for the number of nodes in the linked list
            
      \param list
        Node const *list is a pointer to a list of nodes
        
      \return int
        Returns the integer value of the number of nodes in the linked list
      
    */
/******************************************************************************/

int Count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/******************************************************************************/
   /*!
        
      
      \brief
       Adds a new input member to the end of the linked list
            
      \param pList
       Points to the first node of the linked list
       
      \param value
       the value stored in a node
        
      
    */
/******************************************************************************/

void AddToEnd(Node **pList, int value) {
  Node *pNewNode = MakeNode(value);
  Node *pCurrNode = *pList;

  if (*pList == 0)
    *pList = pNewNode;
  else {
    while (pCurrNode->next) pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }
}

/******************************************************************************/
   /*!
        
      
      \brief
       Adds a new input member to the front of the linked list
            
      \param pList
       Points to the first node of the linked list
       
      \param value
       the value stored in a node
        
      
    */
/******************************************************************************/

void AddToFront(Node **pList, int value) {
  Node *pNewNode = MakeNode(value);
  pNewNode->next = *pList;
  *pList = pNewNode;
}

/******************************************************************************/
   /*!
        
      
      \brief
       Frees the memory allocated for the data structure
            
      \param list
       Node const *list is a pointer to a list of nodes
        
      
    */
/******************************************************************************/

void FreeList(Node *list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
}


/******************************************************************************/
   /*!
        
      
      \brief
       Finds the first node that holds the number which is equal
       to the value input and returns a nullptr if not found
            
      \param list
       Node const *list is a pointer to a list of nodes
       
      \param value
       the value stored in a node
        
      \return pCurrNode
       the address of where the input value is found
       
      \return nullptr
       if no node holding the value is found
      
    */
/******************************************************************************/

Node *Find(Node *list, int value) {
    
    
    Node *pCurrNode=list;
    
    if (pCurrNode==nullptr)
    {
        return nullptr;
    }
    
        
    while(pCurrNode!=NULL)
    {
        if(pCurrNode->value == value)
        {
            return pCurrNode;
        }
        
        else
        {
            pCurrNode = pCurrNode->next;
        }
    }
    
    return nullptr;
}


/******************************************************************************/
   /*!
        
      
      \brief
       Finds the first node that holds the number which is equal
       to the value input and deletes the node
        
      \param pList
       Points to the first node of the linked list
       
      \param value
       the value stored in a node
        
      
    */
/******************************************************************************/

void Delete(Node **pList, int value) {
    
    Node *pCurrNode=*pList;
    
    Node *temp = *pList;
    
    if(pCurrNode==NULL)
    {
        *pList= nullptr;
        
        return;
    }
    
    else if(pCurrNode->value==value)
    {
        *pList = pCurrNode->next;
        delete pCurrNode;
        return;
    }
    
    
    
    while(pCurrNode!=NULL){
        
        if(pCurrNode->value == value)
        {
            temp->next=pCurrNode->next;
            delete pCurrNode;
            return;
        }
        
        else
        {
            temp=pCurrNode;
            pCurrNode = pCurrNode->next;
        }
    }
    
    return;

}


/******************************************************************************/
   /*!
        
      
      \brief
       Inserts a new node holding the value at the position 
       specified by the input
        
      \param pList
       Points to the first node of the linked list
       
      \param value
       The value stored in a node
      
      \param position
       Desired position which is a user input
       
      
    */
/******************************************************************************/

void Insert(Node **pList, int value, int position) {
    
    int i = Count(*pList);
    
    if(position==0)
        
    {
    AddToFront(pList,value);
    return;
    }
    
    else if (position>=i)
    {
        AddToEnd(pList, value);
        return;
    }
    
    else
    {
    Node*pCurrNode=*pList;
    Node*temp= *pList;
    Node *pNewNode=MakeNode(value);
    
        
    while(position!=0)
        
    {
        pCurrNode = pCurrNode->next;
        position-=1;
    }
    
    pNewNode->next = pCurrNode;
    temp->next=pNewNode;
    
    return;
    }

        
}

/******************************************************************************/
   /*!
        
      
      \brief
       Concatenates two lists provided
        
      \param pList1
       Points to the first node of one linked list
       
      \param pList2
       Points to the first node of another linked list
      
      
    */
/******************************************************************************/

void Concat(Node **pList1, Node **pList2) {
    
    Node*pCurrNode=*pList1;
    
     if (pCurrNode==NULL)
         
 {
     if(pList2!=NULL)
     {
         
     *pList1=*pList2;
     *pList2=nullptr;
     return;
     
     }
 } 
 
    while(pCurrNode->next!=NULL)
    {
        pCurrNode = pCurrNode->next;
    }
    
    pCurrNode->next = *pList2;
    *pList2=nullptr;
        
}

