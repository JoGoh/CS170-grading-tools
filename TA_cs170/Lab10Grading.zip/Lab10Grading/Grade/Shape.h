/******************************************************************************/
/*!
\file   main.cpp
\author Nachiappan Manickam
\par    email: n.manickam\@digipen.edu
\par    DigiPen login: n.manickam 
\par    Course: CS170
\par    Lab 10
\date   7/28/2018 
\brief  
   The following functions implemented in lab 10 (main.cpp) is done using the
   in built STL, std::vector which Allows direct access to any element in the 
   sequence, even through pointer arithmetics, and provides relatively fast 
   addition/removal of elements at the end of the sequence. The Point class and 
   color class implemented in this file is a stand alone class.
   It takes in parameters via the Polygon class and shape class resepectivly.
   The operator << is used to print the objects of the  resepective class 
   when constructed. An iterator is also used in the ostream fucntion 
   to access the elements of the vector stored. Apart from this, a Draw 
   function is also implemented to just simulate the drawing process. Virtual
   destructors are also used in this main.cpp.
*/
/******************************************************************************/
#ifndef SHAPE_H
#define SHAPE_H

#include <iostream>
#include <vector>
 
using namespace std;

struct Point 
{  
    int x_, y_;
    Point(int x = 0, int y = 0) : x_(x), y_(y){}
    ~Point(){}
};

struct Color 
{   
    int r_, g_, b_;    
    Color(int x = 0, int y = 0, int z = 0) : r_(x), g_(y), b_(z){}
    ~Color(){}
};

class Shape 
{     
    public: 
    vector<Color>cdeck;
    Shape(){cout << "Shape() ";}
    virtual ~Shape() = 0; 
    virtual void Draw() = 0;
    friend std::ostream& operator<<(std::ostream& os, const Shape& nshape);
    
    //Assignment operator (Deep Copy)
    Shape& operator=(const Shape& rp)
    {
       cdeck=rp.cdeck;
       return *this;
    } 
    
    //Copy Constructor (Shallow Copy)
    Shape(const Shape& sr)
    {
        cdeck=sr.cdeck;
    }
};

//pure virtual function definition 
void Shape::Draw(){cout << "Draw shape ";}

//pure virtual destructor definition
Shape::~Shape(){cout << "~Shape() ";}

class Polygon : public Shape 
{ 
    public:
    vector<Point>deck;
    Polygon(){cout << "Polygon() ";}
    virtual ~Polygon(){cout << "~Polygon() ";} 
    virtual void Draw()
    {
        Shape::Draw();
        cout << "Draw polygon ";
    }
    friend std::ostream& operator<<(std::ostream& os, const Polygon& npoly);
    
    //Assignment operator (Deep Copy)
    Polygon& operator=(const Polygon& rp)
    {
       deck=rp.deck;
       return *this;
    }
    //Copy Constructor (Shallow Copy)
    Polygon(const Polygon& pr) : Shape(pr)
    {
        deck = pr.deck;
    }
};

class Line : public Polygon
{
    public:
    Line(const Color& p0 = Color(), const Point& p1 = Point(), 
    const Point& p2 = Point())
    {
        cout << "Line() ";
        cdeck.push_back(p0);
        deck.push_back(p1);
        deck.push_back(p2);   
    }
    ~Line(){cout << "~Line() ";}
    void Draw()
    {
        Polygon::Draw();
        cout << "Draw line "; 
    }
    friend std::ostream& operator<<(std::ostream& os, const Line& nline);
    
     //Assignment operator (Deep Copy)
    Line& operator=(const Line& rp)
    {
        this->Polygon::operator=(rp);
        return *this;
    }
    
    //Copy Constructor (Shallow Copy)
    Line(const Line& lr) : Polygon(lr) {}     
};

class Triangle : public Polygon
{ 
    public:
    Triangle(const Color& p0 = Color(), const Point& p1 = Point(), 
    const Point& p2 = Point(), const Point& p3 = Point())
    {
        cout << "Triangle() ";
        cdeck.push_back(p0);
        deck.push_back(p1);
        deck.push_back(p2);
        deck.push_back(p3);
    }
    ~Triangle(){cout << "~Triangle() ";}
    void Draw()
    {
        Polygon::Draw();
        cout << "Draw triangle "; 
    }
    friend std::ostream& operator<<(std::ostream& os, Triangle& ntri);
    
    //Assignment operator (Deep Copy)
    Triangle& operator=(const Triangle& rp)
    {
        this->Polygon::operator=(rp); 
        return *this;
    }
    
    //Copy Constructor (Shallow Copy)
    Triangle(const Triangle& tr) : Polygon(tr) {}
};

class Circle : public Shape 
{ 
    public:
    Point cent;
    int radi;
    Circle(const Color& p0 = Color(), const Point& p1 = Point(), 
    int z = 1) : cent(p1),radi(z)
    {
        cdeck.push_back(p0);
        cout << "Circle() ";
    }  
    ~Circle(){cout << "~Circle() ";} 
    void Draw()
    { 
        Shape::Draw();
        cout << "Draw circle "; 
    }
    
    friend std::ostream& operator<<(std::ostream& os, Circle& ncir);
    
    //Assignment operator (Deep Copy)
    Circle& operator=(const Circle& rp)
    {
        this->cent = rp.cent;
        this->radi = rp.radi;
        this->Shape::operator=(rp); 
        return *this;
    }
    
    //Copy Constructor (Shallow Copy)
    Circle(const Circle& tr) : Shape(tr) {}
};

//ostream for Point
std::ostream& operator<<(std::ostream& os, const Point& npt)
{
    os << "Point"<<"(" << npt.x_ << "," << npt.y_ << ")";
    return os; 
} 

//ostream for Color
std::ostream& operator<<(std::ostream& os, const Color& ncol)
{
    os <<"Color"<<"(" << ncol.r_ << "," << ncol.g_<< "," <<ncol.b_ << ")";
    return os;   
}

//ostream for Line
std::ostream& operator<<(std::ostream& os, const Line& nline)
{
    cout << "Line("<< (Polygon&) nline << ")";
    return os;  
}

//ostream for Triangle
std::ostream& operator<<(std::ostream& os, Triangle& ntri)
{
    cout << "Triangle(" <<(Polygon&) ntri << ")"; 
    return os;   
}

//ostream for Polygon
std::ostream& operator<<(std::ostream& os, const Polygon& npoly)
{ 
    cout << "Polygon(";
    cout << (Shape&) npoly;
    vector<Point>::const_iterator mv;
    mv = npoly.deck.begin();
    while (mv != npoly.deck.end())
    {
        os <<*mv;
        mv++;
        if (mv != npoly.deck.end())
        {
            cout << " ";
        }
    }     
     cout << ")";
     return os;    
}

//ostream for Circle
std::ostream& operator<<(std::ostream& os, Circle& ncir)
{
    cout << "Circle(";
    os << (Shape&) ncir <<ncir.cent << " " << ncir.radi << ")";
    return os;
}

//ostream for Shape
std::ostream& operator<<(std::ostream& os, const Shape& nshape)
{
    cout << "Shape(";
    vector<Color>::const_iterator it;
    for (it = nshape.cdeck.begin(); it != nshape.cdeck.end(); it++)
    {
        os <<*it;
    } 
     cout << ")";
     cout << " ";
     return os;
}

#endif