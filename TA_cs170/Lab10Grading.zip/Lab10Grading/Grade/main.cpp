#include <iostream>
#include "Shape.h"

using namespace std;

int main() {

	cout << "1" << endl;
	Line l; 
	cout << endl;

	cout << "2" << endl;
	Triangle t;
	cout << endl;

 	cout << "3" << endl;
	Circle c;
	cout << endl; 

	cout << "4" << endl;
	cout << l;
	cout << endl;

	cout << "5" << endl;
	cout << t;
	cout << endl;

	cout << "6" << endl;
	cout << c;
	cout << endl;

	cout << "7" << endl;
	l.Draw();
	cout << endl;

	cout << "8" << endl;
	t.Draw();
	cout << endl;

	cout << "9" << endl;
	c.Draw();
	cout << endl;

	cout << "10" << endl;
	Shape * a[3];
	a[0] = &l;
	a[1] = &t;
	a[2] = &c;

	for (int i = 0; i < 3; ++i)
	{
		a[i]->Draw();
		cout << endl;
	}

	cout << "11" << endl; 

	return 0;
}