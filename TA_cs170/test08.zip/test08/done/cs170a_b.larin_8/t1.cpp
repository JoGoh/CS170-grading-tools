/*****************************************************************************/
/*!
\file t1.cpp
\author Benjamin Julian M. Larin
\par email:
b.larin\@digipen.edu
\par DigiPen login:
b.larin
\par Course:
CS170-A
\par Lab #8
\date 21/07/2019
\brief This file contains the implementation of the following functions for
the Lab #8 t1.

\par Hours spent on this assignment:
  3 hrs

\par Specific portions that gave you the most trouble:
  t1

*/
/*****************************************************************************/
#include <iostream>

int main()
{
  unsigned numMB = 0;

  while (1)
  {
    try
    {
      new char[1024 * 1000];
      ++numMB;
    
    }
    catch (...)//general catch
    {
      break;
    }
  }

  std::cout << "Memory allocated in MB: " << numMB << std::endl;
  
  system("pause");
  return 0;

}