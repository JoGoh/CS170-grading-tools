/*****************************************************************************/
/*!
\file t3.cpp
\author Benjamin Julian M. Larin
\par email:
b.larin\@digipen.edu
\par DigiPen login:
b.larin
\par Course:
CS170-A
\par Lab #8
\date 21/07/2019
\brief This file contains the implementation of the following functions for
the Lab #8 t3.

\par Hours spent on this assignment:
  3 hrs

\par Specific portions that gave you the most trouble:
  t1

*/
/*****************************************************************************/
#include <iostream>

int main()
{
  unsigned ctr = 0;
  long long result = 0, num = 0;

  std::cout << "input 10 positive integers:" << std::endl;

  while (ctr++ < 10)
  {
    std::cout << "input a positive integer:" << std::endl;
    std::cin >> num;
    try
    {
      if (std::cin.fail() || num < 0)//if input is not a number or negative
        throw "\nThe number you have entered is either: "
              "\n-not a positive integer."
              "\n-not a number."
              "\nProgram restarting...\n";
    }
    catch (const char* errorMSG)
    {
      std::cin.clear();//clears the cin error flag
      std::cin.ignore(10000, '\n');//skips to the new line
      std::cout << errorMSG << std::endl;
      ctr = 0;
      result = num = 0;
    }
    result += num;
  }

  std::cout << "The total sum was: " << result << std::endl;

  return 0;

}