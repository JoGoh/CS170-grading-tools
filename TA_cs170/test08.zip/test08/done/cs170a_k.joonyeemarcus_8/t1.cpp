/******************************************************************************/
/*!
\file t1.cpp
\author Koh Joon Yee Marcus
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: cs170
\par Lab : 08
\date 22/07/2019
\brief
This file contains the implementation of case t1

\par Hours spent on this assignment: 1

*/
/******************************************************************************/

#include<iostream>
int main()
{
	int counter =0;
    try
    {
        // Keep allocating memory dynamically on heap
        // in a cycle till new throws an exception
		std::cout << "Allocating memory..." << std::endl;
        while(1)
        {
            char * ptr = new char[1024*1000];
			counter++;
			(void)ptr; //pedantic
        }
    }
    catch(...)
    {
        std::cout << "Error: Out Of Memory "<< '\n';
    }
	
	std::cout<<"MegaBytes(MB) allocated:"<< counter<<std::endl;
    return 0;
}