/******************************************************************************/
/*!
\file t2.cpp
\author Koh Joon Yee Marcus
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: cs170
\par Lab : 08
\date 22/07/2019
\brief
This file contains the implementation of case t2

\par Hours spent on this assignment: 1

*/
/******************************************************************************/
#include <iostream>

int main()
{
	//Represents how many inputs has been taken
	double sum = 0.0;
	double input = 0.0;
	int count = 0;
	bool restart = true;
	
	//Initial Message
	std::cout << "Please give 10 positive inputs." << std::endl;
	
	while (restart)
	{
		try
		{
			for (; count < 10; ++count)
			{
				std::cout <<"Please enter number " << count+1 <<": " <<std::endl;
				std::cin >> input;
				
				if (std::cin.fail())
					throw "Invalid input! Non-number detected.";
				else if (input < 0.0)
					throw "Invalid input! Negative number detected.";
				else
					sum += input;
			}
			
			std::cout << "Sum is " << sum << "." << std::endl;
			restart = false;
		}
		catch(const char* errMsg)
		{
			std::cout << errMsg << std::endl;
			std::cout << "Exiting Program" <<std::endl;
			std::exit(0);
		}
	}
}