/*************************************************************************/
/*!
\file t1.cpp
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: cs170
\par Lab #8
\date 15/07/2019
\brief
This file uses exception mechanism to calculate how much memory (in MB) 
can be allocated in a program.

Hours spent on this assignment: 1 hour
Specific portions that gave you the most trouble: To delete the assigned
  memory or not.
*/
/*************************************************************************/
#include <iostream>

int main()
{
  unsigned counter = 0;
  try
  {
    while(1)
    {
      new char[1024 * 1000];
      ++counter;
    }
  }
  catch(...)
  {
    std::cout << "Memory allocated is " << counter << std::endl;
  }
  
  return 0;
}