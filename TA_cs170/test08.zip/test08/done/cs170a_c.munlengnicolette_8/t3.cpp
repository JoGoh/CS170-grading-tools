/*************************************************************************/
/*!
\file t3.cpp
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: cs170
\par Lab #8
\date 15/07/2019
\brief
This file calculates and shows sum of 10 positive inputs. 
During the input, program should use exception mechanism to display 
a message that it doesn't allow negative numbers or not-a-numbers (NAN) 
if so is the input and suggests to restart the process of counting from 
the beginning.

Hours spent on this assignment: 
Specific portions that gave you the most trouble: 
*/
/*************************************************************************/

#include <iostream>

int main()
{
  unsigned counter = 0;
  long long sum = 0, input = 0;
  
  std::cout << 
  "Program to calculate and show sum of 10 positive inputs" 
  << std::endl;
  
  while (counter < 10)
  {
    if(counter == 0)
      std::cout << "Please input 10 positive numbers" << std::endl;

    std::cout << counter+1 << ") ";
    std::cin >> input;      // get input
    
    ++counter;
    
    try 
    {
      if (input < 0 || std::cin.fail())
        throw("\nThe number you entered is a negative number "
                "or not-a-number.\n"
                "Restarting program...\n");
    }
    catch(const char* errMsg)
    {
      std::cin.clear();
      std::cin.ignore(10000, '\n');
      std::cout << errMsg << std::endl;
      sum = input = counter = 0;    // restart counter, sum and input
    }
    sum += input;
  }
  std::cout << "The total sum is: " << sum << std::endl;
  
  return 0;
}