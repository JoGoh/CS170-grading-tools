/******************************************************************************/
/*!
\file               t3.cpp
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab08
\par Course:        CS170
\date:              17/07/2019
\brief
        This file contains the implementations of the following
        functions for the Lab08
        
Functions include:
          Input_Amount
          CheckString

Hours spent on this assignment: 30min
Specific portions that gave you the most trouble: cin.ignore
*/
/******************************************************************************/
#include <iostream> //std::cout , std::endl
#include <string>   //std::stoi

//Number from 0-9 in Ascii Table
#define decimal_point 46
#define lowest_No 48
#define highest_No 57

using namespace std;

void CheckString(string curr_String)
{
    for(char& c : curr_String)
    {
      if( (c < lowest_No && c != decimal_point) || c > highest_No)
        throw("Wrong Input");
    }
}

namespace
{
    double result = 0; //Global variable
}

void Input_Amount(double value)
{
   result += value;
}

int main()
{
  int max_Input = 10;
  double user_Input = 0;
  char tempChar = '0';
  std::string User_Input;
  
  cout << "This program does not accept negative numbers or NAN." << endl;
  cout << "Please enter your 10 positive input" << endl;  
  
  while(max_Input > 0)
  {
    cout << "Enter an integer number\n";
    cin >> User_Input;
    try
    {
      CheckString(User_Input);
      user_Input = std::stod(User_Input);
      Input_Amount(user_Input);
      --max_Input;
    }
    
    catch(...)
    {
      cin.clear();
      cin.ignore();
      cout << "You have entered a wrong input" << endl;
      cout << "Press 0 to restart the program" << endl;
      
      cin >> tempChar;
      if(tempChar == '0')
      {
        result = 0;
        max_Input = 10;
             
        cout << "This program does not accept negative numbers or NAN." << endl;
        cout << "Please enter your 10 positive input" << endl;
      }
      else 
      {
        cout << "Exit the program" << endl;
        exit(1);
      }
    }
    
    cout << "Remaining Input left: " << max_Input << endl;
  }

  cout<< "The final result is: "<< result <<endl;
  return 0;
}