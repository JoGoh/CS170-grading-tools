/******************************************************************************/
/*!
\file               t1.cpp
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab08
\par Course:        CS170
\date:              17/07/2019
\brief
        This file contains the implementations of the following
        functions for the Lab08
        
Functions include:
          ignore

Hours spent on this assignment: 30min
Specific portions that gave you the most trouble: new char
*/
/******************************************************************************/
#include <iostream> // cout, endl
#include <new> // bad_alloc

//Use to supress not in used variable warning
char* ignore(char * a)
{
   return a;
}

int main(void)
{
  double mem_Allocated = 0;
  
  while(1) //Infinite Loop
  {
    try
    {
      char* x = new char[1024*1000];
      ignore(x);
      ++mem_Allocated; //This is cause in Memory terms, 1MB = 1024
    }
    catch(...)
    {
      using namespace std;
      cout << "Memory Allocated: " << mem_Allocated << "MB" << endl;
      return 0;
    }
  }
  
  return 0;
}