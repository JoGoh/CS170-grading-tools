/******************************************************************************/
/*!
\file Point.cpp
\author Jong Sze kuan Melvin
\par email: s.jong\@digipen.edu
\par DigiPen login: s.jong
\par Course: CS170a
\par Lab 08
\date 22/07/2019
\brief
 This files contain functions
*/
/******************************************************************************/
#include <iostream>

int main()
{
  int i=0;
  int total=0;
  int array[10];
  std::cout<<"Please enter 10 positive numbers:\n";
  
  try
  {
    while (i!=10)
    {
      std::cin>>array[i];
      
      if(array[i]<0 || std::cin.fail())
      {
        throw(array[i]);
      }
      else
      {
        total+=array[i];
      }
      i++;
  }
  std::cout<<"sum is :\n" << total;
 }

 catch(...)
 {
  std::cout<<"NAN\n";
  std::cout<<"Program terminated.\n";
 }
 return 0;

}