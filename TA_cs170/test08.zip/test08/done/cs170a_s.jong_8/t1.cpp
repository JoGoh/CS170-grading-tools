/******************************************************************************/
/*!
\file Point.cpp
\author Jong Sze kuan Melvin
\par email: s.jong\@digipen.edu
\par DigiPen login: s.jong
\par Course: CS170a
\par Lab 08
\date 22/07/2019
\brief
 This files contain functions
*/
/******************************************************************************/
#include <iostream>

int main()
{
  int totalsize=0;
  
  try
  {
    while(1)
    {
      new char[1024*1000];
      totalsize++;
    }
  }
  catch(...)
  {
    std::cout<<"Max size of program is "<<totalsize<<"MB";
  }
  return 0;
  
}