/******************************************************************************/
/*!
\file Point.cpp
\author Jong Sze kuan Melvin
\par email: s.jong\@digipen.edu
\par DigiPen login: s.jong
\par Course: CS170a
\par Lab 08
\date 22/07/2019
\brief
 This files contain functions
*/
/******************************************************************************/
#include <iostream>

int i=0;
int total=0;
int array[10];

int test()
{
  std::cout<<"Please enter 10 positive numbers:\n";
  
    while(i!=10)
    {
      std::cin>>array[i];
      try
      {
      if(array[i]<0||std::cin.fail())
      {
        std::cin.clear();
        throw(array[i]);
      }
      else
      {
        total+=array[i];
      }
      i++;
    }
    catch(...)
   {
      std::cout<< array[i] << "is not a positive number\n";
      std::cin.clear();
      std::cout<<"Input 1 to Terminate or 2 to restart \n";
      int inputs=0;   
      std::cin>> inputs;
    
    while(inputs!=1&&inputs!=2)
    {
      std::cout << "Error, Please enter 1 or 2\n";
      std::cin>> inputs;
      std::cin.clear();
      std::cin.ignore(10000, '\n');
    }
    
    if(inputs==1)
    {
      std::cout<<"Program Terminated \n";
      inputs=0;
      return 0;
    }
    else if (inputs==2)
    {
      std::cout<<"Continue tp count \n";
      inputs=0;
      test();
    }
   }
  }
  return total;
}
int main()
{
  int sum = test();
  
  if (sum>=0)
  {
    std::cout<<"sum is : " << total;
  }
  return 0;
}