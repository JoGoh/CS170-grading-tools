/******************************************************************************/
/*! 
\file   t1.cpp
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 08
\date   22/7/2019 
\brief  Exceptions
*/ 
/******************************************************************************/
#include <iostream>
#include <new>

int main()
{
  int count = 0;
  try
  {
    while(1)
    {
      char *mleak = new char[1024*1000];
      *mleak = 0;
      ++count;
    }
  }
  catch(std::bad_alloc& ba)
  {
    std::cout<< "Exception thrown at " << count << "Mb"; 
  }
  return 0;
}