/******************************************************************************/
/*! 
\file   t4.cpp
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 08
\date   22/7/2019 
\brief  Exceptions
*/ 
/******************************************************************************/
#include <iostream>

int main()
{
  double total = 0;
  std::cout<< "Please enter 10 positive inputs:";

  for(int i=0; i != 10; ++i)
  {  
    double value = 0;
    try
    {
      std::cin >> value;
      if (std::cin.fail())
        throw "Input is not-a-numbers (NAN).";
      if (value < 0)
        throw "Input does not allow negative numbers.";
      total += value;
    }
    catch(char const * fail)
    {
      std::cout << fail <<std::endl;
      std::cout << "Enter another number:" << std::endl;
      --i;
      std::cin.clear();
      std::cin.ignore(0xFFFFFFFF, '\n');
    }
  }
  std::cout << "Sum = " << total;
  return 0;
}