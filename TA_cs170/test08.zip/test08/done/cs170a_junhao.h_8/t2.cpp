/******************************************************************************/
/*! 
\file   t2.cpp
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 08
\date   22/7/2019 
\brief  Exceptions
*/ 
/******************************************************************************/
#include <iostream>

int main()
{
  double value;
  double total = 0;
  std::cout<< "Please enter 10 positive inputs:";

  try
  {
    for(int i=0; i != 10; ++i)
    {
      std::cin >> value;
      if (std::cin.fail())
        throw "Input is not-a-numbers (NAN).";
      if (value < 0)
        throw "Input does not allow negative numbers.";
      total += value;
    }
  }
  catch(char const * fail)
  {
    std::cout << fail <<std::endl;
    return 0;
  }

  std::cout << "Sum = " << total;
  return 0;
}