/******************************************************************************/
/*! 
\file   t3.cpp
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 08
\date   22/7/2019 
\brief  Exceptions
*/ 
/******************************************************************************/
#include <iostream>
int main()
{
  char restart;
  double total = 0;
  
  while(1)
  {  
    std::cout<< "Please enter 10 positive inputs:";
    double value = 0;
    bool restarted = false;
    for(int i=0; i != 10; ++i)
    {
      try
      {
        std::cin >> value;        
        if (std::cin.fail())
        {
          restarted = true;
          std::cin.clear();
          std::cin.ignore(0xFFFFFFFF, '\n');
          throw "Input is not-a-numbers (NAN).";
        }
        if (value < 0)
        {
          restarted = true;
          std::cin.clear();
          std::cin.ignore(0xFFFFFFFF, '\n');
          throw "Input does not allow negative numbers.";
        }

        total += value;
      }
      catch(char const * fail)
      {
        std::cout << fail <<std::endl;
        std::cout << "Input 0 to exit the program:";

        std::cin >> restart;
        if (restart == '0')
          return 0;

        total = 0;
        break;
      }
    }
    if(!restarted)
      break;
  }
  std::cout << "Sum = " << total;
  return 0;
}