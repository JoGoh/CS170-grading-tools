/******************************************************************************/
/*!
\file t1.cpp
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: cs170
\par Lab 08
\date 21/07/2019
\brief
This file contains the implementation of the following functions for
Lab 8.

Functions include:
MaxMemoryCalculator ()

Hours spent on this assignment: 2.5
*/
/******************************************************************************/

#include <iostream>

/******************************************************************************/
/*!
\brief Uses infinite while(1) loop to allocate char[1000*1024] amount of memory
to calculate number of MegaBytes before exception is thrown.

\fn int MaxMemoryCalculator ()

\return int
*/
/******************************************************************************/
int MaxMemoryCalculator ()
{
  int counter = 0;
  try {
    while(1)
    {
      new char[1000*1024];
      ++counter;
    }
  }
  catch (...) { return counter; }
}

int main()
{
  std::cout << MaxMemoryCalculator() << "MB" << " allocated" << "\n";
  return 0;
}
