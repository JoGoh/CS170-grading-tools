/******************************************************************************/
/*!
\file t4.cpp
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: cs170
\par Lab 08
\date 21/07/2019
\brief
This file contains the implementation of the following functions for
Lab 8.

Functions include:
AddTenPositiveValues (double &input, double &total)

Hours spent on this assignment: 2.5
*/
/******************************************************************************/
#include <iostream>

/******************************************************************************/
/*!
\brief Adds together 10 positive values passed in by user. Throws exception if
values are negative or NaN, then suggests if user wants to continue where they
left off before the exception.

\fn void AddTenPositiveValues (double &input, double &total)

\params input
  Reference to input variable used to store cin

\params total
  Reference to total variable used to store total amount of value added together
*/
/******************************************************************************/
void AddTenPositiveValues (double &input, double &total)
{
  // Function Variables
  bool restart = false;
  int choice = 0, step = 1;

  // Do-While loop
  do
  {
    try
    {
      // Set restart to false in event it is true
      restart = false;
      for(int i = step; i < 11; ++i)
      {
        std::cout << "Please input positive value number " << i << ":" << "\n";
        std::cin >> input;

        // Exception handling
        if (input < 0) throw 1;
        if (std::cin.fail()) throw 2;

        // Clearing input in event of 123abc
        std::cin.clear();
        std::cin.ignore(32767,'\n');

        // Adding input to total
        total += input;

        // Increase step to continue later on if need be
        ++step;
      }
    } catch (int error) {
      // Exception handling
      if (error == 1)
        std::cout << "Input has to be a positive integer." << "\n";
      else if (error == 2)
        std::cout << "Input has to be numerical value." << "\n";

      // Clearing input in event of 123abc
      std::cin.clear();
      std::cin.ignore(32767,'\n');

      // Suggest continuation
      std::cout << "Enter <1> to continue at last step." << "\n";
      std::cout << "Enter any else to quit program." << "\n";
      std::cin >> choice;
      if (choice == 1) restart = true;
      else std::exit(0);
    }
  } while (restart);
}

int main()
{
  // Variables from main function
  double input = 0, total = 0;
  // Calling sum of 10 values function
  AddTenPositiveValues(input, total);
  // Output total value of given values
  std::cout << "Total values added up is: " << total << "\n";
  return 0;
}
