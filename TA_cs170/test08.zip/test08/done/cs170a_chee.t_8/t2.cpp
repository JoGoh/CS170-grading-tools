/******************************************************************************/
/*!
\file t2.cpp
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: cs170
\par Lab 08
\date 21/07/2019
\brief
This file contains the implementation of the following functions for
Lab 8.

Functions include:
AddTenPositiveValues (double &input, double &total)

Hours spent on this assignment: 2.5
*/
/******************************************************************************/
#include <iostream>

/******************************************************************************/
/*!
\brief Adds together 10 positive values passed in by user. Throws exception if
values are negative or NaN, then exits the program.

\fn void AddTenPositiveValues (double &input, double &total)

\params input
  Reference to input variable used to store cin

\params total
  Reference to total variable used to store total amount of value added together
*/
/******************************************************************************/
void AddTenPositiveValues (double &input, double &total)
{
  try
  {
    for(int i = 1; i < 11; ++i)
    {
      std::cout << "Please input positive value number " << i << ":" << "\n";
      std::cin >> input;

      // Exception handling
      if (input < 0) throw 1;
      if (std::cin.fail()) throw 2;

      // Clearing input in event of 123abc
      std::cin.clear();
      std::cin.ignore(32767,'\n');

      // Adds the input to total amount
      total += input;
    }
  } catch (int error) {
    // Exception handling
    if (error == 1)
      std::cout << "Input has to be a positive integer." << "\n";
    else if (error == 2)
      std::cout << "Input has to be numerical value." << "\n";

    // Exit
    std::cout << "Exiting program..." << "\n";
    std::exit(0);
  }
}

int main()
{
  // Variables from main function
  double input = 0, total = 0;
  // Calling sum of 10 values function
  AddTenPositiveValues(input, total);
  // Output total value of given values
  std::cout << "Total values added up is: " << total << "\n";
  return 0;
}
