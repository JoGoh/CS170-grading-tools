/*****************************************************************************/
/*!
\file t3.h

\author Chua Lip Ming
\par email:
   l.chua.a\@digipen.edu

\par DigiPen login:
   l.chua

\par Course:
   cs170

\par Lab #8

\date 21/07/2019

\brief
t3 is like t2 but instead of exit it suggests to restart the 
process of counting from the beginning.

Functions include:
main

\par Hours spent on this assignment:
   2 hours

\par Specific portions that gave you the most trouble:
   NIL
*/
/*****************************************************************************/
#include <iostream>
#include <windows.h>

/** @brief t3 of Lab 8, like t2 but instead of exit it suggests to restart the 
process of counting from the beginning.*/
int main()
{
  unsigned c = 0;
  long long r = 0;
  long long  n = 0;
  bool err = false;

  std::cout << "Calculating sum of 10 positive numbers..." << std::endl;

  while (c < 10)
  {
    c++;
    std::cout << "Input positive number #" << c << ":" << std::endl;
    std::cin >> n;
    try
    {
      if (std::cin.fail())
        throw "\nThe number you have input is not a number(NAN).";
	  else if (n < 0)
        throw "\nThe number you have input is not a positive number.";
    }
    catch (const char* errMsg)
    {
      std::cin.clear();
      std::cin.ignore(10000, '\n');
      std::cout << errMsg << std::endl;
      c = r = 0;
	  n = 0;
    }
    r += n;
  }

  if (!err)
    std::cout << "The total sum was: " << r << "." << std::endl;

  return 0;

}