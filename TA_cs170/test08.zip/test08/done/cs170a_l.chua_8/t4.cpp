/*****************************************************************************/
/*!
\file t4.h

\author Chua Lip Ming
\par email:
   l.chua.a\@digipen.edu

\par DigiPen login:
   l.chua

\par Course:
   cs170

\par Lab #8

\date 21/07/2019

\brief
t4 is like t3 but instead of restarting the process it suggests 
to continue the counting.

Functions include:
main

\par Hours spent on this assignment:
   2 hours

\par Specific portions that gave you the most trouble:
   NIL
*/
/*****************************************************************************/
#include <iostream>
#include <windows.h>

/** @brief t4 of Lab 8, t4 is like t3 but instead of restarting the process 
it suggests to continue the counting.*/
int main()
{
  unsigned c = 0;
  long long r = 0;
  long long  n = 0;
  bool err = false;

  std::cout << "Calculating sum of 10 positive integers..." << std::endl;

  while (c < 10)
  {
	c++;
    std::cout << "Input positive number #" << c << ":" << std::endl;
    std::cin >> n;
    try
    {
      if (std::cin.fail())
        throw "\nThe number you have input is not a number(NAN)."
              "\nDeleting previous input..."
              "\nPlease provide a positive number next...";
	  else if (n < 0)
        throw "\nThe number you have input is not a positive number."
              "\nDeleting previous input..."
              "\nPlease provide a positive number next...";
    }
    catch (const char* errMsg)
    {
      std::cin.clear();
      std::cin.ignore(10000, '\n');
      std::cout << errMsg << std::endl;
      r -= n;
      --c;
    }
    r += n;
  }

  if (!err)
    std::cout << "The total sum was: " << r << "." << std::endl;

  return 0;

}