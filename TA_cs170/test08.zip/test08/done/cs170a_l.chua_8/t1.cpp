/*****************************************************************************/
/*!
\file t1.h

\author Chua Lip Ming
\par email:
   l.chua.a\@digipen.edu

\par DigiPen login:
   l.chua

\par Course:
   cs170

\par Lab #8

\date 21/07/2019

\brief
In t1 you must use exception mechanism to calculate how much 
memory (in MB) can be allocated in a program. Use new[] operator 
and catch(...). Do now worry about memory leak.     
Hints: Use while(1) loop. Allocate using new char[1024*1000] to 
count number of MB. Catch exception using .... You need only 
one variable in your program to count number of MB.

Functions include:
main

\par Hours spent on this assignment:
   2 hours

\par Specific portions that gave you the most trouble:
   NIL
*/
/*****************************************************************************/

#include <iostream>

/** @brief t1 of Lab 8, checks how much memory can be allocated in a program.*/
int main()
{
  unsigned mb = 0;

  while (1)
  {
    try
    {
      new char[1024 * 1000];
      mb++;
    }
    catch (...)
	{
      break;
	}
  }
  std::cout << "Memory allocated in Megabytes(MB): " << mb << std::endl;
  
  return 0;
}