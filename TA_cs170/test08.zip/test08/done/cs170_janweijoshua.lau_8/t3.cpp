#include <iostream>
void handle()
{
  std::cout << "Only unsigned input is allowed" << std::endl;
}
int main()
{
  int sum = 0;
  int input = 0;
    for(int i = 1; i <= 10; ++i)
    {
      try
      {
        std::cout << "input number: " << i <<std::endl;
        std::cin >> input;
        if(std::cin.fail() || input < 0)
        {
          handle();
          std::cin.clear();
          char restart;
          std::cout << "Please enter Y to restart and N to exit" << std::endl;
          std::cin >> restart;
          if(restart == 'Y')
          {
            i = -1;
            sum = 0;
            input = 0;
            continue;
          }
          if(restart == 'N')
          {
            return 0;
          }
        }
        sum += input;
      }
      catch(...)
      {
        std::cin.clear();
        handle();
      }
  }
   std::cout << "The sum of 10 positive inputs is: " << sum << std::endl;
  return 0;
}
