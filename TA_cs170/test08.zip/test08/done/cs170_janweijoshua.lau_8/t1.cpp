// Use exception to calculat ehow much memory (in MB) can be allocated in a progrma.
// use new[] operator and catch(...) do not worry about memory leak
// hint: use while(1) loop. Allocate using new char[1024 * 1000] to count number of MB
// catch exception using ...
// you only need 1 variable in your program to count number of MB
#include <iostream>
int main()
{
  int catcher;
  try
  {
    while(1)
    {
      char* max = new char[1024*1000];
      max = max;
      std::cout
      << catcher
      << std::endl;
      ++catcher;
    }
  }catch(...)
   {
     std::cout 
     << "Arrived at maximum memory allocations which is: " 
     << catcher
     << "Bytes" 
     << std::endl;
   }
  return 0;
}

