#include <iostream>
int handle()
{
  std::cout << "Only unsigned input is allowed" << std::endl;
  return 0;
}
int main()
{
  int sum = 0;
  int input = 0;
    for(int i = 1; i <= 10; ++i)
    {
      try
      {
        std::cout << "input number: " << i <<std::endl;
        std::cin >> input;
        if(std::cin.fail() || input < 0)
        {
          return handle();
        }
        sum += input;
      }
      catch(...)
      {
        return handle();
      }
  }
   std::cout << "The sum of 10 positive inputs is: " << sum << std::endl;
  return 0;
}
