/******************************************************************************/ 
/*! 
 \file   t4.cpp
 \author Chong Huey Jia
 \par    email: hueyjia.chong\@digipen.edu 
 \par    DigiPen login: hueyjia.chong 
 \par    Course: CS170L 
 \par    Lab 08
 \date   15/07/2011 
 \brief     This is to calculate he sum of 10 positive inputs
*/ 
/******************************************************************************/

#include<iostream>

int main()
{
	int input;
	unsigned int total = 0;
		

	for(int i = 10; i > 0; --i)
	{
		try
		{
			std::cin >> input;
			
			// if there is an invalid or negative number input,
			// it will display the message
			if(std::cin.fail() || input < 0)
			{
				throw "It doesn't allow negative numbers or not-a-numbers";
			}
			
			// if input is postive number, it will add the total.
			else
			{
				total += input;
			}
		}
		
		catch(const char* x)
		{
			std::cout << x << std::endl;
			
			// to continue the process of counting
			std::cin.clear();
			std::cin.ignore(100000, '\n');
			
			i += 1;
		}
	}
	
	std::cout << total << std::endl;	
}