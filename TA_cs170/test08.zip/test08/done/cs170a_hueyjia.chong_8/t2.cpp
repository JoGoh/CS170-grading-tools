/******************************************************************************/ 
/*! 
 \file   t2.cpp
 \author Chong Huey Jia
 \par    email: hueyjia.chong\@digipen.edu 
 \par    DigiPen login: hueyjia.chong 
 \par    Course: CS170L 
 \par    Lab 08
 \date   15/07/2011 
 \brief     This is to calculate he sum of 10 positive inputs
*/ 
/******************************************************************************/

#include<iostream>

int main()
{
	try
	{
		int input;
		unsigned int total = 0;
		
		for(int i = 10; i > 0; --i)
		{
			std::cin >> input;
			
			// if there is an invalid or negative number input,
			// it will display the message 
			if(std::cin.fail() || input < 0)
			{
				throw "It doesn't allow negative numbers or not-a-numbers";
			}
			
			// if input is postive number, it will add the total.
			else
			{
				total += input;
			}
		}
		
		std::cout << total << std::endl;
	}
	
	catch(const char* x)
	{
		std::cout << x << std::endl;
		exit(-1);  //exit the program
	}
}