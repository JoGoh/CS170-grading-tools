/******************************************************************************/ 
/*! 
 \file   t1.cpp
 \author Chong Huey Jia
 \par    email: hueyjia.chong\@digipen.edu 
 \par    DigiPen login: hueyjia.chong 
 \par    Course: CS170L 
 \par    Lab 08
 \date   15/07/2011 
 \brief     This is to calculate how much memory can be allocated
*/ 
/******************************************************************************/

#include<iostream>

int main()
{
	int counter = 0; 
	
	try
	{
		while(1)
		{
			new char[1024 * 1000];
			counter++;
		}
	}
	
	catch(...)
	{
		std::cout << counter << std::endl;
	}
}

