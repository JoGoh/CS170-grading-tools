/******************************************************************************/
/*! 
\file   t1.cpp 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 08
\date   22/07/2019 
\brief
     This is file contains the function definitions for t1.cpp
*/ 
/******************************************************************************/
#include <iostream>
/******************************************************************************/
/*! 
\fn          int main ()
\brief       main function of t1.cpp
\return      int
*/ 
/******************************************************************************/
int main ()
{
  //to keep track of the memory allocated in MB
  int MB = 0;
  while (1)
  {
    try
    {
      //allocates memory
      new char[1000*1024];
      MB++;
    }
    catch(std::bad_alloc &e)
    {
      //error message
      std::cout << "Max memory allocated, memory allocated: " 
                << MB << "MB" << std::endl;
      break;
    }
  }
  return 0;
}