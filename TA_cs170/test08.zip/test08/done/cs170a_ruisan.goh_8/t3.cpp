/******************************************************************************/
/*! 
\file   t3.cpp 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 08
\date   22/07/2019 
\brief
     This is file contains the function definitions for t3.cpp
*/ 
/******************************************************************************/
#include <iostream>
#include <stdlib.h>
/******************************************************************************/
/*! 
\fn          int main ()
\brief       main function of t3.cpp
\return      int
*/ 
/******************************************************************************/
int main ()
{
  std::cout << "Please enter 10 positive numbers" << std::endl;
  double sum = 0, add = 0;
  //loop to take in input and check for legal input before adding it to sum
  for(int i = 0; i < 10; i++)
  {
    std::cin >> add;
    try
    {
      if(add < 0 || std::cin.fail())
        throw("Exception: No negative numbers or not-a-numbers (NAN) allowed.");
    }
    catch (const char * msg)
    {
      //error msg with option to reset
      std::cout << msg << std::endl;
      std::cout << "Reset? Yes(1) No(Any other key)" << std::endl;
      std::cin.clear();
      std::cin.ignore();
      std::cin >> add;
      //reset
      if(add==1)
      {
        sum = add = 0;
        i=-1;
        std::cout << "Restarting..." << std::endl;
        continue;
      }
      else
      {
        exit(1);
      }
    }
    sum+=add;
  }
  std::cout << "Sum: " << sum << std::endl;
  return 0;
}