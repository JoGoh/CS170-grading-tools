/**************************************************************************************************************/
/*!
\file   t1.cpp
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 08
\date   22/6/2019
\brief
  Tests how much memory can be allocated in the program
*/
/**************************************************************************************************************/
#include <new>
#include <iostream>
int main() {
	//! Integer to count number of megabytes
	int iCnt = 0;

	try {
		
		//While loop to count maximum memory
		while (1) {

			//Approx one MB
			new char[1024 * 1000];

			//Add to Counter
			++iCnt;
		}
	}
	catch (std::bad_alloc& exe) {
		std::cout << iCnt << " MBs of memory can be allocated in this program" << std::endl;
	}
}