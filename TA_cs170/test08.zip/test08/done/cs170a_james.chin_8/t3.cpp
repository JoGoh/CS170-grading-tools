/**************************************************************************************************************/
/*!
\file   t3.cpp
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 08
\date   22/6/2019
\brief
  Positive Number sumation (If there is an error, can be reset)
*/
/**************************************************************************************************************/
#include <iostream>
#include <limits>

//Retry Function Prototype
void retry();

void get_sum() {

	//! Summation to be printed 
	double sum = 0;

	bool done = false;

	while (done != true) {
		try {
			//Ask for 10 numbers
			for (int iCnt = 1; iCnt < 11; iCnt++) {

				//! Input value to be added
				double input;

				std::cout << "Enter Number (" << iCnt << ") : ";

				std::cin >> input;
				if (std::cin.fail()) {
					throw "Invalid Input: Input is not a valid number (NaN)";
				}
				else if (input < 0) {
					throw "Invalid Input: Input cannot be negative";
				}
				else {
					//If no errors, add to summation
					sum += input;
				}
			}

			done = true;
			std::cout << "The Sum is " << sum << std::endl;
		}
		catch (char const* error) { //If error, print out the error and ask the user to retry
			std::cout << error << std::endl;

			//Clear the buffer
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

			//Restart sumation
			sum = 0;
			
			//Call retry to get user choice
			retry();
		}
	}
}

//Check for user response (retry or exit)
void retry() {
	//! User answer, restart or exit
	char answer = 'N';

	//While there is no valid answer
	while (answer != 'Y') {


		std::cout << "Do you wish to restart the counting from the beginning? [Y/N]";
		std::cin >> answer;

		//Clear the buffer
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

		// No
		if (answer == 'N') {
			std::cout << "Exiting....." << std::endl;
			exit(1);

		}
	}


}

int main() {
	get_sum();
}

