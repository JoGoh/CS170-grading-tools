/**************************************************************************************************************/
/*!
\file   t2.cpp
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 08
\date   22/6/2019
\brief
  Positive Number sumation (no continuation or reset)
*/
/**************************************************************************************************************/
#include <iostream>
int main() {

	//! Summation to be printed 
	double sum = 0;

	//Ask for 10 numbers
	for (int iCnt = 1; iCnt < 11; iCnt++) {

		//! Input value to be added
		double input;

		try {
			std::cout << "Enter Number (" << iCnt << ") : ";

			std::cin >> input;
			if (std::cin.fail()) {
				throw "Invalid Input: Input is not a valid number (NaN)";
			}
			else if (input < 0) {
				throw "Invalid Input: Input cannot be negative";
			}
			else {
				//If no errors, add to summation
				sum += input;
			}

		}
		catch (char const *error) { //If error, print out the error and stop the program
			std::cout << error << std::endl;
			std::cout << "Exiting....." << std::endl;
			exit(1);
		}

	}

	std::cout << "The Sum is " << sum << std::endl;
}