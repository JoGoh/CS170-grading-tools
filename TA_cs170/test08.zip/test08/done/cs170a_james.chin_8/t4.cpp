/**************************************************************************************************************/
/*!
\file   t4.cpp
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 08
\date   22/6/2019
\brief
  Positive Number sumation (If there is an error, can be continued)
*/
/**************************************************************************************************************/
#include <iostream>
#include <limits>

//Continue_Cnt Function Prototype
void continue_cnt();

void get_sum() {

	//! Sumation to be printed
	double sum = 0;
	
	//! Counter, will be stopped if error, and can easily be continued later
	int iCnt = 1;

	while (iCnt < 11) {
		
		//! Input value to be added
		double input;
		
		try {
			std::cout << "Enter Number (" << iCnt << ") : ";

			std::cin >> input;
			if (std::cin.fail()) {
				throw "Invalid Input: Input is not a valid number (NaN)";
			}
			else if (input < 0) {
				throw "Invalid Input: Input cannot be negative";
			}
			else {
				//If no errors, add to summation
				sum += input;
			}


			//Add to Count
			++iCnt;
		}
		catch (char const* error) { //If error, print out the error and ask for the user to continue

			std::cout << error << std::endl;
			
			//Clear the buffer
			std::cin.clear();
			std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

			//Call continue_cnt to get user choice
			continue_cnt();
			
			
		}
	}

	std::cout << "The Sum is " << sum << std::endl;

}

//Ask the user to continue or exit
void continue_cnt() {
	//! User answer, restart or exit
	char answer = 'N';

	while (answer != 'Y') {
		
		//Ask to continue
		std::cout << "Do you wish to continue counting? [Y/N]";
		std::cin >> answer;

		//Clear the buffer 
		std::cin.clear();
		std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

		// No
		if (answer == 'N') {
			std::cout << "Exiting....." << std::endl;
			exit(1);

		}
	}



}

int main() {
	get_sum();
}

