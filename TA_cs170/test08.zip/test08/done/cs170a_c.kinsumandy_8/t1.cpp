/******************************************************************************/ 
/*!
\file t1.cpp 
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par Lab #8
\date 16/07/2019
\brief This file contains the implementation of the following functions for
CS170 (lab 08).
Functions include:
main

Hours spent on this assignment: 2 hr
Specific portions that gave you the most trouble: -
*/
/******************************************************************************/
#include <iostream>

int main()
{
	// Initialise the variable
	size_t numBytes = 0;
	
	// Infinite loop
	while(1)
	{
		try
		{
			// Allocate memory (1MB)
			// and increment the number of bytes
			new char[1024*1000];
			++numBytes;
		}
		
		// Catch if there's any error
		catch(...)
		{
			break;
		}
	}

	std::cout << "Number of MBs created : " << numBytes << std::endl;
		
	return 0;
}