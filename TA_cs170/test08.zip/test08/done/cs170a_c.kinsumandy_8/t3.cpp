/******************************************************************************/ 
/*!
\file t3.cpp 
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par Lab #8
\date 16/07/2019
\brief This file contains the implementation of the following functions for
CS170 (lab 08).
Functions include:
main

Hours spent on this assignment: 2 hr
Specific portions that gave you the most trouble: -
*/
/******************************************************************************/
#include <iostream>

int main()
{
	// Initialise the variables
	double val_Input = 0, sum = 0;

	// Main Loop (10 times)
	for (int i = 0; i < 10; ++i)
	{
        std::cout << "Enter a positive integer value : ";
        std::cin >> val_Input;

        try
        {
            // If NAN / negative number found
            if (std::cin.fail() || val_Input < 0)
				throw "Please enter a positive integer value that is not NAN"
					  "\nProgram Restarting ...\n\n";
        }
		
		// Catch if there's any error
        catch (const char* msg)
        {
			std::cin.clear();
            std::cin.ignore(1000, '\n');
            std::cout << "\n" << msg << std::endl;
			
			// Restart the variables
			i = -1;
			val_Input = 0;
			sum = 0;
        }

        // Adds every valid value to a variable
        sum += val_Input;
    }
    
    std::cout << "\nTotal sum of positive values: " << sum << std::endl;

    return 0;
}