/******************************************************************************/ 
/*! 
\file t1.cpp
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 08
\date 20/07/2019 
\brief This file contains the main function for CS170 Lab 8 Exceptions case t1.

\par Functions include
<br>main

\par Hours spent on this assignment: 2 hours
\par Specific portions that gave you the most trouble: None
*/ 
/******************************************************************************/
#include <iostream>

int main()
{
	//To count how many loops
	int count = 0;
	try
	{
		while (1)
		{
			new char[1024 * 1000];
			++count;
		}
	}
	catch(...)
	{
    std::cout << "Memory allocated: " << count << "MB" << std::endl;
	}
	return 0;
}