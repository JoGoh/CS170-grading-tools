/******************************************************************************/ 
/*! 
\file t2.cpp
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 08
\date 20/07/2019 
\brief This file contains the main function for CS170 Lab 8 Exceptions case t2.

\par Functions include
<br>main

\par Hours spent on this assignment: 2 hours
\par Specific portions that gave you the most trouble: None
*/ 
/******************************************************************************/
#include <iostream>

int main()
{
	//Represents how many inputs has been taken
	double sum = 0.0;
	double input = 0.0;
	
	//Initial Message
	std::cout << "Please give 10 positive inputs." << std::endl;
	
	try
	{
		//Loop for each count
		for (int count = 0; count < 10; ++count)
		{
			std::cout <<"Please enter number " << count << ": " <<std::endl;
			std::cin >> input;
			
			if (std::cin.fail())
				throw "Invalid, non-number detected";
			else if (input < 0.0)
				throw "Invalid, negative number detected";
			else
				sum += input;
		}
		//Only print out if successful
		std::cout << "Sum is " << sum << std::endl;
	}
	catch(const char* errMsg)
	{
		std::cout << errMsg << std::endl;
	}
	return 0;
}