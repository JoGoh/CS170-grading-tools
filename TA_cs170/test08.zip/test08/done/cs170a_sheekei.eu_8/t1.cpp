/******************************************************************************/
/*!
\file               t1.cpp
\author             Eu Shee Kei
\par email:         sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course:        CS170
\par Lab:           8
\date               22/07/2019
\brief
This file contains the implementation of the following program for
the Exceptions assignment.
*/
/******************************************************************************/
#include <iostream>       // cout

int main()
{
  int counter = 0;
  
  // keep allocating memory until program throws exception
  try
  {
    while(1)
    {
      new char[1024*1000];
      ++counter;
    }
  }
  // output total number of memory allocated
  catch(...)
  {
    std::cout << counter << " MB Allocated!" << std::endl;
  }
  return 0;
}
