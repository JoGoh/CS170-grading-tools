/******************************************************************************/
/*!
\file               t3.cpp
\author             Eu Shee Kei
\par email:         sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course:        CS170
\par Lab:           8
\date               22/07/2019
\brief
This file contains the implementation of the following program for
the Exceptions assignment.
*/
/******************************************************************************/
#include <iostream>       // cout, cin

int main()
{
  double total = 0;
  double input = 0;
  int IsRestart = 0;
  
  for(int i = 1; i <= 10; ++i)
  {
    // prompts user to input 10 numbers to total up
    try
    {
      std::cin >> input;
      if(std::cin.fail() || (input < 0))
        throw ("Error! Input is a negative number or not-a-number(NAN)!");
      total += input;
    }

    // if user inputs a negative number of not-a-number, throw error message
    catch(const char * msg)
    {
      std::cin.clear();
      std::cin.ignore(1000, '\n');
      std::cout << msg << std::endl;
      std::cout <<"Enter 1 to restart, or 0 to exit the program." << std::endl;
      std::cin >> IsRestart;
      if(IsRestart)
        i = 0;
      else
      {
        std::cout << "Exiting Program...";
        return 0;
      }
    }
  }
  std::cout << "Total is " << total;
  
  return 0;
}