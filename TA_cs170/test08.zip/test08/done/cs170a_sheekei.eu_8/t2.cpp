/******************************************************************************/
/*!
\file               t2.cpp
\author             Eu Shee Kei
\par email:         sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course:        CS170
\par Lab:           8
\date               22/07/2019
\brief
This file contains the implementation of the following program for
the Exceptions assignment.
*/
/******************************************************************************/
#include <iostream>       // cout, cin

int main()
{
  double total = 0;
  double input = 0;
  
  try
  {
    // prompts user for input and adding up the total
    for(int i = 0; i < 10; ++i)
    {
      std::cin >> input;
      if(std::cin.fail() || input < 0)
        throw ("Error! Input is a negative number or not-a-number(NAN)!");
      total += input;
    }
      std::cout << "Total is " << total << ".";
  }
  // if user inputs a negative number of not-a-number, throw error message
  catch(const char * msg)
  {
    std::cout << msg << std::endl;
    std::cout << "Exiting the program...";
  }
  
  return 0;
}