/******************************************************************************
* @filename: t2.cpp
* @author(s): Choong Xue Ting
* @DP email: xueting.choong@digipen.edu
* @course CS 170
* @CS170LAB8
* @due date by 22/07/2019
* Brief Description:
* In t2 you must calculate and show sum of 10 positive inputs.
During the input, program should use exception mechanism to display a message
that it doesn't allow negative numbers or not-a-numbers (NAN) if so is the
input and then exit the program.

******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int myIn;
    int sum = 0;
    int count = 0;
        
    cout << "Enter a positive number: \n";
        
    try
    {
        while(count != 10)
        {
            cin >> myIn;
                
            if(cin.fail())
            {
                throw ("\n You have entered a character or a symbol. \n");
            }
            else if(myIn < 0)
            {
                throw ("\n You have entered a negative number. \n");
            }
                
            sum += myIn;
            count++;
        }
            
        cout << "The total sum is: " << sum;
    }
        
    catch(const char *msg)
    {
        cout << msg;
    }
    
    return 0;
}