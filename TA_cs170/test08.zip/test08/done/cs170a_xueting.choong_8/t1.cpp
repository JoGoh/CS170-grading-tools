/******************************************************************************
* @filename: t1.cpp
* @author(s): Choong Xue Ting
* @DP email: xueting.choong@digipen.edu
* @course CS 170
* @CS170LAB8
* @due date by 22/07/2019
* Brief Description:
* In t1 you must use exception mechanism to calculate how much memory (in MB)
can be allocated in a program.

******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int size = 0;
    
    try
    {
        while(1)
        {
            new char[1024*1000];
            size++;
        }
    }
    
    catch(...)
    {
        cout << "Maximum size is : " << size << "MB";
    }
    
    return 0;
}