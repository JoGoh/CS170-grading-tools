/******************************************************************************
* @filename: t4.cpp
* @author(s): Choong Xue Ting
* @DP email: xueting.choong@digipen.edu
* @course CS 170
* @CS170LAB8
* @due date by 22/07/2019
* Brief Description:
* t4 is like t3 but instead of restarting the process it suggests to
continue the counting.

******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
    int myIn;
    int sum = 0;
    int count = 0;
    
    while(1)
    {   
        cout << "Enter a positive number: \n";
        
        try
        {
            while(count != 10)
            {
                cin >> myIn;
                
                if(cin.fail())
                {
                    throw ("\n You have entered a character or a symbol. \n");
                }
                else if(myIn < 0)
                {
                    throw ("\n You have entered a negative number. \n");
                }
                
                sum += myIn;
                count++;
            }
            
            cout << "The total sum is: " << sum;
            break;
        }
        
        catch(const char *msg)
        {
            char reply;
            cin.clear();
            cin.ignore(1000000000, '\n');
            cout << msg;
            cout << "\n Do you want to continue? (Y/N)\n";
            cin >> reply;
            if(reply == 'Y' || reply == 'y')
            {
                ;
            }
            else if (reply == 'N' || reply == 'n')
            {
                return 0;
            }
            else
            {
                while(reply != 'Y' && reply != 'y')
                {
                    char ans;
                    cin.clear();
                    cin.ignore(1000000000, '\n');
                    cout << "Please enter a valid response!\n";
                    cin >> ans;
                    if(ans == 'N' || ans == 'n')
                    {
                        return 0;
                    }
                    else if(ans == 'Y' || ans == 'y')
                    {
                        break;
                    }
                }
            }
        }
    }
    
    return 0;
}