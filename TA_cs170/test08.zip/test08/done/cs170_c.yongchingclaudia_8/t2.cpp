#include <iostream>
#include <cmath>

int main()
{
    float sum, input = 0.0f;
    int count = 0;

    try
    {
        while(count<10)
       { 
            std::cin>>input;
            if (input<0 || std::isnan(input))
                throw(input);
            sum+=input;
            count++;
        }
        std::cout<<sum<<std::endl;
    }

    catch(...)
    {
        std::cout<<"no negative number or not-a-number allowed";
        return 0;
    }


    return 0;

}