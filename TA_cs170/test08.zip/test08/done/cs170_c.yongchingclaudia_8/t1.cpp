#include <iostream>

int main()
{
    int count = 0;
    try
    {
        while(1)
        {
            new char[1024*1000];
            count++;
        }
        throw(count);
    }
    catch(...)
    {
        std::cout<<count<<std::endl;
    }
    return 0;
}