#include <cmath>
#include <iostream>

int main()
{
    int decision = 1;
    int count = 0;
    float sum, input = 0.0f;

    do 
    {    

        try
        {
            while(count<10)
        { 
                std::cin>>input;
                if (input<0 || std::isnan(input))
                    throw(input);
                sum+=input;
                count++;
            }
            decision=0;
        }

        catch(...)
        {
            std::cout<<"no negative number or not-a-number allowed"<<std::endl
                    <<"press 1 to continue, press 0 to quit"<<std::endl;
            std::cin>>decision;
        }
    }while (decision == 1);
    std::cout<<sum;

    return 0;
}