#include <cmath>
#include <iostream>

int main()
{
    int decision = 1;
    do 
    {    
        float sum, input = 0.0f;
        int count = 0;

        try
        {
            while(count<10)
        { 
                std::cin>>input;
                if (input<0 || std::isnan(input))
                    {
                        decision=1;
                        throw(input);
                    }
                sum+=input;
                count++;
                
            }
            std::cout<<sum<<std::endl;
            decision=0;
        }

        catch(...)
        {
            std::cin>>decision;
        }
    }while (decision == 1);

    return 0;
}