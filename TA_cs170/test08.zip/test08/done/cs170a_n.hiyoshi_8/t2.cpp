/*****************************************************************************/
/*! 
\file   t2.cpp 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 08
\date   22/07/2019
\brief     
This program demonstrates the exception mechanism for the calculation of
10 positive inputs and displaying a message that it doesn't allow
negative numbers or not-a-numbers (NAN). It ends once exception error occurs.
*/ 
/*****************************************************************************/

#include <iostream>  // cin, cout, endl;

int main(void)
{
  int input = 0;  // To be used to store user's input 
  int total = 0;  // To be used to store the total sum
  
  try
  {
    std::cout << "Please enter a valid positive number: " << std::endl;
    
    for(int i = 0; i < 10; i++)  // Loops 10 times for 10 positive input
    {
      std::cin >> input;  // Input from user

      if (std::cin.fail() || input < 0)  // If input does not fit var type
        throw 0;  // Throw an exception 
      else
        total += input;  // Sum of the positive integers
    }
    
    std::cout << "The sum of 10 positive inputs is " << total << std::endl;
    
  }catch(...)  // Catch all exceptions
    {
      std::cout << 
      "This program doesn't allow negative numbers or not-a-numbers (NAN)!"
      << std::endl;
    }

  return 0;  // Exit the program
}