/*****************************************************************************/
/*! 
\file   t1.cpp 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 08
\date   22/07/2019
\brief     
This program contains the demonstration of exception mechanism to calculate
how much memory (in MB) can be allocated in a program. It ends once memory
allocation limit is reached. 
*/ 
/*****************************************************************************/

#include <iostream>  // cin, cout, endl;

int main(void)
{
  int counter = 0;  // To be used to store the total MB count
  
  try
  {
		std::cout << "Testing memory allocation, please wait..." << std::endl;
		
    while(1)  // Infinite loop to test memory limits
    {
      if(new char[1024 * 1000])  // 1,024,000 BYTES = 1 MEGABYTE
        ++counter;  // Counter to count number of MB allocated
      else
        throw 0;  // Throw an exception 
    }
    
  }catch(...)  // Catch all exceptions
    {
      std::cout << "The amount of memory (in MB) that can be allocated is " 
      << counter << "MB memory" << std::endl;
    }
  
  return 0;  // Exit the program
}