/*****************************************************************************/
/*!
\file cs170_vector.h
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
08
\par Date:
19 July 2019
\par Brief:

	This file contains the implementation of the following functions
	for CS170 Lab 08 - Exceptions

	Functions given: \n
	
	\n
	Functions written: \n 
	int main();
	
	
	\n 
	Hours spent on this assignment: 
	1.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/
#include <iostream>

int main() {

	double input = 0.0;
	double sum = 0.0;

	int userInput = 0;
	bool isRestart = true;
	
	int count = 0;
	

	std::cout << "Enter 10 POSITIVE inputs." << std::endl;
	
	while (isRestart) {
		
		try {
			
			for (; count < 10; ++count) {
				std::cout <<"Enter number " 
									<< count << ": " <<std::endl;
								
				std::cin >> input;
				
				if (std::cin.fail()) {
					throw "Invalid input: NAN value.";
				}
				else if (input < 0.0) {
					throw "Invalid input: Negative value.";
				}
				else {
					sum += input;
				}
			} //end for
			
			std::cout << "Sum of inputs: " << sum << std::endl;
			isRestart = false;
		}
		catch(const char* err) {
			
			std::cout << err << std::endl
								<< "Enter 0 to continue, other numbers to exit." 
								<< std::endl;
			
			std::cin.clear();
			std::cin.ignore(1000000,'\n');
			std::cin >> userInput;
			
			if (userInput != 0) {
				std::cout << "Program will now exit." << std::endl;
				exit(-1);
			}

		}
		
	} //while
	return 0;
} //main