/*****************************************************************************/
/*!
\file cs170_vector.h
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
08
\par Date:
19 July 2019
\par Brief:

	This file contains the implementation of the following functions
	for CS170 Lab 08 - Exceptions

	Functions given: \n
	
	\n
	Functions written: \n 
	int main();
	
	
	\n 
	Hours spent on this assignment: 
	1.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/
#include <iostream>


int main() {
	
	int count = 0;
	
	try {
		while (1) {
			new char[1024 * 1000];
			++count;
		}
	}
	catch(...) {
    std::cout << "Memory successfully allocated: " 
							<< count 
							<< "MB" << std::endl;
	}
	
	return 0;
} //main