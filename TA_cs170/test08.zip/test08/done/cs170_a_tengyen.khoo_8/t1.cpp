/******************************************************************************/
/*!
\file t1.cpp
\author Khoo Teng Yen
\par email: tengyen.khoo\@digipen.edu
\par DigiPen login: tengyen.khoo
\par Course: CS170
\par Lab 08
\date 20/07/2019
\brief
Calculate how much memory (in MB) can be allocated in a program.
*/
/******************************************************************************/
#include <iostream>

int main()
{
  unsigned num = 0;
  
  std::cout << "Calculating how much memory can be allocated in a program"
  << std::endl;
  
  while(1)
  {
    try
    {
      new char[1024*1000];
      ++num;
    }
    catch(...)
    {
      std::cout << "Maximum amount of memory can be allocated is: "
      << num << "MB" << std::endl;
      exit(0);
    }
  }
  return 0;
}