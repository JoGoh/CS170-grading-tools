/******************************************************************************/
/*!
\file t4.cpp
\author Khoo Teng Yen
\par email: tengyen.khoo\@digipen.edu
\par DigiPen login: tengyen.khoo
\par Course: CS170
\par Lab 08
\date 20/07/2019
\brief
Calculate and show sum of 10 positive inputs. If the iput is either a negative
numbers or not-a-numbers (NAN) the program will ask for another input and
contiue.
*/
/******************************************************************************/
#include <iostream>

int main()
{
  int num = 0, result = 0;
  
  std::cout << "Input 10 positive numbers to find their sum" << std::endl;
  
  for(int i = 0; i < 10; ++i)
  {
    std::cout << i + 1 << ") ";
    std::cin >> num;
    
    try
    {
      if(std::cin.fail())
        throw("Input is not a number.");
      
      if(num < 0)
        throw num;
    }
    
    catch(const char *msg)
    {
      std::cin.clear();
      std::cin.ignore(10000, '\n');
      num = 0;
      --i;
      std::cout << msg << " Please enter a number again to continue." 
      << std::endl;
    }
    
    catch(int x)
    {
      std::cin.clear();
      std::cin.ignore(10000, '\n');
      num = 0;
      --i;
      std::cout << x << " is a negative number." 
      << " Please enter a number again to continue." << std::endl;
    }
    
    result += num;
  }
  
  std::cout << "The sum of the 10 positive numbers is: " 
  << result << std::endl;
  
  return 0;
}