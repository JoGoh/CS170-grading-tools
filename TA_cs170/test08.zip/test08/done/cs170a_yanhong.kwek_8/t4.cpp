/******************************************************************************/
/*!
\file t4.cpp
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
This program calculates and show sum of 10 positive inputs, asks the user if
they want to continue counting when negative numbers or not-a-numbers (NAN)
is detected.
*/
/******************************************************************************/
#include <iostream>
#include <climits>
using namespace std;

int main ()
{
    double val=0,sum=0;
    int i=1;
    char input=0;
    
    cout<<"Please enter 10 positive numbers"<<endl;
    while (i<=10)
    {
        try
        {
            cout<<"Input "<<i<<endl;
            cin>>val;
            i++;
            if (cin.fail()) //NAN detected
            {
                cin.clear(); // Clear fail flag
                cin.ignore(INT_MAX,'\n'); // Ignore till end
                throw val;
            }
            else if (val<0) // negative number detected
            {
                throw val;
            }
            else 
            {
                sum+=val;
            }
        }
        catch (...)
        {
            cout<< "Negative numbers and not-a-numbers (NAN) are not allowed"
            <<endl;
            cout << "Do you want to resume counting? (Y/N)" << endl;
            cin >> input;
            if(input == 'N' || input == 'n') //if no exit
            {
                return 0;
            }
            else //else resume counting
            {
                i--;
                continue;
            }
        }
    } 
    cout<<"The sum of 10 positive numbers is "<<sum<<endl;
    return 0;
}