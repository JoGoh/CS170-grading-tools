/******************************************************************************/
/*!
\file t2.cpp
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
This program calculates and show sum of 10 positive inputs, exits the program
when negative numbers or not-a-numbers (NAN) is detected.
*/
/******************************************************************************/
#include <iostream>
using namespace std;

int main ()
{
    double val=0,sum=0;
    int i=1;
    cout<<"Please enter 10 positive numbers"<<endl;
    try
    {
        while (i<=10)
        {
            cout<<"Input "<<i<<endl;
            cin>>val;
            i++;
            if (cin.fail()) //NAN detected
            {
                throw val;
            }
            else if (val<0) // negative number detected
            {
                throw val;
            }
            else
            {
                sum+=val;
            }
        }
        cout<<"The sum of 10 positive numbers is "<<sum<<endl;
    }
    catch (...)
    {
        cout<< "Negative numbers and not-a-numbers (NAN) are not allowed"<<endl;
    }
    return 0;
}
