/******************************************************************************/
/*!
\file t1.cpp
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
This program calculates how much memory (in MB) can be 
allocated in a program.
*/
/******************************************************************************/
#include <iostream>
using namespace std;

int main ()
{
    int total_mem;
    try
    {
        while (1)
        {
            new char[1024*1000];
            total_mem++;
        }
    }
    catch(...)
    {
        cout<<"Total memory that can be allocated is "<<total_mem<<"MB"<<endl;
    }
    return 0;
}