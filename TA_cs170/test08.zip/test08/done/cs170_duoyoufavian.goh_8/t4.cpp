/*****************************************************************************/
/*!
\file t4.cpp
\author Favian Goh
\par email: duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
  This file calculates and shows the sum of 10 positive inputs.
  Negative numbers and NAN are not allowed.
*/
/*****************************************************************************/

#include <iostream> //cin, cout
#include <limits> //numeric_limits
#include <cstdlib> //exit

using namespace std;

int input = 0;
int sum = 0;
int choice = 0;
int i = 10;

/*****************************************************************************/
/*!
  \brief
    Calculate sum of inputs
  
  \param 
    &i
      pass by reference of i for iteration purposes.
*/
/*****************************************************************************/

void CountSum(int &i) const
{
  try
  {
    
    for (; i > 0; --i) //input for 10 nums
    {
      cout << "Enter a positive number: ";
      cin >> input;
      
      //if input entered is a negative number or NAN
      if (cin.fail() || input < 0)
      {
        cin.clear(); //clears the error flag on cin
        //skips to the next newline
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        throw(1); //throw exception
      }
      else
      if (i == 0) //check if it's the first iteration
        sum = input;
      else
        sum += input; //sum of inputs
    }
  
    cout << "The sum is " << sum;
    exit(0);
    
  }
  
  catch(...)
  {
    cout << "\nNegative numbers and NAN are not allowed.";
    cout << "\nDo you want to resume counting?";
    cout << "\n1 to resume, 0 to exit\n";
    
    cin >> choice; 
    if (choice == 1)
      --i;
    else
      exit(0); //exit program
  }
  
}
int main()
{
  
  while(i != 0)
  {
   CountSum(i);
  }
  return 0;
}