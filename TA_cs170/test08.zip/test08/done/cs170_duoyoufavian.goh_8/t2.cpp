/*****************************************************************************/
/*!
\file t2.cpp
\author Favian Goh
\par email: duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
  This file calculates and shows the sum of 10 positive inputs.
  Negative numbers and NAN are not allowed.
*/
/*****************************************************************************/

#include <iostream> //cout
#include <cstdlib> //exit

using namespace std;

int input = 0;
int sum = 0;

int main()
{
  try
  {
    
    for (int i = 0; i < 10; ++i) //input for 10 nums
    {
      cout << "Enter a positive number: ";
      cin >> input;
      
      //if input entered is a negative number or NAN
      if (cin.fail() || input < 0)
      {
        throw(1); //throw exception
      }
      else
      if (i == 0) //check if it's the first iteration
        sum = input; 
      else
        sum += input; //sum of inputs
    }
  
    cout << "The sum is " << sum;
    
  }
  
  catch(...)
  {
    cout << "\n Negative numbers and NAN are not allowed.";
    exit(1); //exit program
  }
}