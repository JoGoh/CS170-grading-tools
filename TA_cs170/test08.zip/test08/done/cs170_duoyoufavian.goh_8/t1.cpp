/*****************************************************************************/
/*!
\file t1.cpp
\author Favian Goh
\par email: duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
This file calculates how much memory (in MB) can be allocated in a program.
*/
/*****************************************************************************/

#include <iostream> //cout

using namespace std;

unsigned i = 0; //iterator
char* tmp; //tmp pointer

int main(void)
{
  
  try
  {
    while(1)
    {
      tmp = new char [1000 * 1024]; //allocate max amount of mem
      ++i; //increment iterator
    }
  }
  
  catch(const bad_alloc&)
  {
    cout << i << " MB"; //max mem allocated before exception
  }
  
  return 0;
}

