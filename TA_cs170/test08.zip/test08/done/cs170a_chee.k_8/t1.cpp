/******************************************************************************/
/*!
\file t1.cpp
\author Samuel Chee
\par email: chee.k\@digipen.edu
\par DigiPen login: chee.k
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
This file contains the exception mechanism which tests for 
how much memory can be allocated in a program.
Functions include:

Hours spent on this assignment: 2 hours
Specific portions that gave you the most trouble:

*/ 
/******************************************************************************/
#include <iostream>

int main()
{
    unsigned int count =0;//Counter to track number of MB
    try
    {
        while(1)//Loop to run till memory allocation fails
        {
            
            char* Leak = new char[1024*1000]{};//Allocate 1MB each time
            count++;//Increase counter if succeeds else program will throw error
            std::cout<<"loading"<<std::endl;
            Leak[0]='a';//Usage of variable for Werror
        }
    }
    catch(...)//Catch all throws
    {
        //Print out message
        std::cout<<"Amount of memory that can be allocated is"
        <<count<<"MB"<<std::endl;
        exit(1);
    }
    return 0;

}