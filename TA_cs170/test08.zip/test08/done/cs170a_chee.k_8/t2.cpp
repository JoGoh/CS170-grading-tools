/******************************************************************************/
/*!
\file t2.cpp
\author Samuel Chee
\par email: chee.k\@digipen.edu
\par DigiPen login: chee.k
\par Course: CS170
\par Lab 08
\date 22/07/2019
\brief
This file contains the exception mechanism which tests for 
invalid inputs in a program and terminates if exception is thrown.
Functions include:

Hours spent on this assignment: 2 hours
Specific portions that gave you the most trouble:

*/ 
/******************************************************************************/
#include <iostream>

int main()
{
    int sum =0;//Variable to store sum of integers
    try
    {
        
        //Loop to run exactly 10 times
        for(int count=1;count<11;count++)
        {
            int number;//Variable to store input of user
            std::cout<<"Please Input "<<count<<" integer out of 10"<<std::endl;
            std::cin>>number;
            if(std::cin.fail())//If input isn't valid
            {
                throw("Error, Input was NaN. Terminating program");
            }
            else if(number <0)//If input was negative
            {
                throw(-1);
            }
            sum+= number;
        }
    }
    catch(const char* error)//Catch throw from NaN
    {
        std::cout<<error<<std::endl;
        exit(1);
    }
    catch(int)//Catch throw from negative input
    {
        std::cout<<"Input cannot be negative. Terminating program"<<std::endl;
        exit(1);
    }
    catch(...)
    {
        std::cout<<"Unhandled Error. Terminating program"<<std::endl;
    }
    std::cout<<"Sum of 10 Integers is "<<sum<<std::endl;
    return 0;
}