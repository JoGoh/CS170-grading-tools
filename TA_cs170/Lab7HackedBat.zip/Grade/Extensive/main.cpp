#include <iostream>
#include <cstdlib>              // atoi
#include "../Sample/cs170_vector.h"
#include "../SimpleMemoryLeakDetector.h"

#include <string>

using std::cout;
using std::endl;

#define TEST_STD_STRING 1

char const* usa_states[] = {
  "\'Alabama\'",
  "\'Alaska\'",
  "\'Arizona\'",
  "\'Arkansas\'",
  "\'California\'",
  "\'Colorado\'",
  "\'Connecticut\'",
  "\'Delaware\'",
  "\'Florida\'",
  "\'Georgia\'",
  "\'Hawaii\'",
  "\'Idaho\'",
  "\'Illinois\'",
  "\'Indiana\'",
  "\'Iowa\'",
  "\'Kansas\'",
  "\'Kentucky\'",
  "\'Louisiana\'",
  "\'Maine\'",
  "\'Maryland\'",
  "\'Massachusetts\'",
  "\'Michigan\'",
  "\'Minnesota\'",
  "\'Mississippi\'",
  "\'Missouri\'",
  "\'Montana\'",
  "\'Nebraska\'",
  "\'Nevada\'",
  "\'New Hampshire\'",
  "\'New Jersey\'",
  "\'New Mexico\'",
  "\'New York\'",
  "\'North Carolina\'",
  "\'North Dakota\'",
  "\'Ohio\'",
  "\'Oklahoma\'",
  "\'Oregon\'",
  "\'Pennsylvania\'",
  "\'Rhode Island\'",
  "\'South Carolina\'",
  "\'South Dakota\'",
  "\'Tennessee\'",
  "\'Texas\'",
  "\'Utah\'",
  "\'Vermont\'",
  "\'Virginia\'",
  "\'Washington\'",
  "\'West Virginia\'",
  "\'Wisconsin\'",
  "\'Wyoming\'"
};

char const* GetUSAState( std::size_t index ) 
{
  return usa_states[ index % 50 ];
}

void TestPushPop( void )
{
  std::cout << "\n********** TestPush **********\n";

  {
    cs170::vector<float> a;
    Print(a);

    cout << "push_back 16 floats:\n";

    for( float i = 0; i < 16; ++i ) 
    {
      a.push_back(i * 1.75f);
      Print(a);
    }
  }
  {
    cs170::vector<int> a;
    Print(a);

    cout << "push_back 16 ints:\n";

    for( int i = 0; i < 16; ++i ) 
    {
      a.push_back(i);
      Print(a);
    }
  }
  {
    cs170::vector<unsigned char> a;
    Print(a);

    cout << "push_back 16 unsigned char:\n";

    for( unsigned char i = 0; i < 16; ++i ) 
    {
      a.push_back('a' + i);
      Print(a);
    }
  }

  #if TEST_STD_STRING == 1
  {
    cs170::vector<std::string> a;
    Print(a);

    cout << "push_back 8 strings:\n";

    for( char i = 0; i < 8; ++i ) 
    {
      a.push_back( GetUSAState(i*3) );
      Print(a);
    }
  }
  #endif

  std::cout << "\n********** TestPop **********\n";

  {
    cs170::vector<float> a;
    Print(a);

    cout << "push_back 16 floats:\n";

    for( float i = 0; i < 16; ++i ) 
    {
      a.push_back(i * 1.75f);
    }
    Print(a);

    cout << "pop_back 12 times: \n";

    for( int i = 0; i < 12; ++i ) 
    {
      a.pop_back();
      Print(a);
    }

    cout << "pop_back until empty: \n";

    while( !a.empty() )
    {
      a.pop_back();
      Print(a);
    }
  }

  #if TEST_STD_STRING == 1
  {
    cs170::vector<std::string> a;
    Print(a);

    cout << "push_back 8 strings:\n";

    for( int i = 0; i < 8; ++i ) 
    {
      a.push_back( GetUSAState( i + 15 ) );
    }

    Print(a);

    cout << "pop_back 6 times: \n";
    Print(a);

    for( int i = 0; i < 6; ++i ) 
    {
      a.pop_back();
      Print(a);
    }

    cout << "pop_back until empty: \n";
    Print(a);
    
    while( !a.empty() )
    {
      a.pop_back();
      Print(a);
    }
  }
  #endif
}

void TestErase(void)
{
  std::cout << "\n********** TestErase **********\n";
  cs170::vector<short> a;

  Print(a);

  std::cout << "push_back 16 shorts:\n";
  for( short i = 0; i < 16; ++i ) 
  {
    a.push_back( i * 8 );
    Print(a);
  }

  std::cout << "erase(0):\n";
  a.erase(0);
  Print(a);

  std::cout << "erase(3):\n";
  a.erase(3);
  Print(a);

  std::cout << "erase(6):\n";
  a.erase(6);
  Print(a);

  std::cout << "erase(11):\n";
  a.erase(11);
  Print(a);

  std::cout << "erase(5):\n";
  a.erase(5);
  Print(a);

  std::cout << "erase(1):\n";
  a.erase(0);
  Print(a);

  std::size_t q = 0;

  while( !a.empty() ) 
  {
    ++q;

    std::size_t i = ((q % 2) ? 0 : (a.size() - 1) );
    std::cout << "erase(" << i << "):\n";
    a.erase(i);
    Print(a);
  }
}

void TestInsert(void)
{
  {
    cout << "\n********** TestInsert **********\n";
    cs170::vector<float> a;
    Print(a);

    cout << "push_back 8 floats:\n";
    for( float i = 0; i < 8; ++i ) 
    {
      a.push_back( i * 1.412492f );
      Print(a);
    }

    cout << "insert(3, 99):\n";
    a.insert(3, 99);
    Print(a);

    cout << "insert(0, 98):\n";
    a.insert(0, 98);
    Print(a);

    cout << "insert(6, 97):\n";
    a.insert(6, 97);
    Print(a);
  }
  {
    int ia[] = { 
      2, 4, 6, 6, 8, 10, 6, 12, -6, 14, 16, 6, 6 
    };

    std::size_t size = sizeof( ia ) / sizeof( *ia );

    std::cout << "Construct from int array:\n";
    cs170::vector<int> a;

    a.push_back( 0 );

    for( std::size_t i = 0; i < size; ++i )
      a.insert( 0, ia[i] );

    Print(a);
  }
}

void TestSubscripts(void)
{
  {
    std::cout << "\n********** TestSubscripts **********\n";
    cs170::vector<int> a;

    std::cout << "push_back 10 even integers:\n";
    for( int i = 0; i < 10; ++i )
      a.push_back( 2 * i );

    Print(a);

    std::cout << "multiple each value by 3:\n";

    for( int i = 0; i < 10; ++i )
      a[i] *= 3;

    Print(a);
  }
  {
    unsigned char ia[] = { 
      2, 4, 6, 6, 8, 10, 6, 12, 234, 14, 16, 6, 6
    };

    std::size_t size = sizeof( ia ) / sizeof( *ia );

    std::cout << "Construct from unsigned char array:\n";
    cs170::vector<unsigned char> temp_vec;

    for( std::size_t i = 0; i < size; ++i )
      temp_vec.push_back( ia[i] );

    const cs170::vector<unsigned char> a(temp_vec);
    Print(a);

    std::size_t index = a.size() / 2;
    std::cout << "using subscript: a[" << index << "]" << std::endl;
    std::cout << "a[" << index << "] = " << static_cast<std::size_t>(a[index]) << std::endl;
  }
  {

    double ia[] = { 
      2.05, 4, 6, 6, 8, 10, 6, 12, -6, 14, 16, 6, 6 
    };

    std::size_t size = sizeof(ia) / sizeof(*ia);

    std::cout << "Construct from double array:\n";
    cs170::vector<double> a;

    for( std::size_t i = 0; i < size; ++i )
      a.push_back( ia[i] );

    Print(a);

    for( std::size_t i = 0; i < size; ++i )
      a[i] *= 3.14159;

    Print(a);
  }
}

void TestCopyAssign(void)
{
  {
    std::cout << "\n********** TestCopy **********\n";
    cs170::vector<int> a;

    std::cout << "push_back 10 even integers:\n";

    for( int i = 0; i < 10; ++i )
        a.push_back( 2 * i );


    std::cout << "Copy: b(a), print a,b\n";
    cs170::vector<int> b(a);

    Print(a);
    Print(b);

    std::cout << "Copy: c(b), print b,c\n";
    const cs170::vector<int> c(b);

    Print(b);
    Print(c);

    std::cout << "clear b, print b,c\n";
    b.clear();

    Print(b);
    Print(c);
  }
  {
    std::cout << "\n********** TestAssign **********\n";
    cs170::vector<int> a, b;

    std::cout << "push_back 10 integers:\n";

    for( int i = 0; i < 10; ++i ) 
    {
      a.push_back(2 * i);
      b.push_back(i);
    }

    Print(a);
    Print(b);

    std::cout << "Assign: b = a, print a,b\n";
    b = a;
    Print(a);
    Print(b);
    
    std::cout << "Set a to zeroes print a,b\n";

    for( std::size_t i = 0; i < static_cast<size_t>(a.size()); ++i ) 
    {
      a[ i ] = 0;
    }
    
    Print(a);
    Print(b);

    std::cout << "Assign: a = a, print a\n";
    a = a;
    Print(a);
    
    cs170::vector<int>* c = new cs170::vector<int>();

    std::cout << "push_back 10 integers:\n";

    for( int i = 0; i < 10; ++i ) 
    {
      c->push_back(i);
    }

    Print(*c);
    Print(b);

    std::cout << "Assign: b = c, print c,b\n";

    b = *c;

    Print(*c);
    Print(b);
    std::cout << "clear c, print c,b\n";

    c->clear();
    Print(*c);
    Print(b);

    std::cout << "delete c, print b\n";
    delete c;

    Print(b);
  }
}


int main( int argc, char **argv )
{
  std::size_t test_num = 0;

  if( argc > 1 )
    test_num = std::size_t( std::atoi( argv[ 1 ] ) );

  typedef void (*Test)( void );

  Test Tests[] = {
    TestPushPop,               //  1 done
    TestErase,              //  3 done
    TestInsert,             //  4
    TestSubscripts,         //  5
    TestCopyAssign          //  6 done
  };

  std::size_t num = sizeof( Tests ) / sizeof( *Tests );

  if( test_num == 0 ) 
  {
    for( std::size_t i = 0; i < num; ++i )
      Tests[ i ]();
  } 
  else if( test_num <= num )
  {
    Tests[ test_num - 1 ]();
  }

  return 0;
}
