#include <iostream>
#include <cstdlib>              // atoi
#include "cs170_vector.h"
#include "../SimpleMemoryLeakDetector.h"

void TestPush(void)
{
    std::cout << "\n********** TestPush **********\n";
    cs170::vector<float> a;
    std::cout << "Empty array:\n";
    Print(a);

    std::cout << "push_back 5 floats:\n";
    for (float i = 0; i < 5; i++) {
        a.push_back(i);
        Print(a);
    }

    std::cout << "pop_back until empty:\n";
    while (!a.empty()) {
        a.pop_back();
        Print(a);
    }
}


void TestPop(void)
{
    std::cout << "\n********** TestPop **********\n";
    cs170::vector<int> a;
    std::cout << "Empty array:\n";
    Print(a);

    std::cout << "push_back 5 integers:\n";
    for (int i = 0; i < 5; i++) {
        a.push_back(i);
        Print(a);
    }

    std::cout << "pop_back:\n";
    a.pop_back();
    Print(a);

    std::cout << "pop_back/front until empty:\n";
    while (!a.empty()) {
        a.pop_back();
        Print(a);
    }
}

void TestRemove(void)
{
    std::cout << "\n********** TestRemove **********\n";
    cs170::vector<short> a;
    std::cout << "Empty array:\n";
    Print(a);

    std::cout << "push_back 5 shorts:\n";
    for (short i = 0; i < 5; i++) {
        a.push_back(i);
        Print(a);
    }

    std::cout << "erase(0), erase(3):\n";
    a.erase(0);
    a.erase(3);
    Print(a);
}

void TestInsert1(void)
{
    std::cout << "\n********** TestInsert1 **********\n";
    cs170::vector<float> a;
    std::cout << "Empty array:\n";
    Print(a);

    std::cout << "push_back 5 floats:\n";
    for (int i = 0; i < 5; i++) {
        a.push_back(i*1.412492f);
        Print(a);
    }

    std::cout << "insert(3, 99):\n";
    a.insert(3, 99);
    Print(a);
    std::cout << "insert(0, 98):\n";
    a.insert(0, 98);
    Print(a);
    std::cout << "insert(6, 97):\n";
    a.insert(6, 97);
    Print(a);
}

void TestSubscripts(void)
{
    std::cout << "\n********** TestSubscripts **********\n";
    cs170::vector<int> a;

    std::cout << "push_back 10 even integers:\n";
    for (int i = 0; i < 10; i++)
        a.push_back(2 * i);

    Print(a);

    std::cout << "multiple each value by 3:\n";
    for (int i = 0; i < 10; i++)
        a[i] = a[i] * 3;
    Print(a);
}

void TestSubscript1(void)
{
    std::cout << "\n********** TestSubscript1 **********\n";
    unsigned char ia[] = { 2, 4, 6, 6, 8, 10,
                           6, 12, 234, 14, 16, 6, 6
                         };
    int size = sizeof(ia) / sizeof(*ia);
    std::cout << "Construct from unsigned char array:\n";
    cs170::vector<unsigned char> temp_vec;
    for(int i=0; i<size; ++i)
        temp_vec.push_back(ia[i]);

    const cs170::vector<unsigned char> a(temp_vec);
    Print(a);

    size_t index = a.size() / 2;
    std::cout << "using subscript: a[" << index << "]" << std::endl;
    std::cout << "a[" << index << "] = " << static_cast<unsigned>(a[index]) << std::endl;
}

void TestSubscript2(void)
{
    std::cout << "\n********** TestSubscript2 **********\n";
    double ia[] = { 2.05, 4, 6, 6, 8, 10, 6, 12, -6, 14, 16, 6, 6 };
    unsigned size = sizeof(ia) / sizeof(*ia);
    std::cout << "Construct from double array:\n";
    cs170::vector<double> a;
    for(unsigned i=0; i<size; ++i)
        a.push_back(ia[i]);

    Print(a);

    for(unsigned i=0; i<size; ++i)
        a[i]=a[i]*3.14159;

    Print(a);
}

void TestInsert2(void)
{
    std::cout << "\n********** TestInsert2 **********\n";
    int ia[] = { 2, 4, 6, 6, 8, 10, 6, 12, -6, 14, 16, 6, 6 };
    int size = sizeof(ia) / sizeof(*ia);
    std::cout << "Construct from int array:\n";
    cs170::vector<int> a;
    for(int i=0; i<size; ++i)
        a.push_back(ia[i]);

    Print(a);

#if 0
    //Suppose to cause abort
    int index = a.size() * 2;   // illegal
    std::cout << "insert integer at index " << index << ":\n";
    a.insert(99, index);
#endif
}

void TestALot1(void)
{
    std::cout << "\n********** TestALot1 **********\n";
    cs170::vector<int> a;

    std::cout << "push_back 10 even integers:\n";
    for (int i = 0; i < 10; i++)
        a.push_back(2 * i);
    Print(a);

    std::cout << "clear:\n";
    a.clear();
    Print(a);

    std::cout << "push_back 10 odd integers:\n";
    for (int i = 0; i < 10; i++)
        a.push_back(2 * i + 1);
    Print(a);

    std::cout << "empty/fill with 10 ints 3 times:\n";
    for (int i = 0; i < 3; i++) {
        while (!a.empty())
            a.pop_back();

        for (int j = 0; j < 10; j++)
            a.push_back(j);
    }
    Print(a);

    std::cout << "remove all but 3 integers:\n";
    while (a.size() > 3)
        a.pop_back();
    Print(a);

    std::cout << "push_back 10 more integers:\n";
    for (int i = 0; i < 10; i++)
        a.push_back(i);
    Print(a);

    std::cout << "clear:\n";
    a.clear();
    Print(a);
}

void TestCopy(void)
{
    std::cout << "\n********** TestCopy **********\n";
    cs170::vector<int> a;

    std::cout << "push_back 10 even integers:\n";
    for (int i = 0; i < 10; i++)
        a.push_back(2 * i);

    std::cout << "Copy: b(a), print a,b\n";
    cs170::vector<int> b(a);
    Print(a);
    Print(b);

    std::cout << "Copy: c(b), print b,c\n";
    const cs170::vector<int> c(b);
    Print(b);
    Print(c);
}

void TestAssign(void)
{
    std::cout << "\n********** TestAssign **********\n";
    cs170::vector<float> a, b;

    std::cout << "push_back 10 floats:\n";
    for (float i = 0; i < 10; i++) {
        a.push_back(2 * i);
        b.push_back(i);
    }

    Print(a);
    Print(b);

    std::cout << "Assign: b = a, print a,b\n";
    b = a;
    Print(a);
    Print(b);

    std::cout << "Assign: a = a, print a\n";
    a = a;
    Print(a);
}

int main(int argc, char **argv)
{
    int test_num = 0;
    if (argc > 1)
        test_num = std::atoi(argv[1]);

    typedef void (*Test) (void);
    Test Tests[] = {
        TestPush,               //  1
        TestPop,                //  2
        TestRemove,             //  3
        TestInsert1,            //  4
        TestSubscripts,         //  5
        TestSubscript1,         //  6
        TestSubscript2,         //  7
        TestInsert2,            //  8
        TestALot1,              //  9
        TestCopy,               // 10
        TestAssign,             // 11

    };
    int num = sizeof(Tests) / sizeof(*Tests);
    if (test_num == 0) {
        for (int i = 0; i < num; i++)
            Tests[i] ();
    } else if (test_num > 0 && test_num <= num)
        Tests[test_num - 1] ();
}
