/************************************************************************* 
*   @filename   main.cpp
*   @author(s)  Aina Tan
*   @DP emails  aina.tan@digipen.edu
*   @course     CS170
*   @assignment Lab 1
*   @due date   by next lab 
*   Brief Description: 
 Program needs to read in a sequence of numbers from the user input, two numbers 
 at a time until receiving 0 0.
**************************************************************************/

#ifndef LIST_H
#define LIST_H

struct Node {
    int value ;              /* data field */
    struct Node *next ;      /* pointer field */
};

// Adds a node to the end of the list
void AddToEnd(Node **pList , int value);

// Adds a node to the front of the list
void AddToFront(Node **pList , int value);

// Returns the number of nodes in the list
int Count(Node *list);

// Frees (deletes) all of the nodes in the list
void FreeList(Node *list);

// Prints all of the nodes values
void PrintList(Node *list);

#endif    /* LIST_H */
