#include <iostream>             // cout, endl
#include <iomanip>              // setw
#include <string>
#include <limits>
#include "list.h"

bool is_circular( CS170::list& my_list )
{
  CS170::node* node_one = my_list.front();
  CS170::node* node_two = nullptr;

  if( !node_one ) 
  {
    return false;
  }

  node_two = node_one->next;

  while( node_two && node_two->next )
  {
    if( node_two == node_one || node_two->next == node_one )
      return true;

    node_one = node_one->next;
    node_two = node_two->next->next;
  }

  return false;
}   

int main(void)
{
    std::string funcName[6] = {"Push_Front          ",
                               "Erase One Element   ",
                               "Erase Some Elements ",
                               "Resize w New Val    ",
                               "Resize w Default Val",
                               "Merge               "};

    int choice, listID = 0, pos1, pos2, newSize, newVal;
    CS170::list list1, list2;
    CS170::list *chosenList;

    do
    {
        std::cin >> choice;
        if (choice != 0 && choice != 6)
            std::cin >> listID;

        if (choice != 0)
        {
            std::cout << funcName[choice-1] << ": ";

            if (listID == 1)
                chosenList = &list1;
            else
                chosenList = &list2;

            switch (choice)
            {
                case 1:
                    std::cin >> newVal;
                    chosenList->push_front(newVal);
                    break;

                case 2:
                    std::cin >> pos1;
                    chosenList->erase(pos1);
                    break;

                case 3:
                    std::cin >> pos1 >> pos2;
                    chosenList->erase(pos1, pos2);
                    break;

                case 4:
                    std::cin >> newSize >> newVal;
                    chosenList->resize(newSize, newVal);
                    break;

                case 5:
                    std::cin >> newSize;
                    chosenList->resize(newSize);
                    break;

                case 6:
                    list1.sort();
                    list2.sort();
                    list1.merge(list2);
                    break;
            }

            if( is_circular( list1 ) || 
                is_circular( list2 ) )
            {
              std::cin.sync();
              std::cin.ignore(std::numeric_limits<std::streamsize>::max());
              std::cout << "List is invalid (circular), test exiting" << std::endl;
              return 0;
            }

            switch (choice)
            {
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                    std::cout << "List" << listID << " (" << std::setw(2) << 
                        chosenList->size() << " nodes): ";
                    chosenList->print_list();
                    break;

                case 6:
                    std::cout << "\n";
                    std::cout << "List1" << " (" << std::setw(2) << 
                        list1.size() << " nodes): ";
                    list1.print_list();

                    std::cout << "List2" << " (" << std::setw(2) << 
                        list2.size() << " nodes): ";
                    list2.print_list();
                    break;
            }
        }
    }
    while (choice != 0);

    return 0;
}
