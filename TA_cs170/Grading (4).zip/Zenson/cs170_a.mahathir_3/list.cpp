/******************************************************************************/
/*!
\file    list.cpp
\author  Abrisam Durrani 
\par     email: a.mahathir\@digipen.edu
\par     Digipen login: a.mahathir 
\par     course: CS170L 
\par     Lab 3
\date    01/02/2019 
\brief
    This file contains various functions that
    manipulates nodes.
*/  
/******************************************************************************/
#include <iostream>
#include "list.h"
/*************************************************************************/
/*! 
    \brief 
        This function creates a new struct of 
        type node.
        
    \param value  
        an int value to be stored in the node
        
    \return 
        the address of the newly created node.     
*/
/**************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/*************************************************************************/
/*! 
    \brief 
      This function prints out the content 
      of the node.
        
    \param list  
      a pointer that points to a read only node
*/
/**************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/*************************************************************************/
/*! 
    \brief 
      This function deletes the current node.
        
    \param list  
      a reference to a pointer to a node
*/
/**************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/*************************************************************************/
/*! 
    \brief 
      This function counts the iterations
      needed to reach the final node.
        
    \param list  
      a pointer that points to a read only node
        
    \return 
      an int value that represents the 
      number of iterations.    
*/
/**************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/*************************************************************************/
/*! 
    \brief 
      This function adds a new node at the end of 
      the linked list
        
    \param list   
      a reference to the pointer that points to
      the first node 
        
    \param value
      an int value that is to 
      be stored into the new node
*/
/**************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/*************************************************************************/
/*! 
    \brief 
      This function adds a new node to
      the front of the linked list. The pointer
      that points to the original node is made to point to 
      first node (the newly created node)
        
    \param list   
      a reference to the pointer that points to
      the first node
        
    \param value
      an int value that is to 
      be stored into the new node
*/
/**************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
/*************************************************************************/
/*! 
    \brief 
      This function reverses the order of the nodes. 
        
    \param list   
      a reference to the pointer that points to
      the first node
*/
/**************************************************************************/
void reverse(Node *&list)
{
    if(list == NULL || list->next == NULL)
    {
        return;
    }
    else
    {
        Node * temp1 = nullptr;
        Node * temp2 = nullptr;
        Node * temp3 = nullptr;
        
        for(temp2 = list; temp2 != NULL;)
        {
            temp3 = temp2->next;
            temp2->next = temp1;
            temp1 = temp2;
            temp2 = temp3;
        }
        
        list = temp1;
    }
}
/*************************************************************************/
/*! 
    \brief 
      This function sorts the node by their values in ascending order.  
      
    \param list   
      a reference to the pointer that points to
      the first node
*/
/**************************************************************************/
void sort(Node *&list)
{
    if(list == NULL || list->next == NULL)
    {
        return;
    }
    
    else
    {
        Node * temp1 = list;
        Node * temp2 = temp1->next;
        int iterations = 1;
        while(iterations)
        {
            iterations = 0;
            temp1 = list;
            temp2 = temp1->next;
            while(temp2 != NULL)
            {
                if( temp1->value > temp2->value )
                {
                    int x = temp1->value;
                    temp1->value = temp2->value;
                    temp2->value = x;
                    iterations++;
                }
                
                temp1=temp2;
                temp2 = temp2->next;
                
            }
            if(iterations == 0)
                {
                    return;
                }
        }
    }
}
/*************************************************************************/
/*! 
    \brief 
      This function deletes nodes that has duplicate values.
        
    \param list   
      a reference to the pointer that points to
      the first node
*/
/**************************************************************************/
void unique(Node *&list)
{
    if(list == NULL || list->next == NULL)
    {
        return;
    }
    
    else
    {
        Node * temp1 = list;
        Node * temp2 = list->next;
        Node * temp3 = nullptr;
    
        while(temp2!=NULL)
        {
            if(temp1->value == temp2->value)
            {
                temp3 = temp2;
                temp1->next = temp2->next;
                temp2 = temp2->next;
                delete temp3;
            }
            else
            {
                temp1= temp2;
                temp2 = temp2->next;                
                
            }
            
        }
        temp1->next = nullptr;
    }   
    
}
 








