/******************************************************************************/
/*!
\file   list.cpp
\author Han Sheng Guang Wilson
\par    email   h.shengguangwilson\@digipen.edu
\par    digipen login: h.shengguangwilson
\par    course     CS170    
\par    assignment Lab 03
\date   Deadline: Friday, 0. February 2019, 06:00 PM
  
\brief 
This source file contains nine functions:
(1)  Node *make_node(int value);
(2)  void print_list(Node const *list);
(3)  void clear(Node *&list);
(4)  int count(Node const *list);
(5)  void push_back(Node *&list, int value);
(6)  void push_front(Node *&list, int value);
(7)  void reverse(Node *&list);
(8)  void sort(Node *&list);
(9)  void unique(Node *&list);

The purpose of this file is to provide call functions for the main source file
to process in std-in of numbers to form a linked-list.
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
/*!
      \brief
       Dynamically allocate memory for new node
     
      \param value
       The given value
     
      \return pNode
      Returns the new node
    
*/
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
/*!
      \brief
       Print the entire list of numbers.
     
      \param list
       The address of the first node of the list.
     
      \return nothing
*/
/******************************************************************************/ 
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
/*!
      \brief
       Delete all nodes in the linked list.
     
      \param list
      The address of the first node of the list.
     
      \return nothing
    
*/
/******************************************************************************/ 
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
/*!
      \brief
       Count the number of elements in the linked list.
     
      \param list
       The address of the first node of the list.
     
      \return count
      The number of elements in the linked list.
    
*/
/******************************************************************************/ 
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/******************************************************************************/
/*!
      \brief
       Creates a new node and add it to the end of the linked list.
     
      \param list
      The address of the first node of the list.
     
     \param value
      The input value provided by the user.
     
      \return nothing
    
*/
/******************************************************************************/ 
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/******************************************************************************/
/*!
      \brief
       Add a node to the front of the linked list.
     
      \param list
      The address of the first node of the list.
      
      \param value
      The input value provided by the user.
     
      \return nothing
    
*/
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
/******************************************************************************/
/*!
      \brief
      Reverse the order of all nodes in the linked list.
            
      \param list
      The address of the first node of the list.
      
      \return nothing
*/
/******************************************************************************/
void reverse(Node *&list){
    Node *curNode = list;
    Node *nxtNode = NULL;
    Node *prvNode = NULL;
    
    if(list == NULL){//check if the list is empty by checking if the 1st node. 
            return;//no action required
    }
    while (curNode!=NULL){
        nxtNode = curNode->next;//link the next node to the variable nxtNode
        curNode->next = prvNode;//link that same node to the variable prvNode
        prvNode = curNode;//link the current node to the variable prvNode 
        curNode = nxtNode;//link variable nxtNode to the current node.
    }
    list = prvNode;
}
/******************************************************************************/
   /*!
      \brief
      Arrange the nodes of the linked list in ascending order.
            
      \param list
      The address of the first node of the list.
      
      \return nothing
    */
/******************************************************************************/
void sort(Node *&list) {
    Node *curNode;
    Node *nxtNode;
    int temp;
    
    if(list == NULL){//check if the list is empty by checking if the 1st node. 
            return;//no action required
    }
    for(curNode = list; curNode->next != NULL; curNode = curNode->next){
        for(nxtNode = curNode->next; nxtNode!= NULL; nxtNode = nxtNode->next){
            if(curNode->value > nxtNode->value)
            {
                temp = curNode->value;
                curNode->value = nxtNode->value;
                nxtNode->value = temp;
            }
        }
    }
}
/******************************************************************************/
   /*!
      \brief
      Removes nodes with consecutive duplicated values.
            
      \param list
      The address of the first node of the list.
      
      \return nothing
    */
/******************************************************************************/
void unique(Node *&list){
    Node *temp = list;
    Node *delNode = nullptr;
    
    if(list == NULL)
        return;
    while(temp->next != NULL){
        if(temp->value == temp->next->value){
            delNode = temp->next;
            if(temp->next->next){
                temp->next = temp->next->next;
            }
            else
            {
                temp->next = nullptr;
            }
            delete delNode;
        }
        else
            temp = temp->next;
    }
}
