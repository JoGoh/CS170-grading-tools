/******************************************************************************/
/*!
\file list.cpp
\author Ling Jie Han, James
\par email: j.ling\@digipen.edu
\par DigiPen login: j.ling
\par Course: CS170
\par Lab 03
\date 01/02/2019
\brief
This is file has various function such as creating new node, count number of 
nodes, clearing list, pushing back and front nodes, reversing list, sorting 
list according to value and deleting duplicate value
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
/*!
\fn Node *make_node(int value)
\brief makes a new node with value for the linked list
\param value
\return pNode

*/
/******************************************************************************/
Node *make_node(int value) 
{
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
/*!
\fn print_list(Node const *list)
\brief Prints all of the nodes values in the linked list.
\param *list
\return 

*/
/******************************************************************************/
void print_list(Node const *list) 
{
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
/*!
\fn clear(Node *&list)
\brief deletes the whole linked list.
\param *&list
\return

*/
/******************************************************************************/
void clear(Node *&list) 
{
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
/*!
\fn count(Node const *list)
\brief Returns the number of nodes in the linked list.
\param *list
\return

*/
/******************************************************************************/
int count(Node const *list) 
{
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/******************************************************************************/
/*!
\fn push_back(Node *&list, int value)
\brief move node back put newnode infront.
\param *&list,value
\return

*/
/******************************************************************************/
void push_back(Node *&list, int value)
{
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/******************************************************************************/
/*!
\fn push_front(Node *&list, int value)
\brief make node move front of linked list, add node to back.
\param *list,value
\return

*/
/******************************************************************************/
void push_front(Node *&list, int value) 
{
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
/******************************************************************************/
/*!
\fn reverse(Node* &list)
\brief reverse linked list of nodes
\param *&list
\return

*/
/******************************************************************************/
void reverse(Node *&list)
{
	Node *pCurr = list;
	Node *pPrev = NULL, *pNext = list;
	
	/* Walk Through the list */
	while(pCurr)
	{
		/* Points to next node */
		pNext = pCurr->next;
		/* Points the node in reverse */
		pCurr->next = pPrev;
		/* Moves previous pointer to current node */
		pPrev = pCurr;
		/* Points to the next node */
		pCurr = pNext;
	}
	list = pPrev;
}
/******************************************************************************/
/*!
\fn sort(Node* &list)
\brief sort nodes base on its value from smallest to largest.
\param *&list
\return

*/
/******************************************************************************/
void sort(Node *&list)
{
	Node *pcurrent = nullptr;
    Node *pfollowing = nullptr;
    int temp = 0;

    for (pcurrent = list; pcurrent->next != NULL; pcurrent = pcurrent->next)
    // Loop with current ptr
    {
     	for(pfollowing = pcurrent->next; pfollowing != NULL; pfollowing = pfollowing->next)
    	// Loop with following ptr      
        {     
        	if (pcurrent->value > pfollowing->value)
    		  //compare current's value and following's value
            {   
            	  temp = pcurrent->value;
    			      //store current's value in temp
                pcurrent->value = pfollowing->value;
    			      //assign following's value to current
                pfollowing->value = temp;
    			      //assign temp's value to following       
            }

            if(pfollowing->next == NULL)
            {
            	break;
            }
        }
    }
}   
/******************************************************************************/
/*!
\fn unique(Node* &list)
\brief delete duplicate values in list
\param &list
\return

*/
/******************************************************************************/
void unique(Node *&list)
{
	  Node *prev = list;
    Node *pCurr = nullptr;
    Node *dup = nullptr;
    
    
    while (prev != NULL && prev->next != NULL)
    {
		pCurr = prev;
   
        while (pCurr->next != NULL)
        {
        	if (prev->value == pCurr->next->value)
            { 
              dup = pCurr->next;
    			    //assign duplicate to point to next node of second
              pCurr->next = pCurr->next->next;
    			    //point second to next next node
              delete dup;
    			    // delete duplicates 
            }
           else 
            pCurr = pCurr->next;
    			  //if not duplicate
        }

        prev = prev->next;
    }
}

