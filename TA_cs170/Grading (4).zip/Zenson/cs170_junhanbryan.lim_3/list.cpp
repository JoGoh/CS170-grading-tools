
/******************************************************************************/
/*!
\file list.cpp
\author Bryan Lim
\par email: junhanbryan.lim\@digipen.edu
\par DigiPen login: junhanbryan.lim
\par Course: CS170L
\par Lab 03
\date 1/02/2019
\brief
This is a file called list.cpp.
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
/*!
\brief
Creates a node.
\param 
value is passed into the function.
\return
pNode is returned.
*/
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}


/******************************************************************************/
/*!
\brief
printing a list.
\param 
list is passed into the function.
\return
void
*/
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/******************************************************************************/
/*!
\brief
clear a node.
\param 
list is passed into the function.
\return
void
*/
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}


/******************************************************************************/
/*!
\brief
counting
\param 
list is passed into the function.
\return
count
*/
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/******************************************************************************/
/*!
\brief
pushing to the back of list
\param 
list , value is passed into the function.
\return
void
*/
/******************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
/*!
\brief
pushing to front of node.
\param 
list , value is passed into the function.
\return
void
*/
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}


/******************************************************************************/
/*!
\brief
reverse elements.
\param 
list is passed into the function.
\return
void
*/
/******************************************************************************/
void reverse (Node* &list){
    Node *current = list;
    Node *prev= NULL;
    Node *next= NULL;
    
    while(current!=NULL)
    {
        next= current->next;
        current->next=prev;
        prev=current;
        current=next;
    }
    list = prev;
}

/******************************************************************************/
/*!
\brief
sorting elements
\param 
list is passed into the function.
\return
void
*/
/******************************************************************************/
void sort (Node* &list){
    int temp=0;
    Node *first=list;
    if(list==NULL)
    {
        return;
    }
    while(first!=NULL)
    {
        Node *second = first->next;
        while(second!=NULL)
        {
         if((first->value)>(second->value))
         {
            temp=first->value;
            first->value=second->value;
            second->value=temp;
            second=second->next;
         }
         else
         {
            second=second->next;
         }
        }
    
     first=first->next;
        
    }
}  





/******************************************************************************/
/*!
\brief
removing duplicates 
\param 
list is passed into the function.
\return
void
*/
/******************************************************************************/
void unique (Node* &list){
    Node *p= list;
    Node *next;
    if(p==NULL)
        return;
    while(p->next!=NULL)
    {
        if(p->value==p->next->value)
        {
            next=p->next->next;
            delete p->next;
            p->next=next;
        }
        else
        {
            p=p->next;
    }
    }
}