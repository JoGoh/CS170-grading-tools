/******************************************************************************/
/*!
\file list.cpp
\author Choy Da Wei, Ethan
\par email: choy.d\@digipen.edu
\par DigiPen login: choy.d
\par Course: CS170
\par Lab 03
\date 01/02/2019
\brief
This is file has various function such as creating new node, count number of 
nodes, clearing list, pushing back and front nodes, reversing list, sorting 
list according to value and deleting duplicate value
*/
/******************************************************************************/

#include <iostream>
#include "list.h"
/******************************************************************************/
/*!
\fn Node *make_node(int value)
\brief makes a new node with value
\param value
\return pNode

*/
/******************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/******************************************************************************/
/*!
\fn print_list(Node const *list)
\brief Prints all of the nodes values
\param *list
\return 

*/
/******************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/******************************************************************************/
/*!
\fn clear(Node *&list)
\brief delete list
\param *&list
\return

*/
/******************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/******************************************************************************/
/*!
\fn count(Node const *list)
\brief Returns the number of nodes in the list
\param *list
\return

*/
/******************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/******************************************************************************/
/*!
\fn push_back(Node *&list, int value)
\brief make node move back put newnode infront
\param *&list,value
\return

*/
/******************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/******************************************************************************/
/*!
\fn push_back(Node *&list, int value)
\brief make node move front, add node to back
\param *list
\return

*/
/******************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}
/******************************************************************************/
/*!
\fn reverse(Node* &list)
\brief reverse list of nodes
\param *&list
\return

*/
/******************************************************************************/

void reverse(Node* &list){
    Node *previous = list;
    Node *current = nullptr;
    Node *following = nullptr;
    if (previous == NULL)
    {   
        return;
    }
    else if (previous->next == NULL)
    {   

    }
    
    else if(previous->next->next == NULL)
    {   current = previous->next;
    //assign current to point to next node of list
        current->next = previous;
    //point backwards to previous
        previous->next = NULL;
    //make previous next link a null
        list = current;
    //make start of list current
    
    }
        
    else if (previous != NULL)
    {   
        current = previous->next;
    //assign current to point to next node of list
        following = current->next;
    //assign following to point to next node after current
        previous->next = nullptr;
    //make previous ptr next link null
        while (previous)
        {
                current->next = previous;
    //point backwards to previous   
                previous = current;
    //move previous ptr to point to same node as current
                current = following;
    //move current ptr to point to following
                following = following->next;
    //move following ptr to point to next node
                
    if (following->next == NULL)
    //if reach end of list end loop
    {       
        break;
        
    }
                
        
        }
        current->next = previous;
        //link my current next node to be previous
        following ->next = current;
        //link my following next node to be current
        list = following;
        //assign start of list to be following ptr
    }
}
/******************************************************************************/
/*!
\fn sort(Node* &list)
\brief sort nodes base on its value
\param *&list
\return

*/
/******************************************************************************/
void sort(Node* &list){
    Node *current = nullptr;
    Node*following = nullptr;
    int temp;
    
    for (current = list; current->next != NULL; current = current->next)
    // Loop with current ptr
    {
        for (following = current->next; following != NULL; following = following->next)
    // Loop with following ptr      
            {     if (current->value > following->value)
    //compare current's value and following's value
                {   
                        temp = current->value;
    //store current's value in temp
                        current->value = following->value;
    //assign following's value to current
                        following->value = temp;
    //assign temp's value to following
                        
                }
                if(following->next == NULL)
                {
                    break;
                }
            }
    }
}   
/******************************************************************************/
/*!
\fn unique(Node* &list)
\brief delete duplicate values in list
\param &list
\return

*/
/******************************************************************************/
void unique(Node* &list){
    
    Node *first = list;
    Node *second = nullptr;
    Node *duplicate = nullptr;
    
    
    while (first != NULL && first->next != NULL)
    {
    second = first;
    //assign second ptr to first node
        while (second->next != NULL)
        {
            if (first->value == second->next->value)
    //compare first node value if equal to second node value
            { 
                duplicate = second->next;
    //assign duplicate to point to next node of second
                second->next = second->next->next;
    //point second to next next node, so as not to lose link
                delete duplicate;
    // delete value inside duplicate
            }
            
            else 
                second = second->next;
    //if not duplicate, move second pointer
        }
        
        first = first->next;
    }
}

  
                