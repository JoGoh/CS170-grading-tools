/******************************************************************************/
/*!
\file   list.cpp
\author John Yio
\par    email: john.yio\@digipen.edu
\par    DigiPen login: john.yio
\par    Course: CS170C
\par    Lab 03
\date   25/01/2019
\brief
     
\brief  
    This file contains the functions required for manipulating a linked list.
      
    Functions include:
        make_node
        print_list
        clear
        count
        push_back
        push_front
        reverse
        sort
        unique
 
  Hours spent on this assignment: 2

  Specific portions that gave you the most trouble: The sort function.
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
/*! 
 
  \fn make_node 
 
  \brief
    Makes a new node for the linked list. 
 
  \param value
    The integer value inside the new node to be made.
    
  \return
   Returns the pointer to the newly created node.  
*/
/*****************************************************************************/ 
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/*****************************************************************************/
/*! 
 
  \fn print_list
 
  \brief
    Prints the values of the nodes in the linked list.
 
  \param list
    The reference to the pointer to the first node.
    
  \return
    Void.
*/
/*****************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/*****************************************************************************/
/*! 
 
  \fn clear
 
  \brief
    Frees the memory allocated for the nodes.
 
  \param list
    The reference to the pointer to the first node.
    
  \return
    Void.
*/
/*****************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/*****************************************************************************/
/*! 
 
  \fn count 
 
  \brief
    Counts the number of nodes in the linked list.
 
  \param list
    The reference to the pointer to the first node.
    
  \return
    Returns an integer value of the number of nodes in the linked list.
*/
/*****************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/*****************************************************************************/
/*! 
 
  \fn push_back 
 
  \brief
    Makes a new node, and adds it to the end of the linked list.
 
  \param list
    The reference to the pointer to the first node.
 
  \param value
    The integer value to be placed in the newly created node.
    
  \return
    Void.
*/
/*****************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/*****************************************************************************/
/*! 
 
  \fn push_front 
 
  \brief
    Makes a new node, and adds it to the front of the linked list.
 
  \param pList
    The reference to the pointer to the first node.
 
  \param value
    The integer value to be placed in the newly created node.
    
  \return
    Void.
*/
/*****************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/*****************************************************************************/
/*! 
 
  \fn reverse 
 
  \brief
    Reverses the order of the linked list.
 
  \param pList
    The reference to the pointer to the first node.
    
  \return
    Void.
*/
/*****************************************************************************/
void reverse(Node* &list){ // list is a ref to a ptr to a Node
  Node* first=list;
  Node* temp1=first;
  Node* temp2=first;
  if(list==nullptr);
  else if(count(list)==1);
  else{
    temp1=(temp1->next);
    temp2=(temp2->next);
    (list->next)=nullptr;//seperate the list
    while(temp2!=nullptr){
      push_front(list,(temp2->value));//push to new list
      temp2=(temp2->next);
    }
    clear(temp1);//clear junk list
  }
}

/*****************************************************************************/
/*! 
 
  \fn sort 
 
  \brief
    Sorts the nodes with their values in ascending order.
 
  \param pList
    The reference to the pointer to the first node.
    
  \return
    Void.
*/
/*****************************************************************************/
void sort(Node* &list){
  if(list==nullptr);
  else if(count(list)==1);
  else{
    Node* move=list;//moving pointer
    Node* after=(list->next);//comparing pointer
    Node* check=list;//checking pointer to stop loop
    while(1){//forever loop
      move=list;//set moving pointer to front of the list
      check=list;//set checking pointer to front of the list
      after=(list->next);//set comparing pointer
      while((after)!=nullptr){
        if((move->value)>(after->value)){//comparing
          push_front(list,(after->value));//smaller value node pushed to front
          (move->next)=(after->next);
          delete after;
          if(move!=nullptr){
            after=(move->next);
          }
        }
        else{
          move=after;
          after=(after->next);
        }
      }
      if(list==check)break;//check if any swapping occured in loop
  }
  }    
}

/*****************************************************************************/
/*! 
 
  \fn unique 
 
  \brief
    Removes extra nodes that have the same value.
 
  \param pList
    The reference to the pointer to the first node.
    
  \return
    Void.
*/
/*****************************************************************************/
void unique(Node* &list){
  if(list==nullptr);
  else if(count(list)==1);
  else{
    sort(list);
    Node*temp1=list;
    Node*temp2=(temp1->next);
    Node*another=nullptr;
    while(temp2!=nullptr){
      if((temp1->value)!=(temp2->value)){
        push_back(another,(temp1->value));//create new list
      }
      temp1=temp2;
      temp2=(temp2->next);
    }
    push_back(another,(temp1->value));//used to add the last node
    clear(list);//clear previous list
    list=another;//so that list is the new list
  }
}