/******************************************************************************/ 
/*! 
\file   list.cpp 
\author Tay Xiang Wei
\par    email: xiangwei.tay\@digipen.edu 
\par    DigiPen login: xiangwei.tay 
\par    Course: CS170s
\par    Lab 03
\date   31/01/2019
\brief  
  This is file is for learning about linked list in c++
*/ 
/******************************************************************************/ 

#include <iostream>
#include "list.h"

/******************************************************************************/
/*! 
 
  \fn make_node 
 
  \brief
  Makes a new Node. Allocates memory and set members
 
  \param parameter1
  value
  \return
  pNode
*/
/******************************************************************************/  
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}

/******************************************************************************/
/*! 
 
  \fn print_list 
 
  \brief
    Prints all of the nodes values
 
  \param parameter1
  Node const *list
  \return
  void
*/
/******************************************************************************/  
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}

/******************************************************************************/
/*! 
 
  \fn clear 
 
  \brief
    Frees (deletes) all of the nodes in the list
 
  \param parameter1
  Node *&list
  \return
  void
*/
/******************************************************************************/  
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}

/******************************************************************************/
/*! 
 
  \fn count 
 
  \brief
    Returns the number of nodes in the list
 
  \param parameter1
  Node const *list
  \return
  count
*/
/******************************************************************************/  
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}

/******************************************************************************/
/*! 
 
  \fn push_back 
 
  \brief
    Push a node to the back of the list
 
  \param parameter1
  Node *&list, int value
  \return
  void
*/
/******************************************************************************/  
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}

/******************************************************************************/
/*! 
 
  \fn push_front 
 
  \brief
    Push a node to the front of the list
 
  \param parameter1
  Node *&list, int value
  \return
  void
*/
/******************************************************************************/  
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
/*! 
 
  \fn reverse 
 
  \brief
    Reverse the order of the elements in the list
 
  \param parameter1
  Node *&list
  \return
  void
*/
/******************************************************************************/  
void reverse(Node *&list){
    Node *Curr = list;
    Node *Temp = NULL;
    Node *Prev = NULL;
    
    while (Curr != NULL)
    {
        Temp = Curr->next;
        Curr->next = Prev;
        Prev = Curr;
        Curr = Temp;
    }
        list = Prev;
}

/******************************************************************************/
/*! 
 
  \fn sort 
 
  \brief
    Sort elements in the list
 
  \param parameter1
  Node *&list
  \return
  void
*/
/******************************************************************************/  
void sort(Node *&list){
    int swapped;
    Node *ptr1;
    Node *lptr = NULL;
    if (list==NULL)
        return;
    do {
        swapped = 0;
        ptr1 = list;
        
        while (ptr1->next != lptr)
        {
            if (ptr1->value > ptr1->next->value)
            {
                int temp = ptr1->value;
                ptr1->value = ptr1->next->value; 
                ptr1->next->value = temp; 
                swapped=1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    }
    while (swapped);
}

/******************************************************************************/
/*! 
 
  \fn unique 
 
  \brief
    Remove duplicate values in a sorted list
 
  \param parameter1
  Node *&list
  \return
  void
*/
/******************************************************************************/  
void unique(Node *&list){
    Node *Curr = list;
    Node *temp = NULL;
    sort(Curr);
    if (Curr == NULL)
    {
        return;
    }
    else{
    while (Curr->next != NULL)
    {
        if(Curr->value == Curr->next->value)
        {
            temp = Curr->next;
            Curr->next = temp->next;
            delete temp;
        }
        else
        {
            Curr = Curr->next;
        }
    }
    }
}