/******************************************************************************/
/*!
\file   list.cpp
\author Gan Kai Ler
\par    email: kailer.g\@digipen.edu
\par    DigiPen login: kailer.g
\par    Course: CS170C
\par    Lab 03
\date   25/01/2019
\brief
     
\brief  
    This file contains the functions required for manipulating a linked list.
      
    Functions include:
        make_node
        print_list
        clear
        count
        push_back
        push_front
        reverse
        sort
        unique
 
  Hours spent on this assignment: 12

  Specific portions that gave you the most trouble: SORT function algorithms
  and the INPUT_LARGE text files.
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
/******************************************************************************/
/*! 
  \brief
    Makes a new node. 
 
  \param value
    The integer value inside the new node to be made.
    
  \return
   Returns a pointer to the newly created node.  
*/
/*****************************************************************************/
Node *make_node(int value) {
  Node *pNode = new Node;
  pNode->value = value;
  pNode->next = nullptr;  
  return pNode;
}
/*****************************************************************************/
/*! 
  \brief
    Cycles through the linked list and prints out all values
 
  \param list
    A pointer to the first member of the list
    
  \return
    Void
*/
/*****************************************************************************/
void print_list(Node const *list) {
  while (list) {
    std::cout << list->value << " ";
    list = list->next;
  }
  std::cout << std::endl;   
}
/*****************************************************************************/
/*! 
  \brief
    Deletes all allocated memory in the linked list
 
  \param list
    Pointer to the first member of the list
    
  \return
    Void.
*/
/*****************************************************************************/
void clear(Node *&list) {
  Node *pCurrNode = list;
  while (pCurrNode) {
    list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = list;
  }
  list=nullptr;
}
/*****************************************************************************/
/*! 
  \brief
    Counts the number of nodes in the list
 
  \param list
    Pointer to the first member of the list
    
  \return
    An integer representing the number of counts.
*/
/*****************************************************************************/
int count(Node const *list) {
  int count = 0;
  while (list) {
    count++;
    list = list->next;
  }
  return count;
}
/*****************************************************************************/
/*! 
  \brief
    Creates a new node and throws it to the end of the linked list
 
  \param list
    Pointer to the first member of the linked list
 
  \param value
    The value the user wants to insert into the linked list
    
  \return
    Void.
*/
/*****************************************************************************/
void push_back(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  Node *pCurrNode = list;

  if (list == nullptr)
    list = pNewNode;
  else {
    while (pCurrNode->next)
      pCurrNode = pCurrNode->next;
    pCurrNode->next = pNewNode;
  }  
}
/*****************************************************************************/
/*! 
  \brief
    Makes a new node, and adds it to the front of the linked list.
 
  \param list
    Pointer to the first member of the linked list
 
  \param value
    The value the user wants to insert into the linked list
    
  \return
    Void.
*/
/*****************************************************************************/
void push_front(Node *&list, int value) {
  Node *pNewNode = make_node(value);
  pNewNode->next = list;
  list = pNewNode;  
}

/******************************************************************************/
/*! 
  \brief
    Swaps the position of two values in the linked list without compromising
	the list position.
 
  \param firstnode
	The first node that you want to swap.
  
  \param secondnode
	The second node that you want to swap.
    
  \return
   void 
*/
/*****************************************************************************/

void valueswap(Node *&firstnode, Node *&secondnode){
	int value = firstnode->value;
	firstnode->value = secondnode->value;
	secondnode->value = value;
	return;
}

/******************************************************************************/
/*! 
  \brief
    Safely deletes a node and links the previous node to the node AFTER the
	deleted one if there it exists; if not, it will link the previous node to
	a NULLPTR.
 
  \param firstnode
	The first node that you want to swap.
  
  \param second
	The node that you are selecting for deletion.
    
  \return
   void 
*/
/*****************************************************************************/
void safedeletion(Node *&firstnode ,Node *&second){ //deletes next node safely by linking current node to the one after that
	Node *imminent_deletion = second;
	if(second->next)
		second = second->next;
	else
	{
		firstnode->next = nullptr;
		delete imminent_deletion;
		second = nullptr;
		return;
	}
	delete imminent_deletion;
	firstnode->next = second;
	return;
}

/******************************************************************************/
/*! 
  \brief
    Reverses the order of the linked list
 
  \param list
	A pointer to the first element of the linked list.
    
  \return
   void 
*/
/*****************************************************************************/
void reverse(Node *&list){
	
	if(!list)
		return;
	
	int length = count(list);
	
	if(length<=1)
		return;
	
	Node *tmp_front = list; //this node iterates through the list
	Node *newlist = list; //new node that points to first member of list
	tmp_front = tmp_front -> next; //cycles tmpfront to the second node
	Node *temp = list;//initialised to point at first member to avoid dangling ptr
	if(length>2)
		temp = tmp_front->next; //cycles temp to the third node
	else
	{
		newlist->next = nullptr;
		temp = newlist;
		newlist = tmp_front;
		tmp_front->next = temp;
		list = newlist;
		return;
		
	}
	newlist->next = nullptr; //Leads the next member of newlist to a nullptr
	
	while(temp->next)
	{
		Node *placeholder = newlist;
		newlist = tmp_front;
		newlist->next = placeholder;
		tmp_front = temp;
		temp = temp->next;
	}
	Node *placeholder = newlist;
	newlist = tmp_front;
	newlist->next = placeholder;
	
	placeholder = newlist;
	newlist = temp;
	newlist->next = placeholder;
	
	list = newlist;
	
}
/******************************************************************************/
/*! 
  \brief
    Sorts all members of the linked list in ascending order.
	
  \param list
	A pointer to the first member of the linked list
	
  \return
   void 
*/
/*****************************************************************************/
// Sort elements in the list
void sort(Node *&list)
{
	if(!list)
		return;

	int size = count(list);
	Node *tmp_front = list;
	Node *counter = list;
	Node *moving = list;
	int lowest_num = 2147483647;
	
	if(size <= 1)
	{
		return;
	}
		
	while(1)
	{
		lowest_num = 2147483647; //resets lowest number
		
		while(counter)//finds the lowest number
		{
			if(counter->value < lowest_num)
			{
				lowest_num = counter->value;
			}
			counter = counter->next;
		}
		while(moving)//scrolls through the entire list, throwing all values that are the lowest number back to the start
		{
			if(moving->value == lowest_num)
			{
				valueswap(tmp_front,moving);
				tmp_front = tmp_front->next;
			}
			moving = moving->next;
		}
		if(tmp_front)
		{
			moving = tmp_front; //resets the moving swapper for next use at the new tmp_front
			counter = tmp_front; //resets the counter for next use, at tmp_front;
		}
	   
	  if(!counter)
			break;		  

	}
}

/******************************************************************************/
/*! 
  \brief
    Deletes all repeated elements of the linked list.
 
  \param list
	Pointer to the first member of the linked list
    
  \return
   void 
*/
/*****************************************************************************/
// Remove duplicate values in a sorted list
void unique(Node *&list)
{
	if(!list)
		return;
	sort(list);
	Node *curr_node = list;
	Node *next_node = list->next;
	int size = count(list);
	int deletions = 0;
	
	if(size <= 1) //If list only has one member, do not execute this function
		return;
	
while(1) //This will loop endlessly until no deletions are detected
{	
	deletions = 0; //resets deletions;
	for(int i=0; i<size; i++)
	{
		while( next_node != nullptr && (curr_node->value == next_node->value) )//keeps checking and deleting until the next value is not the same
		{ //stuck in this while loop
			if(next_node->next != nullptr)
			{
				safedeletion(curr_node,next_node);
				++deletions;
			}
			if((next_node->next == nullptr) && (curr_node->value == next_node->value)) /*This line checks if after the deletion the next node still has the same
			value as the current node; if it is the same AND the next also happens to be last, it will link the current node to nullptr and safely delete the
			node.*/ 
			{
				safedeletion(curr_node,next_node);
				break;
			}
		}	
		if(next_node!=nullptr && next_node->next != nullptr)
		{
			curr_node = curr_node->next;
			next_node = next_node->next;
		}
	}
	if(deletions)
		continue;
	else
		break;
}	
}
