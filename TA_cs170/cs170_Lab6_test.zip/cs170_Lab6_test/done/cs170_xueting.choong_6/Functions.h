/******************************************************************************/
/*!
\file Functions.h
\author Choong Xue Ting
\par email: xueting.choong\@digipen.edu
\par DigiPen login: xueting.choong
\par Course: CS170
\par Lab 06
\date 07/07/2019
\brief
    Template function declarations for count, remove, replace and etc
*/
/******************************************************************************///---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  template <typename T, typename T2> T2 *copy(T *list1, T *last, T2 *list2);
  template <typename T, typename T1> int count(T *first, T *last, const T1 &num);
  template <typename T> void display(T *first, T *last);
  template <typename T,typename T1> bool equal(T *first, T *last, T1 *list2);
  template <typename T,typename T1> void fill(T *first, T *last, T1 item);
  template <typename T,typename T1> T *find(T *first, T *last, const T1 &item);
  template <typename T> T* max_element(T *first, T *last);  
  template <typename T> T* min_element(T *first, T *last);
  template <typename T,typename T1> T *remove(T *first, T *last, T1 item);
  template <typename T,typename T1> void replace(T *first, T *last, const T1 &old, const T1 &start);
  template <typename T> T sum(T *first, T *last); 
  template <typename T> void swap(T &left, T &right);
  template <typename T> void swap_ranges(T *list1, T *listsize, T *list2);
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
