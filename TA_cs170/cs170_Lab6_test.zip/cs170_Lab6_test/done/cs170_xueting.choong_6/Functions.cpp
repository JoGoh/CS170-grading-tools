/******************************************************************************/
/*!
\file Functions.cpp
\author Choong Xue Ting 
\par email: xueting.choong\@digipen.edu
\par DigiPen login: xueting.choong
\par Course: CS170
\par Lab 06
\date 07/07/2019
\brief
    Template function declarations for count, remove, replace and etc
*/
/******************************************************************************/
#include <iostream> // cout, endl

using std::cout;
using std::endl;
/******************************************************************************/
/*!
\brief
    Copy Template element
  
\param list1
    The Template of first

\param last  
    The Template of last
    
\param list2 
    The Template of second    
*/
/******************************************************************************/
template <typename T, typename T2> T2 *copy(T *list1, T *last, T2 *list2)
{
    T *first = list1;
    T2 *second = list2;
    
    while(first!=last)
    {
        *second = *first;
        first++;
        second++;
    }
    
    return second;
}

/******************************************************************************/
/*!
\brief
    Count Template Element
    
\param first
    The Template of first
  
\param last  
    The Template of last
  
\param num
    object of the number
*/
/******************************************************************************/
template <typename T, typename T1> int count(T *first, T *last, const T1 &num)
{
    T *curr = first;
    int count = 0;
    
    while(curr!=last)
    {
        if(*curr==num)
            count++;
        curr++;
    }
    
    return count;
} 

/******************************************************************************/
/*!
\brief
    Display first and last object.

\param first
    The first pointer to display.

\param last
    The second pointer to display.
*/
/******************************************************************************/
template <typename T> void display(T *first, T *last)
{
    T *curr = first;
    
    if(first != last)
    {
        cout << *curr;
        curr++;
        while(curr!=last)
        {
            cout << ", " << *curr;
            curr++;
        }
    }  
    cout << endl;
}

/******************************************************************************/
/*!
\brief
    Find is that equal or not
  
\param first
    The Template of first
  
\param last  
    The Template of last
    
\param list2
    The Template of pointer list2
*/
/******************************************************************************/
template <typename T, typename T1> bool equal(T *first, T *last, T1 *list2)
{
    T *left1 = first;
    T1 * left2 = list2;
    
    while(left1!=last)
    {
        if(*left1!=*left2)
            return 0;
        left1++;
        left2++;
    }
    
    return 1;
}

/******************************************************************************/
/*!
\brief
    Fill Element
    
\param first
    The Template of first
  
\param last  
    The Template of last
    
\param item
    const item
*/
/******************************************************************************/
template <typename T, typename T1> void fill(T *first, T *last, T1 item)
{
    while(first!=last)
    {
        *first = item;
        first++;
    }
}

/******************************************************************************/
/*!
\brief
   find element template
  
\param first
    The Template of first
  
\param last  
    The Template of last

\param item
    const item
*/
/******************************************************************************/
template <typename T, typename T1> T *find(T *first, T *last, const T1 &item)
{
    T *curr = first;
    
    while(curr!=last)
    {
        if(*curr==item)
            return curr;
        curr++;
    }
    
    return curr;
}

/******************************************************************************/
/*!
\brief
    Maximum element in Template
  
\param first
    The Template of first
  
\param last  
    The Template of last
*/
/******************************************************************************/
template <typename T> T *max_element(T *first, T *last)
{
    T *left = first;
    T *max = left;
    left++;
    
    while(left!=last)
    {
        if(*max < *left)
        {
            max = left;
            left++;
        }
        else
            left++;
    }
    
    return max;
    left = first;
}

/******************************************************************************/
/*!
\brief
    Minimum element in Template
  
\param first
    The Template of first
  
\param last
    template of last
*/
/******************************************************************************/
template <typename T> T *min_element(T *first, T *last)
{
    T *left = first;
    T *min = left;
    left++;
    
    while(left!=last)
    {
        if(*min > *left)
        {
            min = left;
            left++;
        }
        else
            left++;
    }
    
    return min;
    left = first;
}

/******************************************************************************/
/*!
\brief
    Remove element
  
\param first
    The Template of first
  
\param last  
    The Template of last
    
\param item
    const item
*/
/******************************************************************************/
template <typename T, typename T1> T *remove(T *first, T *last, T1 item)
{
    T *curr = first;
    T *next = first;
    
    while(curr!=last)
    {
        if(*curr!=item)
        {
            *next = *curr;
            curr++;
            next++;
        }
        else
            curr++;
    }
    
    return next;
}

/******************************************************************************/
/*!
\brief
    Replace element template
  
\param first
    The Template of first
  
\param last  
    The Template of last
    
\param old  
    old reference
        
\param start 
    start reference
*/
/******************************************************************************/
template <typename T, typename T1> void replace(T *first, T *last, const T1 &old, const T1 &start)
{
    while(first!=last)
    {
        if(*first==old)
            *first = start;
        first++;
    }
}

/******************************************************************************/
/*!
\brief
    Sum up Objects
  
\param first
    The Template of first
  
\param last
    template of last
*/
/******************************************************************************/
template <typename T> T sum(T *first, T *last)
{
    T total{};
    while(first!=last)
    {
        total+=*first;
        first++;
    }
    
    return total;
}

/******************************************************************************/
/*!
\brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.

\param left
    The first object to swap.

\param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> void swap(T &left, T &right)
{
    T temp(right); // need a temporary copy
    right = left;
    left = temp;
}

/******************************************************************************/
/*!
\brief
    Swap ranges of list1 and list2 according to listsize.
   
\param list1
    template of list1
  
\param listsize
    template of last
  
\param list2
    template of list2
*/
/******************************************************************************/
template <typename T> void swap_ranges(T *list1, T *listsize, T *list2)
{
    while(list1!=listsize)
    {
        swap(*list1, *list2);
        list1++;
        list2++;                        
    }
}