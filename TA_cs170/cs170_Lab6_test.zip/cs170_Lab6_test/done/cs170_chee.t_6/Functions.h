/******************************************************************************/
/*!
\file Functions.h
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: CS170
\par Lab 06
\date 08/07/2019
\brief
This file contains the implementation of the following functions for
Lab 6.

Functions include:
// Provided template
template <typename T> void swap(T &left, T &right)

// Written emplates
template <typename T1, typename T2> T2 copy(T1 list1, T1 end, T2 list2)
template <typename T1, typename T2> int count(T1 list, T1 end, T2 item)
template <typename T> void display(T list, T end)
template <typename T1, typename T2> bool equal(T1 list1, T1 end, T2 list2)
template <typename T1, typename T2> void fill(T1 list, T1 end, T2 item)
template <typename T1, typename T2> T1 find(T1 list, T1 end, T2 item)
template <typename T> T max_element(T list, T end)
template <typename T> T min_element(T list, T end)
template <typename T1, typename T2> T1 remove(T1 list, T1 end, T2 item)
template <typename T1, typename T2> void replace(T1 list, T1 end,
  T2 olditem, T2 newitem)
template <typename T> int sum(T list, T end)
template <typename T1, typename T2> void swap_ranges(T1 list1, T1 end,
  T2 list2)

Hours spent on this assignment: 6
Specific portions that gave you the most trouble: remove function
*/
/******************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  template <typename T> void swap(T &left, T &right);

  /*
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */

   template <typename T1, typename T2> T2 copy(T1 list1, T1 end, T2 list2);
   template <typename T1, typename T2> int count(T1 list, T1 end, T2 item);
   template <typename T> void display(T list, T end);
   template <typename T1, typename T2> bool equal(T1 list1, T1 end, T2 list2);
   template <typename T1, typename T2> void fill(T1 list, T1 end, T2 item);
   template <typename T1, typename T2> T1 find(T1 list, T1 end, T2 item);
   template <typename T> T max_element(T list, T end);
   template <typename T> T min_element(T list, T end);
   template <typename T1, typename T2> T1 remove(T1 list, T1 end, T2 item);
   template <typename T1, typename T2> void replace(T1 list, T1 end,
     T2 olditem, T2 newitem);
   template <typename T> int sum(T list, T end);
   template <typename T1, typename T2> void swap_ranges(T1 list1, T1 end,
     T2 list2);

  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
