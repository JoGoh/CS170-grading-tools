/******************************************************************************/
/*!
\file Functions.cpp
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: CS170
\par Lab 06
\date 08/07/2019
\brief
This file contains the implementation of the following functions for
Lab 6.

Functions include:
// Provided template
template <typename T> void swap(T &left, T &right)

// Written emplates
template <typename T1, typename T2> T2 copy(T1 list1, T1 end, T2 list2)
template <typename T1, typename T2> int count(T1 list, T1 end, T2 item)
template <typename T> void display(T list, T end)
template <typename T1, typename T2> bool equal(T1 list1, T1 end, T2 list2)
template <typename T1, typename T2> void fill(T1 list, T1 end, T2 item)
template <typename T1, typename T2> T1 find(T1 list, T1 end, T2 item)
template <typename T> T max_element(T list, T end)
template <typename T> T min_element(T list, T end)
template <typename T1, typename T2> T1 remove(T1 list, T1 end, T2 item)
template <typename T1, typename T2> void replace(T1 list, T1 end,
  T2 olditem, T2 newitem)
template <typename T> int sum(T list, T end)
template <typename T1, typename T2> void swap_ranges(T1 list1, T1 end,
  T2 list2)

Hours spent on this assignment: 6
Specific portions that gave you the most trouble: remove function
*/
/******************************************************************************/

#include <iostream> // cout, endl

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.

  \param left
    The first object to swap.

  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T>
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/******************************************************************************/
/*!
\brief Copies elements from source to destination and returns the end of
       destination list

\fn T2 copy(T1 list1, T1 end, T2 list2)

\param list1
  Source List to copy from

\param end
  End of Source list

\param list2
  Destination list to copy to
*/
/******************************************************************************/

template <typename T1, typename T2>
T2 copy(T1 list1, T1 end, T2 list2)
{
  while ( list1 != end ) *list2++ = *list1++;
  return list2;
}

/******************************************************************************/
/*!
\brief Counts number of elements equal to item and returns the amount

\fn int count(T1 list, T1 end, T2 item)

\param list
  Source list to count from

\param end
  End of Source list

\param item
  Comparison item for matching
*/
/******************************************************************************/

template <typename T1, typename T2>
int count(T1 list, T1 end, T2 item)
{
  int counter = 0;
  while ( list != end )
  {
    if (*list == item) ++counter;
    ++list;
  }
  return counter;
}

/******************************************************************************/
/*!
\brief Prints elements of given list

\fn void display(T list, T end)

\param list
  Source list to read from

\param end
  End of Source list
*/
/******************************************************************************/

template <typename T>
void display(T list, T end)
{
  // If the list is empty print an empty line
  if (list == end)
  {
    std::cout << std::endl;
    return;
  }
  // Ensure list is not at the end
  while ( list != end )
  {
    list + 1 != end ?
    std::cout << *list << ", " :
    std::cout << *list << std::endl;
    ++list;
  }
}

/******************************************************************************/
/*!
\brief Check individual elements in a list and returns true if lists are the
       same. Checks against as many elements as there are in list1.

\fn bool equal(T1 list1, T1 end, T2 list2)

\param list1
  Start of first list

\param end
  End of first list

\param list2
  Start of second list
*/
/******************************************************************************/

template <typename T1, typename T2>
bool equal(T1 list1, T1 end, T2 list2)
{
  // Ensure list1 is not at the end and list2 is not beyond the end
  while ( list1 != end && (list2 + 1) )
  {
    if (*list1 != *list2) return false;
    ++list1, ++list2;
  }
  return true;
}

/******************************************************************************/
/*!
\brief Fills entire list with given value (item)

\fn void fill(T1 list, T1 end, T2 item)

\param list
  Start of list

\param end
  End of list

\param item
  Given item to fill the list
*/
/******************************************************************************/

template <typename T1, typename T2>
void fill(T1 list, T1 end, T2 item)
{
  // Ensure list is not at the end
  while ( list != end ) *list++ = item;
}

/******************************************************************************/
/*!
\brief Finds and returns the position of first element's value matching item

\fn T1 find(T1 list, T1 end, T2 item)

\param list
  Start of list

\param end
  End of list

\param item
  Given item to find in list
*/
/******************************************************************************/

template <typename T1, typename T2>
T1 find(T1 list, T1 end, T2 item)
{
  // Ensure list is not at the end
  while ( list != end )
  {
    if (*list == item) return list;
    ++list;
  }
  return end;
}

/******************************************************************************/
/*!
\brief Finds and returns the position of largest valued element in a list

\fn T max_element(T list, T end)

\param list
  Start of list

\param end
  End of list
*/
/******************************************************************************/

template <typename T>
T max_element(T list, T end)
{
  T largest = list;
  // Ensure list is not at the end
  while ( list != end )
  {
    if (*list > *largest) largest = list;
    ++list;
  }
  return largest;
}

/******************************************************************************/
/*!
\brief Finds and returns the position of smallest valued element in a list

\fn T min_element(T list, T end)

\param list
  Start of list

\param end
  End of list
*/
/******************************************************************************/

template <typename T>
T min_element(T list, T end)
{
  T smallest = list;
  // Ensure list is not at the end
  while ( list != end )
  {
    if (*list < *smallest) smallest = list;
    ++list;
  }
  return smallest;
}

/******************************************************************************/
/*!
\brief Remove elements from a given list matching given value (item)

\fn T1 remove(T1 list, T1 end, T2 item)

\param list
  Start of list

\param end
  End of list

\param item
  Item to be removed from the list
*/
/******************************************************************************/

template <typename T1, typename T2>
T1 remove(T1 list, T1 end, T2 item)
{
  T1 finger = list;
  // Ensure finger is not at the end
  while ( finger != end )
  {
    if ( *finger == item )++finger;
    else ++finger, ++list;

    *list = *finger;
  }
  return list;
}

/******************************************************************************/
/*!
\brief Replaces every element in a list matching olditem with newitem

\fn void replace(T1 list, T1 end, T2 olditem, T2 newitem)

\param list
  Start of list

\param end
  End of list

\param olditem
  Old items to be overwritten

\param newitem
  New items to overwrite old items
*/
/******************************************************************************/

template <typename T1, typename T2>
void replace(T1 list, T1 end, T2 olditem, T2 newitem)
{
  // Ensure list is not at the end
  while ( list != end )
  {
    if (*list == olditem) *list = newitem;
    ++list;
  }
}

/******************************************************************************/
/*!
\brief Adds up all the value of every element in a list

\fn int sum(T list, T end)

\param list
  Start of list

\param end
  End of list
*/
/******************************************************************************/

template <typename T>
int sum(T list, T end)
{
  int total = 0;
  // Ensure list is not at the end
  while ( list != end )
  {
    total += *list++;
  }
  return total;
}

/******************************************************************************/
/*!
\brief Swaps the elements between two lists

\fn void swap_ranges(T1 list1, T1 end, T2 list2)

\param list1
  Start of first list

\param end
  End of first list

\param list2
  Start of second list
*/
/******************************************************************************/

template <typename T1, typename T2>
void swap_ranges(T1 list1, T1 end, T2 list2)
{
  // Ensure list is not at the end and list2 is not beyond
  while ( list1 != end && (list2 + 1) )
  {
    swap(*list1, *list2);
    ++list1, ++list2;
  }
}
