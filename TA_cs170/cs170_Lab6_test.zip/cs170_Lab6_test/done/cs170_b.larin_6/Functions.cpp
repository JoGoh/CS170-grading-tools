/*****************************************************************************/
/*!
\file Functions.h
\author Benjamin Julian M. Larin
\par email:
b.larin\@digipen.edu
\par DigiPen login:
b.larin
\par Course:
CS170-A
\par Lab #6
\date 07/07/2019
\brief This file contains the declaration of the following functions for
the Lab #6.

\par Class Member Functions include:
  copy();
  count();
  display();
  equal();
  fill();
  find();
  max_element();
  min_element();
  remove();
  replace();
  sum();
  swap();
  swap_ranges();

\par Hours spent on this assignment:
  4 hrs

\par Specific portions that gave you the most trouble:
  remove();
*/
/*****************************************************************************/
/// \cond
#include <iostream> // cout, endl
/// \endcond
/*****************************************************************************/
  /** copies the elements in first array to the second array

      @param left - 1st element of first array.
      @param end - the first array last element.
      @param right - 1st element of second array.
      @return right - last element of second array.
  */
/*****************************************************************************/
template <typename T1, typename T2> 
T2 copy( T1 left, const T1 &end, T2 right)
{
  while (left != end)
    *right++ = *left++;
  return right;
}

/*****************************************************************************/
  /** counts the number of times the item is found in the array

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @param item - value to find.
      @return count - number of times item appeared.
  */
  /*****************************************************************************/
template <typename T1, typename T2>
T2 count(T1 left, const T1 &end, const T2 &item)
{
  T2 counter = 0;
  while (left != end)
  {
    if (*left == item)
      ++counter;
    ++left;
  }
  return counter;

}

/*****************************************************************************/
  /** prints out the array from beginning to end

      @param left - 1st element of first array.
      @param end -  last element of first array.
  */
  /*****************************************************************************/
template <typename T>
void display(T left, T end)
{
  while (left != end)
  {
    std::cout << *left++;
    if(left != end)
      std::cout << ", ";
  }
  std::cout << std::endl;
}

/*****************************************************************************/
  /** checks if both arrays have the same elements

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @param right - 1st element of second array.
      @return bool - true if equal, otherwise false.
  */
/*****************************************************************************/
template <typename T1, typename T2> 
bool equal(T1 left, const T1 &end, T2 right)
{
  while (left != end)
  {
    if (*left == *right)
    {
      ++left;
      ++right;
    }
    else
      return false;
  }
  return true;
}

/*****************************************************************************/
  /** fills the whole array with the specified item

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @param item - value used to fill.
      @return left - last element of first array.
  */
/*****************************************************************************/
template <typename T1, typename T2> 
T1 fill(T1 left, const T1 &end, const T2 &item)
{
  while (left != end)
    *left++ = item;
  return left;
}

/*****************************************************************************/
  /** checks if the item is found in the array

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @param item - value to find.
      @return left - the element found.
              end - if not found.
  */
/*****************************************************************************/
template <typename T1, typename T2> 
T1 find(T1 left, const T1 &end, const T2 &item)
{
  while (left != end)
  {
    if (*left == item)
      return left;
    ++left;
  }
  return end;
}

/*****************************************************************************/
  /** returns the maximum value

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @return bigger - maximum value.
  */
/*****************************************************************************/
template <typename T> 
T max_element(T left, const T &end)
{
  T bigger = left;
  while (left != end)
  {
    if (*left > *bigger)
      bigger = left++;
    ++left;
  }
  return bigger;
}

/*****************************************************************************/
  /** returns the minimum value

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @return smaller - minimum value.
  */
/*****************************************************************************/
template <typename T> 
T min_element(T left, const T &end)
{
  T smaller = left;
  while (left != end)
  {
    if (*left < *smaller)
      smaller = left++;
    ++left;
  }
  return smaller;
}

/*****************************************************************************/
  /** finds and removes all the item given inside the array

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @param item - value to find and remove.
      @return tmp - last element of first array.
  */
/*****************************************************************************/
template <typename T1, typename T2> 
T1 remove(T1 left, const T1 &end, const T2 &item)
{
  T1 tmp = left;
  while (left != end)
  {
    if (*left != item)
      *tmp++ = *left;
    ++left;
  }
  return tmp;
}

/*****************************************************************************/
  /** finds and replaces the old item with a new item inside the array

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @param olditem - value to find and replace.
      @param newitem - new value.
      @return end -  last element of first array.
  */
/*****************************************************************************/
template <typename T1, typename T2> 
T1 replace(T1 left, const T1 &end, const T2 &olditem, const T2 &newitem)
{
  while (left != end)
  {
    if (*left == olditem)
      *left = newitem;
    ++left;
  }
  return end;
}

/*****************************************************************************/
  /** summates the element values of the array

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @return total -  sum of all elements of the array.
  */
/*****************************************************************************/
template <typename T> 
int sum(T left, const T &end)
{
  int total = 0;
  while (left != end)
    total += *left++;
  return total;
}

/*****************************************************************************/
  /** swaps the values of both elements

      @param left - LHS element.
      @param right -  RHS element.
  */
/*****************************************************************************/
template <typename T>
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/*****************************************************************************/
  /** swaps all values of all elements of both arrays

      @param left - 1st element of first array.
      @param end -  last element of first array.
      @param right - 1st element of second array.
  */
/*****************************************************************************/
template <typename T> 
void swap_ranges(T left, const T &end, T right)
{
  while (left != end)
    swap(*left++, *right++);
}