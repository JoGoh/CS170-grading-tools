/******************************************************************************/
/*!
\file               Functions.h
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab06
\par Course:        CS170
\date:              1/07/2019
\brief
        This file contains the declarations of the following
        functions for the Lab06.
        
Functions include:
        1) copy
        2) count
        3) display
        4) equal
        5) fill
        6) find
        7) max_element
        8) min_element
        9) remove
       10) replace
       11) sum
       12) swap
       13) swap_ranges
        
Hours spent on this assignment: remove
Specific portions that gave you the most trouble: 6hr
*/
/******************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  //Copy - Copies an aggregate to another (Deep Copying)
  template <typename T1, typename T2>
  T2 copy(T1 array_1, const T1& maxRange, T2 array_2);

  //Count - Count and return the number of value that exist within the aggregate
  template <typename T1, typename T2> 
  T2 count(T1 array_1, const T1& maxRange, const T2& value);
 
  //Display - Prints each value within the aggregate
  template <typename T> 
  void display(T array, const T& maxRange);

  template <typename T> 
  void display(T array, nullptr_t maxRange);
	
  //Equal - Checks if two aggregate contains exact same elements.
  template <typename T1, typename T2>
  bool equal(T1 array_1, const T1& maxRange, T2 array_2);
  
  //Fill - Overwrites the aggregate with the value given within a set position.
  template <typename T1, typename T2>
  void fill(T1 array_1, const T1& maxRange, const T2& value);

  //Find - Find the value within the aggregate and returns the address of it.
  template <typename T1, typename T2> 
  T1 find(T1 array_1, const T1& maxRange, const T2& value);

  //Max Element - Return the address of the maximum element within the array
  template <typename T1, typename T2>
  T1 max_element(T1 array_1, const T2& maxRange);

  //Min Element - Return the address of the minimum element within the array
  template <typename T1, typename T2>
  T1 min_element(T1 array_1, const T2& maxRange);
 
  //Remove - Removes value from the aggregate and relink the remaining ones. 
  template <typename T1, typename T2> 
  T1 remove(T1 array_1, const T1& maxRange, const T2& value);

  //Replace - Replaces old_value with new_value within the aggregate.
  template <typename T1, typename T2>
  void replace(T1 array_1, const T1& maxRange, const T2& old_value,
               const T2& new_value);
               
  //Sum - Add the values within the aggregate and return its value.
  template <typename T>
  T sum(const T* array_1, const T* maxRange);
               
  //Swap - Exchange values of the left and right
  template <typename T> 
  void swap(T& left, T& right);
    
  //Swap Ranges - Swap each value within the aggregates
  template <typename T1, typename T2>
  void swap_ranges(T1 array_1,const T1& maxRange, T2 array_2);   
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
