/******************************************************************************/
/*!
\file               Functions.cpp
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab06
\par Course:        CS170
\date:              1/07/2019
\brief
        This file contains the implementations of the following
        functions for the Lab06.
        
Functions include:
        1) copy
        2) count
        3) display
        4) equal
        5) fill
        6) find
        7) max_element
        8) min_element
        9) remove
       10) replace
       11) sum
       12) swap
       13) swap_ranges
       

Hours spent on this assignment: remove
Specific portions that gave you the most trouble: 6hr
*/
/******************************************************************************/
#include <iostream> // cout, endl

/******************************************************************************/
/*!
  \brief           Copies one array value to another (Deep Copy)
  \param  array_1  The array to copy from.
  \param  maxRange The past the end of array_1.
  \param  array_2  The array to copy to.
  \return array_2  The new end of array_2
*/
/******************************************************************************/
    template <typename T1, typename T2>
    T2 copy(T1 array_1, const T1& maxRange,  T2 array_2)
    {
        while(array_1 != maxRange)
        {
            *array_2 = *array_1;
            
            ++array_2;
            ++array_1;
        }
        return array_2;
    }

/******************************************************************************/
/*!
  \brief              Count and return the no of value that exist within array
  \param  array_1     The array to copy from.
  \param  maxRange    The past the end of array_1.
  \param  value       The value to count.
  \return temp_Count  The total amount of value in the array.
*/
/******************************************************************************/    
    template <typename T1, typename T2> 
    T2 count(T1 array_1, const T1& maxRange, const T2& value)
    {
        T2 temp_Count = 0;
        
        while(array_1 != maxRange)
        {
            if(*array_1 == value)
                ++temp_Count;
            
            ++array_1;
        }
        
        return temp_Count;
    }

/******************************************************************************/
/*!
  \brief           Prints each value within the array.
  \param array     The array to read from.
  \param maxRange  The past the end array.
*/
/******************************************************************************/
    template <typename T> 
    void display(T array, const T& maxRange)
    {
        using namespace std; //Directives - not reccommended (Lazy here)        
        
        if(array == maxRange)
        {
            cout << endl;
            return;
        }

        while(array != maxRange - 1)
        {
            cout << *array << ", ";   //Formating  purpose.
            ++array;                  // Shift pointer, reduce overhead.
        }
        cout << *array << endl;       //Special Case - Formating purpose.
    }
    
/******************************************************************************/
/*!
  \brief           Checks if two array contains the exact same elements.
  \param array_1   The array to check with.
  \param maxRange  The past the end of array_1.
  \param array_2   The 2nd array to check with.
  \return 
         true      If the array is the exact same.
         false     If the array is not the exact same.
*/
/******************************************************************************/
    template <typename T1, typename T2>
    bool equal(T1 array_1, const T1& maxRange, T2 array_2)
    {
        while(array_1 != maxRange)
        {
            if(*array_1 != *array_2)
                return false;
            
            ++array_1;
            ++array_2;
        }
        
        return true;
    }
/******************************************************************************/
/*!
  \brief           Overwrites array_2 with the value within a set range
  \param array_1   The array to fill with.
  \param maxRange  The past the end of array_1.
  \param value     The value to fill array_1 with.
*/
/******************************************************************************/
    template <typename T1, typename T2>
    void fill(T1 array_1, const T1& maxRange, const T2& value)
    {
        while(array_1 != maxRange)
        {
            *array_1 = value;
            ++array_1;
        }
    }
/******************************************************************************/
/*!
  \brief           Find the value within the array and return its address
  \param array_1   The array to find with.
  \param maxRange  The past the end of array_1.
  \param value     The value to find within array_1
  \return array_1  Value exist within the array.
          maxRange Value does not exist within the array.
*/
/******************************************************************************/
    template <typename T1, typename T2> 
    T1 find(T1 array_1, const T1& maxRange, const T2& value)
    {
        while(array_1 != maxRange)
        {
            if(*array_1 == value)
                return array_1; //Value is found and return address of it.
            
            ++array_1;
        }
        
        //No value lies within the aggregate
        return maxRange;
    }
    
/******************************************************************************/
/*!
  \brief            Returns the address of the largest element within the array
  \param  array_1   The array to search.
  \param  maxRange  The past the end of array_1.
  \return 
          tempValue The largest element within array_1.
*/
/******************************************************************************/
    template <typename T1, typename T2>
    T1 max_element(T1 array_1, const T2& maxRange)
    {
        T1 temp_Value = array_1;
        
        while(array_1 != maxRange)
        {
            if(*temp_Value < *array_1)
                temp_Value = array_1;
            
            ++array_1;
        }
        
        return temp_Value;
    }

/******************************************************************************/
/*!
  \brief            Returns the address of the smallest element within the array
  \param  array_1   The array to search.
  \param  maxRange  The past the end of array_1.
  \return 
          tempValue The smallest element within array_1.
*/
/******************************************************************************/
    template <typename T1, typename T2>
    T1 min_element(T1 array_1, const T2& maxRange)
    {
        T1 temp_Value = array_1;
        
        while(array_1 != maxRange)
        {
            if(*temp_Value > *array_1)
                temp_Value = array_1;
                
            ++array_1;
        }
        return temp_Value;
    }
    
/******************************************************************************/
/*!
  \brief             Removes the value that exist within the array.
  \param  array_1    The array to remove from..
  \param  maxRange   The past the end of array_1.
  \param  value      The value to remove from array_1.
  \return 
          temp_Array The new end of the array_1.
*/
/******************************************************************************/
    template <typename T1, typename T2> 
    T1 remove(T1 array_1, const T1& maxRange, const T2& value)
    {   
        T1 temp_Array = array_1;
        while(array_1 != maxRange)
        {
            if(*array_1 != value)
            {
                //swap(*temp_Array, *array_1);
                *temp_Array = * array_1;
                ++temp_Array;
            }
            ++array_1;
        }
        return temp_Array;
    }
    
/******************************************************************************/
/*!
  \brief            Replaces the old values with new values within the array
  \param  array_1   The array to remove from..
  \param  maxRange  The past the end of array_1.
  \param  old_value The value to be replaced.
  \param  new_value The value to replaced with.
*/
/******************************************************************************/
    template <typename T1, typename T2>
    void replace(T1 array_1, const T1& maxRange, const T2& old_value, 
                 const T2& new_value)
    {
        while(array_1 != maxRange)
        {
            /*if(array_1 == find(array_1, array_1+1, old_value) )   
                *array_1 = new_value;*/ //Is this better or the next one?
            
            if(*array_1 == old_value)
                *array_1= new_value;
            
            ++array_1;
        }
    }

/******************************************************************************/
/*!
  \brief              Add all the values within the array.
  \param  array_1     The array to sum up all the value with.
  \param  maxRange    The past the end of array_1.
  \return 
          temp_Result The sum of all the values within the array.
*/
/******************************************************************************/
    template <typename T>
    T sum(const T* array_1, const T* maxRange)
    {
        T temp_Result = *array_1 - *array_1;
        
        while(array_1 != maxRange)
        {
            temp_Result += *array_1;
            ++array_1;
        }
        return temp_Result;
    }
/******************************************************************************/
/*!
  \brief         Swaps two objects. There is no return value but the two 
                 objects are swapped in place.
  \param left    The first object to swap.
  \param right   The second object to swap.
*/
/******************************************************************************/
    template <typename T> 
    void swap(T &left, T &right)
    {
      T temp(right); // need a temporary copy
      right = left;
      left = temp;
    }
    
/******************************************************************************/
/*!
  \brief            Swap the values if 2 arrays.
  \param  array_1   The array to swao with array_2.
  \param  maxRange  The past the end of array_1.
  \param  array_2   The array to swap with array_1.
*/
/******************************************************************************/
    //Swap Ranges - Swap each value within the aggregates
    template <typename T1, typename T2>
    void swap_ranges(T1 array_1,const T1& maxRange, T2 array_2)
    {
        while(array_1 != maxRange)
        {
            //Swapping Values
            swap(*array_1, *array_2);
            
            //Iteration
            ++array_2; 
            ++array_1; 
        }
    }
















