/*****************************************************************************/
/*!
\file Functions.cpp
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
06
\par Date:
01 July 2019
\par Brief:

	This file contains the implementation of the following functions
	for CS170 Lab 06 - Templates

	Functions given: \n
	template \<typename T\> 
	void swap(T &left, T &right); \n
	
	\n
	Functions written: \n 
	template \<typename T\> 
	T* copy(const T* left, const T* const left_range, const T* right); \n
	
	template \<typename T\> 
	int count(const T* left, const T* const left_range, const T& item); \n
	
	template \<typename T\> 
	void display(const T* left, const T* const left_range); \n
	
	template \<typename T1, typename T2\> 
	bool equal(const T1* left, const T1* const left_range, const T2* right); \n
	
	template \<typename T\> 
	void fill(T* left, const T* const left_range, const T& item); \n
	
	template \<typename T1, typename T2\>
	T1* find(const T1* left, const T1* const left_range, const T2& item); \n
	
	template \<typename T\> 
	T* max_element(const T* left, const T* const left_range); \n
	
	template \<typename T\> 
	T* min_element(const T* left, const T* const left_range); \n
	
	template \<typename T\> 
	T* remove(T* left, const T* const left_range, const T& item); \n
	
	template \<typename T\> 
	void replace(const T* left, const T* const left_range, 
							const T& old_item, const T& new_item); \n
							
	template \<typename T\>
	T sum(const T* left, const T* const left_range); \n
	
	template \<typename T\> 
	void swap(T &left, T &right); \n
  
	template \<typename T\> 
	void swap_ranges(const T* left, 
	const T* const left_range, const T* right); \n

	\n 
	Hours spent on this assignment: 
	4.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/

#include <iostream> // cout, endl


/*****************************************************************************/
/*!
	\brief Copies the left object into the right.
	Copies the range from left to left_range to the right object.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param right
		Right object.
	\retval right
		Maximum range of the right object.
*/
/*****************************************************************************/
template <typename T>
T* copy(const T* left, const T* const left_range, const T* right) {
	
	if (!left || !left_range || !right) { //null guard
		return nullptr;
	}
	
	while (left < left_range) {
		
		*right = *left;
		
		++right;
		++left;
	}
	
	return right; //end of the right list
}

/*****************************************************************************/
/*!
	\brief Counts the number of a given item in the range.
	Returns an integer indicating the total count of the given item.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param item
		Item to be counted for in the range.
	\retval count
		Integer value of the count of the item in the range.
*/
/*****************************************************************************/
template <typename T> 
int count(const T* left, const T* const left_range, const T& item) {
	
	if (!left || !left_range) { //null guard
		return 0;
	}
	
	int count = 0;
	
	while (left < left_range) {
		
		if (*left == item) {
			++count;
		}
		++left;
	}
	
	return count;
}

/*****************************************************************************/
/*!
	\brief Displays the range.
	Inserts ", " after each item with the exception of the last item.

	\param left
		Left object.
	\param left_range
		Range of the left object.
*/
/*****************************************************************************/
template <typename T>
void display(const T* left, const T* const left_range) {
	
	if (!left || !left_range) { //null guard
		return;
	}
	
	while (left < left_range) {
		
		std::cout << *left;
		
		++left;
		
		if (left == left_range) {
			std::cout << std::endl;
			return;
		}
		else {
			std::cout << ", ";
		}
	}
	std::cout << std::endl;
	
}

/*****************************************************************************/
/*!
	\brief Compares two objects to see if they contain the same items.
	Returns true if the two objects are identical, returns false if
	any items are different.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param right
		Right object.
	\return true
		Returns true if objects are equal.
	\return false
		Returns false if objects contain differences.
*/
/*****************************************************************************/
template <typename T1, typename T2>
bool equal(const T1* left, const T1* const left_range, const T2* right) {
	
	if (!left || !left_range || !right) { //null guard
		return false;
	}
	
	while (left < left_range)
	{
		if (*left != *right)
		{
			return false;
		}

		++right;
		++left;
	}
	
	return true;
}

/*****************************************************************************/
/*!
	\brief Fills a range with a given item.
	Fills the range left to left_range with the given item in parameters.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param item
		The item to be filled into the range.
*/
/*****************************************************************************/
template <typename T>
void fill (T* left, const T* const left_range, const T& item) {
	
	if (!left || !left_range) { //null guard
		return;
	}
	
	while (left < left_range) {
		
		*left = item;
		++left;
	}
}

/*****************************************************************************/
/*!
	\brief Finds the given item in a range.
	Finds the location of the given item from left to left_range. Returns the
	range if item is not found.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param item
		The item to be found in the range.
	\return position
		Location of the item.
	\return left_range
		Returns max range if item is not found.
*/
/*****************************************************************************/
template <typename T1, typename T2>
T1* find(const T1* left, const T1* const left_range, const T2& item) {
	
	if (!left || !left_range) { //null guard
		return nullptr;
	}
	
	T1* position = left;
	
	while (position < left_range) {
		
		if (*position == item) {
			return position;
		}
		
		++position;
	}
	return left_range;
}

/*****************************************************************************/
/*!
	\brief Finds the maximum element in a range.
	Returns the largest item from left to left_range.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\retval max_value
		Returns the largest item.
*/
/*****************************************************************************/
template <typename T>
T* max_element(const T* left, const T* const left_range) {
	
	if (!left || !left_range) { //null guard
		return nullptr;
	}
	
	T* max_value = left;
	
	while (left < left_range) {
		
		if (*left > *max_value) {
			max_value = left;
		}
		++left;
	}
	
	return max_value;
}


/*****************************************************************************/
/*!
	\brief Finds the minimum element in a range.
	Returns the smallest item from left to left_range.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\retval min_value
		Returns the smallest item.
*/
/*****************************************************************************/
template <typename T>
T* min_element(const T* left, const T* const left_range) {
	
	if (!left || !left_range) { //null guard
		return nullptr;
	}
	
	T* min_value = left;
	
	while (left < left_range) {
		
		if (*left < *min_value) {
			min_value = left;
		}
		++left;
	}
	
	return min_value;
}

/*****************************************************************************/
/*!
	\brief Remove items from a given range.
	Removes item from left to left_range, and return the new range.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param item
		Item to be removed.
*/
/*****************************************************************************/
template <typename T>
T* remove(T* left, const T* const left_range, const T& item) {
	
	if (!left || !left_range) { //null guard
		return nullptr;
	}
	
	T* new_list = left; //saves the new list here
	
	while (left < left_range) {
		
		if (*left == item) {
			++left;
		}
		else {
			++new_list;
			++left;
		}
		*new_list = *left;
	}
	
	return new_list;
}

/*****************************************************************************/
/*!
	\brief Replace an item with another given item.
	Replaces old_item from left to left_range with new_item.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param old_item
		Item to be replaced.
	\param new_item
		New item to replace the old one with.
*/
/*****************************************************************************/
template <typename T>
void replace(const T* left, const T* const left_range, 
const T& old_item, const T& new_item) {
	
	if (!left || !left_range) { //null guard
		return;
	}
	
	while (left < left_range) {
		
		if (*left == old_item) {
			*left = new_item;
		}
		++left;
	}
}

/*****************************************************************************/
/*!
	\brief Finds the sum of the provided array/list.
	Adds all the elements together and returns the total value.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\retval sum
		Total value.
*/
/*****************************************************************************/
template <typename T>
T sum(const T* left, const T* const left_range) {
	
	T sum(0);
	
	if (!left || !left_range) { //null guard
		return sum;
	}
	
	while (left < left_range)
	{
		sum += *left;
		++left;
	}
	
	return sum;
}

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T& left, T& right) {
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}


/*****************************************************************************/
/*!
	\brief Swap two objects with a fixed range
	Swaps two objects based on the left object's range.

	\param left
		Left object.
	\param left_range
		Range of the left object.
	\param right
		Right object.
*/
/*****************************************************************************/
template <typename T> 
void swap_ranges(const T* left, const T* const left_range, const T* right) {
	
	if (!left || !left_range || !right) { //null guard
		return;
	}
	
	T temp;
	
	while (left < left_range) {
		
		temp = *right; //assign left into temp value
		*right = *left;
		*left = temp;
		
		++right;
		++left;
	}
}