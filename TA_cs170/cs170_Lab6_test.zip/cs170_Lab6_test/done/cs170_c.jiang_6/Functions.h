/*****************************************************************************/
/*!
\file Functions.h
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
06
\par Date:
01 July 2019
\par Brief:

	This file contains the implementation of the following functions
	for CS170 Lab 06 - Templates

	Functions given: \n
	template \<typename T\> 
	void swap(T &left, T &right); \n
	
	\n
	Functions written: \n 
	template \<typename T\> 
	T* copy(const T* left, const T* const left_range, const T* right); \n
	
	template \<typename T\> 
	int count(const T* left, const T* const left_range, const T& item); \n
	
	template \<typename T\> 
	void display(const T* left, const T* const left_range); \n
	
	template \<typename T1, typename T2\> 
	bool equal(const T1* left, const T1* const left_range, const T2* right); \n
	
	template \<typename T\> 
	void fill(T* left, const T* const left_range, const T& item); \n
	
	template \<typename T1, typename T2\>
	T1* find(const T1* left, const T1* const left_range, const T2& item); \n
	
	template \<typename T\> 
	T* max_element(const T* left, const T* const left_range); \n
	
	template \<typename T\> 
	T* min_element(const T* left, const T* const left_range); \n
	
	template \<typename T\> 
	T* remove(T* left, const T* const left_range, const T& item); \n
	
	template \<typename T\> 
	void replace(const T* left, const T* const left_range, 
							const T& old_item, const T& new_item); \n
							
	template \<typename T\>
	T sum(const T* left, const T* const left_range); \n
	
	template \<typename T\> 
	void swap(T &left, T &right); \n
  
	template \<typename T\> 
	void swap_ranges(const T* left, 
	const T* const left_range, const T* right); \n

	\n 
	Hours spent on this assignment: 
	4.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{ 
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
	template <typename T> 
	T* copy(const T* left, const T* const left_range, const T* right);
	
	template <typename T> 
	int count(const T* left, const T* const left_range, const T& item);
	
	template <typename T> 
	void display(const T* left, const T* const left_range);
	
	template <typename T1, typename T2> 
	bool equal(const T1* left, const T1* const left_range, const T2* right);
	
	template <typename T> 
	void fill (T* left, const T* const left_range, const T& item);
	
	template <typename T1, typename T2>
	T1* find(const T1* left, const T1* const left_range, const T2& item);
	
	template <typename T> 
	T* max_element(const T* left, const T* const left_range);
	
	template <typename T> 
	T* min_element(const T* left, const T* const left_range);
	
	template <typename T> 
	T* remove(T* left, const T* const left_range, const T& item);
	
	template <typename T> 
	void replace(const T* left, const T* const left_range, 
							const T& old_item, const T& new_item);
							
	template <typename T>
	T sum(const T* left, const T* const left_range);
	
	template <typename T> 
	void swap(T &left, T &right);
  
	template <typename T> 
	void swap_ranges(const T* left, const T* const left_range, const T* right);
	
	
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
