/******************************************************************************/
/*! 
  \file functions.cpp
  \author Lau Jan Wei, Joshua
  \par email: janweijoshua.lau\@digipen.edu
  \par DigiPen login: janweijoshua.lau
  \par Course: CS170
  \par Lab 05
  \date 08/07/2019
  \brief
This file contains the implementation of the following functions for Lab 06.
Functions include:
1) copy
2) count
3) equal
4) fill
5) find
6) max_element
7) min_element
8) remove
9) replace
10) sum
11) swap_ranges

Hours spent on this Lab assignment: 12
Specific portions that gave you the most trouble: remove, swap_ranges
*/
/******************************************************************************/
#include <iostream> // cout, endl

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}
/******************************************************************************/
/*!
  \brief
    Copy another object. There is no return value but the first object 
	copies the second
  
  \param i1
    Iterator 1 which is to be copied.
    
  \param i1end
    The end of the iterator 1.
  
  \param i2
    Iterator 2 which is to store the copy of iterator 1.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T2 copy(const T1 i1, const T1 i1end, const T2 i2)
{
  T1 temp1 = i1;
  T2 temp2 = i2;
 while(temp1 != i1end)
 {
   *temp2 = *temp1;
   ++temp1;
   ++temp2;
 }
 return temp2;
}
/******************************************************************************/
/*!
  \brief
    Counts a user defined value and the number of its occurences in the array.
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.
  
  \param item
    User defined value to be counted.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T2 count(const T1 i, const T1 iend, const T2 &item)
{
  int c = 0;
  // make a temp to traverse
  T1 temp = i;
 while(temp != iend)
 {
   if(*temp == item)
     ++c;
   ++temp;
 }
 return c;
}
/******************************************************************************/
/*!
  \brief
    Displays the array by printing it out 
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.
*/
/******************************************************************************/
template <typename T> 
void display(const T i, const T iend)
{
  T temp = i;
  while(temp != iend)
  {
   std::cout << *temp;
   if (temp != iend - 1)
     std::cout << ", ";
   ++temp;
  }
  std::cout << std::endl;
}
/******************************************************************************/
/*!
  \brief
    Finds out if both arrays are equal
  
  \param i1
    Iterator 1 that points to the array 1.
    
  \param i1end
    The end of the iterator 1.
    
  \param i1
    Iterator 2 that points to the array 2.
*/
/******************************************************************************/
template <typename T1, typename T2> 
bool equal(T1 i1, T1 i1end, T2 i2)
{
 while(i1 != i1end)
 {
   if(*i2 != *i1)
     return false;
   ++i1;
   ++i2;
 }
 return true;
}
/******************************************************************************/
/*!
  \brief
    Fills up the whole array with a single user defined value
  
  \param i
    Iterator 1 that points to the array 1.
    
  \param iend
    The end of the iterator 1.
    
  \param value
    Iterator 2 that points to the array 2.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void fill(const T1 i, const T1 iend, const T2 &value)
{
  T1 temp = i;
 while(temp != iend)
 {
   *temp = value;
   ++temp;
 }
}
/******************************************************************************/
/*!
  \brief
    Finding the user defined value in the array
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.
    
  \param value
    User defined value to be found.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 find(const T1 i, const T1 iend, const T2 &value)
{
  T1 temp = i;
 while(temp != iend)
 {
   if(*temp == value)
    return temp;
   ++temp;
 }
 return temp;
}
/******************************************************************************/
/*!
  \brief
    Returns the largest element in the list
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.

*/
/******************************************************************************/
template <typename T> 
T max_element(const T i, const T iend)
{
  T temp = i;
  T max = temp;
 while(temp != iend)
 {
   if(*temp > *max)
   max = temp;
   ++temp;
 }
 return max;
}
/******************************************************************************/
/*!
  \brief
    Returns the smallest element in the list
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.

*/
/******************************************************************************/
template <typename T> 
T min_element(const T i, const T iend)
{
  T temp = i;
  T min = temp;
 while(temp != iend)
 {
   if(*temp < *min)
   min = temp;
   ++temp;
 }
 return min;
}


// ---------------------------------------------------------------
// remove
/******************************************************************************/
/*!
  \brief
    Removes a user defined value in all positions in the array
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.
    
  \param oldnum
    The user defined value to be removes.
  

*/
/******************************************************************************/
template <typename T> 
T* remove(T* i, T* iend, T item)
{
  // T1 tempPtr = i;
  // while(tempPtr != iend)
  // {
   // if(*tempPtr == item)
   // {
     // T1 tempPtrSave = tempPtr;
     // while(tempPtr != iend)
     // {
       // *tempPtr = *(tempPtr+1);
       // ++tempPtr;
     // }
     // tempPtr = tempPtrSave;
   // }
   // ++tempPtr;
  // }
  // return tempPtr;
  while (i != iend)
  {
    if (*i == item)
    {
      T* temp = i;
      while (i != iend-1)
      {
        *i = *(i+1);
        ++i;
      }
      i = temp;
      --iend;
    }
    else
      ++i;
  }
  return iend;
}

/******************************************************************************/
/*!
  \brief
    Replaces user defined old value in all positions in the array with
    the user defined new value.
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.
    
  \param oldnum
    The old user defined value.
    
  \param newnum
    The new user defined value.

*/
/******************************************************************************/
template <typename T1, typename T2> 
void replace(const T1 i, const T1 iend, const T2 &oldnum, const T2 &newnum)
{
  T1 temp = i;
 while(temp != iend)
 {
   if(*temp == oldnum)
   *temp = newnum;
   ++temp;
 }
}

/******************************************************************************/
/*!
  \brief
    Adds all the values in the array up to get a sum total
  
  \param i
    Iterator that points to the array.
    
  \param iend
    The end of the iterator.


*/
/******************************************************************************/
template <typename T> 
T sum(T* i, T* iend)
{
  T sum = 0;
 while(i != iend)
 {
   sum += *i;
   ++i;
 }
 return sum;
}

/******************************************************************************/
/*!
  \brief
    swaps the range of values in the array
  
  \param i
    Iterator 1 that points to the array 1.
    
  \param iend
    The end of the iterator.
    
  \param i2
    Iterator 2 that points to array 2.

*/
/******************************************************************************/
template <typename T> 
void swap_ranges(T* i1, T* i1end, T* i2)
{
  T temp;
  while (i1 < i1end)
  {
    temp = *i1;
    *i1 = *i2;
    *i2 = temp;
    ++i1;
    ++i2;
  }
}