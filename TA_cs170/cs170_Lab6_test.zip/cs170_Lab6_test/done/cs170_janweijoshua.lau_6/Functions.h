/******************************************************************************/
/*! 
  \file functions.h
  \author Lau Jan Wei, Joshua
  \par email: janweijoshua.lau\@digipen.edu
  \par DigiPen login: janweijoshua.lau
  \par Course: CS170
  \par Lab 05
  \date 08/07/2019
  \brief
This file contains the implementation of the following functions for Lab 06.
Functions include:
1) copy
2) count
3) equal
4) fill
5) find
6) max_element
7) min_element
8) remove
9) replace
10) sum
11) swap_ranges

Hours spent on this Lab assignment: 12
Specific portions that gave you the most trouble: remove, swap_ranges
*/
/******************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  template <typename T> void swap(T &left, T &right);
  
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  template <typename T1, typename T2>
  T2 copy(const T1 i1, const T1 i1end, const T2 i2);
  
  template <typename T1, typename T2>
  T2 count(const T1 i, const T1 iend, const T2 &item);
  
  template <typename T>
  void display(const T i, const T iend);
  
  template <typename T1, typename T2>
  bool equal(T1 i1, T1 const i1end, T2 i2); 
  
  template <typename T1, typename T2>
  void fill(const T1 i, const T1 i2, const T2 &value); 
  
  template <typename T1, typename T2>
  T1 find(const T1 i, const T1 iend, const T2 &value);
  
  template <typename T>
  T max_element(const T i, const T iend);
  
  template <typename T>
  T min_element(const T i, const T iend);
  
  template <typename T>
  T* remove(T* i, T* iend, T item);
  
  template <typename T1, typename T2>
  void replace(const T1 i, const T1 iend, const T2 &oldnum, const T2 &newnum);
  
  template <typename T>
  T sum(T* i, T const* iend);
  
  template <typename T>
  void swap_ranges(T* i, T* iend, T* i2);

  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
