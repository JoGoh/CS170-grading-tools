/******************************************************************************/
/*!
\file               Functions.h
\author             Eu Shee Kei
\par email:         sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course:        CS170
\par Lab:           6
\date               08/07/2019
\brief
This file contains the implementation of the following function templates for 
the Functions assignment.
*/
/******************************************************************************/
#include <iostream> // cout, endl

/******************************************************************************/
/*!
\fn     template <typename T1, typename T2> T2* copy(T1* first, T1* last, 
        T2* secondArray)
\brief  Copy objects from one array to the other
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  secondArray    A pointer to the first element of second array
\return void
*/
/******************************************************************************/
template <typename T1, typename T2>
T2* copy(T1* first, T1* last, T2* secondArray)
{
  T1* temp(first);
  T2* temp2(secondArray);
  
  // copy items from first array to second array, starting from first element
  while(temp != last)
  {
    *temp2 = (T2)(*temp);
    ++temp, ++temp2;
  }
  
  return temp2;
}

/******************************************************************************/
/*!
\fn     template <typename T> T count(T* first, T* last, T &item)
\brief  Swaps the values of two arrays
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  item           A reference to a value to be counted in array
\return void
*/
/******************************************************************************/
template <typename T>
T count(T* first, T* last, T &item)
{
  T* temp(first);
  T total = (T)0;
  
  // count number of items while iterating through the array
  while(temp!=last)
  {
    if(*temp == item)
      ++total;
    ++temp;
  }
  
  return total;
}

/******************************************************************************/
/*!
\fn     template <typename T>void display(T* first, T* last)
\brief  Prints the array of values from first to last element
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\return void
*/
/******************************************************************************/
template <typename T>
void display(T* first, T* last)
{
  T* temp(first);

  // print array items, starting from first element
  while(temp != last)
  {
    if(temp+1 == last)
      std::cout << *temp;
    else
      std::cout << *temp << ", ";
    temp++;
  }
  std::cout << std::endl;
}

/******************************************************************************/
/*!
\fn     template <typename T1, typename T2>bool equal(T1* first, T1* last, T2* secondArr)
\brief  Checks if the elements of first and second array matches
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  secondArr      Pointer to the first element of second array
\return bool           true if elements in both arrays matches
                       false if elements in both arrays do not match
*/
/******************************************************************************/
template <typename T1, typename T2>
bool equal(T1* first, T1* last, T2* secondArr)
{
  T1* temp(first);
  T2* temp2(secondArr);
  
  // check if item in first and second array matches. If so, return true.
  // else, return false.
  while(temp != last)
  {
    if(*temp != *temp2)
      return false;
    ++temp, ++temp2;
  }
  
  return true;
}

/******************************************************************************/
/*!
\fn     template <typename T>void fill(T* first, T* last, T& item)
\brief  Fill an empty array with specified value
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  item           A reference to a value to be counted in array
\return void
*/
/******************************************************************************/
template <typename T>
void fill(T* first, T* last, T& item)
{
  T* temp(first);
  
  // fill the array with item, starting from first element
  while(temp != last)
  {
    *temp = item;
    ++temp;
  }
}

/******************************************************************************/
/*!
\fn     template <typename T1, typename T2>T1* find(T1* first, T1* last, 
        T2 &item)
\brief  Find an object in the array
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  item           A reference to a value to be counted in array
\return *T1            A pointer to object found
*/
/******************************************************************************/
template <typename T1, typename T2>
T1* find(T1* first, T1* last, T2 &item)
{
  T1* temp(first);
  
  // find array element matching item, starting from the first element
  while(temp != last)
  {
    if(*temp == item)
      return temp;
    ++temp;
  }
  
  return temp;
}

/******************************************************************************/
/*!
\fn     template <typename T> T* remove(T* first, T* last, T item)
\brief  Remove an object in the array
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  item           A reference to a value to be counted in array
\return T*             A pointer to object removed
*/
/******************************************************************************/
template <typename T>
T* remove(T* first, T* last, T &item)
{
  T* temp(first);
  int match = 0;
  
  // remove elements matching item from the array, from the first element
  while(temp != last)
  {
    if(*temp == item)
      ++match;
    else
      *(temp-match) = *temp;
    ++temp;
  }
  return last-match;
}

/******************************************************************************/
/*!
\fn     template <typename T>void replace(T* first, T* last, T oldItem, 
        T newItem)
\brief  Replaces a specific value in array with specified value
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  oldItem        A value to be replaced in array
\param  newItem        A value to replace a value in array
\return void
*/
/******************************************************************************/
template <typename T>
void replace(T* first, T* last, T oldItem, T newItem)
{
  T* temp(first);
  
  // replace old item in array with new item
  while(temp != last)
  {
    if(*temp == oldItem)
      *temp = newItem;
    ++temp;
  }
}

/******************************************************************************/
/*!
\fn     template <typename T>T* max_element(T* first, T* last)
\brief  Finds the largest value in the array
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\return T*             Pointer to the array with the largest value
*/
/******************************************************************************/
template <typename T>
T* max_element(T* first, T* last)
{
  T* temp(first);
  T* max= temp;
  
  // find the item with the biggest value in the array
  while(temp != last)
  {
    if(*temp > *max)
      max = temp;
    ++temp;
  }
  
  return max;
}

/******************************************************************************/
/*!
\fn     template <typename T>T* min_element(T* first, T* last)
\brief  Finds the smallest value in the array
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\return T*             Pointer to the array with the smallest value
*/
/******************************************************************************/
template <typename T>
T* min_element(T* first, T* last)
{
  T* temp(first);
  T* min = temp;
  
  // find the item with the smallest value in the array
  while(temp != last)
  {
    if(*temp < *min)
      min = temp;
    ++temp;
  }
  
  return min;
}

/******************************************************************************/
/*!
\fn     template <typename T>T sum(T* first, T* last)
\brief  Finds the largest value in the array
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\return T              Total sum of values of elements in the array
*/
/******************************************************************************/
template <typename T>
T sum(T* first, T* last)
{
  T total = 0;
  T* temp(first);
  
  // add up value of all items in the array
  while(temp != last)
  {
    total += *temp;
    ++temp;
  }
  
  return total;
}

/******************************************************************************/
/*!
\fn     template <typename T> void swap(T &left, T &right)
\brief  Swaps two objects. There is no return value but the two objects are
        swapped in place.
\param  left            The first object to swap.
\param  right           The second object to swap.
\return void
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  // swap two items
  T temp(right);
  right = left;
  left = temp;
}

/******************************************************************************/
/*!
\fn     template <typename T> void swap_ranges(T* first, T* last, 
        T* secondArray)
\brief  Swaps the values of two arrays
\param  first          Pointer to the first element of array
\param  last           Pointer to the last element of array
\param  secondArray    Pointer to the first element of second array
\return void
*/
/******************************************************************************/
template <typename T>
void swap_ranges(T* first, T* last, T* secondArray)
{
  T* temp(first);
  T* temp2(secondArray);
  
  // swap items between first and second array, starting from the first element
  while (temp != last)
  {
    swap(*temp, *temp2);
    ++temp, ++temp2;
  }
}