/*****************************************************************************/
/*!
\file Functions.h
\author Favian Goh
\par DP email duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 6
\date 08/07/2019
\brief
  This file contains several function templates declaration that
  work on ranges.
  
  The function templates are:
  
  count
  copy
  display
  equal
  fill
  find
  max_element
  min_element
  remove
  replace
  sum
  swap
  swap_ranges
*/
/*****************************************************************************/

//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  
  template <typename T1, typename T2>
  int count (T1 left, T1 right, const T2& item);
  
  template <typename T1, typename T2>
  T2 copy (T1 left1, T1 right1, T2 left2);
  
  template <typename T> 
  void display (T left, T right);
  
  template <typename T1, typename T2>
  bool equal (T1 left1, T1 right1, T2 left2);
  
  template <typename T1, typename T2>
  void fill (T1 left, T1 right, T2& num);
  
  template <typename T1, typename T2>
  T1 find (T1 left, T1 right, const T2& item);
  
  template <typename T>
  T max_element (T left, T right);
  
  template <typename T>
  T min_element (T left, T right);
  
  template <typename T1, typename T2>
  T1 remove(T1 left, T1 right, const T2& item);
  
  template <typename T1, typename T2>
  void replace (T1 left, T1 right, T2 old_, T2 new_);

  template <typename T>
  int sum (T left1, T right1);
  
  template <typename T>
  void swap(T &left, T &right);

  template <typename T1, typename T2> 
  void swap_ranges(T1 left1, T1 right1, T2 left2);
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
