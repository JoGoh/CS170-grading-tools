/*****************************************************************************/
/*!
\file Functions.cpp
\author Favian Goh
\par DP email duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 6
\date 08/07/2019
\brief
  This file contains several function templates that work on ranges.
  The function templates are:
  
  count
  copy
  display
  equal
  fill
  find
  max_element
  min_element
  remove
  replace
  sum
  swap
  swap_ranges
*/
/*****************************************************************************/

#include <iostream> // cout, endl

/*****************************************************************************/
/*!
  \brief
    Count the amount of times the object to count appears in the ranges.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
    
  \param item
    The object to count.
    
*/
/*****************************************************************************/

template <typename T1, typename T2>
int count (T1 left, T1 right, const T2& item)
{
  int c = 0;            //count
  
  while (left != right) //loop through range
  {
    if (*left == item)  //checks if object same as item
      ++c;              //increment count
    ++left;             //move ptr to next
  }
  
  return c;
}

/*****************************************************************************/
/*!
  \brief
    Copy one range's objects into another range.
  
  \param left1
    The first object of the 1st range.
  
  \param right1
    The last object of the 1st range.
    
  \param left2
    The first object of the 2nd range.
    
*/
/*****************************************************************************/

template <typename T1, typename T2>
T2 copy (T1 left1, T1 right1, T2 left2)
{
  
  while (left1 != right1) //loop through range
  {
    *left2 = *left1;      //copy object into 2nd range
    ++left1;              //move ptr to next object
    ++left2;              //move ptr to next object
  }
  return left2;
}

/*****************************************************************************/
/*!
  \brief
    Display all objects in the range.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
    
*/
/*****************************************************************************/

template <typename T> 
void display (T left, T right)
{
 
  while (left != right)             //loop through range
  {
    if (left == right - 1)          //formatting
      std::cout << *left;
    else
      std::cout << *left << ", ";
    ++left;
  }
  
  std::cout << std::endl;           //endl
}

/*****************************************************************************/
/*!
  \brief
    Check the two ranges have the same elements.
  
  \param left1
    The first object of the 1st range.
  
  \param right1
    The last object of the 1st range.
    
  \param left2
    The first object of the 2nd range.
    
*/
/*****************************************************************************/

template <typename T1, typename T2>
bool equal (T1 left1, T1 right1, T2 left2)
{

  while (left1 != right1) //loop through range
  {
    if (*left1 == *left2) //check if both obhects are equal
    {
      ++left1;
      ++left2;
    }
    else
      return false;       //return false if not equal
  }

  return true;            //return true if equal
  
}

/*****************************************************************************/
/*!
  \brief
    Fill the range with the supplied num.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
    
  \param num
    The object to fill the range with.
    
*/
/*****************************************************************************/

template <typename T1, typename T2>
void fill (T1 left, T1 right, const T2& num)
{
  while (left != right) //loop through range
  {
    *left = num;        //current pos filled with num
    ++left;             //move ptr to next object
  }
}

/*****************************************************************************/
/*!
  \brief
    Find the supplied object in the range.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
  
  \param item
    The object to find in the range.
    
*/
/*****************************************************************************/

template <typename T1, typename T2>
T1 find (T1 left, T1 right, const T2& item)
{
  
  while (left != right)//loop through range
  {
    if (*left == item) //check if current object is same as object to be found
      return left;     //return found object
    ++left;            //move ptr to next object
  }
  
  return right;
  
}

/*****************************************************************************/
/*!
  \brief
    Find the largest object in the range.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
    
*/
/*****************************************************************************/

template <typename T>
T max_element (T left, T right)
{
  T max = left;           //max used to store largest object
  
  while (left != right)   //loop through range
  {
    if (*left > *max)     //checks if current object is larger than current max
      max = left;         //replace max with current object
    ++left;
  }
 
  return max;             //return largest object
}

/*****************************************************************************/
/*!
  \brief
    Find the smallest object in the range.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
    
*/
/*****************************************************************************/

template <typename T>
T min_element (T left, T right)
{
  T min = left;           //max used to store smallest object
  
  while (left != right)   //loop through range
  {
    if (*left < *min)     //checks if current object is larger than current min
      min = left;         //replace max with current object
    ++left;
  }
 
  
  return min;             //return smallest object
}

/*****************************************************************************/
/*!
  \brief
    Remove all objects in the range that are of the supplied object.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
  
  \param item
    The object of the range be to removed.
    
*/
/*****************************************************************************/

template <typename T1, typename T2>
T1 remove(T1 left, T1 right, const T2& item)
{
  T1 result = left;       //store first object of range
  
  while(left != right)    //loop through range
  {
    if(!(*left == item))  //check if current object is not equal to item
    {
      *result++ = *left;  //replace current object with the adjacent object
    }
    ++left;               //move ptr to next object
  }
  
  return result;
}

/*****************************************************************************/
/*!
  \brief
    Replace a current object in the range with a supplied object.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
  
  \param old_
    The object of the range be to replaced.
  
  \param new_
    The new object to replace the old object.
    
*/
/*****************************************************************************/

template <typename T1, typename T2>
void replace (T1 left, T1 right, T2 old_, T2 new_)
{
  while (left != right) //loop through range
  {
    if (*left == old_)  //checks if current object equal
      *left = new_;     //replace current object with new_
    ++left;             //move ptr to next object
  }
}

/*****************************************************************************/
/*!
  \brief
    Sum of all objects in the range.
  
  \param left
    The first object of the range.
  
  \param right
    The last object of the range.
*/
/*****************************************************************************/

template <typename T>
int sum (T left, T right)
{
  int sum_ = 0;         //store sum of all object in the range
  
  while (left != right) //loop through range
  {
    sum_ += *left;      //add the objects into sum
    ++left;             //move ptr to next object
  }
  
  return sum_;
}

/*****************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/*****************************************************************************/

template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/*****************************************************************************/
/*!
  \brief
    Swaps all objects between two ranges.
  
  \param left1
    The first object of the 1st range.
  
  \param right1
    The last object of the 1st range.
    
  \param left2
    The first object of the 2nd range.
*/
/*****************************************************************************/

template <typename T1, typename T2> 
void swap_ranges(T1 left1, T1 right1, T2 left2)
{
  while(left1 != right1)  //loop through range
  {
    swap(*left1, *left2); //swap objects
    ++left1;              //move ptr to next object
    ++left2;              //move ptr to next ptr
  }
}