/******************************************************************************/
/*!
\file Functions.cpp
\author Samuel Chee
\par email: chee.k\@digipen.edu
\par DigiPen login: chee.k
\par Course: CS170
\par Lab 06
\date 05/07/2019
\brief
This file contains the implementation of the following functions 
for the function template assignment.
Functions include:
template<typename T1, typename T2>
T2 copy(T1 begin1,const T1 end1, T2 begin2);<br>

template<typename T1, typename T2>
T2 count(T1 begin,const T1 end,const T2& val);<br>

template<typename T> void display(T begin,const T end);

template<typename T1,typename T2>
bool equal(T1 begin1,const T1 end1, T2 begin2);<br>

template<typename T> void fill(T& begin,const T* end,const T val);<br>

template<typename T1, typename T2>
 T1 find(T1 begin,const T1& end,const T2& val);<br>

template<typename T> T max_element(T begin,const T end);<br>

template<typename T> T min_element(T begin,const T end);<br>

template<typename T>
T* remove(T* begin, T* end const, T& val const);<br>

template<typename T>
void replace(T* begin,const T* end,const T oldItem, const T newItem);<br>

template<typename T> T sum(T* begin,const T* end);<br>

template<typename T> void swap(T &left, T &right);<br>

template<typename T> void swap_ranges(T begin1, T end1, T begin2);<br>

Hours spent on this assignment: 3 hours
Specific portions that gave you the most trouble:
Implementing remove function to withstand stress test.

*/ 
/******************************************************************************/



/******************************************************************************/
/*!
  \brief
    Copies elements from one objects range into another object,
    user is required to ensure 2nd object has enough space for copy.

  \param begin1
    The first object start of range.

  \param end1
        The first object end of range.
    
  \param begin2
    The second object start of range.

  \return T2
    returns templated type which represents end of range of 2nd object
*/
/******************************************************************************/
template<typename T1, typename T2>
T2 copy( T1 begin1, T1 end1, T2 begin2)
{
    while(begin1!=end1)//Run through whole range
    {
        *begin2++=*begin1;//Assign new values to 2nd object
        begin1++;//Increment pos pointer
    }
    return (begin2);//End of range of 2nd object
}
/******************************************************************************/
/*!
  \brief
    Counts elements within an objects range that matches value given
    returns the number of matching objects

  \param begin
    The object start of range.

  \param end
    The object end of range.
    
  \param val
    The value to be checked

  \return T2
    returns number of matching items in object range
*/
/******************************************************************************/
template<typename T1, typename T2>
T2 count(T1 begin, T1 end,const T2& val)
{
    T2 count=0;
    while(begin!=end)//Run through whole range
    {
        if(*begin==val)//If values match
        {
            count++;//Increment counter
        }
        begin++;//Move position
    }
    return count;//Return counter
}
/******************************************************************************/
/*!
  \brief
    Displays elements from objects range
    function returns nothing.

  \param begin
    The object start of range.

  \param end
    The object end of range.
*/
/******************************************************************************/
template<typename T>
void display(T begin, T end)
{
    while(begin!=end)//Runs through whole range
    {
        std::cout<<*begin;//Print value of element
        begin++;//Move position
        if(begin!=end)//If not end
            std::cout<<", ";//Print format for next print out
    }
    std::cout<<std::endl;//Print new line after call
}
/******************************************************************************/
/*!
  \brief
    Compares elements from one objects range to another object,
    and returns boolean if they are equal in the range of the first 
    object.

  \param begin1
    The first object start of range.

  \param end1
    The first object end of range.
    
  \param begin2
    The second object start of range.

  \return bool
    returns boolean if elements in range of first object matches with 
    similar range of 2nd object.
*/
/******************************************************************************/
template<typename T1 , typename T2>
bool equal(T1 begin1, T1 end1, T2 begin2)
{
    while(begin1!=end1)//Runs through whole range 
    {
        if(*begin1!=*begin2)//If values aren't equal
            return false;//Return not equal
        begin1++;
        begin2++;
    }
    return true;//Return equal
}
/******************************************************************************/
/*!
  \brief
    Fills all elements in an array with the given val,returns nothing.

  \param begin
    The object start of range.

  \param end
    The object end of range.
    
  \param val
    The value to be used

*/
/******************************************************************************/
template<typename T>
void fill(T* begin, T* end,const T& val)
{
    while(begin!=end)//Runs through whole range
    {
            *begin=val;//Assign element with given value
            begin++;//Shift down range
    }
}
/******************************************************************************/
/*!
  \brief
    Finds an element of given val from objects range.

  \param begin
    The object start of range.

  \param end
    The object end of range.
    
  \param val
    The value to be found in range

  \return T
    returns templated type which represents position in range.
*/
/******************************************************************************/
template<typename T1 ,typename T2>
T1 find(T1 begin, T1& end,const T2& val)
{
    while (begin!= end)//Runs through whole range
    {
        if(*begin==val)//If values are equal
            return begin;//Return position of found element
        begin++;//else shift down range
    }
    return begin;//Return end
}
/******************************************************************************/
/*!
  \brief
    Searches through range of an object and returns 
    the templated type corresponding to the max value

  \param begin
    The object start of range.

  \param end
    The object end of range.
    
  \return T
    returns templated type which represents max value in range.
*/
/******************************************************************************/
template<typename T>
T max_element(T begin, T end)
{
    T val = begin;//Assign pointer to begin
    while(begin!=end)//Run through whole range
    {
       if(*val<*begin)//If saved value is less than current
           val=begin;//Assign new value
       begin++;
    }
    return val;//Return position of largest value
}
/******************************************************************************/
/*!
  \brief
    Searches through range of an object and returns 
    the templated type corresponding to the min value

  \param begin
    The object start of range.

  \param end
    The object end of range.
    
  \return T
    returns templated type which represents min value in range.
*/
/******************************************************************************/
template<typename T>
T min_element(T begin, T end)
{
    T val = begin;//Assign pointer to begin
    while(begin!=end)//Runs through whole range
    {
       if(*val>*begin)//If saved value is larger than current
           val=begin;//Assign smaller value
       begin++;//Shift down range
    }
    return val;//Return position of smallest value
}
/******************************************************************************/
/*!
  \brief
    Removes an element of given val from objects range.

  \param begin
    The object start of range.
  \param end
    The object end of range
  \param val
    The value to be removed from object range
  
  \return T*
    returns a pointer to templated type which represents new end if range
    after removing matching values.
*/
/******************************************************************************/
template<typename T>
T* remove(T* begin, T* end,const T& val)
{
    T* temp=begin;//Base pointer to iterate through whole array
    T* shift=begin;//Pointer to move only if val not matching
    while(temp!=end)//Look through whole array
    {
        if(*temp!=val)//If current value not equal to target value
            *shift++=*(begin+(temp-begin));//Sort all vals to back of array
    
        temp++;//Increment pointer
    }
    return shift;//New end of array
}
/******************************************************************************/
/*!
  \brief
    Finds an element of given val from objects range 
    and replaces it with a new value given.

  \param begin
    The object start of range.

  \param end
    The object end of range.

  \param oldItem
    The value to be found in range

  \param newItem
    The value to be used to replace old values
*/
/******************************************************************************/
template<typename T>
void replace(T* begin, T* end,const T oldItem, const T newItem)
{
    while(begin!=end)//Runs through whole range
    {
        if(*begin==oldItem)//If found matching old item
            *begin=newItem;//Replace with new item
        begin++;//Move down range
    }
}
/******************************************************************************/
/*!
  \brief
    Sums all element in objects range.

  \param begin
    The object start of range.

  \param end
    The object end of range.

  \return T
    returns templated type which is the sum of all elements in range.
*/
/******************************************************************************/
template<typename T>
T sum(T* begin, T* end)
{
    T temp=0;//Initialise value
    while(begin!=end)//Run through whole range
    {
        temp+=*begin;//Compound addition to value
        begin++;//Move down range
    }
    return temp;//return sum
}

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T>
void swap(T &left, T &right)
{
    T temp(right); // need a temporary copy
    right = left;
    left = temp;
}
/******************************************************************************/
/*!
  \brief
    Swaps two objects ranges. There is no return value 
    but the two objects ranges are swapped .

  \param begin1
    The first object start of range.

  \param end1
    The first object end of range.
    
  \param begin2
    The second object start of range.
*/
/******************************************************************************/
template<typename T>
void swap_ranges(T begin1, T end1, T begin2)
{
    //While within range
    while(begin1!=end1)
    {
        //swap elements in both ranges
        swap(*begin1,*begin2);
        //Increment pointers
        begin1++;
        begin2++;
    }
}