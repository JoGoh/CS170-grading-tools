/*****************************************************************************/
/*!
\file Functions.h
\author Samuel Chee
\par email: chee.k\@digipen.edu
\par DigiPen login: chee.k
\par Course: CS170
\par Lab 06
\date 05/07/2019
\brief
This file contains the implementation of the following functions 
for the function template assignment.
Functions include:
template<typename T1, typename T2>
T2 copy(T1 begin1,const T1 end1, T2 begin2);<br>

template<typename T1, typename T2>
T2 count(T1 begin,const T1 end,const T2& val);<br>

template<typename T> void display(T begin,const T end);

template<typename T1,typename T2>
bool equal(T1 begin1,const T1 end1, T2 begin2);<br>

template<typename T> void fill(T& begin,const T* end,const T val);<br>

template<typename T1, typename T2>
 T1 find(T1 begin,const T1& end,const T2& val);<br>

template<typename T> T max_element(T begin,const T end);<br>

template<typename T> T min_element(T begin,const T end);<br>

template<typename T>
T* remove(T* begin, T* end const, T& val const);<br>

template<typename T>
void replace(T* begin,const T* end,const T oldItem, const T newItem);<br>

template<typename T> T sum(T* begin,const T* end);<br>

template<typename T> void swap(T &left, T &right);<br>

template<typename T> void swap_ranges(T begin1, T end1, T begin2);<br>

Hours spent on this assignment: 3 hours
Specific portions that gave you the most trouble:
Implementing remove function to withstand stress test.

*/ 
/*****************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------
#include <iostream> // cout, endl
namespace CS170
{
  template <typename T1, typename T2> T2 copy(T1 begin1, T1 end1, T2 begin2);

  template <typename T1, typename T2> T2 count(T1 begin, T1 end,const T2& val);
  
  template <typename T> void display(T begin, T end);
  
  template <typename T1,typename T2> bool equal(T1 begin1, T1 end1, T2 begin2);
  
  template <typename T> void fill(T& begin,const T* end, T val);
  
  template <typename T1, typename T2> T1 find(T1 begin, T1& end,const T2& val);
  
  template <typename T> T max_element(T begin, T end);
  
  template <typename T> T min_element(T begin, T end);
  
  template <typename T> T* remove(T* begin, T* end , const T& val );
  
  template <typename T> 
  void replace(T* begin, T* end,const T oldItem, const T newItem);
  
  template <typename T> T sum(T* begin, T* end);
  
  template <typename T> void swap(T& left, T& right);
  
  template <typename T> void swap_ranges(T begin1, T end1, T begin2);
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
