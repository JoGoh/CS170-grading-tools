/**************************************************************************************************************/
/*!
\file   Functions.h
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 06
\date   8/7/2019
\brief
  List of template functions (such as counting or displaying items in a range). Includes Functions.cpp for definition
*/
/**************************************************************************************************************/

//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

/**************************************************************************************************************/
/*!
  \namespace CS170
  \brief Namespace that contains the template functions. More details on functions found in Functions.cpp file
*/
/**************************************************************************************************************/
namespace CS170
{

//Copies values from one range to another
template <typename T1, typename T2> T2* copy(const T1* begin, const T1* end, T2* begin2);
//Counts no. of specific items in a range
template <typename T> int count(const T* begin, const T* end, const T& check);
//Displays all values in the range
template <typename T> void display(const T* begin, const T* end);
//Checks if the ranges are matching by their values
template <typename T1 , typename T2> bool equal(const T1* begin, const T1* end, const T2* begin2);
//Fills the range up with a specific value
template <typename T> void fill(T* begin, const T* end, const T& value);
//Finds the first occurence of a specific item in the range.
template <typename T> T* find(const T* begin, const T* end, const T& check);
//Returns the largest value item in that range
template <typename T> T* max_element(const T* begin, const T* end);
//Returns the smallest value item in that range
template <typename T> T* min_element(const T* begin, const T* end);
//Removes all occurences of a specific item in the range
template <typename T> T* remove(T* begin, const T* end, const T& check);
//Replaces all occurences of a specific item with another item in the range. 
template <typename T> void replace(T* begin, const T* end, const T& check, const T& replace);
//Returns the summation of all the values of items in the range.
template <typename T> T sum(const T* begin, const T* end);
//Swaps the value of two items
template <typename T> void swap(T &left, T &right);
//Swaps the values of all items in a specific range with another.
template <typename T> void swap_ranges(T* begin, const T* end, T* begin2);
  


/* 
*  Other template function declarations for count, remove, replace, etc.
*  go here. Make sure all of your declarations are sorted in alphabetical
*  order. This includes putting the swap function above in the proper
*  position.
*
*/ 
  

#include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
