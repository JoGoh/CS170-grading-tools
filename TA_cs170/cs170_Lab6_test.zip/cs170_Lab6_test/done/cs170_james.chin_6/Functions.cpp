/**************************************************************************************************************/
/*!
\file   Functions.cpp
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 06
\date   8/7/2019
\brief
  Implementation of template functions (such as counting or displaying items in an range)
*/
/**************************************************************************************************************/
#include <iostream> // cout, endl

/******************************************************************************/
/*!
  \fn template <typename T, typename T2> T2* copy(const T* begin, const T* end, T2* begin2)

  \brief
	Copies values in range 1 and inputs them into range 2. Ranges need not be of the exact same type.
	(can be of similar type)
  \param begin
	Pointer to the beginning of the first range

  \param end
	Pointer to the end of the first range

  \param begin2
	Pointer to the beginning of the second range

  \return
	Pointer to the end of the second range

*/
/******************************************************************************/
template <typename T1, typename T2>
T2* copy(const T1* begin, const T1* end, T2* begin2) {

	//Check if range is empty
	if (begin == end) {
		return begin2;
	}

	//Progress through the range
	const T1* current = begin;
	T2* current2 = begin2;
	while (current != end) {

		//Set the value of the 2nd item to be that of the first.
		*current2 = *current;
		++current;
		++current2;
	}

	return current2;
}

/******************************************************************************/
/*!
  \fn template <typename T> int count(const T* begin, const T* end, const T& check)

  \brief
	Counts all the items with the given value in the range

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

  \param check
	Item to count.

  \return
	No. of items

*/
/******************************************************************************/
template <typename T>
int count(const T* begin, const T* end, const T& check)
{
	//Check if range is empty
	if (begin == end) {
		return 0;
	}

	//Progress through the range
	const T* current = begin;
	int iCnt = 0;
	while (current != end) {
		
		//Check if they have the same value, then add one to counter
		if (*current == check) {
			++iCnt;
		}

		++current;
	}

	return iCnt;
}

/******************************************************************************/
/*!
  \fn template <typename T> void display(const T* begin, const T* end)

  \brief
	Using std::cout, prints out the values in the range 

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

*/
/******************************************************************************/
template <typename T> 
void display(const T* begin, const T* end) {
	
	//Check if range is empty
	if (begin == end){
		std::cout << std::endl;
		return;
	}

	//Progress through the range
	const T* current = begin;
	while (current != (end-1)) {
		
		//Print values with a comma
		std::cout << *current << ", ";
		++current;
	}

	//Print the last value without a comma
	std::cout << *current << std::endl;
}

/******************************************************************************/
/*!
  \fn template <typename T1, typename T2> bool equal(const T1* begin, const T1* end, const T2* begin2)

  \brief
	Checks if the two ranges have the same values (equal). If the first range is empty, automatically returns false.
	Ranges need not be of the exact same type (can be of similar type).

  \param begin
	Pointer to the beginning of the first range

  \param end
	Pointer to the end of the first range

  \param begin2
	Pointer to the beginning of the second range

  \return bool
    If they match, return true, else return false.

*/
/******************************************************************************/
template <typename T1, typename T2> 
bool equal(const T1* begin, const T1* end, const T2* begin2) {

	//Check for empty range
	if (begin == end) {
		return false;
	}

	//Progress through the range
	const T1* current = begin;
	const T2* current2 = begin2;
	while (current != end) {

		//If there is ever a point in which the values do not match, the two ranges are not equal.
		if (*current != *current2) {
			return false;
		}

		++current;
		++current2;
	}

	return true;
}


/******************************************************************************/
/*!
  \fn template <typename T> void fill(T* begin, const T* end, const T& value)

  \brief
	Fills the range with the given item. If there are any previous values already in the range, 
	they will be overriden with the value of the given item

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

  \param value
	Item to fill the range.

*/
/******************************************************************************/
template <typename T> 
void fill(T* begin, const T* end, const T& value) {
	
	//Check for empty range
	if (begin == end) {
		return;
	}

	//Progress through the range
	T* current = begin;
	while (current != end) {

		//Change the value of all items in the range to the given value
		*(current) = value;
		++current;
	}
}

/******************************************************************************/
/*!
  \fn template <typename T> T* find(const T* begin, const T* end, const T& check)

  \brief
	Checks for the first occurence of the given item in the range and returns a pointer to it.
	If no such item is found, the pointer to the end of the range will be returned instead.

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

  \param check
	Reference of the item to be found

  \return
	Returns Pointer to the first occurence of the item found in the range 
*/
/******************************************************************************/
template <typename T>
T* find(const T* begin, const T* end, const T& check) {

	//Check if the range is empty
	if (begin == end) {
		return const_cast<T*>(end);
	}

	//Progress through the range
	T* current = const_cast<T*>(begin);
	while (current != end) {

		//If the item is found, return it as a pointer
		if (*current == check) {
			return current;
		}
		++current;
	}

	return const_cast<T*>(end);
}


/******************************************************************************/
/*!
  \fn template <typename T> T* max_element(const T* begin, const T* end)

  \brief
	Checks for the item with the largest value in the range and returns a pointer to it
	If the range is empty, it returns a nullptr instead. 

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

  \return
	Returns Pointer to the item with the largest value in the range
*/
/******************************************************************************/
template <typename T> 
T* max_element(const T* begin, const T* end) {

	//Check if range is empty
	if (begin == end) {
		return const_cast<T*>(begin);
	}
	
	//Progress through the list.
	T* max = const_cast<T*>(begin);
	T* current = const_cast<T*>(begin + 1);
	while (current != end) {

		//If the current value is larger than the previous maximum, set that as the max.
		if (*current > *max) {
			max = current;
		}

		current += 1;
	}

	return max;
}

/******************************************************************************/
/*!
  \fn template <typename T> T* min_element(const T* begin, const T* end)

  \brief
	Checks for the item with the smallest value in the range and returns a pointer to it
	If the range is empty, it returns a nullptr instead. 

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

  \return
	Returns Pointer to the item with the smallest value in the range
*/
/******************************************************************************/
template <typename T> 
T* min_element(const T* begin, const T* end) {

	//Check if range is empty
	if (begin == end) {
		return const_cast<T*>(begin);
	}

	//Progress through the list
	T* min = const_cast<T*>(begin);
	T* current = const_cast<T*>(begin + 1);
	while (current != end) {

		//If the current value is smaller than the previous minimum, set that as min.
		if (*current < *min) {
			min = current;
		}

		current += 1;
	}

	return min;
}

/******************************************************************************/
/*!
  \fn template <typename T> T* remove(T* begin, const T* end, const T& check)

  \brief
	Checks for a certain item in the range, if any are found, they will be removed.

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

  \param check
	Reference to the item to be removed from the range.

  \return
    Returns Pointer to the new end (ignore everything after the new end)
*/
/******************************************************************************/
template <typename T>
T* remove(T* begin, const T* end, const T& check)
{
	//Check if the range is empty.
	if (begin == end) {
		return const_cast<T*>(end);
	}

	
	int shift = 0;

	//Progress through the range
	T* current = begin;
	while (current != end) {

		//If the item to be deleted is found, add one to the shift counter.
		if (*current == check) {
			++shift;
		}
		else {
			//Shift the elements to the front of the range based off the number of deletes. 
			//This will override any values that need to be deleted. As well as decrease the size of the range.
			*(current - shift) = *current;
		}
		++current;
	}

	//Shift the end of the range to the front and return it.
	return (const_cast<T*>(end) - shift);
}

/******************************************************************************/
/*!
  \fn template <typename T> void replace(T* begin, const T* end, const T& check, const T& replace)

  \brief
	Checks for a certain item in the range, if any are found, they will be replaced by another given item.

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range

  \param check
	Reference to the item to be removed from the range.

  \param replace
	Reference to the item to replace the removed.
*/
/******************************************************************************/
template <typename T> 
void replace(T* begin, const T* end, const T& check, const T& replace) {
	
	//Check if the range is empty
	if (begin == end) {
		return;
	}

	//Progress through the list
	T* current = begin;
	while (current != end) {

		//If the item to be replace is found, replace it with the new item.
		if (*current == check) {
			*current = replace;
		}

		++current;
	} 
}

/******************************************************************************/
/*!
  \fn template <typename T> T sum(const T* begin, const T* end)

  \brief
	Counts the total sum of the values in the ranges

  \param begin
	Pointer to the beginning of the range

  \param end
	Pointer to the end of the range 

  \return
    Sum of all the values in the range (Sum is the type of the values)
*/
/******************************************************************************/
template <typename T> 
T sum(const T* begin, const T* end) {
	
	//Check if the range is empty
	if (begin == end){
		return 0;
	}
	
	// Progress through the list
	const T* current = begin + 1;
	T sum = *begin;
	while (current != end) {

		//Add each value to the sum
		sum += *current;

		++current;
	}

	return sum;
}

/******************************************************************************/
/*!
  \fn void template <typename T> void swap(T &left, T &right)

  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/******************************************************************************/
/*!
  \fn template <typename T> void swap_ranges(T* begin, const T* end, T* begin2)

  \brief
	Swaps the values of the two ranges. Ranges should be the same type to avoid loss of precision.

  \param begin
	Pointer to the beginning of the first range.

  \param end
	Pointer to the end of the first range.

  \param begin2
	Pointer to the beginning of the second range. 
*/
/******************************************************************************/
template <typename T> 
void swap_ranges(T* begin, const T* end, T* begin2) {
	
	//Check if the range is empty
	if (begin == end) {
		return;
	}

	//Progress through the range
	T* current = begin;
	T* current2 = begin2;
	while (current != end) {
		//Swap each item in the range with its counterpart.
		swap(*current, *current2);

		++current;
		++current2;
	}
}
