/******************************************************************************/
/*!
\file Functions.cpp
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 06
\date 08/07/2019
\brief
Function template
*/
/******************************************************************************/
#include <iostream>
#include "Functions.h"
/******************************************************************************/
/*!
    \brief
    Copies a range
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
   \param output
    To store copied range.
    
    \return
    The copied range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T2 copy(T1 first, T1 last, T2 output)
{
    while (first!=last)
    {
        *output=*first;
        first++;
        output++;
    }
    return output;
}

/******************************************************************************/
/*!
    \brief
    Count the number of times a value has appeared.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \param val
    The value to count.
    
    \return
    The count.
*/
/******************************************************************************/
template <typename T1, typename T2> 
int count(T1 first, T1 last, const T2& val)
{
    int counter=0;
    while (first!=last)
    {
        if (*first==val)
        {
            counter++;
        }
        first++;
    }
    return counter;
}

/******************************************************************************/
/*!
    \brief
    To display the values.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
*/
/******************************************************************************/
template <typename T>
void display (T first, T last)
{
    if(first == last)
    {
        std::cout<< std::endl;
        return;
    }
    else
    {
        std::cout << *first;
        first++;
        while (first!=last)
        {
            std::cout <<", "<<*first;
            first++;
        }
    }
    std::cout <<std::endl;
}

/******************************************************************************/
/*!
    \brief
    Compares the 2 ranges.

    \param first
    The first number in first range.
  
    \param last
    The last number in first range.
    
    \param second
    The second range.
    
    \return
    True or false.
*/
/******************************************************************************/
template <typename T1, typename T2> 
bool equal(T1 first, T1 last, T2 second)
{
    while (first!=last)
    {
        if(*first!=*second)
        {
            return false;
        }
        first++;
        second++;
    }
    return true;  
}

/******************************************************************************/
/*!
    \brief
    Fill range with value given.
    
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \param val
    The value to fill in range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void fill(T1 first, T1 last, const T2& val)
{
    while (first!=last)
    {
        *first =val;
        first++;
    }
}

/******************************************************************************/
/*!
    \brief
    Find the position of the value given.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \param val
    The value to find.
    
    \return
    The position found.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 find(T1 first, T1 last, const T2& val)
{
    while (first!=last)
    {
        if (*first ==val)
        {
            return first;
        }
        first++;
    }
    return first;
}

/******************************************************************************/
/*!
    \brief
    Find maximum value in range.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \return
    The maximum value.
*/
/******************************************************************************/
template <typename T> 
T max_element(T first, T last)
{
    T temp = first;
    while (first!=last)
    {
        if(*first> *temp)
        {
            temp = first;
        }
        first++;
    }
    return temp;
}

/******************************************************************************/
/*!
    \brief
    Find minimum value in range.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \return
    The minimum value.
*/
/******************************************************************************/
template <typename T> 
T min_element(T first, T last)
{
    T temp = first;
    while (first!=last)
    {
        if(*first< *temp)
        {
            temp = first;
        }
        first++;
    }
    return temp;
}

/******************************************************************************/
/*!
    \brief
    Remove given value in range.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \param val
    The value to be removed.
    
    \return
    The new range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 remove(T1 first, T1 last, const T2& val)
{
    T1 temp = first;
    while (first!=last)
    {
        if (*first!=val)
        {
            *temp = *first;
            temp++;
        }
        first++;
    }
    return temp;
}

/******************************************************************************/
/*!
    \brief
    Replace given value in range.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \param old_val
    The value to be replaced.
    
    \param new_val
    The value to be replaced with.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void replace(T1 first, T1 last, const T2& old_val, const T2& new_val)
{
    while (first!=last)
    {
        if (*first==old_val)
        {
            *first = new_val;
        }
        first++;
    }
}

/******************************************************************************/
/*!
    \brief
    Add all values.
  
    \param first
    The first number in range.
  
    \param last
    The last number in range.
    
    \return
    The total sum.
*/
/******************************************************************************/
template <typename T>
int sum(const T* first, const T* last)
{
    T total =0;
    while (first!=last)
    {
        total += *first;
        first++;
    }
    return total;
}

/******************************************************************************/
/*!
    \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
    \param left
    The first object to swap.
  
    \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
    T temp(right); // need a temporary copy
    right = left;
    left = temp;
}

/******************************************************************************/
/*!
  \brief
    Swaps two ranges.
  
  \param first
    The first number in first range.
  
  \param last
    The last number in first range.
    
  \param second
    The first number in second range.
    
  \return
    The second range.
*/
/******************************************************************************/
template <typename T1, typename T2>
T2 swap_ranges(T1 first, T1 last, T2 second)
{
    while (first!=last)
    {
        swap(*first,*second);
        first++;
        second++;
    }
    return second;
}
