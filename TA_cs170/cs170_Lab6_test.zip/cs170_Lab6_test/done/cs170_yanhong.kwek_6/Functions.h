/******************************************************************************/
/*!
\file Functions.h
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 06
\date 08/07/2019
\brief
Header file for a function template.
*/
/******************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
    template <typename T1, typename T2> T2 copy(T1 first, T1 last, T2 output);
    template <typename T1, typename T2> int count(T1 first, T1 last, const T2& val);
    template <typename T> void display (T first, T last);
    template <typename T1, typename T2> bool equal(T1 first, T1 last, T2 second);
    template <typename T1, typename T2> void fill(T1 first, T1 last, const T2& val);
    template <typename T1, typename T2> T1 find(T1 first, T1 last, const T2& val);
    template <typename T> T max_element(T first, T last);
    template <typename T> T min_element(T first, T last);
    template <typename T1, typename T2> T1 remove(T1 first, T1 last, const T2& val);
    template <typename T1, typename T2> void replace(T1 first, T1 last, const T2& old_value, const T2& new_value);
    template <typename T> int sum(const T* first, const T* last);
    template <typename T> void swap(T &left, T &right);
    template <typename T1, typename T2> T2 swap_ranges(T1 first1, T1 last, T2 first2);
    #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
