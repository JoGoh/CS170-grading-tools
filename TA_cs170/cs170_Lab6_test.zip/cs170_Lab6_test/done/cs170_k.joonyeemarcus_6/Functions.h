/******************************************************************************/
/*!
\file Functions.h
\author Koh Joon Yee Marcus
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: CS170
\par Assignment : 06
\date 10/03/2019
\brief
This file contains the implementation of the following funtion templates for
 Lab 06
Function templates include:
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges


Hours spent on this assignment: 3 <br>
Specific portions that gave you the most trouble: Remove in one pass. <br>
*/
/******************************************************************************/



//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  
  template <typename T>
  T* copy(const T* begin , const T* end , T* begin2);
  
  template <typename T> 
  int count(const T *begin, const T *end, const T& value);
  
  template <typename T> 
  void display(const T* begin , const T*end);
  
  template<typename T1, typename T2>
  bool equal(T1* begin , T1* end, T2* begin2);
  
  template <typename T1 , typename T2>
  void fill(T1 begin , T1 end, const T2& value);
  
  template<typename T1,  typename T2>
  T1 find( T1  begin ,  T1 end, const T2& item);
  
  // template<typename T> 
  // const T* find(const T *  begin , const T* end, const T& item);
  
  template <typename T>
  T* max_element(T* begin , T* end);
  
  // template <typename T>
  // const T* max_element(const T*begin , const T* end);
  
  template<typename T>
  T* min_element(T* begin, T* end);
  
  // template<typename T>
  // const T* min_element(const  T* begin, const T*end);
  
  template <typename T>
  T* remove(T* begin , T* end , T value);
  
  template<typename T>
  void replace(T* begin , T* end, T oldvalue, T newvalue);
  
  template<typename T>
  T sum(T* begin, T* end);
  
  template <typename T> void swap(T &left, T &right);
  
  template <typename T> 
  void swap_ranges(T* begin, T*end , T* begin2);
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
