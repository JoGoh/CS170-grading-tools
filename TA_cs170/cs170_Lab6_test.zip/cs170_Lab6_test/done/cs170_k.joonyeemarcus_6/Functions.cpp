

/******************************************************************************/
/*!
\file functions.cpp
\author Koh Joon Yee Marcus
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: CS170
\par Assignment : 06
\date 10/03/2019
\brief
This file contains the implementation of the following funtion templates for
 Lab 06
Function templates include:
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges


Hours spent on this assignment: 3 <br>
Specific portions that gave you the most trouble: Remove in one pass. <br>
*/
/******************************************************************************/

#include <iostream> // cout, endl




/**
 *  \brief This function template copies one array into another using the range
 *  of the first one.
 *
 *  
 *  \param [in] begin -  the beginning range of the array to be copied from.
 *  \param [in] end - the ending range of the array to be copied from.
 *  \param [in] begin2 - the beginning of the array that is to be copied into.
 *  \return Returns begin2 which is the copied array.
 *  
 */
template <typename T>
T* copy(const T* begin , const T* end , T* begin2)
{
	
	while(begin !=end)
	{
		*begin2 = *begin;
		++begin2; ++begin;
	}
	return begin2;
}


/**
 *  \brief This function template counts the number of items that have the
 *  	given value in the array and returns the count.
 *  
 *  \param [in] begin - the beginning range of the array.
 *  \param [in] end - the ending range of the array.
 *  \param [in] value - the value to search the array for and count.
 *  \return Return the number of items(int) with the specified value.
 *  
 */
template <typename T> 
int count(const T *begin, const T *end, const T& value)
{
	int counter= 0;
	while(begin != end)
	{
		if(*begin == value)
		{
			counter++;
		}
		++begin;
	}
	return counter;
}


/**
 *  \brief Thi function simply display the entire array.
 *  
 *  \param [in] begin - the beginning range of the array
 *  \param [in] end - the ending range of the array
 *  \return void
 */
template <typename T> 
void display(const T* begin , const T*end)
{
	while(begin != end)
	{
		//Check if next iteration is already the end
		if(begin+1 == end)
		{
			//To end the display format line
			std::cout << *begin;
			++begin; //Move to next
		}
		else
		{
			//To match output format
			std::cout<< *begin << ", ";
			++begin; //Move to next
		}
	}
	//end line
	std::cout << std::endl;
}

/**
 *  \brief Since this function compares 2 arrays of 2 different types the
 *  template has 2 different parameters T1 and T2
 *  
 *  \param [in] begin - the beginning range of the array.
 *  \param [in] end - the ending range of the array.
 *  \param [in] begin2 the starting of the second array to be compared to.
 *  \return Return true if the arrays are equal, false if not.
 *  
 */
template<typename T1, typename T2>
bool equal(T1* begin , T1* end, T2* begin2)
{
	while(begin != end)
	{
		if(*begin != *begin2)
			return false;
		++begin; ++begin2;
	}
	
	return true;
	
}

/**
 *  \brief This function template simply fills the entire array with the
 *  specified value.
 *  
 *  \param [in] begin - the beginning range of the array.
 *  \param [in] end - the ending range of the array.
 *  \param [in] value - the value to fill the array with.
 *  \return void
 */
template <typename T1 , typename T2>
void fill(T1 begin , T1 end, const T2& value)
{
	while(begin != end)
	{
		*begin = value;
		++begin;
	}
}

/**
 *  \brief Find the first item with the specified value.
 *  
 *  \param [in] begin - the beginning range of the array.
 *  \param [in] end - the ending range of the array.
 *  \param [in] item - the item to search the array for.
 *  \return Return a pointer to type T which represents the position where 
 *  the item was found.
 *  
 */
template<typename T1 , typename T2>
T1 find( T1  begin ,  T1 end, const T2& item)
{
	while(begin != end)
	{
		if(*begin == item)
		{
			return begin;
		}
		++begin;
	}
	return end;
}

/**
 *  \brief This is a second template for the find function that allows the
 *  passing and returning of const parameters
 *  
 *  \param [in] begin - the read-only beginning range of the array.
 *  \param [in] end - the read-only ending range of the array.
 *  \param [in] item - the item to search the array for. It is of read-only
 *  type.
 *  \return Return a read-only pointer of the templated type that represents
 *  the position at which the item was found in the array.
 *  
 *  \details More details
 */
// template<typename T>
// const T* find(const T *  begin , const T* end, const T& item)
// {
	// while(begin != end)
	// {
		// if(*begin == item)
		// {
			// return begin;
		// }
		// ++begin;
	// }
	// return end;
// }



/**
 *  \brief This function template iterates through the entire array and
 *  returns the element of the array with the largest value.
 *  
 *  \param [in] begin - the beginning range of the array.
 *  \param [in] end - the ending range of the array.
 *  \return Return a pointer to the element that has the largest value in the
 *  array.
 *  
 *  \details More details
 */
template <typename T>
T* max_element(T*begin , T* end)
{
	T* temp = begin;
	while(begin != end)
	{
		if(*begin > *temp)
		{
			temp = begin;
		}
		begin++;
	}
	return temp;
}



/**
 *  \brief This function template iterates through the entire array and
 *  returns the element of the array with the smallest value.
 *  
 *  \param [in] begin - the beginning range of the array.
 *  \param [in] end - the ending range of the array.
 *  \return Return a pointer to the element that has the smallest value
 *  in the array.
 *  
 *  \details More details
 */
template<typename T>
T* min_element(T* begin, T*end)
{
	T* temp = begin;
	while(begin!= end)
	{
		if(*begin < *temp)
		{
			temp = begin;
		}
		begin++;
	}
	return temp;
}


/**
 *  \brief This function template iterates through the entire array and
 *  removes all items of the specified value.
 *  
 *  \param [in] begin - the starting range of the array
 *  \param [in] end -the end range of the array
 *  \param [in] value the value to remove from the array.
 *  \return Return a pointer that represents the new end of the array.
 *  
 *  \details Using 2 pointers, keep one pointer as the newend
 */
template <typename T>
T* remove(T* begin , T* end , T value)
{
	T* temp = begin;
	T* newend = begin;
	
	while(temp != end)
	{
		if(*temp == value)
		{
			++temp;
		}
		else
		{
			newend++; temp++; //move both pointers forward
		}
		*newend = *temp;
	}
	return newend; //return the new end
}


/**
 *  \brief Replace the items of the array with a specified value with a new
 *  value given.
 *  
 *  \param [in] begin - the start of the array
 *  \param [in] end - the end of the array
 *  \param [in] oldvalue - the value to search for and replace with newvalue
 *  \param [in] newvalue - the value to replace with.
 *  \return void
 *  
 */
template<typename T>
void replace(T* begin , T* end, T oldvalue, T newvalue)
{
	while(begin!=end)
	{
		if(*begin == oldvalue)
		{
			*begin = newvalue;
		}
		begin++;
	}
}

/**
 *  \brief This funtion template adds the value of all the elements in the
 *  array and returns the sum of all the elements.
 *  
 *  \param [in] begin -the starting range of the array
 *  \param [in] end - the ending range of the array.
 *  \return the sum of all the elements in the templated type.
 *  
 */
template<typename T>
T sum(T* begin, T* end)
{
	T sumValue = 0;
	
	while(begin != end)
	{
		sumValue+= *begin;
		begin++;
	}
	return sumValue;
}


/*!
  \brief
	Swaps two objects. There is no return value but the two objects are
	swapped in place.

  \param left
	The first object to swap.

  \param right
	The second object to swap.
*/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/**
 *  \brief Swaps 2 arrays with each other
 *  
 *  \param [in] begin - the start range of the array
 *  \param [in] end - the ending range of the array
 *  \param [in] begin2 - the start of the second array
 *  \return void
 *  
 */
template <typename T>
void swap_ranges(T* begin, T*end , T* begin2)
{
	T* temp = begin;
	T* temp2 = begin2;
	T tempVal = 0;
	while(temp != end)
	{
		tempVal = *temp;
		*temp = *temp2;
		*temp2 = tempVal;
		++temp, ++temp2;
	}	
}


