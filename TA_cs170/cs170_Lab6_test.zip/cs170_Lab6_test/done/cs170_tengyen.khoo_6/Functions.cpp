/******************************************************************************/
/*!
\file Functions.cpp
\author Khoo Teng Yen
\par email: tengyen.khoo\@digipen.edu
\par DigiPen login: tengyen.khoo
\par Course: CS170
\par Lab 06
\date 04/07/2019
\brief
This file contains the definitions of algorithmic function templates that work
with ranges. It has a basic function that displays all values of all elements in
a range. There are also functions that copy elements from a range into another,
swap the element values between both ranges, or just simply swap the values of
two given elements. Next, some of these functions also perform the summing up of
all element values in a range, as well as the counting of the number of elements
that hold a specified value. In addition, there is a comparison function that
checks if two given ranges are equal to each other. Some "search-related"
functions are able to look through ranges and find an element of a specified
value, or find the largest or smallest element value in a range. Lastly, the
remaining functions are able to fill a range with a given value, replace all
specified values with a new value, and remove elements holding a specified
value from a range.

Functions include:
copy()
count()
display()
equal()
fill()
find()
max_element()
min_element()
remove()
replace()
sum()
swap()
swap_ranges()
*/
/******************************************************************************/
// \cond
#include <iostream> // cout, endl
// \endcond

/******************************************************************************/
/*!
  \brief
    Copies an array to another array.
  
  \param begin1
    The start of the first array.
  
  \param end1
    The end of the first array.
  
  \param begin2
    The start of the second array.
  
  \return
    Returns the reference to the last element in the second array.
*/
/******************************************************************************/
template <typename T1, typename T2>
T2 copy(T1 begin1, const T1 &end1, T2 begin2)
{
  while(begin1 != end1)
  {
    *begin2 = *begin1;
    ++begin1;
    ++begin2;
  }
  return begin2;
}

/******************************************************************************/
/*!
  \brief
    Counts a specified number of elements in the array.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
    
  \param num
    The specified number to be found.
  
  \return
    the count of the specified value.
*/
/******************************************************************************/
template <typename T1, typename T2>
int count(T1 begin, const T1 &end, const T2 &num)
{
  int size = 0;
  
  while(begin != end)
  {
    if(*begin == num)
      ++size;
    ++begin;
  }
  return size;
}

/******************************************************************************/
/*!
  \brief
    Displays the array
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
*/
/******************************************************************************/
template <typename T>
void display(T begin, const T &end)
{
  if(begin != end)
  {
    std::cout << *(begin++);
    while(begin != end)
    {
      std::cout << ", " << *(begin++);
    }
    std::cout << std::endl;
  }
  else
    std::cout << std::endl;
}

/******************************************************************************/
/*!
  \brief
    Checks if the two arrays are equal.
  
  \param begin1
    The start of the first array.
  
  \param end1
    The end of the first array.
  
  \param begin2
    The start of the second array.
  
  \return
    Returns true if both the array is equal otherwise false.
*/
/******************************************************************************/
template <typename T1, typename T2>
bool equal(T1 begin1, const T1 &end1, T2 begin2)
{
  bool isequal = true;
  
  while(begin1 != end1)
  {
    if(*begin1 != *begin2)
      isequal = false;
    ++begin1;
    ++begin2;
  }
  
  return isequal;
}

/******************************************************************************/
/*!
  \brief
    Fills the array with the specified number.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
  
  \param num
    The number that will fill the array.
  
*/
/******************************************************************************/
template <typename T1, typename T2>
void fill(T1 begin, const T1 &end, const T2 &num)
{
  while(begin != end)
  {
    *begin = num;
    ++begin;
  }
}

/******************************************************************************/
/*!
  \brief
    Finds the specified number.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
  
  \param num
    The specified number to be found.
  
  \return
    Returns a reference to the first instance of the specified number that 
    is found.
*/
/******************************************************************************/
template <typename T1, typename T2>
T1 find(T1 begin, const T1 &end, const T2 &num)
{
  while(begin != end)
  {
    if(*begin == num)
      return begin;
    ++begin;
  }
  return end;
}

/******************************************************************************/
/*!
  \brief
    Finds the largest number in the array.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
  
  \return
    Returns the largest number in the array.
*/
/******************************************************************************/
template <typename T>
T max_element(T begin, const T &end)
{
  T compare(begin);
  
  while(begin != end)
  {
    if(*compare < *begin)
      compare = begin;
    ++begin;
  }
  return compare;
}

/******************************************************************************/
/*!
  \brief
    Finds the smallest number in the array.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
  
  \return
    Returns the smallest number in the array.
*/
/******************************************************************************/
template <typename T>
T min_element(T begin, const T &end)
{
  T compare(begin);
  
  while(begin != end)
  {
    if(*compare > *begin)
      compare = begin;
    ++begin;
  }
  return compare;
}

/******************************************************************************/
/*!
  \brief
    Removes the specified number from the array.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
  
  \param num
    The number to be removed from the array.
  
  \return
    Returns the new end after removing the specified number in the array.
*/
/******************************************************************************/
template <typename T1, typename T2>
T1 remove(T1 begin, const T1 &end, T2 &num)
{
  T1 temp(begin);
  
  while(temp != end)
  {
    if(*temp != num)
    {
      *begin = *temp;
      ++begin;
    }
    ++temp;
  }
  
  return begin;
}

/******************************************************************************/
/*!
  \brief
    Replace the an old specified number with a new specified number.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
  
  \param oldnum
    The old number that will be replaced by the new number from the array.
  
  \param newnum
    The new number that will be replacing the old number from the array.
*/
/******************************************************************************/
template <typename T1, typename T2>
void replace(T1 begin, const T1 &end, const T2 &oldnum, const T2 &newnum)
{
  while(begin != end)
  {
    if(*begin == oldnum)
      *begin = newnum;
    ++begin;
  }
}

/******************************************************************************/
/*!
  \brief
    Caculates the total sum of the array.
  
  \param begin
    The start of the array.
  
  \param end
    The end of the array.
  
  \return
    Returns the total sum of the array.
*/
/******************************************************************************/
template <typename T>
auto sum(T begin, const T &end)
{
  auto total = decltype(*T() * 0)();
  
  while(begin != end)
  {
    total += *(begin++);
  }
  
  return total;
}

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/******************************************************************************/
/*!
  \brief
    Swaps two array within the given range. There is no return value but
    the two objects are swapped in place.
  
  \param begin1
    The start of the first array.
  
  \param end1
    The end of the first array.
  
  \param begin2
    The start of the second array.
*/
/******************************************************************************/
template <typename T1, typename T2>
void swap_ranges(T1 begin1, const T1 &end1, T2 begin2)
{
  while(begin1 != end1)
  {
    swap(*begin1, *begin2);
    ++begin1;
    ++begin2;
  }
}