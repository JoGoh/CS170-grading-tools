/*****************************************************************************/
/*! 
\file   Functions.cpp 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 06
\date   08/07/2019
\brief     
This program contains the various function templates that will perform 
actions such as copying, finding, counting, displaying, filling, etc.
*/ 
/*****************************************************************************/

#include <iostream> // cout, endl

/*****************************************************************************/

/*****************************************************************************/
/*!

\brief
Copies all the elements in the range defined by first into the new range
of elements defined by result until it reaches the end of the range 
defined by end. 

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\param result
The beginning of the new range of elements

\return
Returns the end of the new range of elements

*/ 
/*****************************************************************************/
template <typename T1, typename T2> 
T2 copy(T1 first, T1 end, T2 result)
{
  while(first != end) // Loop until end of range
  {
    *result = *first; // Copy element of old range into element of new range
    ++first;  // Move to the next element in the old range of elements
    ++result; // Move to the next element in the new range of elements
  }
  return result; // Return the end of the new range of elements
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and increments a counter 
each time it finds an element equal to value.

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\param value
The value to compare the elements with

\return
Returns the number of elements that satisfies the condition

*/ 
/*****************************************************************************/
template <typename T1, typename T2> 
T2 count(T1 first, T1 end, const T2& value)
{
  T2 counter = 0; // Counter to track number of times value is found
  
  while(first != end) // Loop until end of range
  {
    if(*first == value) // If element in range is the same as the value
      ++counter; // Increment counter
    
    ++first; // Move to the next element in the range of elements
  }
  return counter; // Return total count of elements found
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and displays each element 
in the range.

\param first
The beginning of the range of elements

\param end
The end of the range of elements

*/ 
/*****************************************************************************/
template <typename T>
void display(T first, T end)
{
  while(first != end) // Loop until end of range
  {
    if(first+1 != end) // If the element is not the last element
      std::cout << *first << ", "; // Print the correct format
    else
      std::cout << *first; // If it's the last element, don't print the comma
    
    first++; // Move to the next element in the range of elements
  }
  std::cout << std::endl; // Print new line
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and compares itself with the 
elements in the second range of elements.

\param left
The beginning of the range of elements

\param end
The end of the range of elements

\param right
The beginning of the second range of elements

\return
Returns true if the elements in the two ranges are equal. Otherwise, false.

*/ 
/*****************************************************************************/
template <typename T1, typename T2> 
bool equal(T1 left, T1 end, T2 right)
{
  while(left != end) // Loop until end of range
  {
    if(*left != *right) // If left range doesn't match right range
      return false; // The two range of elements are not equal
    
    ++left; // Move to the next element in the left range of elements
    ++right; // Move to the next element in the right range of elements
  }
  return true; // The two range of elements are equal
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and compares the element to the
specified value. 

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\param value
The value to compare the elements with

\return
Returns the position of the element containing the value if it's found.
Otherwise, it returns the element after the last element in the range. 

*/ 
/*****************************************************************************/
template <typename T1, typename T2> 
T1 find(T1 first, T1 end, const T2& value)
{
  while(first != end) // Loop until end of range
  {
    if(*first == value) // If element in the range matches the value
      return first; // Return the position of the element 

    first++; // Move to the next element in the range of elements
  }
  return end; // Element not found, return the end of range
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and changes them to the 
specified value. 

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\param value
The value to change the elements with

*/ 
/*****************************************************************************/
template <typename T1, typename T2> 
void fill(T1 first, T1 end, const T2& value)
{
  while(first != end) // Loop until end of range
  {
    *first = value; // Fill in the element of the range with value
    ++first; // Move to the next element in the range of elements
  }
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and finds the largest element
available in the range. 

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\return
Returns the position of the largest element in the range.

*/ 
/*****************************************************************************/
template <typename T> 
T max_element(T first, T end)
{
  if(first == end) // If there's only 1 element
    return end; // Nothing to compare, return the element
  
  T largest = first; // Setting largest to be the first element
  ++first; // Move to the next element in the range of elements
  
  while(first != end) // Loop until end of range
  {
    if(*first > *largest) // If a larger than current element exists
      largest = first; // Replace it as the largest
    
    ++first; // Move to the next element in the range of elements
  }
  return largest; // Return the position of the largest element
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and finds the smallest element
available in the range. 

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\return
Returns the position of the smallest element in the range.

*/ 
/*****************************************************************************/
template <typename T> 
T min_element(T first, T end)
{
  if(first == end) // If there's only 1 element
    return end; // Nothing to compare, return the element
  
  T smallest = first; // Setting smallest to be the first element
  ++first; // Move to the next element in the range of elements
  
  while(first != end) // Loop until end of range
  {
    if(*first < *smallest) // If a smaller than current element exists
      smallest = first; // Replace it as the smallest
    
    ++first; // Move to the next element in the range of elements
  }
  return smallest; // Return the position of the smallest element
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and removes the elements
that matches the specified value.

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\param value
The value to compare the elements with

\return
Returns the position of the new end of the range of elements.

*/ 
/*****************************************************************************/
template <typename T1, typename T2>
T1 remove(T1 first, T1 end, const T2& value)
{
  T1 result = first; // Pointer to the beginning of the range of elements
  
  while(first != end) // Loop until end of range
  {
    if(*first != value) // If element doesn't match value
    {
      *result = *first; // Replace element with value that didn't match
      ++result; // Move to the next element in the new range of elements
    }
    ++first; // Move to the next element in the range of elements
  }
  return result; // Returns the position of the new end of range
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and finds the element that
matches the oldvalue and replaces it with the newvalue. 

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\param oldvalue
The value of elements to replace

\param newvalue
The value to replace the elmements with

*/ 
/*****************************************************************************/
template <typename T1, typename T2> 
void replace(T1 first, T1 end, const T2& oldvalue, const T2& newvalue)
{
  while(first != end) // Loop until end of range
  {
    if(*first == oldvalue) // If element matches the value
      *first = newvalue; // Replace the element with the new value
    
    ++first; // Move to the next element in the range of elements
  }
}

/*****************************************************************************/
/*!

\brief
Goes through all the elements in the range and computes the total sum
of all the elements in the range. 

\param first
The beginning of the range of elements

\param end
The end of the range of elements

\return
Returns total sum of elements in the range.
*/ 
/*****************************************************************************/
template <typename T>
int sum(T first, T end)
{
  int total = 0; // To store the total sum of all the elements
  
  while(first != end) // Loop until end of range
  {
    total += *first; // Update the total sum
    ++first; // Move to the next element in the range of elements
  }
  return total; // Return the total sum of elements
}

/******************************************************************************/
/*!

\brief
Swaps two objects. There is no return value but the two objects are
swapped in place.
  
\param left
The first object to swap
  
\param right
The second object to swap

*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left; // Swap right with left 
  left = temp; // Put temporary copy into left
}

/******************************************************************************/
/*!

\brief
Goes through all the elements in the range and swaps the elements in first
with the elements in result until first reaches the end of the range.
  
\param first
The beginning of the range of elements

\param end
The end of the range of elements

\param result
The beginning of the other range of elements

*/
/******************************************************************************/
template <typename T1, typename T2> 
void swap_ranges(T1 first, T1 end, T2 result)
{
  while(first != end) // Loop until end of range
  {
    swap(*first, *result); // Swap elements in the old and the new range
    ++first; // Move to the next element in the old range of elements
    ++result; // Move to the next element in the new range of elements
  }
}  
