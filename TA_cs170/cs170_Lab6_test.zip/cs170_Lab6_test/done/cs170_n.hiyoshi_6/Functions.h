/*****************************************************************************/
/*! 
\file   Functions.h 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 06
\date   08/07/2019
\brief     
This file contains the various function templates declarations for the 
Function.cpp file that will perform actions such as copying, finding, 
counting, displaying, filling, etc.
*/ 
/*****************************************************************************/

//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  template <typename T1, typename T2>
  T2 copy(T1 first, T1 end, T2 result);
  
  template <typename T1, typename T2>
  T2 count(T1 first, T1 end, const T2& value);
  
  template <typename T>
  void display(T first, T end);
  
  template <typename T1, typename T2>
  bool equal(T1 left, T1 end, T2 right);
  
  template <typename T1, typename T2>
  T1 find(T1 first, T1 end, const T2& value);
  
  template <typename T1, typename T2> 
  void fill(T1 first, T1 end, const T2& value);
  
  template <typename T>
  T max_element(T first, T end);
  
  template <typename T>
  T min_element(T first, T end);
  
  template <typename T1, typename T2>
  T1 remove(T1 first, T1 end, const T2& value);
  
  template <typename T1, typename T2>
  void replace(T1 first, T1 end, const T2& oldvalue,const T2& newvalue);
  
  template <typename T>
  int sum(T first, T end);
  
  template <typename T>
  void swap(T &left, T &right);
  
  template <typename T1, typename T2> 
  void swap_ranges(T1 first, T1 end, T2 result);

  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
