#include <iostream> // cout, endl

/******************************************************************************/
/*!
  \brief
	to copy the whole list 1 to list 2
	
  \param i1start
	the first element in the first list
  
  \param i1end
	the last element in the first list
	
  \param i2
	the first element in the second list
*/
/******************************************************************************/
	template <typename T1, typename T2> T2 copy(T1 i1start, const T1 i1end, T2 i2)
	{
		T1 l1 = i1start;
		T2 l2 = i2;
		
		while(l1 != i1end)
		{
			*l2 = *l1;
			++l1;
			++l2;
		}
		return l2;
	}
/******************************************************************************/
/*!
  \brief
	to check how many element have the value equal to num
  
  \param i1start
	the first element in the first list
  
  \param i1end
	the last element in the first list
	
  \param num
	a given value
*/
/******************************************************************************/	
	template <typename T1, typename T2> T2 count(T1 i1start, T1 i1end, T2 num)
	{
		T1 l1 = i1start;
		T2 number = num;
		T2 counter = 0;
		
		while(l1 != i1end)
		{
			if(*l1 == num)
			{
				++counter;
			}
			++l1;
		}
		return counter;
	}
/******************************************************************************/
/*!
  \brief
	print out every element in the list
      
  \param start
	first element in the list
	
  \param end
	last element in the list
*/
/******************************************************************************/	
	template <typename T> void display(T start, T end)
	{
		T tmp = start;
		T finish = end - 1;
		
		while(tmp != end)
		{
			if(tmp == finish)
			{
				std::cout << *tmp;
			}
			else
			{
				std::cout << *tmp << ", ";
			}
			++tmp;
		}
		
		std::cout << std::endl;
	}
/******************************************************************************/
/*!
  \brief
	check if list 1 is same as list 2
      
  \param i1start
	the first element in the first list
  
  \param i1end
	the last element in the first list
	
  \param i2
	the first element in the second list
*/
/******************************************************************************/	
	template <typename T1, typename T2> bool equal(T1 i1start, T1 i1end, T2 i2)
	{
		T1 l1 = i1start;
		T2 l2 = i2;
		
		while(l1 != i1end)
		{
			if(*l1 == *l2)
			{
				++l1;
				++l2;
			}
			
			else
			{
				return false;
				break;
			}
		}
		
		return true;
	}
/******************************************************************************/
/*!
  \brief
	to make all the element value equal to num
      
  \param i1start
	first element in the first list
	
  \param i1end
	last element in the first list
  
  \param num
	to find the element that value is equal to this
*/
/******************************************************************************/	
	template <typename T1, typename T2> void fill(T1 i1start, T1 i1end, T2 num)
	{
		T1 l1 = i1start;
		T2 number = num;
		
		while(l1 != i1end)
		{
			*l1 = number;
			++l1;
		}
	}
/******************************************************************************/
/*!
  \brief 
	to find the element that value is equal to num in the list

  \param i1start
	first element in the first list
	
  \param i1end
	last element in the first list
  
  \param num
	to find the element that value is equal to this
*/
/******************************************************************************/	
	template <typename T1, typename T2> T1 find(T1 i1start, T1 i1end, T2 num)
	{
		T1 l1 = i1start;
		T2 number = num;
		
		while(l1 != i1end)
		{
			if(*l1 == number)
			{
				break;
			}
			
			++l1;
		}
		
		return l1;
	}
/******************************************************************************/
/*!
  \brief
	to find the biggest number in the list
      
  \param start
	first element in the list
  
  \param end
	last element in the list
*/
/******************************************************************************/	
	template <typename T> T max_element(T start, T end)
	{
		T tmp = start;
		T max = start;
		
		while(tmp != end)
		{
			if(*tmp > *max)
			{
				max = tmp;
			}
			
			++tmp;
		}
		
		return max;
	}
/******************************************************************************/
/*!
  \brief
	to find the smallest number in the list
      
  \param start
	first element in the list
  
  \param end
	last element in the list
*/
/******************************************************************************/	
	template <typename T> T min_element(T start, T end)
	{
		T tmp = start;
		T min = start;
		
		while(tmp != end)
		{
			if(*tmp < *min)
			{
				min = tmp;
			}
			
			++tmp;
		}
		
		return min;
	}
/******************************************************************************/
/*!
  \brief
      is to remove all the element that have value equal to num
	  
  \param i1start
	the first element in the list
  
  \param i1end
	the last element in the list
  
  \param num
	if the element value is equal to this, the element will be remove
*/
/******************************************************************************/	
	template <typename T> T* remove(T* i1start, T* i1end, T num)
	{
		T* tmp = i1start;
		
		while(i1start != i1end)
		{
			if(*i1start != num)
			{
				*tmp = *i1start;
				++tmp;
				++i1start;
			}
			
			else
			{
				++i1start;
			}
		}
		
		return tmp;
	}
/******************************************************************************/
/*!
  \brief
	this is to replace the the old value with the new value
      
  \param i1start
	the first element in the list
  
  \param i1end
	the last element in the list
	
  \param oldi
	to replace the element that have this value to the newi
  
  \param newi
	to change all value that is oldi to newi
*/
/******************************************************************************/	
	template <typename T> void replace(T* i1start, T* i1end, const T oldi, const T newi)
	{
		T* l1 = i1start;
		
		while(l1 != i1end)
		{
			if(*l1 == oldi)
			{
				*l1 = newi;
			}
			++l1;
		}
	}
/******************************************************************************/
/*!
  \brief
	This is to get the total number when all the elements add up together
      
  \param start
	the first element of the list
  
  \param end
	the last element of the list
*/
/******************************************************************************/	
	template <typename T> T sum(T* start, T* end)
	{
		T* tmp = start;
		T num = 0;
		
		while(tmp != end)
		{
			num += *tmp;
			++tmp;
		}
		
		return num;
	}
/******************************************************************************/
/*!
  \brief
	Swaps all the elements in the 2 list.
      
  \param i1start
	the first element in the first list
  
  \param i1end
	the last element in the first list
	
  \param i2
	the first element in the second list
*/
/******************************************************************************/	
	template <typename T> void swap_ranges(T i1start, T i1end, T i2)
	{
		T l1 = i1start;
		T l2 = i2;
		
		while(l1 != i1end)
		{
			swap(*l1, *l2);
			++l1;
			++l2;
		}			
	}

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}
