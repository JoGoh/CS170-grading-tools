//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
	template <typename T1, typename T2> T2 copy(T1 i1start, const T1 i1end, T2 i2);
	template <typename T1, typename T2> T2 count(T1 i1start, T1 i1end, T2 num);
	template <typename T> void display(T start, T end);
	template <typename T1, typename T2> bool equal(T1 i1start, T1 i1end, T2 i2);
	template <typename T1, typename T2> void fill(T1 i1start, T1 i1end, T2 num);
	template <typename T1, typename T2> T1 find(T1 i1start, T1 i1end, T2 num);
	template <typename T> T max_element(T start, T end);
	template <typename T> T min_element(T start, T end);
	template <typename T> T* remove(T* i1start, T* i1end, T num);
	template <typename T> void replace(T* i1start, T* i1end, const T oldi, const T newi);
	template <typename T> T sum(T* start, T* end);
	template <typename T> void swap(T &left, T &right);
	template <typename T> void swap_ranges(T i1start, T i1end, T i2);
	
  
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
