/*************************************************************************/
/*!
\file Functions.cpp
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: CS170
\par Lab #6
\date 07/07/2019
Brief Description:
Implementation of the algorithmic function templates that works
with ranges. 

Hours spent on this assignment: 7 hrs
Specific portions that gave you the most trouble: Function Templates
*/
/*************************************************************************/
/// \cond
#include <iostream>
/// \endcond

/******************************************************************************/
/*!
  \brief
    Counts the number of elements with the specified item.
  
  \param first
    Reference to the beginning of the first range.
  
  \param end
    Reference to the one after end of the first range.
    
  \param item
    Item to be counted.
    
  \return
    The integer value of the number of counted elements.
*/
/******************************************************************************/
template <typename T1, typename T2> 
int count(T1 first, const T1 &end, const T2 &item)
{
  int counter = 0;          // Initialise counter to count number of items
  while(first != end)       // Loop through the range
  {
    if(*first == item)      // Found item
      counter++;            // Increment counter
    first++;                // Go to next element
  }
  return counter;           // Return counted number
}

/******************************************************************************/
/*!
  \brief
    Copies the elements in first range to the second range until
    the end of the first range.
  
  \param first
    Reference to the beginning of the first range.
  
  \param i1end
    Reference to the one after end of the first range.
    
  \param i2
    Reference to the beginning of the second range.
    
  \return
    Reference to the end of the second range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T2 copy(T1 first, const T1 & i1end, const T2 i2)
{
  T2 copied = i2;             // Initialise a copy of the second range
  while(first != i1end)       // Loop through first range 
  {
    *copied = *first;         // Copy the element into copied
    ++first;                  // Increment to next element in the first range
    ++copied;                 // Increment to the next element in copied range
  }
  return copied;              // Return the copied range
}

/******************************************************************************/
/*!
  \brief
    Displays all elements in the specified range.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
*/
/******************************************************************************/
template <typename T> 
void display(T first, const T &end)
{
  while(first != end)       // Loop through the range
  {
    std::cout << *first;    // Cout the element
    if(++first != end)      // Find the last element
      std::cout << ", ";    // Cout a ,
  }
  std::cout << std::endl;   // Cout a new line
}

/******************************************************************************/
/*!
  \brief
    Checks if the values of two ranges are equal to each other.
    Compares up to the end of the first range.
  
  \param i1
    Reference to the beginning of the first range.
  
  \param i1end
    Reference to the one after end of the first range.
    
  \param i2 
    Reference to the beginning of the second range.
  
  \return
    Returns true(equal) or false(not equal).
*/
/******************************************************************************/
template <typename T1, typename T2>
bool equal(T1 i1, const T1 &i1end, T2 i2)
{
  while(i1 != i1end)          // Loop through the range
  {
    if(*i1 != *i2)            // Found one element that is not equal
      return false;           // Return false since two ranges are not equal
    ++i1;                     // Increment i1
    ++i2;                     // Increment i2
  }
  return true;                // Return true since two ranges are equal
}

/******************************************************************************/
/*!
  \brief
    Fills the range with the specified value.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
    
  \param number 
    Value to fill in the range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void fill(T1 first, const T1 &end, T2 number)
{
  while(first != end)          // Loop through the range
  {
    *first = number;          // Assign first to the number
    ++first;                  // Increment first
  }
}

/******************************************************************************/
/*!
  \brief
    Finds the first element with a specified value in a range.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
    
  \param item
    Reference to the object to be found.
    
  \return
    Reference to the element that contains the specified value.
*/
/******************************************************************************/
template <typename T1, typename T2>
T1 find(T1 first, const T1 &end, const T2 &item)
{
  while(first != end)          // Loop through the range
  {
    if(*(first) == item)       // Found item
      return first;            // Return position of first
    ++first;                   // Increment first
  }
  return end;                  // Item not found, return end
}

/******************************************************************************/
/*!
  \brief
    Finds the maximum element in the range.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
    
  \return 
    Reference to the maximum element in the range.
*/
/******************************************************************************/
template <typename T> 
T max_element(T first, const T &end)
{
  T curr = first;                // Copy range
  while(first != end)            // Loop through range
  {
    // If curr is smaller than first
    if(*curr < *first)           
      curr = first;              // Set new maximum element
    ++first;                     // Increment first
  }
  return curr;                   // Return maximum element
}

/******************************************************************************/
/*!
  \brief
    Finds the minimum element in the range.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
    
  \return 
    Reference to the minimum element in the range.
*/
/******************************************************************************/
template <typename T> 
T min_element(T first, const T &end)
{
  T res = first;                // Initialise a copy first
  while(first != end)           // Loop through range
  {
    // If curr is bigger than first
    if(*res > *first)           
      res = first;              // Set new minimum element
    ++first;
  }
  return res;                   // Return minimum element
}

/******************************************************************************/
/*!
  \brief
    Removes all specified objects in the range.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
    
  \param item
    The object that is to be removed.
    
  \return
    The reference to the new end.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 remove(T1 first, const T1 & end, const T2 &item)
{
  T1 tmp = first;                 // Initialise a copy first
  while(tmp != end)               // Loop through copy's range
  {
    // found item to remove
    if(*tmp == item)
    {
      ++tmp;                      // Increment tmp
      continue;                   // continue
    }
    *first = *tmp;                // Copy value into first array
    ++first;                      // Increment first 
    ++tmp;                        // Increment tmp
  }
  return first;                   // Return new first range
}

/******************************************************************************/
/*!
  \brief
    Replaces old item(s) with another specified item.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
  
  \param olditem
    The item to be replaced.
   
  \param newitem
    The item that is replacing the old item.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void replace(T1 first, const T1 & end, const T2 &olditem, const T2 &newitem)
{
  while(first != end)               // Loop through range
  {
    if((*first) == olditem)         // Found old item
      *first = newitem;             // Replace old item with new item
    ++first;                        // Increment first
  }
}

/******************************************************************************/
/*!
  \brief
    Adds up all elements in an range.
  
  \param first
    Reference to the beginning of the range.
  
  \param end
    Reference to the one after end of the range.
    
  \return
    Sum of all elements in the range.
*/
/******************************************************************************/
template <typename T>
auto sum(T first, const T &end) -> decltype(*T() * 0)
{
  auto total = decltype(*T() * 0)();        // Determine type of total
  while(first != end)                       // Loop through range
  {
    total += *first;                        // Add to total
    ++first;                                // Increment first
  }
  return total;                             // Return total
}

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right);                      // need a temporary copy of right
  right = left;                       // assign left to right
  left = temp;
}

/******************************************************************************/
/*!
  \brief
    Swaps two objects in a range. 
    There is no return value but the two objects are swapped in place.
  
  \param left
    Reference to the beginning of the range.
  
  \param left_end
    Reference to the one after end of the range.
  
  \param right
    Reference to the beginning of the second object.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void swap_ranges(T1 left, const T1 &left_end, T2 right)
{
  while(left != left_end)                  // Loop through to the end
  {
    swap(*left, *right);              // swap elements of left and right
    ++left;                           // go to next element
    ++right;                          // go to next element
  }
}