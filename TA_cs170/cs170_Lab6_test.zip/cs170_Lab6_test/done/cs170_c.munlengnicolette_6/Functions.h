/*************************************************************************/
/*!
\file Functions.h
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: CS170
\par Lab #6
\date 07/07/2019
Brief Description:
Declarations of the algorithmic function templates that works
with ranges.

Hours spent on this assignment: 7 hrs
Specific portions that gave you the most trouble: Function Templates
*/
/*************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  /* Counts the number of elements with the specified item. 
     Returns the integer value of the number of counted elements. */
  template <typename T1, typename T2> 
  int count(T1 first, const T1 &end, const T2 &item);
  
  /* Copies the elements in first range to the second range until
     the end of the first range. Return the reference to the end
     of the second range.*/
  template <typename T1, typename T2> 
  T2 copy(T1 first, const T1 & i1end, const T2 i2);
  
  // Displays all elements in the specified range.
  template <typename T> 
  void display(T first, const T &end);
  
  /* Checks if the values of two ranges are equal to each other.
     Compares up to the end of the first range. Returns true(equal)
     or false(not equal). */
  template <typename T1, typename T2>
  bool equal(T1 i1, const T1 &i1end, T2 i2);
  
  // Fills the range with the specified value.
  template <typename T1, typename T2> 
  void fill(T1 first, const T1 &end, T2 number);
  
  /* Finds the first element with a specified value in a range. 
     Returns the reference to the element that contains
     the specified value.*/
  template <typename T1, typename T2>
  T1 find(T1 first, const T1 &end, const T2 &item);
  
  /* Finds the maximum element in the range. 
     Returns the reference to the maximum element in the range.*/
  template <typename T> 
  T max_element(T first, const T &end);
  
  /* Finds the minimum element in the range.
     Returns the reference to the minimum element in the range. */
  template <typename T> 
  T min_element(T first, const T &end);
  
  /* Removes all specified objects in the range.
     Returns the reference to the new end. */
  template <typename T1, typename T2> 
  T1 remove(T1 first, const T1 & end, const T2 &item);
  
  // Replaces old item(s) with another specified item.
  template <typename T1, typename T2> 
  void replace(T1 first, const T1 & end, const T2 &olditem, const T2 &newitem);
  
  /* Adds up all elements in a range. Returns the sum of 
     all elements in the range. */
  template <typename T>
  auto sum(T first, const T &end) -> decltype(*T() * 0);
  
  
  /* Swaps two objects. There is no return value but the two
     objects are swapped in place. */
  template <typename T> void swap(T &left, T &right);
  
  /* Swaps two objects in a range. 
    There is no return value but the two objects are swapped in place. */
  template <typename T1, typename T2> 
  void swap_ranges(T1 left, const T1 &left_end, T2 right);
  
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
