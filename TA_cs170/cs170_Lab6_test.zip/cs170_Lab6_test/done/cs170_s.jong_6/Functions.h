//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  template <typename T1, typename T2> 
  T2 copy(T1 array1, const T1 array1_end, T2 array2);
  
  template <typename T1, typename T2> 
  T2 count(T1 array1, const T1 array1_end, const T2 &item);
  
  template <typename T1, typename T2> 
  void display(T1 array1, const T2 newend);
  
  template <typename T1, typename T2> 
  bool equal(T1 array1, const T1 array1_end, T2 array2);
  
  template <typename T1, typename T2> 
  void fill(T1 array1, const T1 array1_end, T2 array2);
  
  template <typename T1, typename T2> 
  T1 find(T1 array1, const T1 array1_end, const T2 item);
  
  template <typename T1, typename T2> 
  T1 max_element(T1 array1, const T2 array1_end);
  
  template <typename T1, typename T2> 
  T1 min_element(T1 array1, const T2 array1_end);
  
  template <typename T1, typename T2> 
  T1 remove(T1 array1, const T1 array1_end, const T2 &item);
  
  template <typename T1, typename T2> 
  void replace(T1 array1, const T1 array1_end, const T2 olditem, const T2 newitem);
  
  template <typename T> 
  int sum(T array1, const T array1_end);
  
  template <typename T> 
  void swap(T &left, T &right);
  
  template <typename T1, typename T2> 
  void swap_range(T1 array1, const T1 array1_end, T2 array2);
  
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
