/******************************************************************************/
/*!
\file Point.cpp
\author Jong Sze kuan Melvin
\par email: s.jong\@digipen.edu
\par DigiPen login: s.jong
\par Course: CS170a
\par Lab 06
\date 8/07/2019
\brief
 This files contain functions
*/
/******************************************************************************/
#include <iostream> // cout, endl
/******************************************************************************/
/*!
  \brief
   Copy element of first range to second range.
  
  \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
  \param array2
    Starting address of second range.
    
  \param array2_end
    Last address of the second range.
   
  \returns
   The last address of the second range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T2 copy(T1 array1, const T1 array1_end, T2 array2)
{
  while(array1 != array1_end)
  {
    *array2 = *array1;
    array1++;
    array2++;
  }
  return array2;
}
/******************************************************************************/
/*!
  \brief
    Count the no of times element appear in the range.
  
  \param array1
    Starting address of first range.
    
  \param array1_end
    Last address of the first range.
  
  \param item
    Element counted.
    
  \returns
    The no of times elements appears in the range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T2 count(T1 array1, const T1 array1_end, const T2 &item)
{
  T2 count = 0;
  while(array1 != array1_end)
  {
    if(*array1 == item)
    {
      count++;
    }
    array1++;
  }
  return count;
}
/******************************************************************************/
/*!
  \brief
    Display the range of the object.
  
  \param array1
    Starting address of first range.
  
  \param newend
    End address of range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void display(T1 array1, const T2 newend)
{
  while (array1 != newend)
  {
    std::cout << *(array1);
    array1++;
    if (array1 != newend)
      std::cout << ", ";
  }
  std::cout<< std::endl;
}
/******************************************************************************/
/*!
  \brief
    Determine if the first range is same as the second range.
    
   \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
  \param array2
    Starting address of second range.
    
  \returns
    Returns the boolean true if the range are equal or else false.   
*/
/******************************************************************************/
template <typename T1, typename T2> 
bool equal(T1 array1, const T1 array1_end, T2 array2)
{
  while (array1 != array1_end)
  {
    if (*array1 != *array2)
    {
      return false;
      break;
    }
    array1++;
    array2++;
  }
  return true;
}
/******************************************************************************/
/*!
  \brief
    Fills the first range with elements of the second range.
  
  \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
  \param array2
    Starting address of second range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void fill(T1 array1, const T1 array1_end, T2 array2)
{
  while (array1 != array1_end)
  {
    *array1 =array2;
    array1++;
  }
}
/******************************************************************************/
/*!
  \brief
    Find the given element in the range.
  
  \param array1
    Starting address of first range.
    
  \param array1_end
    Last address of the first range.
  
  \param item
    Element found.
   
  \returns
    Last address of the first range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 find(T1 array1, const T1 array1_end, const T2 item)
{
  while(array1 != array1_end)
  {
    if(*array1 == item)
    {
      return array1;
    }
      array1++;
  }
    return array1_end;      
}
/******************************************************************************/
/*!
  \brief
    Determine highest element in the range.
  
  \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
   \returns
   Highest element in range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 max_element(T1 array1, const T2 array1_end)
{
  T2 max = array1;
    
  while(array1 != array1_end)
  {
    if(*array1 > *max)
    {
      max = array1;
    }
    array1++;
  }
  return max;
}
/******************************************************************************/
/*!
  \brief
    Determine smallest element in the range.
  
  \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
  \returns
   Smallest element in range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 min_element(T1 array1, const T2 array1_end)
{
  T2 min = array1;
  
  while(array1 != array1_end)
  {
    if(*array1 < *min)
    {
      min = array1;
    }
    array1++;
  }
  return min;
}
/******************************************************************************/
/*!
  \brief
    Remove the given element in the range.
  
  \param array1
    Starting address of first range.
    
  \param array1_end
    Last address of the first range.
  
  \param item
    Element removed.
    
  \returns
   Last address of new range.  
*/
/******************************************************************************/
template <typename T1, typename T2> 
T1 remove(T1 array1, const T1 array1_end, const T2 &item)
{
  T1 tmp_array = array1;
  while(array1 != array1_end)
  {
    if(*array1 == item)
    {
      array1++;
    }
    else
    {
      *tmp_array = *array1;
      array1++;
      tmp_array++;
    }
  }
  return tmp_array;
}
/******************************************************************************/
/*!
  \brief
    Raplaces the old element from the range with  the given element.
  
  \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
   \param olditem
   Element to be replaced.
  
  \param newitem
   Element to be replaced with.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void replace(T1 array1, const T1 array1_end, const T2 olditem, const T2 newitem)
{
  while(array1 != array1_end)
  {
    if(*array1 == olditem)
    {
      *array1 = newitem;
    }
    array1++;
  }
}
/******************************************************************************/
/*!
  \brief
   Find the total sum of element in the range.
  
  \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
   \returns
   Sum of the element in the range.   
*/
/******************************************************************************/
template <typename T> 
int sum(T array1, const T array1_end)
{
  int sum =0;
  while(array1 != array1_end)
  {
    sum += *(array1);
    array1++;
  }
  return sum;
}
/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}
/******************************************************************************/
/*!
  \brief
   Swaps two range of element.
  
  \param array1
   Starting address of first range.
  
  \param array1_end
   Last address of the first range.
   
  \param array2
    Starting address of second range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void swap_ranges(T1 array1, const T1 array1_end, T2 array2)
{
  while (array1 != array1_end)
  {
    swap(*array1, *array2);
    array1++;
    array2++;
  }
}
