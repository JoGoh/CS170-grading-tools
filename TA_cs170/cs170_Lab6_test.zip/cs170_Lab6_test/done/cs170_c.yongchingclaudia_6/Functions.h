//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------
/******************************************************************************/
/*!
\file functions.h 
\author Chan Yong Ching Claudia 
\par email: c.yongchingclaudia\@digipen.edu 
\par DigiPen login: c.yongchingclaudia 
\par Course: CS170 
\par Assignment 4
\date 7/07/2019 
\brief This file contains the implementation of the following functions for the 
functions assignment. They are all templated functions so it allows any type to
perfrom the following functions. users can use the functions to copy from a 
list to another, to find or remove specific elements, or to find the sum of
the list.
Functions include: 
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges
Hours spent on this assignment: 36
Specific portions that gave you the most trouble: remove 
*/
/******************************************************************************/
#include <iostream> // cout, endl

namespace CS170
{
  template <typename T1, typename T2>
  T2 copy(T1 fbegin, const T1 fend, T2 second);

  template<typename T1, typename T2>
  T2 count(T1 begin, const T1 end, const T2& item);

  template <typename T>
  void display(T begin, const T end);

  template <typename T1, typename T2>
  bool equal(T1 fbegin, const T1 fend, T2 second);

  template <typename T1, typename T2>
  void fill(T1 begin, const T1 end, const T2& item);

  template <typename T1, typename T2>
  T1 find(T1 begin, const T1 end, const T2& item);

  template <typename T>
  T max_element(T begin, const T end);

  template <typename T>
  T min_element(T begin, const T end);

  template <typename T1, typename T2> 
  T1 remove(T1 begin, const T1 end, const T2& item);

  template<typename T1, typename T2>
  void replace(T1 begin, const T1 end, const T2& olditem, const T2& newitem);

  template <typename T>
  T sum(T* begin, const T* end);

  template <typename T>
  void swap(T &left, T &right);

  template <typename T1, typename T2>
  void swap_ranges(T1 fbegin, const T1 fend, T2 second);
  
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
