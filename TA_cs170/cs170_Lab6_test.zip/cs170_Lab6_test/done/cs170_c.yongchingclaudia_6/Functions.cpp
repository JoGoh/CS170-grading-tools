/******************************************************************************/
/*!
\file functions.h 
\author Chan Yong Ching Claudia 
\par email: c.yongchingclaudia\@digipen.edu 
\par DigiPen login: c.yongchingclaudia 
\par Course: CS170 
\par Assignment 4
\date 7/07/2019 
\brief This file contains the implementation of the following functions for the 
functions assignment. They are all templated functions so it allows any type to
perfrom the following functions. users can use the functions to copy from a 
list to another, to find or remove specific elements, or to find the sum of
the list.
Functions include: 
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges
Hours spent on this assignment: 36
Specific portions that gave you the most trouble: remove 
*/
/******************************************************************************/

//#include <iostream> // cout, endl

/******************************************************************************/
/*!
*\fn            T2 copy(T1 fbegin, const T1 fend, T2 second)

*\brief         copying the whole list over from another list

*\param         fbegin - start of the first list that contains the value to be 
                         copied over

*\param         fend - end of the first list

*\param         second - second list that is going to copy from the first list

*\return        return the start of the second list 
*/
/******************************************************************************/

template <typename T1, typename T2>
T2 copy(T1 fbegin, const T1 fend, T2 second)
{
	while (fbegin!=fend)
	{
		*second = *fbegin;
		++fbegin;
		++second;
	}
	return second;
}

/******************************************************************************/
/*!
*\fn            T2 count(T1 begin, const T1 end, const T2& item)

*\brief         copying the number of time an item appears in the list

*\param         begin - start of the list that contains values

*\param         end - end of the list

*\param         item - item to be counted 

*\return        return the number of time the item appeared
*/
/******************************************************************************/

template<typename T1, typename T2>
T2 count(T1 begin, const T1 end, const T2& item)
{
	T2 count = 0;
	while (begin != end)
	{
		if (*begin == item)
			count++;
		
		begin++;
	}
	return count;
}

/******************************************************************************/
/*!
*\fn            void display(T begin, const T end)

*\brief         displays the list on to the screen

*\param         begin - start of the list that needs to be printed

*\param         end - end of the list
*/
/******************************************************************************/

template <typename T>
void display(T begin, const T end)
{
	if(begin==end)
	{
		std::cout<<std::endl;
		return;
	}
	std::cout<<*begin;
	if(begin!=end)
		begin++;
	while(begin!=end)
	{	
		std::cout<<", "<<*begin;
		++begin;
	}
	std::cout<<std::endl;
}

/******************************************************************************/
/*!
*\fn            bool equal(T1 fbegin, const T1 fend, T2 second)

*\brief         checks if the two list are equal 

*\param         fbegin - start of the first list to be checked

*\param         fend - end of the first list

*\param         second - start of the second list

*\return        return true if the lists are equal else return false
*/
/******************************************************************************/

template <typename T1, typename T2>
bool equal(T1 fbegin, const T1 fend, T2 second)
{
	while (fbegin != fend)
	{
		if (*fbegin != *second)
			return false;

		++fbegin;
		++second;
	}
	return true;
}

/******************************************************************************/
/*!
*\fn            void fill(T1 begin, const T1 end, const T2& item)

*\brief         fills the list completely with the required item

*\param         begin - start of the list

*\param         end - end of the list

*\param         item - item to fill the list with 
*/
/******************************************************************************/

template <typename T1, typename T2>
void fill(T1 begin, const T1 end, const T2& item)
{
	while (begin!=end)
	{
		*begin = item;
		++begin;
	}
}

/******************************************************************************/
/*!
*\fn            T1 find(T1 begin, const T1 end, const T2& item)

*\brief         find if an item is the list and returns it if it exists in the 
                list

*\param         begin - start of the list

*\param         end - end of the list

*\param         item - item to be searched fot

*\return        returns where the item is
*/
/******************************************************************************/

template <typename T1, typename T2>
T1 find(T1 begin, const T1 end, const T2& item)
{
	while (begin != end)
	{
		if (*begin == item)
			return begin;
		++begin;
	}
	return end;
}

/******************************************************************************/
/*!
*\fn            T max_element(T begin, const T end)

*\brief         find the element of the largest value in the list

*\param         begin - start of the list

*\param         end - end of the list

*\return        returns the largest element
*/
/******************************************************************************/

template <typename T>
T max_element(T begin, const T end)
{
	T max = begin;
	while(begin != end)
	{
		if (*begin > *max)
			max = begin;
			
		++begin;
	}
	return max;
}

/******************************************************************************/
/*!
*\fn            T min_element(T begin, const T end)

*\brief         find the element of the largest value in the list

*\param         begin - start of the list

*\param         end - end of the list

*\return        returns the largest element
*/
/******************************************************************************/

template <typename T>
T min_element(T begin, const T end)
{
	T min = begin;
	while(begin != end)
	{
		if (*begin < *min)
			min = begin;

		++begin;
	}
	return min;
}

/******************************************************************************/
/*!
*\fn            T1 remove(T1 begin, const T1 end, const T2& item)

*\brief         find the element of the same value as item in the list and
                remove it

*\param         begin - start of the list

*\param         end - end of the list

*\param         item - item to be removed from the list

*\return        returns the new list
*/
/******************************************************************************/

template <typename T1, typename T2> 
T1 remove(T1 begin, const T1 end, const T2& item)
{
	T1 tmp = begin;
	while(begin!=end)
	{
		if (*begin!=item)
		{
			*tmp = *begin;
			tmp++;
		}
		begin++;
	}
	return tmp;
}

/******************************************************************************/
/*!
*\fn            void replace(T1 begin, const T1 end, const T2& olditem, 
                             const T2& newitem)

*\brief         replace all the elements that is the same as old item with 
                newitem

*\param         begin - start of the list

*\param         end - end of the list

*\param         olditem - item to be replaced

*\param         newitem - item to replace with
*/
/******************************************************************************/

template<typename T1, typename T2>
void replace(T1 begin, const T1 end, const T2& olditem, const T2& newitem)
{
	while (begin != end)
	{
		if (*begin == olditem)
			*begin = newitem;
		begin++;
	}
}

/******************************************************************************/
/*!
*\fn            T sum(T* begin, const T* end)

*\brief         calculate the sum of all the elements in the list

*\param         begin - start of the list

*\param         end - end of the list

*\return        returns the sum of the list
*/
/******************************************************************************/

template <typename T>
T sum(T* begin, const T* end)
{
	T sum = 0;
	while(begin != end)
	{
		sum+=*begin;
		++begin;
	}
	return sum;
}

/******************************************************************************/
/*!
*\fn            void swap(T &left, T &right)

*\brief         swaps two element in the list

*\param         left - first element to be swapped

*\param         right - second element to be swapped
*/
/******************************************************************************/

/*!
  \brief
	Swaps two objects. There is no return value but the two objects are
	swapped in place.

  \param left
	The first object to swap.

  \param right
	The second object to swap.
*/
template <typename T>
void swap(T &left, T &right)
{
	T temp(right); // need a temporary copy
	right = left;
	left = temp;
}

/******************************************************************************/
/*!
*\fn            void swap_ranges(T1 fbegin, const T1 fend, T2 second)

*\brief         swaps all the elements in two lists

*\param         fbegin - start of the first list to be swapped

*\param         fend - end of the first list to be swapped

*\param         second - start of the second list to be swapped
*/
/******************************************************************************/

template <typename T1, typename T2>
void swap_ranges(T1 fbegin, const T1 fend, T2 second)
{
	while (fbegin!=fend)
	{
		swap(*fbegin, *second);
		fbegin++;
		second++;
	}
}


