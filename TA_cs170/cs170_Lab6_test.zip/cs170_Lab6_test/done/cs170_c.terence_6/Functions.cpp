/******************************************************************************/ 
/*! 
\file Functions.cpp
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 06
\date 06/07/2019 
\brief This file contains the declaration of the following functions for
CS170 Lab 6: Function Templates
\par Functions include
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges

\par Hours spent on this assignment: 4 hours
\par Specific portions that gave you the most trouble: Ensuring const is
	applied when neccessary
*/ 
/******************************************************************************/
#include <iostream> // cout, endl
/******************************************************************************/
/*!
	\brief
		Copies the list given by the first two parameters to the given location

	\param first
		The start of the first list to copy.

	\param last
		The end of the first list.
		
	\param loc
		The new location of the list to copy to
*/
/******************************************************************************/
template <typename T>
T* copy(const T* first, const T* last, T* loc)
{
	//Nullptr check
	if (first == nullptr || last == nullptr || loc == nullptr)
		return nullptr;
	
	//Iterate through the entire list
	while (first < last)
	{
		//Copies the value over to location
		*loc = *first;
		
		//Iterate both to move on to next value
		++loc;
		++first;
	}
	
	return loc;
}
/******************************************************************************/
/*!
	\brief
		Counts all items in the given list that has same value as one given item

	\param first
		The start of the list to count.

	\param last
		The end of the list.
		
	\param item
		The reference to the item to count
		
	\return int
		The number of items that match the given item in the list
*/
/******************************************************************************/
template <typename T>
int count(const T* first, const T* last, const T& item)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return 0;
	
	int num = 0;
	
	//Iterate through entire list
	while (first < last)
	{
		//If current value matches item, add one to count
		if (*first == item)
			++num;
		
		//Move to next item
		++first;
	}
	
	return num;
}
/******************************************************************************/
/*!
	\brief
		Prints out all items within the two parameters of the list
		
	\param first
		The start of the list to print.

	\param last
		The end of the list.
*/
/******************************************************************************/
template <typename T>
void display(const T* first, const T* last)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return;
	
	//Iterate through entire list
	while (first < last)
	{
		//Prints out value
		std::cout<< *first;
		
		//Prints out ", " if still have another value
		if (first != last - 1)
			std::cout << ", ";
		
		++first;
	}
	// Prints /n at back
	std::cout << std::endl;
}
/******************************************************************************/
/*!
	\brief
		Compares two lists to check if they are equal.
	
	\param first
		The start of the first list to compare.

	\param last
		The end of the first list.
		
	\param rFirst
		The start of second list to compare.
		
	\return bool
		Whether the two lists are equal or not.
*/
/******************************************************************************/
template <typename T1, typename T2>
bool equal(const T1* first, const T1* last, const T2* rFirst)
{
	//Nullptr check
	if (first == nullptr || last == nullptr || rFirst == nullptr)
		return false;
	
	bool isEqual = true;
	
	//Iterate through entire list
	while (first < last)
	{
		//Checks if current value does not match
		if (*first != *rFirst)
		{
			//If values do not match, can break and return false
			isEqual = false;
			break;
		}
		//Moves on to next value
		++first;
		++rFirst;
	}
	
	return isEqual;
}
/******************************************************************************/
/*!
	\brief
		Fills all values in list with given value

	\param first
		The start of the list to fill.

	\param last
		The end of the first list.
		
	\param value
		The reference to the item to fill the list.
*/
/******************************************************************************/
template <typename T>
void fill(T* first, T* last, const T& value)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return;
	
	//Iterate through entire list
	while (first < last)
	{
		//Sets value and move to next item
		*first = value;
		++first;
	}
}
/******************************************************************************/
/*!
	\brief
		Searches through the list to find first item in list to match

	\param first
		The start of the first list to find.

	\param last
		The end of the first list.
		
	\param item
		The reference to the item to find.
		
	\return T1*
		The pointer to the first value found in list.
*/
/******************************************************************************/
template <typename T1, typename T2>
T1* find(T1* first, T1* last, const T2& item)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return nullptr;
	
	//Iterate through entire list
	while(first < last)
	{
		//If the value is identical, found and break
		if (*first == item)
			break;
		//else go to next value
		++first;
	}
	
	//Return the first found instance
	//Or if not found, will return last (iterated to end)
	return first;
}
/******************************************************************************/
/*!
	\brief
		Finds the biggest element in the given list
	
	\param first
		The start of the first list to find max_element.

	\param last
		The end of the first list.
		
	\return T*
		The pointer to the highest element in list.
*/
/******************************************************************************/
template <typename T>
T* max_element(T* first, T* last)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return nullptr;
	
	//maxVal is pointer to the max value
	T* maxVal = first;
	
	//Iterate through entire list
	while (first < last)
	{
		//If current value is higher than max value, point maxVal to this
		if (*first > *maxVal)
			maxVal = first;
		//Move on to next item on list
		++first;
	}
	
	return maxVal;
}
/******************************************************************************/
/*!
	\brief
		Finds the smallest element in the given list.
	
	\param first
		The start of the first list to find min element.

	\param last
		The end of the first list.
		
	\return T*
		The pointer to the lowest element in list
*/
/******************************************************************************/
template <typename T>
T* min_element(T* first, T* last)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return nullptr;
	
	//minVal is pointer to lowest value
	T* minVal = first;
	
	//Iterate through entire list
	while (first < last)
	{
		//If current value is lower than min value, point minVal to this
		if (*first < *minVal)
			minVal = first;
		//Move on to next item on list
		++first;
	}
	
	return minVal;
}
/******************************************************************************/
/*!
	\brief
		Removes all elements in the list with given value

	\param first
		The start of the first list to find and remove elements.

	\param last
		The end of the first list.
		
	\param item
		The reference to the item to remove.
		
	\return T*
		The reference to the new end of the list
*/
/******************************************************************************/
template <typename T>
T* remove(T* first, T* last, const T& item)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return nullptr;
	
	//Create two iterators
	//First iterator goes through entire list
	//Second iterator acts as "new" list
	T* iterator = first;
	T* itAlt = first;
	
	//Iterate through entire list
	while (iterator < last)
	{
		//If item matches object to remove
		if (*iterator == item)
		{
			//Move to main pointer to next to "skip" to be removed item
			++iterator;
		}
		else //Otherwise, move both pointers to next since both acceptable
		{
			++iterator;
			++itAlt;
		}
		
		//Always set new value of iterator
		//If new value is still to be removed, it will in next loop
		*itAlt = *iterator;
	}
	
	return itAlt;
}
/******************************************************************************/
/*!
	\brief
		Replaces all elements with given values with the new value
	
	\param first
		The start of the first list to replace.

	\param last
		The end of the first list.
		
	\param oldItem
		The reference to the item to replace
		
	\param newItem
		The reference to the item that is replacing oldItem
*/
/******************************************************************************/
template <typename T>
void replace(T* first, T* last, const T& oldItem, const T& newItem)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return;
	
	//Goes through entire loop
	while (first < last)
	{
		//If current item matches oldItem, replace with new item
		if (*first == oldItem)
			*first = newItem;
		//Iterate to next item
		++first;
	}
}
/******************************************************************************/
/*!
	\brief
		Calculates the sum of all values within the list
		
	\param first
		The start of the first list to calculate sum.

	\param last
		The end of the first list.
		
	\return T
		The total sum of the elements in the list
*/
/******************************************************************************/
template <typename T>
T sum(const T* first, const T* last)
{
	//Creates a basic item of 0
	T sum(0);
	
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return sum;
	
	//Goes through entire list
	while (first < last)
	{
		//Adds value to sum, and iterate
		sum += *first;
		++first;
	}
	
	return sum;
}
/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
	T temp(right); // need a temporary copy
	right = left;
	left = temp;
}
/******************************************************************************/
/*!
	\brief
		Swaps all elements within the two lists

	\param first
		The start of the first list to swap.

	\param last
		The end of the first list.
		
	\param right
		The start of the second list to swap
*/
/******************************************************************************/
template <typename T>
void swap_ranges(T* first, T* last, T* right)
{
	//Nullptr check
	if (first == nullptr || last == nullptr)
		return;
	
	//Goes through entire list
	while (first < last)
	{
		//With each iteration, swap the values and move to next item
		swap(*first, *right);
		
		++first;
		++right;
	}
}