/******************************************************************************/ 
/*! 
\file Functions.cpp
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 06
\date 06/07/2019 
\brief This file contains the declaration of the following functions for
CS170 Lab 6: Function Templates
\par Functions include
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges

\par Hours spent on this assignment: 4 hours
\par Specific portions that gave you the most trouble: Ensuring const is
	applied when neccessary
*/ 
/******************************************************************************///---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
	//Copies from list to loc
	template <typename T> 
	T* copy(const T* first,const T* last, T* loc);
	//Counts all items in list with value of item
	template <typename T> 
	int count(const T* first, const T* last, const T& item);
	//Displays all items in list
	template <typename T> 
	void display(const T *first, const T* last);
	//Checks if two lists are equal in terms of element values
	template <typename T1, typename T2> 
	bool equal(const T1* first, const T1* last, const T2* rFirst);
	//Fills list with given value
	template <typename T> 
	void fill(T* first, T* last, const T& value);
	//Finds first element of item in list
	template <typename T1, typename T2> 
	T1* find(T1* first, T1* last, const T2& item);
	//Finds biggest element in list
	template <typename T> 
	T* max_element(T* first, T* last);
	//Finds smallest element in list
	template <typename T> 
	T* min_element(T* first, T* last);
	//Removes all elements with value of item in list
	template <typename T> 
	T* remove(T* first, T* last, const T& item);
	//Reaplces all elements with oldItem value with newItem value
	template <typename T> 
	void replace(T* first, T* last, const T& oldItem, const T& newItem);
	//Calculates the sum of all elements in list
	template <typename T> 
	T sum(const T* first, const T* last);
	//Swaps two elements around
	template <typename T> 
	void swap(T& left, const T& right);
	//Swaps two ranges of elements around
	template <typename T> 
	void swap_ranges(T* first, T* last, T* right);
	

	#include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
