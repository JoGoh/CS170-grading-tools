/******************************************************************************/
/*!
\file Functions.cpp
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par lab #6
\date 02/07/2019
\brief
This file contains the implementations of function templates to be
used with test cases. This project contains functions to perform
operations on ranges, such as remove/replace/copy/search from
one range to another range. It contains the following functions;
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges

Hours spent on this assignment: 10
Specific portions that gave you the most trouble: sum & remove
*/
/******************************************************************************/
#include <iostream> // cout, endl

/******************************************************************************/
/*!
  \brief
    Copies from 1 object into another object

  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \param other
    The first of another object.
    
  \return T2
*/
/******************************************************************************/
template <typename T1, typename T2> 
T2 copy(T1 begin, const T1 &end, T2 other)
{
    // Loop to the end, copy the element and increment both pointer
    while (begin != end)
        *(other++) = *(begin++);
    
    return other;
}
/******************************************************************************/
/*!
  \brief
    The number of times that the desired value appears in the object

  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \param value
    The desired value
    
  \return int
*/
/******************************************************************************/
template<typename T1, typename T2>
int count(T1 begin, const T1 &end, const T2 &value)
{
    // Initialise the counter
    int counter = 0;
    
    // Loop to the end
    while (begin != end)
    {
        // If found the value, increment the counter
        if (*begin == value)
            ++counter;
        
        // Increment begin
        ++begin;
    }
    return counter;
}
/******************************************************************************/
/*!
  \brief
    Print out all the elements in the object. There is no return value

  \param begin
    The start of the object.

  \param end
    The end of the object.
*/
/******************************************************************************/
template<typename T>
void display(T begin, const T &end)
{
    // Loop to the end
    while (begin != end)
    {
        // print out all of the elements
        std::cout << *begin;
        
        // Increment begin
        ++begin;
        
        // Add in the comma and space
        if (begin != end)
            std::cout << ", ";
            
    }
    
    // Print on next line
    std::cout << std::endl;
}
/******************************************************************************/
/*!
  \brief
    Check if the two objects are equal

  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \param other
    The start of another object
  
  \return bool
*/
/******************************************************************************/
template<typename T1, typename T2>
bool equal(T1 begin, const T1 &end, T2 other)
{
    // Loop to the end
    while (begin != end)
    {
        // Check if there's any value that is different. If yes, return false
        if (*(begin++) != *(other++))
            return false;
    }
    
    return true;
}
/******************************************************************************/
/*!
  \brief
    Fills the object with the desired value. There is no return value

  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \param value
    The desired value
*/
/******************************************************************************/
template<typename T1, typename T2>
void fill(T1 begin, const T1 &end, const T2 &value)
{
    // Loop to the end, copy from value and increment the begin
    while (begin != end)
        *(begin++) = value;
}
/******************************************************************************/
/*!
  \brief
    Find the first element of the desired value from the object
    
  \param begin
    The start of the object.

  \param end
    The end of the object.

  \param value
    The desired value

  \return T1
*/
/******************************************************************************/
template<typename T1, typename T2>
T1 find(T1 begin, const T1 &end, const T2 &value)
{
    // Loop to the end
    while (begin != end)
    {
        // Check if it's equal to desired value 
        if (*begin == value)
            break;
                
        // Increment begin
        ++begin;
    }
    return begin;
}
/******************************************************************************/
/*!
  \brief
    Return the biggest value in the object
    
  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \return T
*/
/******************************************************************************/
template<typename T>
T max_element(T begin, const T &end)
{    
    // Set the max
    T max = begin;
    
    // Loop to the end    
    while (begin != end)
    {
        // Check for the largest value
        if (*begin > *max)
            max = begin;
        
        // Increment begin
        ++begin;
    }
    
    return max;
}
/******************************************************************************/
/*!
  \brief
    Return the smallest value in the object

  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \return T
*/
/******************************************************************************/
template<typename T>
T min_element(T begin, const T &end)
{
    // Set the min
    T min = begin;
    
    // Loop to the end    
    while (begin != end)
    {
        // Check for the smallest value
        if (*begin < *min)
            min = begin;
        
        // Increment begin
        ++begin;
    }
    
    return min;
}
/******************************************************************************/
/*!
  \brief
    Removes all elements of the desired value from the object
    
  \param begin
    The start of the object.

  \param end
    The end of the object.

  \param value
    The desired value that used to remove the object.

  \return T1
*/
/******************************************************************************/
template<typename T1, typename T2>
T1 remove(T1 begin, T1 end, const T2 &value)
{
    // To initialise swap
    T1 swapValue = begin;
    
    // Loop to the end
    while (begin != end)
    {
        // swap the order, move the "unwanted" to the front
        // else increment the begin
        if (*begin != value)
            swap(*(swapValue++), *(begin++));
        else
            ++begin;
    }
    
    // Return from where the first element after shifting the "unwanted"
    return swapValue;
}
/******************************************************************************/
/*!
  \brief
    Replaces all elements of the value in the object with the new desired value.
    There is no return value
    
  \param begin
    The start of the object.

  \param end
    The end of the object.

  \param oldValue
    The value that needed to be replaced.

  \param newValue
    The value for replacing.
*/
/******************************************************************************/
template<typename T1, typename T2>
void replace(T1 begin, const T1 &end, 
             const T2 &oldValue, const T2 &newValue)
 {
    // Loop to the end
    while (begin != end)
    {
        // Find the old value
        begin = find(begin, end, oldValue);

        // If found, replace it with the new value
        if (begin != end)
            *begin = newValue;
    }
 }
/******************************************************************************/
/*!
  \brief
    Find the total sum of the object.

  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \return auto
*/
/******************************************************************************/
template <typename T> 
auto sum(T begin, const T &end) -> decltype(*T() + *T())
{
    // To initialise sum
    auto sum = decltype(*T() + *T())();
    
    // Loop to the end, increment begin and add it into the sum
    while (begin != end)
        sum += *(begin++);
    
    return sum;
}
/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
    T temp(right); // need a temporary copy
    right = left;
    left = temp;
}
/******************************************************************************/
/*!
  \brief
    Swaps all of the elements of the two objects. There is no return value

  \param begin
    The start of the object.

  \param end
    The end of the object.
    
  \param other
    The start of another object
*/
/******************************************************************************/
template <typename T1, typename T2> 
void swap_ranges(T1 begin, const T2 &end, T1 other)
{
    // Loop to the end
    while (begin != end)
        swap(*(begin++), *(other++));
}