/******************************************************************************/
/*!
\file Functions.h
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par lab #6
\date 02/07/2019
\brief
This file contains the implementations of function templates to be
used with test cases. This project contains functions to perform
operations on ranges, such as remove/replace/copy/search from
one range to another range. It contains the following functions;
copy
count
display
equal
fill
find
max_element
min_element
remove
replace
sum
swap
swap_ranges

Hours spent on this assignment: 10
Specific portions that gave you the most trouble: sum & remove
*/
/******************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
    template <typename T1, typename T2> 
    T2 copy(T1 begin, const T1 &end, T2 other);
    
    template<typename T1, typename T2>
    int count(T1 begin, const T1 &end, const T2 &value);
    
    template<typename T>
    void display(T begin, const T &end);

    template<typename T1, typename T2>
    bool equal(T1 begin, const T1 &end, T2 other);
    
    template<typename T1, typename T2>
    void fill(T1 begin, const T1 &end, const T2 &value);
    
    template<typename T1, typename T2>
    T1 find(T1 begin, const T2 &end, const T2 &value);

    template<typename T>
    T max_element(T begin, const T &end);
    
    template<typename T>
    T min_element(T begin, const T &end);

    template<typename T1, typename T2>
    T1 remove(T1 begin, T1 end, const T2 &value);
    
    template<typename T1, typename T2>
    void replace(T1 begin, const T1 &end, 
                 const T2 &oldValue, const T2 &newValue);

    template <typename T> 
    auto sum(T begin, const T& end) -> decltype(*T() + *T());
    
    template <typename T> 
    void swap(T &left, T &right);
    
    template <typename T1, typename T2> 
    void swap_ranges(T1 begin, const T2 &end, T1 other);
  
    #include "Functions.cpp"
}
#endif
//---------------------------------------------------------------------------
