/******************************************************************************/
/*! 
\file   Functions.cpp 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 06
\date   08/07/2019 
\brief
     This is file contains the function definitions for Functions.cpp
*/ 
/******************************************************************************/
#include <iostream> // cout, endl

/******************************************************************************/
/*!
  \brief
    Swaps two objects. There is no return value but the two objects are
    swapped in place.
  
  \param left
    The first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}
/******************************************************************************/
/*!
  \brief
    Swaps two objects until a certain range. There is no return value but the 
    two objects are swapped in place for that range.
  
  \param left
    The first object to swap.
  
  \param leftend
    The end point first object to swap.
  
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap_ranges(T *left,T *leftend ,T *right)
{
  while(left != leftend)
  {
    swap(*left,*right);
    left++;
    right++;
  }
}
/******************************************************************************/
/*!
  \brief
    Displays the numbers in the array of a given range.
  
  \param left
    The first object to display.
  
  \param leftend
    The end point first object to display.
*/
/******************************************************************************/
template <typename T> 
void display(T* left,T* leftend)
{
  if (left == nullptr || leftend == nullptr)
  {
    printf("\n");
    return;
  }
  while((left+1) != leftend)
  {
    std::cout << *left << ", ";
    left++;
  }
  std::cout << *left << std::endl;
}
/******************************************************************************/
/*!
  \brief
    Remove all the numbers in the array with the number value in the array of a 
    given range.
  
  \param left
    The first object to check for removal.
  
  \param leftend
    The end point first object to check for removal.
  
  \param value
    The value to be removed
*/
/******************************************************************************/
template <typename T> 
T* remove(T *left,T *leftend ,T value)
{
  T* endpt = leftend;
  T* start = left;
  int count = 1;
  while(start != endpt)
  {
    //check if the current value needs to be removed
    if(*start == value)
    {
      endpt--;
      while(start != endpt)
      {
        //copy the value of the number in the array after it, skippiing those 
        //with the number to be removed
        if (*(start+count) == value && (start+count)!= leftend) 
        {
          count++;
          endpt--;
          continue;
        }
        *start = *(start+count);
        start++;
      }
    }
    else
    {
      start++;
    }
  }
  if(endpt == left) endpt = nullptr;
  return endpt;
}
/******************************************************************************/
/*!
  \brief
    Count the number of numbers in the array that matches item.
  
  \param left
    The first object to check for the same number.
  
  \param leftend
    The end point first object to check for the same number.
  
  \param item
    The value to be checked for
*/
/******************************************************************************/
template <typename T> 
T count(T *left,T *leftend ,T item)
{
  T counter = 0;
  while(left != leftend)
  {
    if(*left == item) counter++;
    left++;
  }
  return counter;
}
/******************************************************************************/
/*!
  \brief
    finds the first number in the array that matches item.
  
  \param left
    The first object to check for the same number.
  
  \param leftend
    The end point first object to check for the same number.
  
  \param item
    The value to be checked for
*/
/******************************************************************************/
template <typename T1,typename T2> 
T1* find(T1 *left,T1 *leftend ,const T2 item)
{
  T1* pos = left;
  while(pos != leftend)
  {
    if(*pos == item)break;
    pos++;
  }
  return pos;
}
/******************************************************************************/
/*!
  \brief
    copy lhs to rhs within a given range
  
  \param left
    The first object to start copying
  
  \param leftend
    The end point first object to stop copying
  
  \param right
    array to copy to
*/
/******************************************************************************/
template <typename T> 
T* copy(const T *left,const T *leftend ,T *right)
{
  while(left != leftend)
  {
    *right = *left;
    left++;
    right++;
  }
  return right;
}
/******************************************************************************/
/*!
  \brief
    fills the numbers of the array within a given range with item
  
  \param left
    The first object to start filling
  
  \param leftend
    The end point first object to stop filling
  
  \param item
    the number to fill
*/
/******************************************************************************/
template <typename T> 
void fill(T *left,T *leftend ,T item)
{
  while(left != leftend)
  {
    *left = item;
    left++;
  }
}
/******************************************************************************/
/*!
  \brief
    replace the numbers in the array in a given range with olditem with newitem
  
  \param left
    The first object to check for replacement
  
  \param leftend
    The end point first object to check for replacement
  
  \param olditem
    the number to check for
      
  \param newitem
    the number to replace
*/
/******************************************************************************/
template <typename T> 
void replace(T *left,T *leftend ,T olditem, T newitem)
{
  while(left != leftend)
  {
    if(*left == olditem) *left = newitem;
    left++;
  }
}
/******************************************************************************/
/*!
  \brief
    finds the min element of an object within a given range
  
  \param left
    The first object to check min element
  
  \param leftend
    The end point first object to check for min element
*/
/******************************************************************************/
template <typename T> 
T* min_element(T *left,T *leftend)
{
  T* min = left;
  while(left != leftend)
  {
    if(*left < *min) min = left;
    left++;
  }
  return min;
}
/******************************************************************************/
/*!
  \brief
    finds the max element of an object within a given range
  
  \param left
    The first object to check max element
  
  \param leftend
    The end point first object to check for max element
*/
/******************************************************************************/
template <typename T> 
T* max_element(T *left,T *leftend)
{
  T* max = left;
  while(left != leftend)
  {
    if(*left > *max) max = left;
    left++;
  }
  return max;
}
/******************************************************************************/
/*!
  \brief
    checks if lhs and rhs within a given range are equal
  
  \param left
    The first object to check for equal
  
  \param leftend
    The end point first object to check for equal
  
  \param right
    The second object to check for equal
*/
/******************************************************************************/
template <typename T1,typename T2>
bool equal(T1 *left,T1 *leftend ,T2 *right)
{
  while(left != leftend)
  {
    if(*left != *right) return false;
    left++;
    right++;
  }
  return true;
}
/******************************************************************************/
/*!
  \brief
    gets the sum of the numbers in the array
  
  \param left
    The first object to get the sum
  
  \param leftend
    he first object to get the sum
*/
/******************************************************************************/
template <typename T> T sum(T *left,T *leftend)
{
  T sum = 0;
    if (left == nullptr || leftend == nullptr) return sum;
  while(left != leftend)
  {
    sum+=*left;
    left++;
  }
  return sum;
}