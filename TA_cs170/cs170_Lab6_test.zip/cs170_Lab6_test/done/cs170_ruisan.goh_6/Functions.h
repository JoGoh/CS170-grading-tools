/******************************************************************************/
/*! 
\file   Functions.h 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 06
\date   08/07/2019 
\brief
     This is file contains the function declarations for Functions.cpp
*/ 
/******************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  template <typename T> void swap(T &left, T &right);
  
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *  position.
   *
   */ 
  
  #include "Functions.cpp"
  template <typename T> void swap_ranges(T *left,T *leftend ,T *right);
  template <typename T> void display(T* left,T* leftend);
  template <typename T> T* remove(T *left,T *leftend ,T value);
  template <typename T> T count(T *left,T *leftend ,T item);
  template <typename T1,typename T2> T1* find(T1 *left,T1 *leftend ,const T2 item);
  template <typename T> T* copy(const T *left,const T *leftend ,T *right);
  template <typename T> void fill(T *left,T *leftend ,T item);
  template <typename T> void replace(T *left,T *leftend ,T olditem, T newitem);
  template <typename T> T* min_element(T *left,T *leftend);
  template <typename T> T* max_element(T *left,T *leftend);
  template <typename T1,typename T2> bool equal(T1 *left,T1 *leftend ,T2 *right);
  template <typename T> T sum(T *left,T *leftend);
}

#endif
//---------------------------------------------------------------------------
