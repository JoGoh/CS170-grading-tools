/******************************************************************************/
/*! 
\file   Functions.cpp
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 06 
\date   08/7/2019 
\brief  Implemention of several template functions that work on ranges
*/ 
/******************************************************************************/
#include <iostream> // cout, endl

/******************************************************************************/
/*!   
  This is function take in a range and copy it into a empty range.

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
  \param right      
    Iterator points to the location to copy to.

  \return
    Iterator to the start copied range.
*/ 
/******************************************************************************/
template <typename T1, typename T2> 
T2 copy(T1 front,const T1 back, T2 right)
{
  T2 tmp = right;
  while (front != back)
  {
    *tmp = *front;
    ++tmp;
    ++front;
  }
  return tmp;
}

/******************************************************************************/
/*!   
  Take in a range and a value and count the number of value specified.

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
  \param value   
    The value to count.

  \return 
    The number of value specified..
*/ 
/******************************************************************************/
template <typename T1, typename T2> 
int count(T1 front, const T1 &back, const T2 &value)
{
  int counter = 0;
  while (front != back)
  {
    if (*front == value)
      ++counter;
    ++front;
  }
  return counter;
}

/******************************************************************************/
/*!   
  Take in a range and print out the entire range

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
*/ 
/******************************************************************************/
template <typename T> 
void display(T front, const T &back)
{
  while (front != back)
  {
    std::cout << *front;
    ++front;
    if (front != back)
      std::cout << ", ";
  }
  std::cout << std::endl;
}

/******************************************************************************/
/*!   
  Take in 2 range and compare the contents to see if they are the same.

  \param front     
    Iterator points to the front of the first range.
  \param back      
    Iterator points to the back of the first range.
  \param right      
    Iterator points to the front of the second range.

  \return 
    The result of the comparison.
*/ 
/******************************************************************************/
template <typename T1, typename T2> 
bool equal(T1 front, const T1 &back, T2 right)
{
  while (front != back)
  {
    if (*front != *right)
      return false;
    ++front;
    ++right;
  }
  return true;
}

/******************************************************************************/
/*!   
  Take in a range and a value and fill the range with the value.

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
  \param value   
    The value to fill the range with.
*/ 
/******************************************************************************/
template <typename T1, typename T2> 
void fill(T1 front, const T1 &back, const T2 &value)
{
  while (front != back)
  {
    *front = value;
    ++front;
  }
}

/******************************************************************************/
/*!   
  Take in a range and find the value given

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
  \param value   
    The value to find.

  \return
    The found value.
*/ 
/******************************************************************************/
template <typename T1, typename T2> 
T1 find(T1 front, const T1 &back, const T2 &value)
{
  while (front != back)
  {
    if (*front == value)
      return front;
    ++front;
  }
  return front;
}

/******************************************************************************/
/*!   
  Take in a range and find the largest element

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
*/ 
/******************************************************************************/
template <typename T> 
T max_element(T front, const T &back)
{
  T tmp = front;
  while (front != back)
  {
    if (*tmp < *front)
      tmp = front;
    ++front; 
  }
  return tmp;
}

/******************************************************************************/
/*!   
  Take in a range and find the smallest element

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
*/ 
/******************************************************************************/
template <typename T> 
T min_element(T front, const T &back)
{
  T tmp = front;
  while (front != back)
  {
    if (*tmp > *front)
      tmp = front;
    ++front; 
  }
  return tmp;
}


/******************************************************************************/
/*!   
  Take in a range and remove the value given.

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
  \param value   
    The value to remove.

  \return
    The found list of value removed.
*/ 
/******************************************************************************/
template <typename T1, typename T2> 
T1 remove(T1 front, const T1 &back, const T2 &value)
{
  T1 newend = front;
  while (front != back)
  {
    if (*front != value)
    {
      swap(*front, *newend);
      ++newend;
    }
    ++front;
  }
  return newend; 
}

/******************************************************************************/
/*!   
  Take in a range and replace a selected value with another value given.

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.
  \param old
    The value to replace from.
  \param value
    The value to replace to.
*/ 
/******************************************************************************/
template <typename T1, typename T2> 
void replace(T1 front,const T1 &back, const T2 &old, const T2 &value)
{
  while (front != back)
  {
    if (*front == old)
      *front = value;
    ++front; 
  }
}

/******************************************************************************/
/*!   
  Take in a range and calculate the total of every element.

  \param front     
    Iterator points to the front of the range.
  \param back      
    Iterator points to the back of the range.

  \return
    The total caluculated sum
*/ 
/******************************************************************************/
template <typename T> 
T sum(T* front, const T* back)
{
  T Total = *front - *front;
  while (front != back)
  {
    Total += *front;
    ++front;
  }
  return Total;
}

/******************************************************************************/
/*!
  Swaps two objects. There is no return value but the two objects are
  swapped in place.
  
  \param left
    The first object to swap.
  \param right
    The second object to swap.
*/
/******************************************************************************/
template <typename T> 
void swap(T &left, T &right)
{
  T temp(right); // need a temporary copy
  right = left;
  left = temp;
}

/******************************************************************************/
/*!
  Swaps two range.
  
  \param front 
    Iterator points to the front of the first range.
  \param back
    Iterator points to the back of the first range.
  \param right
    Iterator points to the front of the second range.
*/
/******************************************************************************/
template <typename T1, typename T2> 
void swap_ranges(T1 front, const T1 &back, T2 right)
{
  while (front != back)
  {
    swap(*front,*right);
    ++front;
    ++right;
  }
}

