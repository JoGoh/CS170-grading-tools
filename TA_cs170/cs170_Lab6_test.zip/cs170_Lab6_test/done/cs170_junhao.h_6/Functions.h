/******************************************************************************/
/*! 
\file   Functions.h
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 06 
\date   08/7/2019 
\brief  Implemention of several template functions that work on ranges
*/ 
/******************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
  template <typename T1, typename T2> 
  T2 copy(T1 front,const T1 &back, T2 &right);
  template <typename T1, typename T2> 
  int count(T1 front,const T1 &back, const T2 &value);
  template <typename T> 
  void display(T front, const T &back);
  template <typename T1, typename T2> 
  bool equal(T1 front, const T1 &back, T2 right);
  template <typename T1, typename T2> 
  void fill(T1 front, const T1 &back, const T2 &value);
  template <typename T1, typename T2> 
  T1 find(T1 front, const T1 &back, const T2 &value);
  template <typename T> 
  T max_element(T front, const T &back);
  template <typename T> 
  T min_element(T front, const T &back);
  template <typename T> 
  T remove(T front, const T &back, const T &value);
  template <typename T1, typename T2> 
  void replace(T1 front, const T1 &back, const T2 &old, const T2 &value);
  template <typename T> 
  T sum(T* front, const T* back);
  template <typename T> 
  void swap(T &left, T &right);
  template <typename T1, typename T2> 
  void swap_ranges(T1 front, const T1 &back, T2 right);
  
  /* 
   *  Other template function declarations for count, remove, replace, etc.
   *  go here. Make sure all of your declarations are sorted in alphabetical
   *  order. This includes putting the swap function above in the proper
   *
   */ 
  
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
