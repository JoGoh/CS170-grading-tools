/*****************************************************************************/
/*!
\file Functions.h
\author Chua Lip Ming
\par email:
l.chua\@digipen.edu
\par DigiPen login:
l.chua
\par Course:
CS170-A
\par Lab #6
\date 07/07/2019
\brief This file contains the declaration of the following functions for
the Lab #6.

\par Class Member Functions include:
  copy();
  count();
  display();
  equal();
  fill();
  find();
  max_element();
  min_element();
  remove();
  replace();
  sum();
  swap();
  swap_ranges();

\par Hours spent on this assignment:
  8 hrs

\par Specific portions that gave you the most trouble:
  remove();
  sum();
*/
/*****************************************************************************/
//---------------------------------------------------------------------------
#ifndef FUNCTIONS_H
#define FUNCTIONS_H
//---------------------------------------------------------------------------

namespace CS170
{
/*****************************************************************************/
  /*copies the elements in first array to the second array*/
  template <typename T1, typename T2> 
  T2 copy(T1 left, const T1 &end, T2 right);
/*****************************************************************************/
  /*counts the number of times the item is found in the array*/
  template <typename T1, typename T2> 
  T2 count(T1 left, const T1 &end, const T2 &item);
/*****************************************************************************/
  /*prints out the array from beginning to end*/
  template <typename T> 
  void display(T left, T end);
/*****************************************************************************/
  /*checks if both arrays have the same elements*/
  template <typename T1, typename T2> 
  bool equal(T1 left, const T1 &end, T2 right);
/*****************************************************************************/
  /*fills the whole array with the specified item*/
  template <typename T1, typename T2> 
  T1 fill(T1 left, const T1 &end, const T2 &item);
/*****************************************************************************/
  /*checks if the item is found in the array*/
  template <typename T1, typename T2> 
  T1 find(T1 left, const T1 &end, const T2 &item);
/*****************************************************************************/
  /*returns the maximum value*/
  template <typename T> 
  T max_element(T left, const T &end);
/*****************************************************************************/
  /*returns the minimum value*/
  template <typename T> 
  T min_element(T left, const T &end);
/*****************************************************************************/
  /*finds and removes the item given inside the array*/
  template <typename T1, typename T2> 
  T1 remove(T1 left, const T1 &end, const T2 &item);
/*****************************************************************************/
  /*finds and replaces the old item with a new item inside the array*/
  template <typename T1, typename T2> 
  T1 replace(T1 left, const T1 &end, const T2 &olditem, const T2 &newitem);
/*****************************************************************************/
  /*summates the element values of the array*/
  template <typename T> 
  int sum(T left, const T &end);
/*****************************************************************************/
  /*swaps the values of both elements*/
  template <typename T> 
  void swap(T &left, T &right);
/*****************************************************************************/
  /*swaps all values of all elements of both arrays*/
  template <typename T> 
  void swap_ranges(T left, const T &end, T right); 
/*****************************************************************************/
  #include "Functions.cpp"
}

#endif
//---------------------------------------------------------------------------
