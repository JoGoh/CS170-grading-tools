/******************************************************************************
\file: list.cpp
\author: Ong Jia Quan Joel
\par email: o.jiaquanjoel@digipen.edu
\par DigiPen login: o.jiaquanjoel
\par Course: CS170
\par Lab 4
\date 03/06/2019
\brief This file contains the implementation of the following functions for the
Lab exercise 4.

Functions include:
make_node();
list();
~list();
print_list() const;
size() const;
empty() const;
clear();
push_front();
front();
erase(int pos);
erase(int first, int last);
resize();
sort();
merge();
merge_sort();
split_list();
merge_two_sorted_list();

******************************************************************************/

#include <iostream>
#include "list.h"

//--------- Function declaration -----------//
// Merge Sort 
void merge_sort(CS170::node *&head);

// Split into list
void split_list(CS170::node* source, CS170::node*& leftRef, 
                CS170::node*& rightRef);

// Join two list into 1
CS170::node* merge_two_sorted_list(CS170::node* a, CS170::node* b);


/************************************************************************/
/*!
  \brief
    Sort list in ascending order using merge sort method

  \param list 
   Reference to a pointer to a list

  \return
    void
*/
/************************************************************************/
void merge_sort(CS170::node *& list)
{
    CS170::node* head = list;
    CS170::node* left_list = nullptr;
    CS170::node* right_list = nullptr;

    // Exit,
    // - if no node 
    // - if only 1 node
    if ((head == nullptr) || (head->next == nullptr))
        return;

    // Split list into two list
    split_list(head, left_list, right_list);

    // Recursively sort both list 
    merge_sort(left_list);
    merge_sort(right_list);

    // list = merge the two sorted lists together 
    list = merge_two_sorted_list(left_list, right_list);
}

/************************************************************************/
/*!
  \brief
    Split list into 2 smaller list

  \param source 
   Reference to a pointer to a list 
   
  \param leftRef 
   Reference to a pointer to a smaller list to be filled up
   
  \param rightRef 
   Reference to a pointer to a smaller list to be filled up

  \return
    void
*/
/************************************************************************/
void split_list(CS170::node* source, CS170::node*& leftRef, 
                CS170::node*& rightRef)
{
    // Setup start point
    CS170::node* later = source->next;
    CS170::node* slow = source;

    // Advance 'later' two nodes, and advance 'slow' one node 
    while (later != nullptr)
    {
        later = later->next;

        if (later != nullptr)
        {
            slow = slow->next;
            later = later->next;
        }
    }

    // 'slow' is before the midpoint in the list, so split it in two 
    // at that point. 
    leftRef = source;
    rightRef = slow->next;
    slow->next = nullptr;
}

/************************************************************************/
/*!
  \brief
    Merge 2 list into 1

  \param left 
   Reference to a pointer to a list
   
  \param right 
   Reference to a pointer to another list

  \return
    return a pointer to a merged list that has been sorted
*/
/************************************************************************/
CS170::node* merge_two_sorted_list(CS170::node* left, CS170::node* right)
{
    CS170::node* result = nullptr;

    if (left == nullptr)
        return (right);
    else if (right == nullptr)
        return (left);

    // Pick either left or right, and recur
    if (left->value <= right->value)
    {
        result = left;
        result->next = merge_two_sorted_list(left->next, right);
    }
    else
    {
        result = right;
        result->next = merge_two_sorted_list(left, right->next);
    }

    return result;
}

/************************************************************************/
/*!
  \brief
    Constructor

  \return
    void
*/
/************************************************************************/
CS170::list::list()
    : list_size(0)
    , the_list(nullptr)
{
}

/************************************************************************/
/*!
  \brief
    Destructor

  \return
    void
*/
/************************************************************************/
CS170::list::~list()
{
    clear();
}

/************************************************************************/
/*!
  \brief
    Prints out the values contained in the list 

  \return
    void
*/
/************************************************************************/
void CS170::list::print_list() const
{
    CS170::node* tempList = the_list;
    while (tempList)
    {
        std::cout << tempList->value << " ";
        tempList = tempList->next;
    }
    std::cout << std::endl;
}


/************************************************************************/
/*!
  \brief
    Get size of the list 

  \return
    Returns the current size of the list 
*/
/************************************************************************/
unsigned CS170::list::size() const
{
    return list_size;
}

/************************************************************************/
/*!
  \brief
    Check if list is empty

  \return
    Returns true if list is empty, false otherwise
*/
/************************************************************************/
bool CS170::list::empty() const
{
    return (list_size == 0 ? true : false);
}

/************************************************************************/
/*!
  \brief
    Frees (deletes) all of the nodes in the list 

  \return
    void
*/
/************************************************************************/
void CS170::list::clear()
{
    while (the_list)
    {
        // Get node to delete
        node* deleteNode = the_list;

        // Go to next node
        the_list = the_list->next;

        // Delete node
        delete deleteNode;
    }
    list_size = 0;
    the_list = nullptr;
}

/************************************************************************/
/*!
  \brief
    Creates a node with val and add it to the front of the list

  \return
    void
*/
/************************************************************************/
void CS170::list::push_front(int val)
{
    // Create Node
    CS170::node *pNewNode = make_node(val);

    // Link Node
    pNewNode->next = the_list;

    // Assign new head
    the_list = pNewNode;
}

/************************************************************************/
/*!
  \brief
    Get the first node in the list 

  \return
    Return the first node in the list 
*/
/************************************************************************/
CS170::node * CS170::list::front()
{
    return the_list;
}

/************************************************************************/
/*!
  \brief
    Removes nodes at position pos. Position count starts from zero.

  \return
    void
*/
/************************************************************************/
void CS170::list::erase(int pos)
{
    // Exit 
    //- if list is empty,
    //- if out of range
    if (the_list == nullptr || pos < 0 || pos >= (int)list_size)
        return;

    // Erasing first node
    if (pos == 0)
    {
        // Record node to delete
        CS170::node* deleteNode = the_list;

        // Go to next node
        the_list = the_list->next;

        // Delete deleteNode
        delete deleteNode;

        // Decrease size
        list_size--;
    }
    // Erasing other node
    else
    {
        // Create temp list
        CS170::node* tempList = the_list;

        // Record: Previous Node
        CS170::node* prevNode = nullptr;

        // which index current node is
        int index = 0;

        while (tempList)
        {
            // Found node to erase
            if (index == pos)
            {
                // Record node to delete
                CS170::node* deleteNode = tempList;

                // Link prev node to next node
                prevNode->next = tempList->next;

                // Delete deleteNode
                delete deleteNode;

                // Decrease size
                list_size--;
                break;
            }

            // Record this node as previous
            prevNode = tempList;

            // Go to next
            tempList = tempList->next;

            // Increment index
            index++;
        }
    }
}

/************************************************************************/
/*!
  \brief
    Removes nodes from position first to position last-1.

  \param first 
   starting point of the range to delete 
   
  \param last 
   ending point of the range to delete 

  \return
    void
*/
/************************************************************************/
void CS170::list::erase(int first, int last)
{
    // Exit 
    //- if list is empty,
    if (the_list == nullptr)
        return;

    // Create temp list
    CS170::node* tempList = the_list;

    // Record: Previous Node
    CS170::node* prevNode = nullptr;

    // which index current node is
    int index = 0;

    while (tempList)
    {
        // Found node to erase
        if (index >= first && index < last)
        {
            // Record node to delete
            CS170::node* deleteNode = tempList;

            // Link prev node to next node
            if(prevNode != nullptr)
                prevNode->next = tempList->next;
            
            // Link main list to something
            if(the_list == tempList)
                the_list = tempList->next;
            
            // Go to next
            tempList = tempList->next;

            // Delete deleteNode
            delete deleteNode;

            // Decrease size
            list_size--;
        }
        else
        {
            // Record this node as previous
            prevNode = tempList;

            // Go to next
            tempList = tempList->next;
        }

        // Increment index
        index++;

    }
    

}

/************************************************************************/
/*!
  \brief
    Resizes the list to contain n elements.

  \param n 
   resize list to size of n
   
  \param val 
   If n is larger than the current size, the new elements
   are initialized as val

  \return
    void
*/
/************************************************************************/
void CS170::list::resize(int n, int val)
{
    // Node to add
    int diff = n - size();

    // Reducing list
    if (diff < 0)
    {
        // remove from the list ranging from n to size of list
        erase(n, size());
    }
    // Expanding list
    else
    {
        while (diff)
        {
            // Push back
            node *newNode = make_node(val);
            node *tempList = the_list;

            if (the_list == nullptr)
                the_list = newNode;
            else 
            {
                while (tempList->next)
                    tempList = tempList->next;

                tempList->next = newNode;
            }
            --diff;
        }
    }
}

/************************************************************************/
/*!
  \brief
    Sorts the list ascendingly

  \return
    void
*/
/************************************************************************/
void CS170::list::sort()
{
    merge_sort(the_list);
}

/************************************************************************/
/*!
  \brief
    Merge 2 list into 1

  \param l2 
   Reference to a list

  \return
    void
*/
/************************************************************************/
void CS170::list::merge(list & l2)
{
    // Create a temp node to contain our this->list
    CS170::node* list1 = the_list;
    CS170::node* list2 = l2.front();

    //- If List 1 is not empty,
    if (list1 != nullptr)
    {
        // Find the last node of list1
        while (list1->next != nullptr)
            list1 = list1->next;

        // Concat every node from list2 to list1
        while (list2 != nullptr)
        {
            list1->next = make_node(list2->value);
            list1 = list1->next;
            list2 = list2->next;
        }
    }
    //- If list 1 is empty,
    else
    {
        //- If list 2 is not empty
        if (list2 != nullptr)
        {
            // original list = list 2
            the_list = make_node(list2->value);
            list1 = the_list;
            list2 = list2->next;
            
            // Assign the remaining node from list 2 to list 1
            while (list2 != nullptr)
            {
                list1->next = make_node(list2->value);
                list1 = list1->next;
                list2 = list2->next;
            }
            
        }
    }
    l2.clear();

    sort();
}

/************************************************************************/
/*!
  \brief
    create a new node

  \param val 
    value the node will contain

  \return
    Return a node
*/
/************************************************************************/
CS170::node * CS170::list::make_node(int val)
{
    CS170::node *pNode = new CS170::node;
    pNode->value = val;
    pNode->next = nullptr;
    list_size++;
    return pNode;
}

