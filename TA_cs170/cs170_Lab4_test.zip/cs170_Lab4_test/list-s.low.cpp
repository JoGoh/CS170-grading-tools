/******************************************************************************
\file: list.cpp
\author: Low Seng Tat Darren
\par email: s.low@digipen.edu
\par DigiPen login: s.low
\par Course: CS170
\par Lab 4
\date 07/06/2019
\brief This file contains the implementation of the following functions for the
Lab exercise 4.

Functions include:
list();
~list();
print_list();
size();
empty();
clear();
push_front();
front();
erase(pos);
erase(first, last);
resize();
sort();
merge();
make_node();

******************************************************************************/

#include <iostream>
#include "list.h"

namespace CS170
{
    // Helper function for the merge sort
    node *merge_sorted_list(node* left, node* right);
    node *get_middle(node *&list); 
    void merge_sort(node *&list);
    
    /**
        Constructor for list. */
    /*!
        @return void
    */
    list::list()
    : list_size(0)
    , the_list(nullptr)
    {
        
    }
    
    /**
        Deconstructor for list. */
    /*!
        @return void
    */
    list::~list()
    {
        clear();
    }
    
    /**
        Function to print the whole link list */
    /*!
        @return void
    */
    void list::print_list() const
    {
        node *list = the_list;
        while (list) 
        {
            std::cout << list->value << " ";
            list = list->next;
        }
        std::cout << std::endl;
    }
    
    /**
        Get size of list  */
    /*!
        @return size of the list
    */
    unsigned list::size() const
    {
        return list_size;
    }
    
    /**
        Function that returns true if list is empty, false otherwise */
    /*!
        @return bool depending on if the list is empty
    */
    bool list::empty() const
    {
        if (list_size)
            return false;

        return true;
    }
    
    /**
        Function to clear the list */
    /*!
        @return void
    */
    void list::clear()
    {
        node *pCurrNode = the_list;
        while (pCurrNode) 
        {
            the_list = pCurrNode->next;
            delete pCurrNode;
            pCurrNode = the_list;
            --list_size;
        }
        the_list = nullptr;
    }
    
    /**
        Function that adds from front of the list */
    /*!
        @param val: value given to the new node
        @returns void
    */
    void list::push_front(int val)
    {
        node *pNewNode = make_node(val);
        pNewNode->next = the_list;
        the_list = pNewNode;  
    }
    
    /**
        Function that returns the first node in the List */
    /*!
        @returns first node in the list
    */
    node * list::front()
    {
        return the_list;
    }
    
    /**
        Function that removes nodes from position given */
    /*! 
        @param pos: The desired position
        @returns void
    */
    void list::erase(int pos)
    {
        if(the_list == nullptr || pos < 0 || pos >= (int)list_size)
            return;
        
        node *curNode = the_list;
        node *prevNode = nullptr;
        
        // Check to erase first node
        if(pos == 0)
        {
            // Set prevNode to be deleted
            prevNode = curNode;
            // Set new head
            curNode = curNode->next;
            the_list = curNode;
            delete prevNode;
            --list_size;
        }
        else
        {
            // Loop to find the position of node
            for(int i = 0; i < pos; i++)
            {
                if(curNode->next)
                {
                    prevNode = curNode;
                    curNode = curNode->next;
                }
            }
            
            // Check if last node or not
            if(curNode->next)
                // Link up the list before delete middle node
                prevNode->next = curNode->next;
            else
                prevNode->next = nullptr;
            
            delete curNode;
            --list_size;
        }
    }
    
    /**
        Function that removes nodes from given range */
    /*!
        @param first: The first position
        @param last: The last position
        @returns void
    */
    void list::erase(int first, int last)
    {
        node *curNode = the_list;
        node *prevNode = nullptr;
        int index = 0;
        
        if(the_list == nullptr)
            return;
        
        while(curNode)
        {
            // Check if in range to delete
            if (index >= first && index < last)
            {
                node *deleteNode = curNode;
                
                // Link to next next node before delete
                if(prevNode)
                    prevNode->next = curNode->next;
                
                // Check if deleting first node
                if(the_list == curNode)
                    the_list = curNode->next;
                
                curNode = curNode->next;
                delete deleteNode;
                -- list_size;
            }
            else
            {
                // Move node
                prevNode = curNode;
                curNode = curNode->next;
            }
            
            // Increment the index
            ++index;
        }
    }
    
    /**
        Function that resizes the size of the list and adds a 
        value to the new nodes if list is smaller */
    /*!
        @param n: size of list given to change
        @param val: value given to the new node
        @returns void
    */
    void list::resize(int n, int val)
    {
        int diff = n - size();
        
        if(diff < 0)
        {
            // Clear list from n to size of list
            erase(n, size());
        }
        else
        {
            while (diff)
            {
                // Push back function
                node *newNode = make_node(val);
                node *tempList = the_list;

                if (the_list == nullptr)
                    the_list = newNode;
                else 
                {
                    while (tempList->next)
                        tempList = tempList->next;

                    tempList->next = newNode;
                }
                --diff;
            }
        }
    }
    
    /**
        Function that get the middle node in list */
    /*!
        @param list: reference to the list 
        @return middle node
    */
    node *get_middle(node *&list)
    {
        if (list == nullptr)
          return list;

        node *middle = list;
        node *fast = list;

        // Fast node will be 2x faster
        // So slower node will stop at middle
        while (fast->next && fast->next->next)
        {
            middle = middle->next;
            fast = fast->next->next;
        }
        return middle;
    }
    
    /**
        Function that merge two list together */
    /*!
        @param left: reference to the left list
        @param right: reference to the right list 
        @return head node
    */
    node *merge_sorted_list(node* left, node* right)
    {
        
        if (left == nullptr || right == nullptr)
            return nullptr;

        node *headNode = nullptr;
        node *curNode = nullptr;

        // Check left or right smaller and set it as head
        if (left->value < right->value)
        {
            headNode = left;
            left = left->next;
        }
        else
        {
            headNode = right;
            right = right->next;
        }

        // Assign the current node to the head node
        curNode = headNode;

        // Loop through remainder of right and left list
        while(left && right)
        {
            // Check for smaller node and set it next
            if (left->value < right->value)
            {
                curNode->next = left;
                left = left->next;
            }
            else
            {
                curNode->next = right;
                right = right->next;
            }
            curNode = curNode->next;
        }

        // Check for remainder and add to list
        if (left)
          curNode->next = left;
        else
          curNode->next = right;

        // Return the list
        return headNode;
    }
    
    /**
        Function that sort nodes in list */
    /*!
        @param list: reference to the list 
        @return void
    */
    void merge_sort(node *&list)
    {
        if (list == nullptr || list->next == nullptr)
            return;

        // Initialise the node
        node *left_list = list;
        node *middle = get_middle(list);
        node *right_list = middle->next;
        
        //To set end of left list
        middle->next = nullptr;

        // Sort left and right list
        merge_sort(left_list);
        merge_sort(right_list);

        // Merge sorted list 
        list = merge_sorted_list(left_list, right_list);
    }
    /**
        Function to sort list */
    /*!
        @returns void
    */
    void list::sort()
    {
        merge_sort(the_list);
    }
    
    /**
        Function that merges 2 lists in order and deletes the other */
    /*!
        @param l2: reference to second list
        @returns void
    */
    void list::merge(list & l2)
    {
        node *list1 = the_list;
        node *list2 = l2.front();

        // Loop to last element of list 1
        if (list1 != nullptr)
        {
            while (list1->next)
                list1 = list1->next;
        
            // Add every node from list2 into list1
            while (list2)
            {
                list1->next = make_node(list2->value);
                list1 = list1->next;
                list2 = list2->next;
            }
        }
        else
        {
            if (list2 != nullptr)
            {
                the_list = make_node(list2->value);
                list1 = the_list;
                list2 = list2->next;
                
                // Loop through entire list2
                while (list2)
                {
                    // Create new nodes and add into list 1
                    list1->next = make_node(list2->value);
                    list1 = list1->next;
                    list2 = list2->next;
                    
                }
            }
        }

        // Clear list 2
        l2.clear();

        // Sort the list in order
        sort();
    }
    
    /**
        Function to create a new node */
    /*!
        @param val: value given to the node
        @return a pointer to a node
    */
    node * list::make_node(int val)
    {
        node *pNode = new node;
        pNode->value = val;
        pNode->next = nullptr;  
        ++list_size;
        return pNode;
    }
}