/***********************************************************************/
/*!     
\file   list.cpp
\author Samuel Chee
\par    email: chee.k\@digipen.edu
\par    Digipen login: chee.k
\par    Course: CS170
\par    Lab 04
\date   08/06/2019
\brief This file contains the implementation of the following functions for the 
Lab 04 assignment.
Functions include:

make_node(int val);

list();

~list();

print_list() const;

size() const;

empty() const;

clear();

push_front(int val);

front();

erase(int pos);

erase(int first, int last);

resize(int n, int val = 0);

sort();

merge(list &l2);

*/
/***********************************************************************/

#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here
namespace CS170 
{
/*****************************************************************************/
/*!      
\fn list::make_node

\brief Function takes in a value and creates a new struct node with said value.

\param val
    Value used to make a new node.

*/
/*****************************************************************************/
    node *list::make_node(int val)
    {
    node *pNode = new node;
    pNode->value = val;
    pNode->next = nullptr;
    return pNode;
    }
/*****************************************************************************/
/*! 
\fn list::list

\brief Constructor that builds list object with default values.

*/
/*****************************************************************************/
    list::list()
    {
    //Initialise default values
    list_size=0;
    the_list= nullptr;
    }
/*****************************************************************************/
/*! 
\fn list::~list

\brief Destructor that destroys list object 

*/
/*****************************************************************************/
    list::~list()
    {
    clear();//Call to destroy all nodes in list
    }
/******** *********************************************************************/
/*!    
\fn list::print_list

\brief Function that prints list values and is read-only.

*/
/*****************************************************************************/
    void list::print_list() const
    {
    node* current = the_list;
    while (current) {
    std::cout << current->value << " ";
    current = current->next;
    }
    std::cout << std::endl;  
    }
/*****************************************************************************/
/*!     
\fn list::size

\brief Getter Function that returns the size of the list
            
\return unsigned
    Number of nodes in the list.
*/
/*****************************************************************************/
    unsigned list::size() const
    {
    return list_size;//Get list size
    }
/*****************************************************************************/
/*!     
\fn list::empty

\brief Function checks size of list and returns if it is empty or not
            
\return bool
    Boolean value whether list is empty.
*/
/*****************************************************************************/
    bool list::empty() const
    {
    if(list_size==0)
        return 1;//If empty returns true
    else 
        return 0;//Else is false
    }
/*****************************************************************************/
/*!       
\fn list::clear

\brief Function deletes the entire list.

*/
/*****************************************************************************/
    // Frees (deletes) all of the nodes in the list 
    void list::clear()
    {
    struct node *previous;
    if(the_list!=nullptr)
    while(the_list->next)/*Loop to run till last node*/
    {
    previous=the_list;/*Assign pointer to current node*/
    the_list =the_list->next;/*Shift pList pointer to next node*/
    delete previous;/*Free previous node*/
    }
    delete the_list;/*Free last node*/
    the_list=nullptr;
    }
/*****************************************************************************/
/*!     
\fn list::push_front

\brief Function takes in  an int.and adds new nodes to the front.

\param val
    Value input to be added to linked list
*/
/*****************************************************************************/
    void list::push_front(int val)
    {
    struct node *pNode= make_node (val);//Create new node with value input
    pNode->next = the_list;/*Assigning new node path to old node*/
    the_list = pNode;/*Shifting pointer to newest node,
                    ends at node furthest from end*/
    list_size++;
    }
/*****************************************************************************/
/*!     
\fn list::front

\brief Getter Function that returns the first node of the list
            
\return node*
   Address of first node in list
*/
/*****************************************************************************/
    // Return the first node in the list 
    node *list::front()
    {
        return the_list;//Get first node in the list
    }
    
/*****************************************************************************/
/*!     
\fn list::erase(int)

\brief  Function that takes in an int and deletes a node in a list.
            
\param pos
    Position of nodes in the list.
*/
/*****************************************************************************/
    void list::erase(int pos)
    {
        if(pos<0 || the_list==nullptr)
            return;
        if(pos>static_cast<int>(list_size))
            return;
        if(pos==0)//First node to be removed,special case
        {
            node* target = the_list;
            if(the_list!=nullptr)
            the_list= the_list->next;//Re-assign start of list
            delete target;//delete first node
            list_size--;
        }
        else
        {
            node* previous = the_list;//Assign pointer to track previous node
            node* target = previous->next;//Check from first node onwards
            //For loop to get to target node
            for(int count =1; count<pos;count++)
            {
                target=target->next;//Shift nodes 
                previous=previous->next;
            }
            previous->next=target->next;//Alter path of previous node
            delete target;//Delete target node
            list_size--;
            target=nullptr;
        }
    }
/*****************************************************************************/
/*!     
\fn list::erase(int,int)

\brief  Function that takes in two ints and deletes nodes in a range.
            
\param first
    Start Position of nodes in the list.
    
\param last
    End Position of nodes in the list
*/
/*****************************************************************************/
    void list::erase(int first, int last)
    {
        int count=0;
        if(first<0 || last<0||the_list==nullptr|| first==last)
            return;
        do
        {
            erase(first);
        }while(++count!=last-first);
    }
    
/*****************************************************************************/
/*!     
\fn list::resize

\brief  Function that takes in two ints, number and value, and resizes 
        the list depending one required size and makes nodes with input value
            
\param n
    Number of nodes to be in the list.
    
\param val
    Value of all new nodes
*/
/*****************************************************************************/
    void list::resize(int n, int val)
    {
        //If no resizing required or n is negative
        if((n)==static_cast<int>(list_size)|| n<0)
            return;
    
        if(n<static_cast<int>(list_size))//Shrink list
        {
            while(static_cast<int>(list_size)!=n)
            {
                erase(n , static_cast<int>(list_size));
            }
            return;
        }
        else if(n>static_cast<int>(list_size)) //Expand list
        {
            if(the_list==nullptr)
            {
                node* fNode=make_node(val);
                the_list= fNode;
                list_size++;
            }
            node* end=the_list;
            
            while(end->next!= nullptr)
            {
                //Find last node
                end=end->next;
            }
            
            //For list size smaller than n elements
            for(;static_cast<int>(list_size)<n;++list_size)
            {
                /*Create new node and assign to end*/
                node* nNode= make_node(val);
                end->next= nNode;
                end= end->next;
            }
        }
    }
/*****************************************************************************/
/*!     
\fn list::sort

\brief  Function that sorts a list in ascending order

*/
/*****************************************************************************/
    // Sorts the list ascendingly
    void list::sort()
    {
        //Only one element or empty
    if(the_list==nullptr|| the_list->next ==nullptr)
        return;
    node* end = nullptr;//Pointer to end of loop
    int swapCount;//Counter to check swap action
    do
    {
        node* curr=the_list;//Initialise to start of list every loop
        swapCount=0;//Initialise to zero to check for swapping
        while(curr->next != end)
        {
            if(curr->value > curr->next->value)
            {
                int temp = curr->value;//Save current value to temp 
                curr->value = curr->next->value;//Swap the values 
                curr->next->value = temp;
                swapCount=1;//Increment the swap counter
                
            }
            curr = curr->next;
            
        }
        
        end = curr;//Assign new end of loop
    }while(swapCount);//To continue looping until no swaps left
    }
        
/*****************************************************************************/
/*!     
\fn list::merge 

\brief  Function that takes in reference to a list object and merges it into 
        current list. And merged list will be in ascending order.
            
\param l2
    Reference to second list.

*/
/*****************************************************************************/
    void list::merge(list &l2)
    {
        
        if(the_list==nullptr)
        {
            the_list=l2.front();
            sort();
            list_size+=l2.size();
            l2.list_size= 0;
            l2.the_list=nullptr;
            return;
        }
        else if(l2.the_list==nullptr)
            return;
        
        node* current2 = l2.front();
        //node* prev = nullptr;
        node* current1 = the_list;
        //Find node before the end
        while(current1->next!=nullptr)
        {
            current1 = current1->next;
        }
        
        //Concatenate lists together
        current1->next = current2;
        //sort values
        sort();
        list_size+= l2.size();
        l2.list_size= 0;
        l2.the_list=nullptr;
    }
}