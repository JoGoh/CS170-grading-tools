/**************************************************************************************************************/
/*!
\file   list.cpp
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 04
\date   10/6/2019
\brief
  Implementation of functions (such as adding or deleting nodes from a Linked List)
*/
/**************************************************************************************************************/
#include <iostream>
#include "list.h"

/**************************************************************************************************************/
/*!
  \namespace CS170
  \brief Namespace that contains the class list, struct node and definitions of other functions used for the list
*/
/**************************************************************************************************************/
namespace CS170 {
/**************************************************************************************************************/
/*!
	\fn node* list::make_node(int val)
	\brief Creates Nodes to be added to the Linked list using new. Allocate memory and set members.
	\param val int value that the Node is supposed to hold
	\return Returns a Reference to a node (with given int value) to be added to the linked list
*/
/**************************************************************************************************************/
node* list::make_node(int val) {
	//Create a new node using new
	node* pNode = new node();
	//Initialize node with data
	pNode->value = val;
	pNode->next = nullptr;
	return pNode;
}

/**************************************************************************************************************/
/*!
	\fn list::list()
	\brief Constructor to initialize the list
*/
/**************************************************************************************************************/
list::list() {
	this->the_list = nullptr;
	this->list_size = 0;
}

/**************************************************************************************************************/
/*!
	\fn list::~list()
	\brief Destructor to empty the list and release the allocate memory
*/
/**************************************************************************************************************/
list::~list() {
	clear();
}

/**************************************************************************************************************/
/*!
	\fn void list::print_list() const
	\brief Prints all the Nodes values in the Linked list using cout
*/
/**************************************************************************************************************/
void list::print_list() const {
	//Go through the list 
	node* pCurrNode = the_list;
	while (pCurrNode) {
		//print out the value of each node
		std::cout << pCurrNode->value << " ";
		pCurrNode = pCurrNode->next;
	}

	std::cout << std::endl;
}

/**************************************************************************************************************/
/*!
	\fn unsigned list::size() const
	\brief Counts all the Nodes in the Linked List
	\return Returns the number (unsigned int) of Nodes in the Linked list
*/
/**************************************************************************************************************/
unsigned list::size() const {
	return list_size;
}

/**************************************************************************************************************/
/*!
	\fn bool list::empty() const
	\brief Checks if the list is empty.
	\return Returns true if the list is empty, returns false otherwise.
*/
/**************************************************************************************************************/
bool list::empty() const {
	//If the head of the list is a nullptr, the list is empty
	if (the_list == nullptr) {
		return true;
	}
	else {
		return false;
	}
}


/**************************************************************************************************************/
/*!
	\fn void list::clear()
	\brief Frees (deletes) all of the nodes in the list
*/
/**************************************************************************************************************/
void list::clear() {
	//If the head of the list is a nullptr, the list is already empty
	if (the_list == nullptr) {
		return;
	}

	node* pCurrNode = the_list;
	node* pNextNode;
	//Loop through the list
	while (pCurrNode) {
		pNextNode = pCurrNode->next;
		//Delete the Node
		delete pCurrNode;
		pCurrNode = pNextNode;
	}

	//Dont leave the node dangling
	the_list = nullptr;
	list_size = 0;
}

/**************************************************************************************************************/
/*!
	\fn list::push_front(int val)
	\brief Push a node (with the given value) to the front of the Linked List.
	\param val int value of the node to be added
*/
/**************************************************************************************************************/
void list::push_front(int val) {
	//If the head of the list is a nullptr, the list is empty
	if (the_list == nullptr) {
		//The added node becomes the head of the list (and the only node in the list)
		the_list = make_node(val);
	}
	else {
		//The added node becomes the head of the list (linking to the previous first node of the list)
		node* pNewNode = make_node(val);
		pNewNode->next = the_list;
		the_list = pNewNode;
	}
	//Increment the list size
	list_size += 1;

}


/**************************************************************************************************************/
/*!
	\fn list::front()
	\brief Retrieves the node in the front of the list.
	\return Return the node from the front of the list
*/
/**************************************************************************************************************/
node* list::front() {
	return the_list;
}

/**************************************************************************************************************/
/*!
	\fn list::erase(int pos)
	\brief Removes (Deletes) nodes at position pos. Position count starts from zero.
	\param pos (int) pos where Node should be removed in the list.
*/
/**************************************************************************************************************/
void list::erase(int pos) {

	//If the head of the list is a nullptr, the list is empty
	if (the_list == nullptr) {
		return;
	}
	else if (pos < 0) {
		//Test if the input is negative
		return;
	}

	node* pNextNode = (the_list->next);

	//Special Case Scenario if pos 0, there is no previous node to link to the next node.
	if (pos == 0) {
		delete the_list;
		//Make next node head of the list
		the_list = pNextNode;
		list_size -= 1;
		return;
	}

	//Else if not 0
	node* pPrevNode = the_list;
	//Loop until PrevNode reaches the one before stated position. 
	for (int iCnt = 0; iCnt < (pos - 1); iCnt++) {

		//There should not be any null pointer in PrevNode unless the position is larger than the size of the list
		if (pPrevNode == nullptr) {
			return;
		}
		else {
			pPrevNode = pPrevNode->next;
		}
	}
	node* pCurrNode = (pPrevNode->next);

	//Prematurely end the method if its a nullptr
	if (pCurrNode == nullptr) {
		return;
	}
	else {
		//Destroy the CurrNode and link the PrevNode to the NextNode	
		pNextNode = (pCurrNode->next);
		delete (pCurrNode);
		pPrevNode->next = pNextNode;
		pCurrNode = nullptr;
		list_size -= 1;
	}


}

/**************************************************************************************************************/
/*!
\fn list::erase(int first, int last)
\brief Removes (Deletes) nodes from position first to position last-1. Position count starts from zero. 
Will disregard cases where the first >= last, where the first pos or last pos are negative 
and where the start pos is larger than the list size.
If the last position is larger than the list size, all nodes leading to the last node (starting from first node)
will be deleted.
\param first (int) pos of the first Node that should be deleted.
\param last (int) pos of the Node after the last Node to be deleted.
*/
/**************************************************************************************************************/
void list::erase(int first, int last) {
	//These are all checks to ensure that the input is valid.

	if (the_list == nullptr) {
		//Test if list is empty
		return;
	}
	else if (first >= last) {
		//Test if the first position comes later than the last position
		return;
	}
	else if (first < 0 || last < 0) {
		//Test if the input is negative
		return;
	}

	if (first == 0) {
		//SCENARIO IN WHICH DELETING FROM START OF THE LIST
		node* pCurrNode = the_list;
		node* pPrevNode;
		for (int iCnt = 0; iCnt < last; iCnt++) {
			//There should not be any null pointer unless the position is larger than the size of the list
			if (pCurrNode == nullptr) { 
				the_list = nullptr;
				list_size = 0;
				return;
			}
			else {
				pPrevNode = pCurrNode;
				pCurrNode = (pCurrNode->next);
				delete pPrevNode;
			}
		}
		the_list = pCurrNode;

	} else {
		//SCENARIO IN WHICH DELETING FROM ANY OTHER CROSS SECTION OF THE LIST
		//FromNode is to be linked to ToNode, to 'seal the gap' made by deleting the range of nodes
		node* pFromNode = the_list;
		node* pToNode;

		//Similar to erase(pos), loop through the list to get FromNode one off the position to delete
		for (int iCnt = 0; iCnt < (first-1); iCnt++) {

			//There should not be any null pointer unless the position is larger than the size of the list
			if (pFromNode == nullptr) {
				return;
			}
			else {
				//Progress through the list
				pFromNode = (pFromNode->next);
			}
		}

		//Prematurely end the method if its a nullptr
		if (pFromNode == nullptr) {
			return;
		}
		else {
			//Initialize ToNode
			pToNode = pFromNode;
			pToNode = (pToNode->next);
			node* pCurrNode;

			//Loop through the list, get the position of the To Node
			for (int iCnt = first; iCnt < last ; iCnt++) {

				//If pToNode meets a nullptr, that means the last position is larger than the list size
				if (pToNode == nullptr) {
					pFromNode->next = nullptr;
					list_size -= (iCnt - first);
					return;
				}
				else {
					//Delete every Node along the way
					pCurrNode = pToNode;
					pToNode = pToNode->next;
					delete pCurrNode;
				}
			}
			//Afterwards, link the FromNode to the ToNode
			pFromNode->next = pToNode;
		}


	}
	//Change the list size accordingly
	list_size -= (last - first);
}

/**************************************************************************************************************/
/*!
\fn list::resize(int n, int val = 0)
\brief Resizes the list to contain n elements. 
If n is smaller than the current size, then keep only the first n elements, then destroy those beyond.
If n is larger than the current size, the new elements are initialized as val. 
If n is 0 or negative, list::clear() will be called instead.
\param n (int) No of elements that the list should be resized to.
\param val (int) If any new Nodes are added, they will be created with a value of val. The default value is 0
*/
/**************************************************************************************************************/
void list::resize(int n, int val /*=0*/) {
	//If n is less than or equal 0, that is basically removing all nodes. Hence call the clear function 
	if (n <= 0) {
		clear();
		return;
	}

	//Initialize the List
	if (the_list == nullptr) {
		the_list = make_node(val);
	}

	node* pCurrNode = the_list;
	node* pNextNode = pCurrNode->next;
	//We only need a for loop, as we are given the amount of nodes we need to pass through
	//Hence pass through the given number of nodes (aka n)
	for (int iCnt = 1; iCnt < n; iCnt++) {

		//If we meet a nullptr, that means the size of the list is smaller than the resize, hence we must add onto the list
		if (pNextNode == nullptr) {
			pNextNode = make_node(val);
			pCurrNode->next = pNextNode;
		}

		//Continue to progress through the list
		pNextNode = pNextNode->next;
		pCurrNode = pCurrNode->next;
	}

	//Since the resize has ended, we can just end off the list. Regardless of whether the list size was bigger or smaller than resize
	pCurrNode->next = nullptr;

	//However, if there are still more nodes after this, the list was bigger than the resize dictated by n. We need to delete the remaining nodes.
	while (pNextNode) {
		//Delete every Node along the way
		pCurrNode = pNextNode;
		pNextNode = pNextNode->next;
		delete pCurrNode;
	}
		

	//Set the list size to the new size
	list_size = n;
}

/**************************************************************************************************************/
/*!
\fn void split_list_frm_node(node* pList, node*& pList1, node*& pList2)
\brief Splits the lists into half. Used in the sorting method for the list class.
\param pList Reference to the pointer of the Node that acts as the head of the Linked list. This is the main List which will be split.
\param pList1 Reference to the pointer of the Node that acts as the head of the Linked list. This is where the first half of the List will be stored.
\param pList2 Reference to the pointer of the Node that acts as the head of the Linked list This is where the second half of the List will be stored.
*/
/**************************************************************************************************************/
void split_list_frm_node(node* pList, node*& pList1, node*& pList2) {
	//Check for nullptr
	if (pList == nullptr) {
		return;
	}

	//Fast Node is always 2 Nodes ahead of the first node.
	node* fast_node = (pList->next);
	node* slow_node = pList;

	//If FastNode is nullptr, it has reached the end of the list
	//The SlowNode should hence have reached midpoint the list
	while (fast_node) {
		fast_node = (fast_node->next);
		if (fast_node) {
			fast_node = (fast_node->next);
			slow_node = (slow_node->next);
		}
	}

	//Take the list before the slow_node as list1, take the one after as list2
	pList2 = (slow_node->next);
	slow_node->next = nullptr;
	pList1 = pList;
}
/**************************************************************************************************************/
/*!
\fn node* merge_list_frm_node(node*& pList1, node*& pList2)
\brief Merges pList1 and 2 together into a sorted list. Used in the sorting method for the list class.
\param pList1 Reference to the pointer of the Node that acts as the head of Linked list 1
\param pList2 Reference to the pointer of the Node that acts as the head of Linked list 2
\return Returns the Pointer of the head of the Merged List
*/
/**************************************************************************************************************/
node* merge_list_frm_node(node*& pList1, node*& pList2) {
	//If any one list is null, we can just return the other list
	if (pList1 == nullptr) {
		return pList2;
	}
	else if (pList2 == nullptr) {
		return pList1;
	}

	//Start off the MergedList, this code is to initialize MergedList with a Node
	node* pMergedList = nullptr;
	if ((pList1->value) <= (pList2->value)) {
		//1st list is smaller, add to list
		pMergedList = pList1;
		pList1 = (pList1->next);
	}
	else {
		//2nd List is smaller, add to list
		pMergedList = pList2;
		pList2 = (pList2->next);
	}
	node* pCurrNode = pMergedList;

	//Progress through both lists
	while ((pList1 != nullptr) && (pList2 != nullptr)) {
		if ((pList1->value) <= (pList2->value)) {
			//If 1st list is smaller, add to list
			pCurrNode->next = pList1;
			pList1 = (pList1->next);
		}
		else {
			//If 2nd list is smaller, add to list
			pCurrNode->next = pList2;
			pList2 = (pList2->next);
		}
		//Progress through the list
		pCurrNode = (pCurrNode->next);
	}

	//If any one list is null, all values have been read from it and we can add the remainder of the 2nd list
	if (pList1 == nullptr) {
		pCurrNode->next = pList2;
	}
	else if (pList2 == nullptr) {
		pCurrNode->next = pList1;
	}


	return pMergedList;
}

/**************************************************************************************************************/
/*!
\fn void merge_sort_frm_node(node*& pList)
\brief Sorts the elements in the Linked List (using MergeSort).Used in the sorting method for the list class.
\param pList Reference to the pointer of the Node that acts as the head of the Linked list
*/
/**************************************************************************************************************/
void merge_sort_frm_node(node*& pList) {
	if ((pList == nullptr) || ((pList->next) == nullptr)) {
		return;
	}
	else {

		//Perform MergeSort
		node* pList1 = nullptr;
		node* pList2 = nullptr;

		//Split the list into two parts
		split_list_frm_node(pList, pList1, pList2);
		//Then recursively sort the two lists individually.
		merge_sort_frm_node(pList1);
		merge_sort_frm_node(pList2);

		//Then merge the two lists together
		pList = merge_list_frm_node(pList1, pList2);
	}

}

/**************************************************************************************************************/
/*!
\fn void list::sort()
\brief Sorts the the Linked List (by calling void merge_sort_frm_node(node*& pList) ).
*/
/**************************************************************************************************************/
void list::sort() {
	merge_sort_frm_node(the_list);
}


/**************************************************************************************************************/
/*!
\fn void list::merge(list& l2)
\brief Assume the current list and l2 are both sorted ascendingly, this function merges them into one, 
so that the elements are still in ascending order.
The current list will store the merged elements, while l2 will become empty.
\param l2 Reference to List 2
*/
/**************************************************************************************************************/
void list::merge(list& l2) {
	node* pList2 = l2.front();
	the_list = merge_list_frm_node(the_list, pList2);
	list_size += l2.list_size;
	l2.the_list = nullptr;
	l2.list_size = 0;
}
}