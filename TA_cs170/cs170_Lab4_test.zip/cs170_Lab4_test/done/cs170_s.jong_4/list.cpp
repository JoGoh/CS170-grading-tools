/******************************************************************************/
/*!
\file list.cpp
\author Jong Sze kuan Melvin
\par email: s.jong\@digipen.edu
\par DigiPen login: s.jong
\par Course: CS170a
\par Lab 04
\date 10/06/2019
\brief
 This files contain functions
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

using namespace std;
namespace CS170 {
 /******************************************************************************/
/*!
 \brief
  Constructor for list. Creates an empty list
*/
/******************************************************************************/ 
list::list() : list_size(0), the_list (nullptr) {}

/******************************************************************************/
/*!
 \brief
  Destructor for list. Empty the list and release the allocated memory 
*/
/******************************************************************************/
  list::~list()
  {
    clear();
    list_size = 0;
    the_list = nullptr;
  }
 /******************************************************************************/
/*!
 \fn node *list::make_node
 \brief
  Allocate memory and set members
 \param int val
\return
Return pNode
*/
/******************************************************************************/
  node *list::make_node(int val)
  {
    node *pnode = new node;
    pnode->value = val;
    pnode->next = nullptr;  
    return pnode;
	}
 /******************************************************************************/
/*!
 \fn void list::print_list
 \brief
  Prints out the values contained in the list
*/
/******************************************************************************/
  void list::print_list()const
  {
    node *tmp = the_list;
    
    while (tmp != nullptr)
    {
      std::cout << tmp->value << " ";
      tmp = tmp->next;
    }
     std::cout << std::endl; 
  }
 /******************************************************************************/
/*!
 \fn unsigned list::size
 \brief
 Returns the current size of the list 
\return
Return length
*/
/******************************************************************************/
   unsigned list::size() const
   {
     node *tmp = the_list;
     unsigned length = 0;
     
     while (tmp)
     {
       tmp = tmp -> next;
       length++;
     }
      return length;
  }
 /******************************************************************************/
/*!
 \fn bool list::empty
 \brief
  Returns true if list is empty, false otherwise
\return
Return true or false
*/
/******************************************************************************/
  bool list::empty()const
  {
    if (the_list == nullptr)
        return true;
    else
        return false;     
  }
  /******************************************************************************/
/*!
 \fn void list::clear
 \brief
  Frees (deletes) all of the nodes in the list 
*/
/******************************************************************************/     
  void list::clear()
  {
    node *pcurrnode = the_list;
    
    while (pcurrnode) 
    {
        the_list = pcurrnode->next;
        delete pcurrnode;
        pcurrnode = the_list;
    }
      the_list = nullptr;
  }
 /******************************************************************************/
/*!
 \fn void list::push_front
 \brief
  Creates a node with val and add it to the front of the list
 \param int val
*/
/******************************************************************************/
  void list::push_front(int val)
  {
	  node *pnewnode = make_node(val);
    pnewnode->next = the_list;
    the_list = pnewnode;
  }
 /******************************************************************************/
/*!
 \fn node *list::front
 \brief
  Return the first node in the list 
\return
Return the_list
*/
/******************************************************************************/
  node *list::front()
  {
    return the_list;
  }
  /******************************************************************************/
/*!
 \fn void list::sort
 \brief
  Sorts the list ascendingly
*/
/******************************************************************************/
  void list::sort()
  {
    node *i = the_list;
   
    if (i == nullptr) return;
    node *j;
   
    for (; i-> next != nullptr; i = i -> next)
    {
      for (j = i->next; j != nullptr; j = j -> next)
        {
          if( (i->value) > (j->value) )
          {
            int store;
            store = i -> value;
            i -> value = j -> value;
            j -> value = store;
          }
        }
    }
  }
 /******************************************************************************/
/*!
 \fn void list::erase
 \brief
  Removes nodes at position pos. Position count starts from zero.
 \param int pos
*/
/******************************************************************************/
  void list::erase(int pos)
  {
	  if (!the_list) return;
    
    node *tmp = the_list;
    
    if (!tmp) return;
    
    node *pre_tmp = the_list;
    int i =0;
    
    if (pos == 0) // check postion is 0
    {
      the_list = tmp -> next;
      delete tmp; 
    }
    else
    {
      while (i < pos) // loop until i is higher than pos
      {
        pre_tmp = tmp;
        tmp = tmp -> next;
        i++;
      }
      
      if (tmp-> next == nullptr)
      {
        pre_tmp -> next = tmp -> next;
        delete tmp;
      }
      
      else
      {
        pre_tmp -> next = tmp -> next;
        delete tmp;
      }
    }
  }
 /******************************************************************************/
/*!
 \fn void list::erase
 \brief
  Removes nodes from position first to position last-1. Position count starts from zero.
 \param int first, int last
*/
/******************************************************************************/
  void list::erase(int first, int last){
	  node *tmp = the_list;
    unsigned length = size();
    int i = last - first;
    unsigned n = first;
    
    if (tmp)
    {
      if (n > length) return;
      if (first < last) // compare between the two position
      {
        while (i--)
        {
          erase (first); // erase first position
        }
      }
    }
    
  }
 /******************************************************************************/
/*!
 \fn void list::resize
 \brief
  Resizes the list to contain n elements. If n is smaller than the current size, then keep only
  the first n elements, then destroy those beyond.If n is larger than the current size, the new elements
  are initialized as val.
 \param int n, int val
*/
/******************************************************************************/
  void list::resize(int n, int val){
	  node *tmp = the_list;
    int length = size();
    node *pre_tmp = the_list;
    node *next_tmp;
    node *del_tmp;
    if (tmp == nullptr)
    {
      for (int i = 0; i < n; i++)
      {
        push_front(val); // move to next
      }
    }
    else if (n==0)
    {
      clear();
    }
    else if (n < length) // n smaller than current size
    {
      for (int i =1; i < n; i++)
      {
        pre_tmp = tmp;
        tmp = tmp -> next;
      }
      next_tmp = tmp;
      del_tmp = tmp;
      
      while (next_tmp -> next != nullptr)
      {
        del_tmp = next_tmp;
        next_tmp = next_tmp -> next;
        pre_tmp -> next = next_tmp;
        delete del_tmp;
      }
    }
    else if (n > length) // n larger than current size
    {
      while (tmp -> next != nullptr)
      {
        tmp = tmp -> next;
      }
      for (int i = length; i < n; i++)
      {
        node *newptr = make_node(val);
        tmp->next = newptr;
        tmp = tmp->next;
      }
      tmp -> next = nullptr;
    }
  }
 /******************************************************************************/
/*!
 \fn void list::merge
 \brief
  Assume the current list and l2 are both sorted ascendingly,this function merges them into one, so that the elements
  are still in ascending order. The current list will store the merged elements, 
  while l2 will become empty.
 \param list &l2
*/
/******************************************************************************/      
  void list::merge(list &l2){
	  node *tmp = the_list;
    
    if(tmp != nullptr)  
      {
        while (tmp -> next != nullptr) //loop until it equal to nullptr
        {
          tmp = tmp -> next;
        }
        tmp -> next = l2.the_list;
        l2.the_list = nullptr;
        sort();
      }
      else // list is empty
      {
        the_list = l2.the_list;
        l2.the_list = nullptr;
        sort();
      }
  }
}