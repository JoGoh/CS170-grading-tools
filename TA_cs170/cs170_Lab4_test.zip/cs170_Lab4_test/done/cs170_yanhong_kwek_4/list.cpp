/******************************************************************************/
/*!
\file list.cpp
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170L
\par Lab 04
\date 10/06/2019
\brief
    The following functions implemented in list.cpp allows to(1) Add a node to 
    to the end of the linked list, (2) Add a node to the front of the linked 
    list, (3) Delete all nodes in the linked list, (4) find a node in the 
    linked list with the same given value, (5) Find and delete a node with 
    the value given, (6) Insert a node at the given position and, (7) Join 2 
    linked list together. 
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

namespace CS170
{
/******************************************************************************/
    /*!
        \brief
        constructor for list. Creates an empty list
    */
/******************************************************************************/
list::list() //constructor
{
    list_size =0;
    the_list=nullptr;
}

/******************************************************************************/
    /*!
        \brief
        Destructor for list. 
        Empty the list and release the allocated memory
    */
/******************************************************************************/
list::~list()//deconstructor
{
    clear();
    list_size = 0;
}

/******************************************************************************/
   /*!
        \brief
        The function allocates memory and set members of 
        the struct node.
            
        \param val
        Value of the node added
        
        \return Pnode
        Returns the Pnode value.
    */
/******************************************************************************/
node *list::make_node(int val)
{
    node *Pnode = new node;
    Pnode->value=val;
    Pnode->next=nullptr;
    return Pnode;
}

/******************************************************************************/
   /*!
        \brief
        The function prints all of the nodes values in the list.
    */
/******************************************************************************/
void list::print_list() const
{
    node *temp = the_list;
    while (temp) 
    {
        std::cout << temp->value << " ";
        temp = temp->next;
    }
    std::cout << std::endl;
}

/******************************************************************************/
   /*!
        \brief
        The function returns the list size.
        
        \return count
        Returns the list_size.
    */
/******************************************************************************/
unsigned list::size() const
{
    return list_size;
}

/******************************************************************************/
    /*!
        \brief
        Returns true if list is empty, false otherwise
        
        \return bool
        Returns 1 or 0.
    */
/******************************************************************************/
bool list::empty() const
{
    if (the_list==nullptr)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

/******************************************************************************/
    /*!
        \brief
        The function will delete all nodes in the linked list.
    */
/******************************************************************************/
void list::clear() 
{
    node *temp = the_list;
    while (temp) 
    {
        the_list = temp->next;
        delete temp;
        temp = the_list;
    }
    the_list=nullptr;
    list_size=0;
} 

/******************************************************************************/
    /*!
        \brief
        Add a node to the front of the list

        \param val
        Value of the node added
    */
/******************************************************************************/
void list::push_front(int val)
{
    node *temp = make_node(val);
    temp->next = the_list;
    the_list = temp;
    list_size++;
}

/******************************************************************************/
    /*!
        \brief
        Return the first node in the list
    */
/******************************************************************************/
node *list::front()
{
    return the_list;
}

/******************************************************************************/
    /*!
        \brief
        Removes nodes at position pos.

        \param pos
        The position of the node to be deleted.
    */
/******************************************************************************/
void list::erase(int pos)
{
    node *curr = the_list;
    node *prev = the_list;
    int length=size();
  
    if (pos>length)
    {
        return;
    }
    else if (pos <0)
    {
        return;
    }    
    else
    {
        while (curr) //move curr pointer to pos
        {
            if (pos==0)
            {
                break;
            }
            else 
            {
                prev=curr;
                curr=curr->next;
                pos--;
            }
    }
    if (curr==nullptr)
    {
        return;
    }
    else if (curr ==the_list) //if curr if at the head of list
    {
        the_list = curr->next;
        delete curr;
        list_size--;
    }
    else // if curr is somewhere in between
    {
        prev->next =curr->next; 
        delete curr;
        list_size--;
    }
    }
}

/******************************************************************************/
    /*!
        \brief
        Removes nodes from position first to position last-1.

        \param first
        The position of the first node to be deleted.
        
        \param last
        The position of the last node to be deleted.
    */
/******************************************************************************/
void list::erase(int first, int last)
{
    node *temp = the_list;
    int length=size();
    int extra=last-first;
    
    if (temp==nullptr)
    {
        return;
    }
    else if (first<0)
    {
        return;
    }
     
    else if (first>length)
    {
        return;
    }
    
    else if (first == last)
    {
        return;
    }
    
    else if (temp) // if list is not empty
    {
        while (extra) //delete nodes
        {
            erase(first);
            extra--;
        }
        list_size-=extra;
        return;
    }
            
    else
    {
        return;
    }
}

/******************************************************************************/
    /*!
        \brief
        Resizes the list to contain n elements. if n is smaller than the
        current size, then keep only the first n elements, then destroy
        those beyond. If n is larger than the current size, the new elements
        are initialized as val.
        
        \param n
        The size of the list to be resized to.
        
        \param val
        Value of the node added.
    */
/******************************************************************************/
void list:: resize(int n, int val)
{
    if (n<0)
    {
        return;
    }
    else if(the_list) // if list if not empty
    {
        int length = size();
        node *curr = the_list;
       
       if (n > length) // if resize length is larger than list length
        {
            while(curr->next) // move to end of list
            {
            curr = curr->next;
            }
            while(n > length) // add nodes to end
            {
                node *newNode = make_node(val);
                curr->next = newNode;
                curr = newNode;
                length++;
            }
            list_size=n;
        }
        else // if list length is larger, then erase
        {
            erase (n,length);
            list_size=n;
            
        }
    }
      
    else // if list is empty
    {
        int i = 0;
        while(i != n)
        {
            push_front(val);
            i++;
        }
        list_size=n;
    }
}

/******************************************************************************/
    /*!
        \brief
        Sorts the list ascendingly.
    */
/******************************************************************************/
void list::sort()
{
    node *min=NULL;
    node *curr =NULL;
    node *temp =the_list;
    int val=0;
    while(temp)
    {
        min=temp;
        curr=temp->next;
        
        while(curr) // find smallest value
        {
            if(curr->value < min->value) 
            {
                min=curr;
            }
            curr=curr->next;
        }
        if(min!=temp) // swap with smallest value
        {
            val=min->value;
            min->value=temp->value;
            temp->value=val;
        }
        temp=temp->next;
    }
}

/******************************************************************************/
    /*!
        \brief
        Assume the current list and l2 are both sorted ascendingly,
        this function merges them into one, so that the elements
        are still in ascending order.
        The current list will store the merged elements, 
        while l2 will become empty.
        
        \param &l2
        The second list used for merging.
    */
/******************************************************************************/
void list::merge(list &l2)
{
    node *ptr = the_list;
    node *newlist = nullptr; 

    if(ptr) // if 11 not empty
    {
        while(ptr->next) 
        {
            ptr=ptr->next;
        }
        ptr->next =l2.the_list;
        l2.the_list = nullptr; 
        sort();
        list_size+=l2.list_size;
        l2.list_size = 0;
    }
    else // if l1 is empty, allocate space in list
    {   
        newlist = l2.the_list;
        l2.the_list = nullptr;
        list_size += l2.list_size;
        l2.list_size = 0;
        the_list = newlist;
        sort();
    }
}

}
