/*****************************************************************************/
/*!
\file list.cpp
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
04
\par Date:
04 June 2019
\par Brief:

	This file contains the implementation of the following functions
	for CS170 Lab 04 - Classes

	Functions given: \n
	None \n
	
	\n
	Functions written: \n 
	list(); \n
	~list(); \n
	void print_list() const; \n
	unsigned size() const; \n
	bool empty() const; \n
	void clear(); \n
	void push_front(int val); \n
	node* front(); \n
	void erase(int pos); \n
	void erase(int first, int last); \n
	void resize(int n, int val = 0); \n
	void sort(); \n
	void merge(list &l2); \n
	node* make_node(int val); \n
	
	\n
	Helper Functions written: \n
	void moveNode(node** destination, node** source); \n
	node* mergeLinkedList(node* left, node* right); \n
	void splitLinkedList(node* &list, node** left, node** right); \n
	void sortList(node* &list); \n
	
	\n 
	Hours spent on this assignment: 
	3.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/
#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here

namespace CS170 {
	
/*****************************************************************************/
/*!
	Default Constructor, initializes list_size to be 0 and the initial
	the_list to be nullptr
*/
/*****************************************************************************/
	list::list(): list_size(0),
								the_list(nullptr) {}
	
/*****************************************************************************/
/*!
	Default Destructor
*/
/*****************************************************************************/
	list::~list() {}
	
	node* list::make_node(int val) {
		node *pNode = new node;
		pNode->value = val;
		pNode->next = nullptr;  
		return pNode;
	}
	
/*****************************************************************************/
/*!
	Prints out the values contained in the list
*/
/*****************************************************************************/
	void list::print_list() const {
		node* pTemp = the_list;
		while (pTemp) {
			std::cout << pTemp->value << " ";
			pTemp = pTemp->next;
		}
		std::cout << std::endl; 
	}
	
/*****************************************************************************/
/*!
	Returns the current size of the list 
	\retval list_size
			Size of the list in unsigned integer type
*/
/*****************************************************************************/
	unsigned list::size() const {
		return list_size;
	}
	
/*****************************************************************************/
/*!
	Returns true if list is empty, false otherwise 
	\return true
			Return true if list is empty
	\return false
			Return false if list has at least 1 node
*/
/*****************************************************************************/
	bool list::empty() const {
		if (list_size == 0) {
			return true;
		}
		return false;
	}
	
/*****************************************************************************/
/*!
	Frees (deletes) all of the nodes in the list, and resets the list size
	to 0
*/
/*****************************************************************************/
	void list::clear() {
		
		node* pTemp = the_list;
		while (pTemp) {
			the_list = pTemp->next;
			delete pTemp;
			pTemp = the_list;
		}
		the_list=nullptr;
		list_size = 0;
	}
	
/*****************************************************************************/
/*!
	Creates a node with value input and add it to the front of the list
	\param val
			Integer value to be saved at inserted node
*/
/*****************************************************************************/
	void list::push_front(int val) {
		node* pNewNode = make_node(val);
		
		if (!empty()) { //if list is not empty, shift first value back
			pNewNode->next = the_list;
		}
		the_list = pNewNode; 
		++list_size;
	}
	
/*****************************************************************************/
/*!
	Return the first node in the list
	\retval the_list
			The beginning node of the linked list
*/
/*****************************************************************************/
	node* list::front() {
		return the_list;
	}
	
/*****************************************************************************/
/*!
	Removes nodes at position pos, count starts from 0
	\param pos
			Integer position of the node that is to be deleted
*/
/*****************************************************************************/
	void list::erase(int pos) {
		
		bool isEmpty = empty();
		//pos less than 0 or pos larger than size or list is empty guard
		if (pos < 0 || pos >= (int)list_size || isEmpty) {
			return;
		}
		
		node* temp = the_list;
		
		if (pos == 0) { //delete first node check
		
			//single value list guard
			the_list = the_list->next ? the_list->next : nullptr;
			delete temp;
			--list_size;
			return;
		}
		
		for (int i = 1; i < pos; ++i) { //nodes after the first pos (0)
			temp = temp->next;
		}
		//temp will be the immediate node before the given pos
		
		if (temp->next->next) { //if next node is NOT the last node
			node* deletedNode = temp->next;
			temp->next = temp->next->next; //connect current->next of next
			delete deletedNode; //delete next node
		} else { //if next node is the last node
			delete temp->next;
			temp->next = nullptr;
		}
		
		--list_size; //update size
	}
	
/*****************************************************************************/
/*!
	Function Overload -
	Removes nodes from position first to position last - 1, count starts from 0
	\param first
			Integer position of the node that is to be deleted
	\param last
			Integer position of the node that is to be deleted
*/
/*****************************************************************************/
	void list::erase(int first, int last) {
		
		int min, max;
		if (last < first) { //supports backwards erase i.e. last < first
			min = last;
			max = first;
		} else {
			min = first;
			max = last;
		}
		
		if (min < 0) { //first pos < 0 check
			return;
		}
		
		if (max > (int)list_size) {
			max = list_size;
		}

		int eraseCount = max - min;
		
		while (eraseCount > 0) {
			erase(min); //erase from first pos and iterate
			--eraseCount;
		}
	}
	
/*****************************************************************************/
/*!
	Resizes the list to contain n elements. 
  If n is smaller than the current size, then keep only 
  the first n elements, then destroy those beyond. 
  If n is larger than the current size, the new elements 
  are initialized as val
	\param n
			Integer position of the node that is to be deleted
	\param val
			Integer position of the node that is to be deleted
*/
/*****************************************************************************/
	void list::resize(int n, int val) {
		
		if (n == (int)list_size || n < 0) { //same size and n < 0 guard
			return;
		}
		
		if (n == 0) { //shrink to 0 check
			clear();
			return;
		}
		
		//assign temp to first node or nullptr if list is empty
		node* temp = the_list ? the_list : nullptr;
		
		if (n < (int)list_size && temp) { //shrink
			
			node* deletedNode = nullptr;
			
			for (int i = 1; i < n; ++i) {
				temp = temp->next;
			}
			
			//saves position of last node after shrinking
			node* endOfList = temp; 
			
			//move 1 more node down to start shrinking
			temp = temp->next;
			
			for (; (int)list_size > n; --list_size) {
				deletedNode = temp;
				temp = temp->next ? temp->next : temp;
				delete deletedNode;
			} //end for loop
			
			//update the node at the end of list
			endOfList->next = nullptr;


		} else if (n > (int)list_size) { //expand
		
			for (int j = 1; j < (int)list_size; ++j) {
				temp = temp->next;
			}
			
			for (; (int)list_size < n; ++list_size) {
				if (the_list) { //if list has values already
					temp->next = make_node(val);
					temp = temp->next;
				} else { //else if list is currently empty
					the_list = make_node(val);
					temp = the_list;
				} //end if else
			} //end for loop
		} //end else
		
	}

/*****************************************************************************/
/*!
	Helper Function -
	This function takes the node at the front of the source reference, and
	moves it to the front of the destination reference
	\param destination
			Double pointer to the destination linked list
	\param source
			Double pointer to the source linked list
*/
/*****************************************************************************/
	void moveNode(node** destination, node** source) {  

		if (!(*source)) { //empty source guard
			return;
		}
		
		//temp node that points to source
    node* temp = *source;  
		//moves source 1 node forward
    *source = temp->next;  
		//connects temp with destination
    temp->next = *destination;  
		//moves destination to temp to complete the move node
    *destination = temp;  
	}  

/*****************************************************************************/
/*!
	Helper Function -
	This function merges 2 lists together and returns the result
	\param left
			Pointer to the "left", aka first list
	\param right
			Pointer to the "right", aka second list
	\retval result
			The final result of the combined list
*/
/*****************************************************************************/
node* mergeLinkedList(node* left, node* right) {
	
	node* result = nullptr;
	node** lastPointerRef = &result;
	
	while(1) { 
		if (!left) { //empty left list guard
			*lastPointerRef = right;
			break;
		}
		else if (!right) { //empty right list guard
			*lastPointerRef = left;
			break;
		}
		
		if (left->value <= right->value) { //sorts into lastPointerRef
			moveNode(lastPointerRef, &left); 
		}
		else {
			moveNode(lastPointerRef, &right); 
		}
		
		//advance to ->next field
		lastPointerRef = &((*lastPointerRef)->next);  
	}
	
	return result;
}

/*****************************************************************************/
/*!
	Helper Function -
	This function splits a given linked list into left and right list, with
	the front list getting the extra node if list is odd
	\param list
			Pointer to the given linked list
	\param left
			Double pointer to the "left", aka first list
	\param right
			Double pointer to the "right", aka second list
*/
/*****************************************************************************/
void splitLinkedList(node* &list, node** left, node** right) {
	
	if (!list || !(list->next)) { //empty list/single node guard
		return;
	}
	
	node* slow = list;
	node* fast = list->next;
	
	while (fast) {
		fast = fast->next;
		if (fast) {
			slow = slow->next;
			fast = fast->next;
		}
	}
	
	*left = list;
	*right = slow->next;
	slow->next = nullptr;
}


/*****************************************************************************/
/*!
	Helper Function -
	This function sorts the given list and calls itself recursively to split
	the list down into smaller halves, then merge the sorted pieces back
	together
	\param list
			Pointer to the given linked list
*/
/*****************************************************************************/
	void sortList(node* &list) {
	
		if (!list || !(list->next)) { //empty list/single node guard
			return; 
		} 
		
		node* left = nullptr;
		node* right = nullptr;
		
		splitLinkedList(list, &left, &right);
		
		sortList(left);
		sortList(right);
		
		list = mergeLinkedList(left, right);
	}

/*****************************************************************************/
/*!
	This function sort elements in the list in ascending order
*/
/*****************************************************************************/	
  void list::sort() {
		
		if (!the_list || !(the_list->next)) { //empty or single value guard
			return;
		}
		
		sortList(the_list);
	}
	
/*****************************************************************************/
/*!
	Assume the current list and l2 are both sorted ascendingly, 
  this function merges them into one, so that the elements 
  are still in ascending order. 
  The current list will store the merged elements, 
  while l2 will become empty
	\param l2
			Address of list 2
*/
/*****************************************************************************/
  void list::merge(list &l2) {
		
		if (!the_list) { //if list 1 is empty
			//check if list 2 is empty as well, if not, move l2 to l1
			the_list = l2.the_list ? l2.the_list : nullptr;
			list_size += l2.list_size;
			l2.the_list = nullptr;
			l2.list_size = 0;
			return;
		}
		
		node* temp = the_list;
		
		for (unsigned int i = 0; i < list_size; ++i) {
			//iterate to the last node
			temp = temp->next ? temp->next : temp;
		}
		
		//connect end of l1 to start of l2
		temp->next = l2.the_list; 
		
		//add the size of l2 to size of l1
		list_size += l2.list_size;
		
		//sort the merged list again
		sort(); 
		
		//clear list 2
		l2.the_list = nullptr;
		l2.list_size = 0;
	}
	
	
} //end namespace CS170

