/******************************************************************************/
/*!
\file               list.cpp
\author             Eu Shee Kei
\par email:         sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course:        CS170
\par                Lab 04
\date               09/06/2019
\brief
This file contains implementations needed to manipulate linked list
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

using namespace CS170;

/******************************************************************************/
/*!
  \fn     list::list()
  \brief  Constructor for list. Creates an empty list 
  \return void
*/
/******************************************************************************/
list::list()
: list_size(0)
, the_list(nullptr)
{
  
}

/******************************************************************************/
/*!
  \fn     list::~list()
  \brief  Destructor for list. Empty the list and release the allocated memory 
  \return void
*/
/******************************************************************************/
list::~list()
{
  clear();
}

/******************************************************************************/
/*!
  \fn     void list::print_list() const
  \brief  Prints out the values contained in the list 
  \return void
*/
/******************************************************************************/
void list::print_list() const
{
  node *pTempNode = the_list;
  while (pTempNode) 
  {
    std::cout << pTempNode->value << " ";
    pTempNode = pTempNode->next;
  }
  std::cout << std::endl;
}

/******************************************************************************/
/*!
  \fn     unsigned list::size() const
  \brief  Returns the current size of the list 
  \return unsigned
*/
/******************************************************************************/
unsigned list::size() const
{
  return list_size;
}

/******************************************************************************/
/*!
  \fn     bool list::empty() const
  \brief  Returns true if list is empty, false otherwise 
  \return void
*/
/******************************************************************************/
bool list::empty() const
{
  return !the_list;
}

/******************************************************************************/
/*!
  \fn     void list::clear()
  \brief  Frees (deletes) all of the nodes in the list 
  \return void
*/
/******************************************************************************/
void list::clear()
{
   // if list has 0 node
  if(!the_list)
  {
    the_list = nullptr;
    return;
  }

  // if list has 1 or more nodes
  node *pTempNode = the_list;
  node *pNextTempNode = the_list->next;
  
  // iterate through the list while deleting each node
  while(pTempNode->next)
  {
    delete pTempNode;
    pTempNode = pNextTempNode;
    pNextTempNode = pNextTempNode->next;
  }
  delete pTempNode;
  
  the_list = nullptr;
  list_size = 0;
}

/******************************************************************************/
/*!
  \fn     void list::push_front(int val)
  \brief  Creates a node with val and add it to the front of the list
  \param  val 				value to be initialise with node
  \return void
*/
/******************************************************************************/
void list::push_front(int val)
{
  // if list has 0 node
  if(!the_list)
  {
    the_list = make_node(val);
    the_list->next = nullptr;
    return;
  }
  
  // if list has 1 or more nodes, link new node to front of list
  node *pTempNode = the_list;
  the_list = make_node(val);
  the_list->next = pTempNode;
}

/******************************************************************************/
/*!
  \fn     node* list::front()
  \brief  Return the first node in the list  
  \return node* pointer to a node
*/
/******************************************************************************/
node* list::front()
{
  return the_list;
}

/******************************************************************************/
/*!
  \fn     void list::erase(int pos)
  \brief  Removes nodes at position pos. 
          Position count starts from zero.
  \param  pos				position of node to be erased
  \return void
*/
/******************************************************************************/
void list::erase(int pos)
{
  // if position if out or range or list has 0 nodes
  if ((unsigned)pos > list_size || pos < 0 || !the_list)
    return;
  
  node *pTempNode = the_list;
  
  // if position is zero
  if(pos == 0)
  {
    if(pTempNode->next)
    {
      pTempNode = pTempNode->next;
      delete the_list;
      the_list = pTempNode;
    }
    else
    {
      delete pTempNode;
      pTempNode = nullptr;
      the_list = nullptr;
    }
  }
  
  // if position is 1 or higher
  else if(pos > 0)
  {
    int count = pos - 1;
    if (count < 0)
      return;
    
    // move temp pointer to one position before desired position
    while(count--)
    {
      pTempNode = pTempNode->next;
    }
    
    node *pEraseNode = pTempNode->next;
    pTempNode->next = pTempNode->next->next;
    delete pEraseNode;
    pEraseNode = nullptr;
  }
  
  --list_size;
}

/******************************************************************************/
/*!
  \fn     void list::erase(int first, int last)
  \brief  Removes nodes from position first to position last-1. 
          Position count starts from zero.
  \param  first        position of the first node to be erased
  \param  last         position of one after the node to be erased
  \return void
*/
/******************************************************************************/
void list::erase(int first, int last)
{
  if(first < 0|| last < 0 || first > static_cast<int>(list_size) ||
     last < first || ( first == 0 && last == 0 ) ||!the_list)
     return;
  
  node *pJoinNode = the_list;
  node *pDeleteNode = the_list->next;
  
  // if last position exceeds size of list, clear the list
  if(last > static_cast<int>(list_size))
    clear();
  
  // if position starts from zero, erase starting from first node
  else if(first == 0)
  {
    int diffPos = last - first - 1;
    while(diffPos--)
    {
      delete pJoinNode;
      pJoinNode = pDeleteNode;
      pDeleteNode = pDeleteNode->next;
    }
    delete pJoinNode;
    pJoinNode = nullptr;
    the_list = pDeleteNode;
    
    list_size -= last - first;
  }
  
  else if (first > 0)
  {
     int beforeFirstPos = first - 1;
     int diffPos = last-first;
     
     //std::cout << "I'm at: " << pJoinNode->value << std::endl;
    // move temp pointer to position before first, and set temp pointers for
    // next two nodes
    while(beforeFirstPos--)
    {
      pJoinNode = pJoinNode->next;
    }
    node *pRemoveNode = pJoinNode->next;
    node *pNextNode = pJoinNode->next->next;

    // delete nodes from first to last-1
    while(diffPos--)
    {
      delete pRemoveNode;
      pRemoveNode = pNextNode;
      if(pNextNode)
      {
        pNextNode = pNextNode->next;
      }
    }
    
    // join node before first to last node
    pNextNode = nullptr;
    pJoinNode->next = pRemoveNode;
    
    list_size -= last - first;
  }
}

/******************************************************************************/
/*!
  \fn     void list::resize(int n, int val)
  \brief  Resizes the list to contain n elements.
          If n is smaller than the current size, then keep only
          the first n elements, then destroy those beyond.
          If n is larger than the current size, the new elements
          are initialized as val.
  \param  n               size of list to be resized to
  \param  val             val to be initialised in new nodes
  \return void
*/
/******************************************************************************/
void list::resize(int n, int val)
{
  if( n < 0 || n == static_cast<int>(list_size))
    return;
  
  // if list is empty, resize accordingly
  if(!the_list)
  {
    int resize = n-1;
    node *pNewNode = make_node(val);
    node *pTempNode = pNewNode;
    while(resize--)
    {
      node *pNextNode = make_node(val);
      pTempNode->next = pNextNode;
      pTempNode = pTempNode->next;
    }
    pTempNode->next = nullptr;
    the_list = pNewNode;
  }
  
  // if n is zero, empty the list
  else if (n == 0)
    clear();
  
  // if the list has 1 or more nodes, resize accordingly
  else if (the_list)
  {
     node *pTempNode = the_list;

    // resize list to smaller
    if(n < static_cast<int>(list_size))
    {
      int firstn = n-1;
      
      // move temp ptr to position
      while(firstn--)
      {
        pTempNode = pTempNode->next;
      }
      
      node *pEraseNode = pTempNode->next;
      pTempNode->next = nullptr;
      pTempNode = pEraseNode->next;

      // destroy remaining nodes
      while(pTempNode)
      {
        delete pEraseNode;
        pEraseNode = pTempNode;
        pTempNode = pTempNode->next;
      }
      delete pEraseNode;
      pEraseNode = nullptr;
    }
    
    // expand list size
    else if (n > static_cast<int>(list_size))
    {
      int lastn = n - list_size;
      
      while(pTempNode->next)
      {
        pTempNode = pTempNode->next;
      }
      while(lastn--)
      {
        node *pNewNode = make_node(val);
        pTempNode->next = pNewNode;
        pTempNode = pTempNode->next;
      }
      pTempNode->next = nullptr;
    }
  }
  
  // update list_size
  list_size = n;
}

/******************************************************************************/
/*!
  \fn     void swap(int *value1, int *value2)
  \brief  Swap two integers
  \param  value1          An integer to be swapped
  \param  value2          An integer to be swapped
  \return void
*/
/******************************************************************************/
void swap(int *value1, int *value2)
{
  int temp = *value1;
  *value1 = *value2;
  *value2 = temp;
}

/******************************************************************************/
/*!
  \fn     void list::sort()
  \brief  Sorts the list ascendingly 
  \return void
*/
/******************************************************************************/
void list::sort()
{
  // if list has 0 nodes
  if(!the_list)
  {
    the_list = nullptr;
    return;
  }
  
  // Pointer to beginning of the list
  node *pStartingNode = the_list;
  // Pointer to iterate through list
  node *pIteratingNode = the_list;
  // Store smallest value in the list
  int smallValue = the_list->value;
  
  // if list has 1 or more nodes
  while(pStartingNode)
  {
    // reset iterator to beginning and small value to value of first node
    pIteratingNode = pStartingNode;
    smallValue = pStartingNode->value;
    
    // iterate through list, to find and store smallest value
    while(pIteratingNode)
    {
      if(pIteratingNode->value < smallValue)
      {
        smallValue = pIteratingNode->value;
      }
      pIteratingNode = pIteratingNode->next;
    }
    
    pIteratingNode = pStartingNode;
    
    // iterate through list, to find matching value and swap with first node
    while(pIteratingNode)
    {
      if(pIteratingNode->value == smallValue)
      {
        swap(&(pIteratingNode->value), &(pStartingNode->value));
        pStartingNode = pStartingNode->next;
      }
      pIteratingNode = pIteratingNode->next;
    }
  }
}

/******************************************************************************/
/*!
  \fn     void list::merge(list &l2)
  \brief  Assume the current list and l2 are both sorted ascendingly,
          this function merges them into one, so that the elements
          are still in ascending order.
          The current list will store the merged elements, 
          while l2 will become empty.
  \param  l2        a reference to list 2
  \return void
*/
/******************************************************************************/
void list::merge(list &l2)
{
  if((!the_list && !(l2.the_list)) || (the_list && !(l2.the_list)))
    return;
  
  node *pTempNode = the_list;
  
  // if the list1 is empty and list2 is not empty, point list1 to list2
  if(!the_list)
  {
    the_list = l2.the_list;
  }
  
  else if(the_list)
  {
    // move temp pointer to the last node
    while(pTempNode->next)
    {
      pTempNode = pTempNode->next;
    }
    pTempNode->next = l2.the_list; 
    
    sort();
  } 
  // update list size
  list_size += l2.size();
  
  // list2 to become empty
  l2.the_list = nullptr;
  l2.list_size = 0;
}

/******************************************************************************/
/*!
  \fn     node* list::make_node(int val)
  \brief  Makes a new node
  \param  val			value to be initialised
  \return void
*/
/******************************************************************************/
node* list::make_node(int val)
{
  node *pNode = new node;
  pNode->value = val;
  pNode->next = nullptr;
  ++list_size;
  return pNode;
}