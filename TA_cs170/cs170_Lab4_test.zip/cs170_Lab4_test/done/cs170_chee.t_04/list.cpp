/******************************************************************************/
/*!
\file list.cpp
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: CS170
\par Lab 04
\date 10/6/2019
\brief
This file contains the implementation of the following functions for
Lab 4.

Functions include:
 list()
~list()
void print_list() const
unsigned size() const
bool empty() const
void clear()
void push_front(int val)
node *front()
void erase(int pos)
void erase(int first, int last)
void resize(int n, int val = 0)
void sort()
void merge(list &l2)

node *make_node(int val)
void MergeSort(node** list)
node* SortedMerge(node* a, node* b)
void ListSplitter(node* list, node** firstHalf, node** secondHalf)

Hours spent on this assignment: 7
Specific portions that gave you the most trouble: merge function, Couldn't
reuse sortedmerge because need to empty list 2 instead of simply shifting
pointers around
*/
/******************************************************************************/

#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here

namespace CS170
{

// FUNCTION DECLARATIONS

	void MergeSort(node** list);
	node* SortedMerge(node* a, node* b);
	void ListSplitter(node* list, node** firstHalf, node** secondHalf);

/******************************************************************************/
/*!
\brief Creates a Node using a given integer value and allocate memory space

\fn node* list::make_node(int val)

\param val
*/
/******************************************************************************/
	node* list::make_node(int val)
	{
		node* pNode = new node;
		pNode->value = val;
		pNode->next = nullptr;
		return pNode;
	}

/******************************************************************************/
/*!
\brief Linked List Constructor

\fn list::list()
*/
/******************************************************************************/
	list::list()
	{
		list_size = 0;
		the_list = nullptr;
	}

/******************************************************************************/
/*!
\brief Linked List Destructor

\fn list::~list()
*/
/******************************************************************************/
	list::~list()
	{
		if (the_list) clear();
		list_size = 0;
	}

/******************************************************************************/
/*!
\brief Prints out the values of a linked list

\fn void list::print_list() const
*/
/******************************************************************************/
	void list::print_list() const
	{
		node* pCurrNode = the_list;
		while (pCurrNode) {
			std::cout << pCurrNode->value << " ";
			pCurrNode = pCurrNode->next;
		}
		std::cout << std::endl;
	}

/******************************************************************************/
/*!
\brief Returns current size of list

\fn unsigned list::size() const
*/
/******************************************************************************/
	unsigned list::size() const
	{
		return list_size;
	}

/******************************************************************************/
/*!
\brief Returns true if list is empty, false otherwise

\fn bool list::empty() const
*/
/******************************************************************************/
	bool list::empty() const
	{
		return (!list_size);
	}

/******************************************************************************/
/*!
\brief Frees (deletes) all of the nodes in the list

\fn void list::clear()
*/
/******************************************************************************/
	void list::clear()
	{
		list_size = 0;
		node* pCurrNode = the_list;
		while (pCurrNode) {
			the_list = pCurrNode->next;
			delete pCurrNode;
			pCurrNode = the_list;
		}
		the_list = nullptr;
	}

/******************************************************************************/
/*!
\brief Creates a node with val and add it to the front of the list

\fn void list::push_front(int val)

\param val
*/
/******************************************************************************/
	void list::push_front(int val)
	{
		node* pNode = the_list;
		the_list = make_node(val);
		the_list->next = pNode;
		++list_size;
	}

/******************************************************************************/
/*!
\brief Return the first node in the list

\fn node* list::front()
*/
/******************************************************************************/
	node* list::front()
	{
		return the_list;
	}

/******************************************************************************/
/*!
\brief Removes nodes at position pos. Position count starts from zero.

\fn void list::erase(int pos)

\param pos
*/
/******************************************************************************/
	void list::erase(int pos)
	{
		node* pCurrNode = the_list;
		if (!pCurrNode) return;
		// if position is less than or equal to 0, should just remove
		// first element
		if (pos <= 0)
		{
			the_list = pCurrNode->next;
			delete pCurrNode;
			--list_size;
			return;
		}
		// if position is larger or equal to list size, simply delete last
		if (pos >= static_cast<int>(list_size))
		{
			while (pCurrNode->next->next) pCurrNode = pCurrNode->next;
			node* pNode = pCurrNode->next;
			pCurrNode->next = nullptr;
			delete pNode;
			--list_size;
			return;
		}
		// if position in the middle then traverse until 1 node before pos
		for (int i = 1; i < pos; ++i) pCurrNode = pCurrNode->next;
		node* pNode = pCurrNode->next;
		pCurrNode->next = pCurrNode->next->next;
		delete pNode;
		--list_size;
	}

/******************************************************************************/
/*!
\brief Removes nodes from position first to position last-1.
Position count starts from zero.

\fn void list::erase(int first, int last)

\param first, last
*/
/******************************************************************************/
	void list::erase(int first, int last)
	{
		// Extra Cases:
		// If first is larger than last, don't bother
		if (first > last) return;
		if(first == last) return;
		// If less than 0 then set as 0
		if (first < 0) first = 0;
		// If larger than actual size, delete up till size
		int size = static_cast<int>(list_size);
		if (last >= size) last = size;
		if (first > size) return;
		// If same value, simply reuse erase function at position
		int nodesToDelete = last - first + 1;
		while (--nodesToDelete)
		{
			erase(first);
		}
	}

/******************************************************************************/
/*!
\brief Resizes the list to contain n elements.
If n is smaller than the current size, then keep only the first n elements,
then destroy those beyond. If n is larger than the current size, the new
elements are initialized as val.

\fn void list::resize(int n, int val)

\param n, val
*/
/******************************************************************************/
	void list::resize(int n, int val)
	{
		int size = static_cast<int>(list_size);
		node* pCurrNode = the_list;
		// Catch if n is negative int
		if (n < 0) clear();
		// Catch if n is same size as list
		if (n == size) return;

		// if n is smaller
		if (n < size)
		{
			erase(n, size);
			// set list_size
			list_size = n;
		}
		// if n is larger
		else
		{
			// Calculate how many nodes to add
			int nodesToAdd = n - size;
			// set list_size
			list_size = n;
			if (!pCurrNode)
			{
				pCurrNode = the_list = make_node(val);
				--nodesToAdd;
				for (int i = 0; i < nodesToAdd; ++i)
				{
					node* pNewNode = make_node(val);
					pCurrNode->next = pNewNode;
					pCurrNode = pCurrNode->next;
				}
			}
			else
			{
				while (pCurrNode->next) pCurrNode = pCurrNode->next;
				for (int i = 0; i < nodesToAdd; ++i)
				{
					node* pNewNode = make_node(val);
					pCurrNode->next = pNewNode;
					pCurrNode = pCurrNode->next;
				}
			}
		}
	}



/******************************************************************************/
/*!
\brief Sorts the list ascendingly, uses MERGESORT and mergesort helper function

\fn void list::sort()
*/
/******************************************************************************/
	void list::sort()
	{
		// Use MergeSort Helper Function
		MergeSort(&the_list);
	}

/******************************************************************************/
/*!
\brief Assume the current list and l2 are both sorted ascendingly, this
function merges them into one, so that the elements are still in ascending
order. The current list will store the merged elements, while l2 will become
empty.

To empty List 2, insert all larger values of list 2 at the front of list 1,
then insert remaining values between nodes in list 1. If any other nodes remain
at the end of list 1, simply

\fn void list::merge(list &l2)

\param l2
*/
/******************************************************************************/
	void list::merge(list &l2)
	{
		// Set Variables
		node* pList1 = the_list;
		node* pList2 = l2.front();
		if (!pList1 && !pList2) return;

		node* temp_list = make_node(pList2->value);
		node* nodesToBeMerged = temp_list;
		list_size += l2.size();

		while (pList2)
		{
				pList2 = pList2->next;
				if (pList2) temp_list->next = make_node(pList2->value);
				temp_list = temp_list->next;
		}

		the_list = SortedMerge(pList1, nodesToBeMerged);
		l2.clear();
	}

/******************************************************************************/
/*!
\brief HELPER FUNCTION: Recursively Sort elements in a linked list. Uses
ListSplitter to split up lists into smaller chunks then sorted using
SortedMerge helper function.

\fn void list::MergeSort(node** list)

\param list
*/
/******************************************************************************/
	void MergeSort(node** list)
	{
		node* head = *list;
		node* a;
		node* b;

		// Return if list have less than two nodes
		if (head == NULL || head->next == NULL) return;
		ListSplitter(head, &a, &b);

		// Divide and conquer method, split up front half all the way then back
		MergeSort(&a);
		MergeSort(&b);

		// Merge the two lists recursively in sorted way
		*list = SortedMerge(a, b);
	}

/******************************************************************************/
/*!
\brief HELPER FUNCTION: Recursively compare and chain-link nodes into a
"result" list. Requires already sorted lists to use

\fn node* list::SortedMerge(node* a, node* b)

\param a, b
*/
/******************************************************************************/
	node* SortedMerge(node* a, node* b)
	{
		node* result = nullptr;

		// Base cases to end recursive
		if (!a) return (b);
		else if (!b) return (a);

		// Check for value for which is smaller, add it to the list then recur
		if (a->value <= b->value) {
			result = a;
			result->next = SortedMerge(a->next, b);
		}
		else {
			result = b;
			result->next = SortedMerge(a, b->next);
		}
		return result;
	}

/******************************************************************************/
/*!
\brief HELPER FUNCTION: Creates two lists out of one linked list

\fn void list::ListSplitter(node* list, node** firstHalf, node** secondHalf)

\param list, firstHalf, secondHalf
*/
/******************************************************************************/
	void ListSplitter(node* list, node** firstHalf, node** secondHalf)
	{
		node* slow = list;
		node* fast = list->next;

		// Set fast pointer to traverse twice and slow pointer only once
		while (fast) {
			fast = fast->next;
			if (fast) {
				slow = slow->next;
				fast = fast->next;
			}
		}

		// Reset first half as the head node, second half as slow pointer's next
		*firstHalf = list;
		*secondHalf = slow->next;
		slow->next = nullptr;
	}
}
