/******************************************************************************/
/*!
\file   list.cpp
\author Josiah Goh
\par    email: goh.j\@digipen.edu
\par    DigiPen login: goh.j
\par    Course: CS170
\par    Lab 04
\date   04/02/2019
\brief  
    This file contains the implementation of the following functions for the
      linked list lab.
    Functions include:

    make_node
    print_list
    empty
    clear
    size
    push_front
    front
    sort
    erase
    erase
    resize
    merge
    
 
 
  Specific portions that gave you the most trouble: NONE

  
*/
/*****************************************************************************/

#include <iostream>//cout, endl
#include "list.h"
#define LARGEST_INT 2147483647//largest int


using namespace std;
namespace CS170 {
    
/*****************************************************************************/
/*!
  \brief
   constructor for list.
*/
/*****************************************************************************/
list::list() : list_size(0), the_list (nullptr) {}

/*****************************************************************************/
/*!
  \brief
   destructor for list.
*/
/*****************************************************************************/
list::~list() //destructor
{
    clear ();
}

/*****************************************************************************/
/*!
  \brief
    Creates a new node.
    Allocate memory and set members.

  \param val
    The value of the node.

  \return pNode
   the pointer to the new node.  

*/
/*****************************************************************************/
node *list::make_node(int val)
{
    node *pNode = new node;
    pNode->value = val;
    pNode->next = nullptr;
    list_size++;  //increment size
    return pNode; 
}

/*****************************************************************************/
/*!
  \brief
    Prints the linked list.
    Prints all of the nodes values

*/
/*****************************************************************************/
void list::print_list() const 
{
    node *reader=the_list;
    while (reader) {
    std::cout << reader->value << " ";
    reader = reader->next;
    }
    std::cout << std::endl;   
}

/*****************************************************************************/
/*!
  \brief
    checks if the list is empty

  \return true
    if the list is empty
    
  \return true
    if the list is not empty    
*/
/*****************************************************************************/
bool list::empty() const
{
    if(!the_list)
       return true;

    return false;
}

/*****************************************************************************/
/*!
  \brief
  Frees (deletes) all of the nodes in the list.

*/
/*****************************************************************************/
void list::clear()
{
    node *pCurrNode = the_list;
    while (pCurrNode) {
    the_list = pCurrNode->next;
    delete pCurrNode;
    pCurrNode = the_list;
    list_size--;
    }
    the_list=nullptr;
}

/*****************************************************************************/
/*!
  \brief
  Returns the number of nodes in the list

  \return list_size
  the number of nodes in the list
  

*/
/*****************************************************************************/
unsigned list::size()const 
{   // suppose to use an increment each time you make node
    return list_size;
}

/*****************************************************************************/
/*!
  \brief
   Push a node to the front of the list
 
  \param value
  The value of the node.
  
  
*/
/*****************************************************************************/
void list::push_front(int value) 
{
    //list node auto given
    node *pNewNode = make_node(value);
    pNewNode->next = the_list;
    the_list = pNewNode;  
}
 
/*****************************************************************************/
/*!
  \brief
   the front of the list

  \return the_list
  the front of the list
    
*/
/*****************************************************************************/ 
node *list::front()
{

    return the_list;

}

/*****************************************************************************/
/*!
  \brief
   Sort elements in the list in ascending order based on value

*/
/*****************************************************************************/
void list::sort()
{  
    
    node *head=the_list;  
    node *second = head;
    node *shift = the_list;
    int tmp =0;
    int min=LARGEST_INT;


    if(!the_list) 
       return;

    while(head)
    {  
        min = LARGEST_INT;//set first to compare

        for(second=head;second;second=second->next)
        {    
            if( min > second->value )
            {
                min = second->value;//update min 
            }
        }
        for(shift=head;shift;shift=shift->next)
        {//rapid shifting values to front 
            if(shift->value == min)
            {
                
                tmp = head->value;
                head->value = shift->value;
                shift->value = tmp; 
                head = head->next;
                //after swapped, move on while discluding prev min
      
            }
        }
    }
}

/*****************************************************************************/
/*!
  \brief
  Frees (deletes) a particular node in the list.

  \param pos
    position to be deleted

*/
/*****************************************************************************/
void list::erase(int pos)
{
    node *before=the_list;
    node *after=nullptr;
    if(!the_list) // empty list
        return;

    if(!pos)// if its the first node
    {
        the_list=the_list->next;
        delete before;
        list_size--;
        return;
    }
         //scan until node before delete
    for(int i = 0; (before!=NULL) && i<pos-1;i++)
            before=before->next;
    // when pos of delete is more than the list size
    if (!before || !(before->next))
        return;

    after=(before->next)->next; // after the deletion node

    delete(before->next);
    list_size--;
    before->next=after;//re-link the nodes  
    
}

/*****************************************************************************/
/*!
  \brief
  Frees (deletes) a chain of nodes from first to last in the list.

  \param first
    starting position to be deleted
  
  \param last
    ending position to be deleted
*/
/*****************************************************************************/
void list::erase(int first, int last)
{
    node *before=the_list;
    node *after=nullptr;
    int num = last-first;
    int j=0;

    if(!the_list || first == last || num < 0 ) // empty list
        return;                                //no need to delete any
                                               //if its reverse
    //scan until node before delete
    for( j = 0; (before!=NULL) && j<first-1;j++)
    {
        before=before->next;
    } 

    if(j == first && list_size==1)//only one node left to be deleted
    {
        delete before;
        the_list=nullptr;
        list_size--;
    }
        
    //when pos of delete is more than the list size
    //the second part of the orr statement would short if first satisfied
    if (!before || !(before->next))
        return;


    if(!first)// if its the first node
    {
        for(int i = 0;the_list!=nullptr && i<num; i++)
        {   
            before=the_list;//re initialize
            the_list=the_list->next;
            delete before;
            list_size--;
            
        }
        return;
    }

    for(int i = 0;(before->next)!=nullptr && i<num; i++)
    {
        after=(before->next)->next;
        delete ( before->next);
        list_size--;
        before->next=after;//re-link the nodes  
    }

}

/*****************************************************************************/
/*!
  \brief
  Resizes the list to contain n elements.

  \param n
    elements to be resized to
  
  \param val
    values that the new nodes would be given
*/
/*****************************************************************************/
void list::resize(int n, int val)
{   
    node * temp=nullptr;
    node *last=the_list;
    int m =list_size; //forcefully make list_size to be signed

    if(!the_list&&(n>m))//add something to nothing
    {   
        temp=make_node(val);
        the_list=temp;//link first node
        last=the_list;
        int num=n-m;
        
        for(int i = 1; i<num; i++)
        {
            temp=make_node(val);//new         
            last->next=temp;//link
            last=last->next;
        }
        return;
    }
      
    if(!the_list||n==m) // empty list orr nth to be done
        return;

    while(last->next)//iterate to last node
    {
        last=last->next;
    }
        
    if(n>m)//adding new nodes
    {   
        int num=n-m;//num to create
        
        for(int i = 0; i<num;i++)
        {
            temp=make_node(val);//new        
            last->next=temp;//link
            last=last->next;
        }
        return;
    }

    if(!n)//clear list
    {
        clear();
        return;
    }
        
    if(n<m)//delete
    {
        erase(n,m);
        return;     
    }

}

/*****************************************************************************/
/*!
  \brief
  Merges both sorted list in ascending order
  
  \param l2
    the other list
  
*/
/*****************************************************************************/ 
void list::merge(list &l2)
{   
    node *merged=nullptr;
    node *shifter= nullptr;//movement in mergedlist



    if(!the_list&&!(l2.the_list))
        return;




    if(!the_list)//when first list expires
    {
        shifter=l2.the_list;//connect the rest of the merged list to l2
        merged=shifter;
        l2.the_list = nullptr; //disconnect
        the_list = merged;
        list_size+=l2.list_size;//shift size
        l2.list_size=0;
        return;
    }
    else if(!(l2.the_list))//when l2 expires
    {
        return;
    }       


    if(the_list->value<=(l2.the_list->value))
    {   //start of merged list              
        shifter=the_list;
        merged=shifter;
        the_list=the_list->next;    
    }
    else
    {
        shifter=l2.the_list;
        merged=shifter;
        l2.the_list=l2.the_list->next;

    }

    while(1)//inf loop to run through both list
    {
        
        if(!the_list)//when first list expires
        {
            //connect the rest of the merged list to l2
            shifter->next=l2.the_list;
            break;
        }
                  
        if(!l2.the_list)//when l2 expires
        {
            shifter->next=the_list;
            break;
        }
        
        if(the_list->value<=(l2.the_list)->value)
        {
            
            shifter->next=the_list;
            the_list=the_list->next;
            
        }
        else
        {
            shifter->next=l2.the_list;
            l2.the_list=(l2.the_list)->next;
        }
        shifter=shifter->next;
        
    }
        
    l2.the_list = nullptr; //disconnect l2
    the_list = merged;     
    list_size+=l2.list_size; //add the size
    l2.list_size=0;         //make it 0
}

}
