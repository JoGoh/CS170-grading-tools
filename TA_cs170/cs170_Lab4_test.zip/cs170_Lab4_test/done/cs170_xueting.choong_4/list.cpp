/******************************************************************************/
/*!
\file list.cpp
\author Choong Xue Ting 
\par email: xueting.choong\@digipen.edu
\par DigiPen login: xueting.choong
\par Course: CS170
\par Lab 04
\date 10/06/2019
\brief
    This file consists of the functions called in main.cpp
    The following functions implemented in list.cpp are 
    (1) Constructor for list.
    (2) Destructor for list.
    (3) Prints out the values contained in the list.
    (4) Returns the current size of the list.
    (5) Returns true if list is empty, false otherwise.
    (6) Frees (deletes) all of the nodes in the list.
    (7) Creates a node with val and add it to the front of the list.
    (8) Return the first node in the list.
    (9) Removes nodes at position pos. Position count starts from zero.
    (10) Removes nodes from position first to position last-1. Position count
		 starts from zero.
    (11) Resizes the list to contain n elements.
    (12) Sorts the list ascendingly.
    (13) Merge current list and l2 into one.
    (14) Make new Node.
*/
/******************************************************************************/
#include <iostream>
#include "list.h"
using namespace std;
/******************************************************************************/
   /*!
      \brief
        Constructor for list.
        This function creates an empty list and set the number of item in the
        list to 0.
    */
/******************************************************************************/
CS170::list::list()
{
    list_size = 0;
    the_list = NULL;
}
/******************************************************************************/
   /*!
      \brief
        Destructor for list.
        This function empty the list and release the allocated memory.
    */
/******************************************************************************/
//make use of temp variable to store head and move along the entire list
//delete head using temp, after moving along the list
CS170::list::~list()
{
    while(the_list)
    {
        node *temp = the_list;
        the_list = the_list->next;
        delete temp;
    }
}
/******************************************************************************/
   /*!
      \brief
        This function prints out the values contained in the list.
    */
/******************************************************************************/
//with existing list, print value of curr node with spacing
//move along the entire list using curr variable
void CS170::list::print_list() const
{
	node *curr = the_list;
    while(curr)
    { 
        cout << curr->value << " ";
        curr = curr->next;	
    }
    cout << endl;
}
/******************************************************************************/
   /*!
      \brief
        This function returns the current size of the list.
        
      \return list_size
        Return the size of the list.
    */
/******************************************************************************/
unsigned CS170::list::size() const
{
    return list_size;
}
/******************************************************************************/
   /*!
      \brief
        This function checks the boolean representation on whether the list
        is empty or not empty.
        
      \return list_size 
        Return true if list is empty, false otherwise.
    */
/******************************************************************************/
//equals to zero, true statement. doesnt equal to zero, false statement.
bool CS170::list::empty() const
{
    return list_size == 0;
}
/******************************************************************************/
   /*!
      \brief
        This function frees (deletes) all of the nodes in the list.
    */
/******************************************************************************/
//make use of temp variable to store head and move along the entire list
//delete head using temp, after moving along the list
//set the list to null and set number of item in list to 0
void CS170::list::clear()
{
    while(the_list)
    {
        node *temp = the_list;
        the_list = the_list->next;
        delete temp;
    }
    
    the_list = NULL;
    list_size = 0;
}
/******************************************************************************/
   /*!
      \brief
        This function creates a node with vla and add it to the front of the
        list.
            
      \param val
        val - takes in an int value from main.cpp.
    */
/******************************************************************************/
void CS170::list::push_front(int val)
{
    node *newnode = make_node(val);
    newnode->next = the_list;
    the_list = newnode;
    list_size++;
}
/******************************************************************************/
   /*!
      \brief
        This function returns the first node in the list.
        
      \return the_list
        Return first node of the list.
    */
/******************************************************************************/
CS170::node* CS170::list::front()
{
    return the_list;
}
/******************************************************************************/
   /*!
      \brief
        This function removes node postition pos and position count starts
        from zero.
            
      \param pos
        pos - takes in an int value from main.cpp.
    */
/******************************************************************************/
void CS170::list::erase(int pos)
{   //empty list
    if(the_list == NULL)
        return;
    //invalid pos
    if(pos < 0 || pos > static_cast<int> (list_size))
        return;
    //make use of temp variable
    node *temp = the_list;
    //head node
    if(pos == 0)
    {
        the_list = the_list->next;
        delete temp;
        list_size--;
		return;
    }
    //iterate position
    for (int i=0; temp!=NULL && i<pos-1; i++) 
         temp = temp->next;
    //
    node *next = (temp->next)->next;
    delete(temp->next);
	list_size--;
    temp->next = next;
}
/******************************************************************************/
   /*!
      \brief
        This function removes nodes from position first to position last-1 and 
        position count starts from zero.
            
      \param first
        first - takes in an int value from main.cpp.
        
      \param last
        last - takes in an int value from main.cpp.
    */
/******************************************************************************/
void CS170::list::erase(int first, int last)
{
    int count = last - first;
    
    for(int i=0; i < count; i++)
        erase(first);
}
/******************************************************************************/
   /*!
      \brief
        This function resizes the list to contain n elements. If n is smaller
        than the current size, then keep onlythe first n elements, then destroy
        those beyond. If n is larger than the current size, the new elements
        are initialized as val.
            
      \param n
        n - takes in an int value from main.cpp.
        
      \param val
        val - takes in an int value from main.cpp.
    */
/******************************************************************************/
void CS170::list::resize(int n, int val)
{
    //for n is smaller than current size
    if(n < static_cast<int>(list_size))
	{
        erase(n, list_size);
    }
    //for n is larger than current size
    else if(n > static_cast<int>(list_size))
    {
        int numExtra = n - list_size;
        list_size += numExtra;
        
        if(!the_list)
        {
            the_list = make_node(val);
            numExtra --;
        }
        
        node *temp = the_list;
        
        while(temp->next)
        {
            temp = temp->next;
        }
        
        for(int i=0; i < numExtra; i++)
        {
            node *temp2 = make_node(val);
            temp->next = temp2;
            temp = temp->next;
        }
    }
}
/******************************************************************************/
   /*!
      \brief
        This function sorts the list ascendingly.
    */
/******************************************************************************/
void CS170::list::sort()
{
    for(node *i = the_list; i != NULL; i = i->next)
    {
        for(node *j = the_list; j->next != NULL; j = j->next)
        {
            if( j->value > j->next->value)
            {
               int temp = j->value;
               j->value = j->next->value;
               j->next->value = temp;
            }
        }
    }
}
/******************************************************************************/
   /*!
      \brief
        This function merge current list and l2 into one. Assume the current
        list and l2 are both sorted ascendingly, this function merges them into
        one, so that the elements are still in ascending order. The current
        list will store the merged elements, while l2 will become empty.
            
      \param &l2
        &l2 - values that are available in the list l2.
    */
/******************************************************************************/
void CS170::list::merge(list &l2)
{
	node * p1 = the_list;
	node * p2 = l2.the_list;
	if(!p1)
	{
		the_list=l2.the_list;
		l2.the_list=nullptr;
		list_size+=l2.list_size;
		l2.list_size=0;
		return;
	}
	else if (!p2)
		return;
	
	


	node * mergehead = nullptr;
	if(p1&&p2)
	{
		if(p1->value < p2->value)
		{
			mergehead=p1;
			p1=p1->next;
		}
		else
		{
			mergehead=p2;
			p2=p2->next;
		}
	}
	
    node * merged = mergehead;
	
	while (p1&&p2)
	{
		
		if(p1->value < p2->value)
		{
			merged->next=p1;
			p1=p1->next;
		}
		else
		{
			merged->next=p2;
			p2=p2->next;
		}	
		merged=merged->next;
	}
	if(!p1)
	{
		merged->next=p2;
		l2.the_list=nullptr;
		list_size+=l2.list_size;
		l2.list_size=0;
		the_list=mergehead;
		return;
	}
	else 
	{
		merged->next=p1;
		l2.the_list=nullptr;
		list_size+=l2.list_size;
		l2.list_size=0;
		the_list=mergehead;
	}
}
/******************************************************************************/
   /*!
      \brief
        This function make new node.
            
      \param val
        val - takes in an int value given by user, used to assign to newly
        created node.
      
      \return newnode
        Return the newly created node.
    */
/******************************************************************************/
CS170::node * CS170::list::make_node(int val)
{
    node *newnode = new node;
    newnode->next = NULL;
    newnode->value = val;
    
    return newnode;
}
