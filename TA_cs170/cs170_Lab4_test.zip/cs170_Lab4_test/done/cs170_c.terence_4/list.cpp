/******************************************************************************/ 
/*! 
\file list.cpp
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 04
\date 07/06/2019 
\brief This file contains the implementation of the following functions for
CS170 Lab 4: C++ Classes
\par Constructors/Destructors include:
list()
~list()
\par Functions include: 
print_list
size
empty
clear
push_front
front
erase (Single)
erase (Multiple)
resize
sort
merge
make_node

\par Hours spent on this assignment: 2 hours
\par Specific portions that gave you the most trouble:  Erase function
*/ 
/******************************************************************************/
#include <iostream>
#include "list.h"

namespace CS170 
{
/******************************************************************************/
/*!
	\brief
		Default constructor for list. Creates an empty list
*/
/******************************************************************************/
	list::list()
	{
		list_size = 0;
		the_list = nullptr;
	}
/******************************************************************************/
/*!
	\brief
		Default destructor for list. Deletes the list and frees all memory used.
*/
/******************************************************************************/
	list::~list()
	{
		clear();
	}
/******************************************************************************/
/*!
	\brief
		Reads in the data of list, and prints each node in proper order
*/
/******************************************************************************/
	void list::print_list() const
	{
		node* toPrintNode = the_list;
		for (unsigned i = 0; i < list_size; ++i)
		{
			std::cout << toPrintNode->value << " ";
			toPrintNode = toPrintNode->next;
		}
		std::cout << std::endl;
	}
/******************************************************************************/
/*!
	\brief
		Returns number of nodes in list as an unsigned value
		
	\return unsigned
		Number of ndoes in list
*/
/******************************************************************************/
	unsigned list::size() const
	{
		return list_size;
	}
/******************************************************************************/
/*!
	\brief
		Checks if list is empty and return that value.

	\return bool
		True if list is empty, false if list has at least one node in list
*/
/******************************************************************************/
	bool list::empty() const
	{
		if (list_size)
			return 1;
		else
			return 0;
	}
/******************************************************************************/
/*!
	\brief
		Deletes all nodes in list.
*/
/******************************************************************************/
	void list::clear()
	{
		node* toDeleteNode;
		for (unsigned i = 0; i < list_size; ++i)
		{
			toDeleteNode = the_list;
			the_list = the_list->next;
			delete toDeleteNode;
		}
		list_size = 0;
	}
/******************************************************************************/
/*!
	\brief
		Creates a node with input value and pushes it to the front of the list

	\param val
		Value of new Node
*/
/******************************************************************************/
	void list::push_front(int val)
	{
		node *toAdd = make_node(val);
		toAdd->next = the_list;
		the_list = toAdd;
		++list_size;
	}
/******************************************************************************/
/*!
	\brief
		Returns the start of the list
		
	\return node*
		Address of first node in list
*/
/******************************************************************************/
	node* list::front()
	{
		return the_list;
	}
/******************************************************************************/
/*!
	\brief
		Deletes a node at given position within list. If value is negative, deletes
		first node instead. If value is out of bounds, ignore it

	\param pos
		Position of node to delete
*/
/******************************************************************************/
	void list::erase(int pos)
	{
		//Safety check if no nodes in list
		if (!list_size)
			return;
		
		//Safety check if delete node 0 or negative input
		if (pos < 1)
		{
			node *toErase = the_list;
			the_list = the_list->next;
			delete toErase;
			--list_size;
		}
		else //if pos >= 1
		{
			//Out of bounds check
			//Checks if position is more than last node's position (-1) due to pos 0
			if (pos > (int)list_size - 1)
				return;
			
			node *itNode = the_list;
			int count = 0;
			//This gets the node before the correct position, and also if it is
			while (count + 1 != pos)
			{
				itNode = itNode->next;
				++count;
			}
			node* toErase = itNode->next;
			itNode->next = toErase->next;
			delete toErase;
			--list_size;
		}
	}
/******************************************************************************/
/*!
	\brief
		Deletes all nodes between two given positions within list. Ignore out of
		bounds nodes, and if minimum point is <0, treat it as position 0.

	\param first
		Position of first node to delete
		
	\param last
		Position of last node to delete
*/
/******************************************************************************/
	void list::erase(int first, int last)
	{
		int min = first, max = last;
		
		//Checking if inputs are in wrong order, resetting them
		if (first > last)
		{
			max = first;
			min = last;
		}
		
		//Checking if max value is out of bounds
		//There is no need to check for min, since even if min > list_size
		//and still smaller than max, numToDelete will be <= 0 so it won't delete.
		if (max > (int)list_size)
			max = list_size;
		
		//Calculate number of nodes to delete. +1 due to position.
		//Etc if delete 1-3, that is deleting 3 nodes, so need add 1 more to count
		int numToDelete = max - min + 1;
		
		//While there are still nodes to delete
		while (numToDelete > 1)
		{
			erase(min);
			--numToDelete;
		}
	}
/******************************************************************************/
/*!
	\brief
		Resizes a list based on given size and value. If size is larger than current
		list, creates and initializes all excess nodes with given value. If size is
		smaller, deletes all excess nodes from the back

	\param n
		Number of nodes in updated list
		
	\param val
		Value of nodes to initialize, if updated list is larger in size
*/
/******************************************************************************/
	void list::resize(int n, int val)
	{
		int check = list_size - n;
		//If list_size is more than n
		if (check > 0)
		{
			//Erase all nodes from position n to the end, leaving n number of nodes
			erase(n, list_size);
		}
		//If list_size is less than n
		else if (check < 0)
		{
			//Checker in case list is empty
			if (the_list == nullptr)
			{
				//Add one node in if no nodes exists
				push_front(val);
				++check;
			}
			//Add the number of new nodes to list. -= since check is negative
			list_size -= check;
			
			//Create to have a pointer to last node
			node* curLastNode = the_list;
			while (curLastNode->next != nullptr)
			{
				curLastNode = curLastNode->next;
			}
			
			//Keep adding nodes until difference is met
			while (check < 0)
			{
				curLastNode->next = make_node(val);
				curLastNode = curLastNode->next;
				++check;
			}
		}
		//Ignore if list_size is same as n
	}
/******************************************************************************/
/*!
	\brief
		Helper function to find the last node of a list

	\param start
		The start node to find the end node of list
*/
/******************************************************************************/
	node* getEnd(node *start)
	{
		while (start != nullptr && start->next != nullptr)
			start = start->next;
		return start;
	}
/******************************************************************************/
/*!
	\brief
		Helper function to split a parition into two sections

	\param head
		The first node in the partition
		
	\param end
		The last node in the partition
		
	\param newHead
		The pointer to pointer to represent the new head of partition
		
	\param newEnd
	The pointer to pointer to represent the new end of partition
*/
/******************************************************************************/
	node* partition(node* head, node* end, node** newHead, node** newEnd)
	{
		//Pivot acts as the "middle point", anything higher goes right,
		//anything lower goes left, to split the list into smaller lists
		node* pivot = end;
		node* prev = nullptr, *current = head, *tail = pivot;
		
		//Since head/end of list might change, have to update newHead/newEnd
		//Checks if iterator is not at the end yet
		while (current != pivot)
		{
			//If the node is smaller than pivot
			if (current->value < pivot->value)
			{
				//Assigns new head
				//Note that since quicksort will call itself again
				//No need to sort this partition, it will autosort with quicksort
				//Calling itself
				if (*newHead == nullptr)
					*newHead = current;
				prev = current;
				current = current->next;
			}
			//This does the same thing for nodes higher than pivot
			else
			{
				//Skips the current node since current node is going to the other end
				if (prev)
					prev->next = current->next;
				
				//Saving the next node for iteration
				node* temp = current->next;
				current->next = nullptr;
				
				//Puts this current node at the end of partition
				tail->next = current;
				tail = current;
				
				//Goes to the next node to check
				current = temp;
			}
		}
		
		//Now that the list has been split into below pivot and above pivot
		//Assign the newHead and newEnd
		
		//If *newHead is nullptr, it means pivot is smaller noded (no node smaller)
		if (*newHead == nullptr)
			*newHead = pivot;
		
		//Always update newEnd
		*newEnd = tail;
		
		//Returns the pivot node
		return pivot;
	}
/******************************************************************************/
/*!
	\brief
		Recurring quicksort helper function that calls itself to sort the list

	\param head
		Head of list to quicksort
		
	\param end
		End of list to quicksort
*/
/******************************************************************************/
		node* quickSort(node* head, node* end)
		{
			//Checks if sorting is needed
		if (head == nullptr || head == end)
			return head;
		
		node* newHead = nullptr, *newEnd = nullptr;
		
		//Sets the pivot of the list
		node* pivot = partition(head, end, &newHead, &newEnd);
		
		//If newHead is pivot, pivot is smallest element
		//So no need to check lower values. Otherwise
		if (newHead != pivot)
		{
			node* temp = newHead;
			
			//Iterate node until it reaches pivot
			while (temp->next != pivot)
				temp = temp->next;
			//Temporarily sets the pivot's next node to be nullptr
			temp->next = nullptr;
			
			//Recur this to split the new list on the left of pivot
			newHead = quickSort(newHead, temp);
			
			//Once left side is sorted
			//Reattach left side with pivot
			temp = getEnd(newHead);
			temp->next = pivot;
		}
		
		//Now that left side is sorted (either by sorting or not needing it)
		//Sort the right side as well, treating pivot->next as the new start
		pivot->next = quickSort(pivot->next, newEnd);
		
		return newHead;
	}
/******************************************************************************/
/*!
	\brief
		Sorts the list to ensure it is in ascending order
*/
/******************************************************************************/
  // Sorts the list ascendingly
	void list::sort()
	{
		//Empty/One node guard
		if (front() == nullptr || front()->next == nullptr)
			return;
		the_list = quickSort(front(), getEnd(front()));
	}
/******************************************************************************/
/*!
	\brief
		Merges both this list with given list. Given list will become empty while
		new list would hold all values. Assumes both lists are sorted, and ensure
		lists are still sorted after merging

	\param l2
		List to be merged with this list
*/
/******************************************************************************/
	void list::merge(list &l2)
	{
		node* itNode = the_list;
		
		if (itNode != nullptr)
		{
			//Iterate to last node in first list
			while (itNode->next != nullptr)
				itNode = itNode->next;
			
			//Linking for this list
			itNode->next = l2.the_list;
			list_size += l2.list_size;
			
			//Linking for other list
			l2.the_list = nullptr;
			l2.list_size = 0;
			
			//Sort afterwards
			sort();
		}
		else //If this list is empty
		{
			//Linking for this list
			the_list = l2.the_list;
			list_size = l2.list_size;
			
			//Linking for other list
			l2.the_list = nullptr;
			l2.list_size = 0;
			
			//Sort not needed since is already sorted
		}
	}
/******************************************************************************/
/*!
	\brief
		Creates and allocates space for a new Node. Returns node address

	\param val
		Value of new Node
		
	\return node*
		Address of new Node created
*/
/******************************************************************************/
	node* list::make_node(int val)
	{
		node *pNode = new node;
		pNode->value = val;
		pNode->next = nullptr;  
		return pNode;
	}
}
