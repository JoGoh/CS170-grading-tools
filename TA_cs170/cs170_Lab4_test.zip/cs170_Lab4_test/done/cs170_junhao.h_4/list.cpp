/******************************************************************************/
/*! 
\file   list.cpp
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 03 
\date   03/6/2019 
\brief     Creating a linked list in class.  
It include: 
make_node, 
list, 
~list, 
print_list,
size,
empty,
clear,
push_front, 
front, 
erase,
resize,
sort, 
merge 
*/ 
/******************************************************************************/
#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here
namespace CS170 
{
/******************************************************************************/
/*!      
  This function allocate memory and set members 
 
  \param   val (int)   
  value to set for allocated memory

  \return  node
  Return a allocated memory containing value 
*/ 
/******************************************************************************/
  node *list::make_node(int val) 
  {
    node *pNode = new node;
    pNode->value = val;
    pNode->next = nullptr;  
    ++list_size;
    return pNode;
  }

/******************************************************************************/
/*!      
  This function is the default constructor for list
*/ 
/******************************************************************************/
  list::list() : list_size{0},the_list{nullptr}
  {}

/******************************************************************************/
/*!      
  This function is the destructor for list
*/ 
/******************************************************************************/
  list::~list()
  {
    clear();
  }
 
/******************************************************************************/
/*!      
  This function prints the entire linked list.
*/ 
/******************************************************************************/
  void list::print_list() const
  {
    node *tmp = the_list;
    while (tmp)
    {
      std::cout << tmp->value << " ";
      tmp = tmp->next;
    }
    std::cout << std::endl;   
  }

/******************************************************************************/
/*!      
  This function is the getter for list_size.
*/ 
/******************************************************************************/
  unsigned list::size() const
  {
    return list_size;
  }

/******************************************************************************/
/*!      
  This function checks if list is empty.
*/ 
/******************************************************************************/
  bool list::empty() const
  {
    return list_size ? false : true;
  }

/******************************************************************************/
/*!      
  This function clears the list.
*/ 
/******************************************************************************/
  void list::clear()
  {
    node *CurrNode = the_list;
    while (CurrNode) 
    {
      the_list = CurrNode->next;
      delete CurrNode;
      CurrNode = the_list;
      --list_size;
    }
    the_list = nullptr;
  }

/******************************************************************************/
/*!    
  Adds a node to the start of the list
 
  \param   val (int)   
  value to set for allocated memory
*/ 
/******************************************************************************/
  void list::push_front(int val)
  {
    node *NewNode = make_node(val);
    NewNode->next = the_list;
    the_list = NewNode;  
  }

/******************************************************************************/
/*!      
  This function is the getter for the_list.
*/ 
/******************************************************************************/
  node *list::front()
  {
    return the_list;
  }

/******************************************************************************/
/*!    
  Delete a node in set position
 
  \param   pos (int)   
  position of node to be deleted
*/ 
/******************************************************************************/
  void list::erase(int pos)
  {
    if (pos < 0 || empty())
      return;
    if (static_cast<unsigned>(pos) >= list_size)
      return;

    if (pos == 0)
    {
      node *temp = the_list->next;
      delete the_list;
      the_list = temp;
    }
    else
    {
      node *Curr = the_list , *Prev = nullptr;
      int i = 0;
      while (i != pos && Curr)
      {
        Prev = Curr;
        Curr = Curr->next;
        ++i;
      }
      Prev->next = Curr->next;
      delete Curr;
    }
    --list_size;
  }

/******************************************************************************/
/*!    
  Delete a node in set range of position
 
  \param   first (int)   
  position of first node to be deleted

  \param   last (int)   
  position of last node to be deleted
*/ 
/******************************************************************************/
  void list::erase(int first, int last)
  {
    if (first < 0 || last < 0 || first > last)
      return;
    node *Prev = nullptr, *Curr = the_list;
    int counter = 0;
    
    // Check if the list is it a nullptr
    if(the_list)
    {
      while(Curr)
      {
        if(counter >= first && counter < last)
        {
          node * tmp = Curr;
          if(Prev)
            Prev->next = Curr->next;
          if(the_list == Curr)
            the_list = Curr->next;
          
          //remove portion
          Curr = Curr->next;
          delete tmp;
          --list_size;
        }
        else
        {
          // Increment the current list and the previous list
          Prev = Curr;
          Curr = Curr->next;
        }
        ++counter;
      }
    }
    else
      return;
  }

/******************************************************************************/
/*!    
  Resizes the list to contain n elements. If n is smaller than the current size,
  then keep only the first n elements, then destroy those beyond.If n is 
  larger than the current size, the new elements are initialized as val.

  \param   n (int)   
  new size of list

  \param   val (int)   
  contents of new node to be added
*/ 
/******************************************************************************/
  void list::resize(int n, int val)
  {
    if (n <= 0) 
    {
      clear();
      return;
    }

    // if n is smaller than list size
    else if (static_cast<unsigned>(n) < list_size)
    {
      erase(n, list_size);
      return;
    }
    // if n is larger than list size
    else
    {
      int Cap = (n - list_size);
      // Larger capacity check
      while (Cap)
      {
        node * Curr = the_list;
        node *tmp = make_node(val);
        if(Curr != nullptr)
        {
          while(Curr->next)
            Curr = Curr->next;
          Curr->next = tmp;
        }
        else
          the_list = tmp;
        --Cap;
      }
    }
  }

/******************************************************************************/
/*!    
  Selective Sort the list in ascending order
*/ 
/******************************************************************************/
  void list::sort()
  {
    // Create 2 temporary Node
    node *lhs = the_list;
    node *rhs = the_list;
    // Value used for swapping
    int tmp = 0;
    int min_value = 0;
    
    // Value used to check which value is the smallest in the list
    if(rhs != nullptr)
      min_value = rhs->value;
    
    while(lhs != nullptr)
    {
      //Reset rhs position and value
      rhs = lhs;
      min_value = rhs->value;
      while(rhs != nullptr)
      {
       
        if(rhs->value < min_value)
          // Getting the smallest value in the list
          min_value = rhs->value;
        
         rhs = rhs->next;
      }
      // reset rhs again
      rhs = lhs;
      
      while(rhs != nullptr)
      {
        if(rhs->value == min_value)
        {
          tmp = rhs->value;
          rhs->value = lhs->value;
          lhs->value = tmp;
          lhs = lhs->next;
        }
        // Shifting rhs forward
        rhs = rhs->next;
      }
    }
    return;
  }

/******************************************************************************/
/*!    
  Assume the current list and l2 are both sorted ascendingly, this function 
  merges them into one, so that the elements are still in ascending order.
  The current list will store the merged elements, while l2 will become empty.

  \param   l2 (list)   
  A separate to merge with
*/ 
/******************************************************************************/
  void list::merge(list &l2)
  {
    node *lhs = the_list;
    node *rhs = l2.front();
    node *lprev = nullptr, *rprev = nullptr;

    while (true)
    {
      // loop ends once pointer iterates to end of link list
      if (lhs == nullptr)
      {
        if (!lprev) // check if list is empty from the start
          the_list = rhs;
        else
          lprev->next = rhs;
        list_size += l2.size();
        l2.list_size = 0;
        break;
      }
      if (rhs == nullptr)
        break;

      // Compare the value of the 2 list
      if (lhs->value <= rhs->value)
      {
        // move to next node in lhs
        lprev = lhs;
        lhs = lhs->next;
      }
      else
      {
        rprev = rhs;
        rhs = rhs->next;
        rprev->next = lhs;
        if (lprev == nullptr)
        {
          lprev = rprev;
          the_list = lprev;
        }
        else
        {
          lprev->next = rprev;
          lprev = lprev->next;
        }

        // adjust the list size
        ++(this->list_size);
        --(l2.list_size);
      }
    }
    l2.the_list = nullptr;
  }        
}