/******************************************************************************/
/*!
\file list.cpp
\author Koh Joon Yee Marcus
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: CS170
\par Lab : 04
\date 10/06/2019
\brief
This file contains the implementation of the following functions for Lab 04
Functions include:
sort
merge
erase
erase (range)

\par Hours spent on this assignment: 3


*/
/******************************************************************************/

#include <stdlib.h>
#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here

namespace CS170
{
    list::list()
    {
    the_list= (nullptr);
    list_size =(0);
    }


    list::~list()
    {
        //make temp pointer to list head
        while(the_list)
        {
            node * pList = the_list->next;
            delete the_list;
            the_list = pList;
        }
        the_list = nullptr;
        list_size = 0;
    }

    node *list::make_node(int val){
        node * pNode = new node;
        pNode->value = val;
        pNode->next = nullptr;
        return pNode;
    }

    void list::print_list() const
    {
        //Create temp pointer to list head
        node * pList =  the_list;
        while(pList)
        {
            std::cout << pList->value << " ";
            pList = pList->next;
        }
        std::cout <<std::endl;
    }


    unsigned list::size() const
    {
        //create temp pointer to the list head
        node * pList = the_list;
        //Create unsigned variable to return
        size_t count = 0;


        while (pList) {
        count++;
        pList = pList->next;
        }
        return count;
    }


    bool list::empty() const
    {
        if(the_list!= nullptr && the_list->next!=nullptr)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    void list::clear()
    {
        //make temp pointer to list head
        while(the_list)
        {
            node * pList = the_list->next;
            delete the_list;
            the_list = pList;
        }
        list_size = 0;

    }

    void list::push_front(int val)
    {
        if(the_list == nullptr)
        {
            the_list = make_node(val);
            list_size++;
        }
        else
        {
            //create the new node to be inserted
            node * newNode = make_node(val);

            //make the new node point to the current head
            newNode->next = the_list;
            //make the new head the new inserted node
            the_list = newNode;
            //Increment list_size after inserting new node
            list_size++;
        }
    }



    node * list::front()
    {
        return the_list;
    }

    void list::erase(int pos)
    {
        if(the_list)
        {
            if(pos <= 0)
            {
                node* remove_this = the_list;
                the_list = the_list->next;
                delete remove_this;
                list_size--;
            }
            else
            {
                node* previousPos = the_list;
                node * currentPos = the_list;

                while(pos)
                {
                    previousPos = currentPos;
                    currentPos = currentPos->next;
                    if(currentPos->next == nullptr)
                    {
                        break; //because pos is > list_size
                    }
                    --pos;
                }
                node * tempNode = nullptr;
                tempNode = currentPos;
                previousPos->next = currentPos->next;
                delete tempNode;
                list_size--;
            }
        }
    }



/**
	\fn void list::erase(int first, int last)
    \brief this function takes in two integers specifying the range of
	nodes to delete within the list and removes them accordingly
	\param first - the start of the range
	\param last - the end of the range
	\return void
*/
    void list::erase(int first, int last)
    {
        if(first > last)
        {
            return;
        }
        if(first < 0 && last > static_cast<int>(list_size) )
        {
            clear();
        }

        if(first <0 && last <= static_cast<int>(list_size))
        {

            node * temp = the_list;
            node * pList = the_list;
            int i=0;
            while(i != last)
            {
                temp = pList;
                pList = pList->next;
                delete temp;
                list_size--;
                i++;
            }
        }
        else if(first >= 0  &&  last > static_cast<int>(list_size))
        {
            node * temp  = the_list;
            node * pList = the_list;
            int i = first;
            if(first> static_cast<int>( list_size))
            {
                return;
            }

            if(first==0)
            {
                clear();
            }
            else
            {
                while(i < first)
                {
                    pList= pList->next;
                    i++;
                }
                while(pList)
                {
                    temp = pList;
                    pList = pList ->next;
                    delete temp;
                    list_size--;
                }
            }

        }
        else if(first>=0 && last <=static_cast<int>(list_size))
        {
            node * current = the_list;
            node* temp;
            int count;
            int skipnumber = last - first;

            if(first==0)
            {
                while(skipnumber)
                {
                    node* temp = current;
                    current = current->next;
                    delete temp;
                    list_size--;
                    --skipnumber;
                }

                the_list= current;
            }

            else
            {
                while(current)
                {
                  for(count = 1; count < first  && current!=nullptr; count++)
                  {
                    current = current->next;
                  }
                  if(current == nullptr)
                  {
                    return;
                  }
                  temp = current->next;

                  for(count = 1 ;count<= skipnumber && temp!=nullptr; count++)
                  {
                    node* removethis = temp;
                    temp = temp->next;
                    delete removethis;
                    list_size--;
                  }
                  current->next = temp;

                  current = temp;
                }
            }
        }
    }

/**
	\fn void list::resize(int n, int vals)
	\brief this function takes in 2 integers and changes the size of the list
	if n is greater than the list size then the list is resized with new nodes
	initialized as vals.
	\param n - the size of the list to be changed to
	\param vals - the vals of the nodes to be added to the list if n>list_size
	\return void
*/
    void list::resize(int n, int vals)
    {
        if(n== static_cast<int>(list_size))
        {
            return;
        }

        if(n < static_cast<int>(list_size))
        {

            if(n== 0 )
            {
                clear();
            }

            else
            {
                node *current = the_list, *temp;
                int count;

                for (count = 1; count < n &&
                        current!= nullptr; count++)
                        current = current->next;

                // If we reached end of list, then return
                if (current == nullptr)
                    return;

                temp = current->next;
                while(temp)
                {
                    node *removethis = temp;
                    temp = temp->next;
                    delete removethis;
                    list_size--;
                }
                current->next = temp;
                current = temp;
            }
        }
        else if( n > static_cast<int>(list_size))
        {
            int i = 1;
            node * pList = the_list;
            if(the_list==nullptr)
            {
                for(i= n; i> 0 ; i--)
                {
                    push_front(vals);
                }
            }
            else
            {
                while( pList->next)
                {
                    pList = pList->next;
                    i++;
                }
                while(i< n)
                {
                    pList->next = make_node(vals);
                    i++;
                    pList =pList->next;
                    list_size++;
                }
            }
        }
    }


/**
	\fn void list::sort()
	\brief sorts the list in ascending order
	\return void
*/
    void list::sort()
    {
        node* temp = the_list;

        // Traverse the List
        while (temp)
        {
            node* min = temp;
            node* r = temp->next;

            // Traverse the unsorted sublist
            while (r) {
                if (min->value > r->value)
                    min = r;

                r = r->next;
            }

            // Swap Data
            int x = temp->value;
            temp->value = min->value;
            min->value = x;
            temp = temp->next;
        }
    }

/**
	\fn void list::merge(list &l2)
	\brief A function that merges two lists and sorts the resulting list
	\param l2 - a reference to the second list
	\return void
*/
    void list::merge(list &l2)
    {
        node * pList2 = l2.the_list;

            if(pList2)
            {
                node * temp = pList2;

                while(temp)
                {
                    push_front(temp->value);
                    temp= temp->next;
                }
            }

            //then delete list 2.
            l2.clear();
            //then sort list 1

        sort();
    }



}












