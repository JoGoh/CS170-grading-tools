/******************************************************************************/
/*!
\file list.cpp
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par Lab #4
\date 04/06/2019
\brief This file contains the implementation of the following functions for
CS170 (lab 04).
Functions include:
getMiddleNode
mergeList
mergeSort
list
~list
make_node
print_list
size
empty
clear
push_front
front
erase
erase
resize
sort
merge

Hours spent on this assignment: 5
Specific portions that gave you the most trouble: -
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

namespace CS170
{
    // To get middle node of list
    node *getMiddleNode(node *&list);

    // Merge them into a list
    node *mergeList(node *&left, node *&right);

    // Merge sort
    void mergeSort(node *&list);
    
/******************************************************************************/
/*!
    \brief getMiddleNode
        To return the middle node from the list

    \param list
        The Node's reference to a pointer

    \return
        Node*
*/
/******************************************************************************/
    node *getMiddleNode(node *&list)
    {
        // To check the list is not empty
        if (list)
        {
            // To create the reference node
            node *middleNode = list;
            node *endNode = list;
            
            // Loop through the list and get the middle node
            while (endNode->next && endNode->next->next)
            {
                // Increment the middle node
                // Increment the end node as well (but twice the speed)
                middleNode = middleNode->next;
                endNode = endNode->next->next;
            }
            // Gotten the middle node and return
            return middleNode;
        }
        
        // if list is empty
        return nullptr;
    }
/******************************************************************************/
/*!
    \brief mergeList
        To merge two sorted list into one

    \param left 
        The Node's reference to a pointer to a left list

    \param right 
        The Node's reference to a pointer to a right list

    \return
        Node*
*/
/******************************************************************************/
    node *mergeList(node *&left, node *&right)
    {
        // To check if the list is empty
        if (left == nullptr || right == nullptr)
            return nullptr;

        // To create reference node
        node *startNode = nullptr;
        node *currNode = nullptr;

        // If left is smaller,
        // set the start node to the left list
        // else set the start node to the right list
        if (left->value < right->value)
        {
            // Set the start node to the left list
            startNode = left;

            // Go to next
            left = left->next;
        }
        else
        {
            // Set the start node to the right list
            startNode = right;

            // Go to next
            right = right->next;
        }

        // Assign the current node to the start node
        currNode = startNode;

        // Loop through the left and right list
        while (left && right)
        {
            // If left is smaller,
            // set the curr node to point to left
            if (left->value < right->value)
            {
                // Add the left node to the list
                // Increment the left 
                currNode->next = left;
                left = left->next;
            }
            else
            {
                // Add the right node to the list
                // Increment the right 
                currNode->next = right;
                right = right->next;
            }

            // Increment the curr node
            currNode = currNode->next;
        }

        // If either of the list have leftover, concat it to the end of list
        if (left)
            currNode->next = left;
        else
            currNode->next = right;

        // Return the start of the list
        return startNode;
    }
/******************************************************************************/
/*!
    \brief mergeSort
        To merge two sorted list into one

    \param list
        The Node's reference to a pointer

    \return
        void
*/
/******************************************************************************/
    void mergeSort(node *&list)
    {
        // To check if the list is empty
        if (list == nullptr || list->next == nullptr)
          return;

        // To initialise the reference node
        node *leftList = list;
        node *middleNode = getMiddleNode(list);
        node *rightList = middleNode->next;

        // To set the middleNode next
        middleNode->next = nullptr;

        // Sort left list
        mergeSort(leftList);

        // Sort right list
        mergeSort(rightList);

        // Merge both list into one, in a sorted order
        list = mergeList(leftList, rightList);  
    }
/******************************************************************************/
/*!
    \brief list
        Constructor. To construct a empty list

    \return
        No return type
*/
/******************************************************************************/
    list::list() 
        : list_size(0)
        , the_list(nullptr)
    {
    }
/******************************************************************************/
/*!
    \brief ~list
        Destructor. To delete the list and release the allocated memory 

    \return
        No return type
*/
/******************************************************************************/
    list::~list()
    {
        clear();
    }
/******************************************************************************/
/*!
    \brief make_node
        To create a node

    \param val
        The desired value for the node

    \return
        node*
*/
/******************************************************************************/
    node* list::make_node(int val)
    {
        // Allocate memory and set members
        node *pNode = new node;
      
        // Assign
        pNode->value = val;
        pNode->next = nullptr;
        
        // Increment the size of the list
        ++list_size;
        
        return pNode;
    }
/******************************************************************************/
/*!
    \brief print_list
        To print the list of every node

    \return
        void
*/
/******************************************************************************/
    void list::print_list() const
    {
        // Create a reference node to move the list
        node *currNode = the_list;
        
        // Prints all of the nodes values
        while (currNode) 
        {
            std::cout << currNode->value << " ";
            currNode = currNode->next;
        }
        std::cout << std::endl; 
    }
/******************************************************************************/
/*!
    \brief size
        To return the current size of the list

    \return
        unsigned
*/
/******************************************************************************/
    unsigned list::size() const
    {
        return list_size;
    }
/******************************************************************************/
/*!
    \brief empty
        Returns true if list is empty, false otherwise

    \return
        bool
*/
/******************************************************************************/
    bool list::empty() const
    {
        // Check if the list is empty
        if (list_size)
            return false;
        
        return true;
    }
/******************************************************************************/
/*!
    \brief clear
        Delete the whole list

    \return
        void
*/
/******************************************************************************/
    void list::clear()
    {
        // Create a temp node to be deleted
        node *pCurrNode = the_list;

        // Loop through the node
        while (pCurrNode) 
        {
            // Increment the node and delete
            the_list = pCurrNode->next;
            delete pCurrNode;
            pCurrNode = the_list;
            
            // Decrement the list size
            --list_size;
        }
        // Set the list to be nullptr
        the_list = nullptr;
    }
/******************************************************************************/
/*!
    \brief push_front
        Add a node to the start of the list

    \param val
        The desired value for the node

    \return
        void
*/
/******************************************************************************/
    void list::push_front(int val)
    {
        // Make a new node
        node *pNewNode = make_node(val);
        
        // Assign the node
        pNewNode->next = the_list;
        the_list = pNewNode;  
    }
/******************************************************************************/
/*!
    \brief front
        To return the first node in the list 

    \return
        node*
*/
/******************************************************************************/
    node* list::front()
    {
        return the_list;
    }
/******************************************************************************/
/*!
    \brief erase
        To remove the node at the desired position.
        Position count starts from zero.

    \param pos
        The desired position for the node
        
    \return
        void
*/
/******************************************************************************/
    void list::erase(int pos)
    {
        // To ensure that the list is not empty
        if (!the_list)
            return;
        
        // Make sure the position given is in range
        if ((unsigned)pos >= list_size)
            return;
        
        // Create reference node
        node *currNode = the_list;
        node *prevNode = nullptr;
        
        // Loop through the list to the desired position
        for (int i = 0 ; i < pos; ++i)
        {
            // Iterate through the list
            prevNode = currNode;
            currNode = currNode->next;
        }
        
        // To check if there's a previous node
        if (prevNode != nullptr)
        {
            // Link the nodes and delete the curr node
            prevNode->next = currNode->next;
            delete currNode;
            currNode = nullptr;

            // Decrement the list size
            --list_size;
            
            return;
        }
        // if position given is at 0
        else 
        {
            // Delete the curr node
            the_list = currNode->next;
            delete currNode;
            currNode = nullptr;
            
            // Decrement the list size
            --list_size;
            
            return;
        }
    }
/******************************************************************************/
/*!
    \brief erase
        To remove the node from position first to position last-1. 
        Position count starts from zero.

    \param first
        The desired position for the first node

    \param last
        The desired position for the last node
        
    \return
        void
*/
/******************************************************************************/
    void list::erase(int first, int last)
    {
        //- if list is empty,
        if (the_list == nullptr)
            return;

        // Create reference node
        node *currNode = the_list;
        node *prevNode = nullptr;

        // which index the current node is at
        int index = 0;

        // Loop through the list
        while (currNode)
        {
            // Found the node to be erase
            if (index >= first && index < last)
            {
                // Record node to delete
                node* tobeDeleted = currNode;

                // Link the prev node to the next node
                if (prevNode != nullptr)
                    prevNode->next = currNode->next;
                
                // Link main list to something
                if (the_list == currNode)
                    the_list = currNode->next;
                
                // Move the curr Node 
                currNode = currNode->next;

                // Delete the node
                delete tobeDeleted;

                // Decrease size
                --list_size;
            }
            else
            {
                // Increment the node
                prevNode = currNode;
                currNode = currNode->next;
            }

            // Increment the index
            ++index;

        }
    }
/******************************************************************************/
/*!
    \brief resize
        Resizes the list to contain n elements. If n is smaller than the 
        current size, then keep only the first n elements, then destroy those
        beyond. If n is larger than the current size, the new elements
        are initialized as val.

    \param n
        The desired number of elements for the list

    \param val
        The desired value for the node
        
    \return
        void
*/
/******************************************************************************/
    void list::resize(int n, int val)
    {
        // If n is smaller than the list of the list
        // erase those beyond
        if ((unsigned)n < list_size)
            erase(n, list_size);
        else
        {
            // The difference between the n elements and the size of the list
            int diff = n - list_size;
            
            while (diff)
            {
                // Create reference node
                node *currNode = the_list;
            
                // Make a new node
                node *pNewNode = make_node(val);
                
                // Check if the list is not empty
                if (currNode)
                {
                    // Increment the node to the last
                    while (currNode->next)
                        currNode = currNode->next;
                    
                    currNode->next = pNewNode;
                }
                else
                    the_list = pNewNode;
                
                // Decrease the diff
                -- diff;
            }
        }
            
    }
/******************************************************************************/
/*!
    \brief sort
        To sort the list in the list ascendingly (divide and conquer)
        
    \return
        void
*/
/******************************************************************************/
    void list::sort()
    {
        mergeSort(the_list);
    }
/******************************************************************************/
/*!
    \brief merge
        Assume the current list and l2 are both sorted ascendingly,
        this function merges them into one, so that the elements
        are still in ascending order. The current list will store the merged
        elements, while l2 will become empty.

    \param l2
        Another list's reference to be merge
        
    \return
        void
*/
/******************************************************************************/
    void list::merge(list &l2)
    {
        // Create reference node
        node *list1 = the_list;
        node *list2 = l2.front();

        // To check if list 1 is empty
        if (list1 != nullptr)
        {
            // Loop through list 1, to reach the last node
            while (list1->next != nullptr)
                list1 = list1->next;

            // Add every node from list2 to list1
            while (list2 != nullptr)
            {
                list1->next = make_node(list2->value);
                list1 = list1->next;
                list2 = list2->next;
            }
        }
        else
        {
            //- If list 2 is not empty
            if (list2 != nullptr)
            {
                // original list = list 2
                the_list = make_node(list2->value);
                list1 = the_list;
                list2 = list2->next;
                
                // Assign the remaining node from list 2 to list 1
                while (list2 != nullptr)
                {
                    list1->next = make_node(list2->value);
                    list1 = list1->next;
                    list2 = list2->next;
                }
                
            }
        }
        
        // Clear away list 2
        l2.clear();

        // Sort the list
        sort();
    }
}