/*****************************************************************************/
/*! 
\file   list.cpp 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 04
\date   10/06/2019
\brief     
This program contains the various member class functions that will modify
linked list and provide functionalities such as printing, sorting, deleting,
merging, clearing, etc. 
*/ 
/*****************************************************************************/

#include <iostream>
#include "list.h"

/*****************************************************************************/

using namespace CS170;

list::list()
{
	list_size = 0;
	the_list = nullptr;
}

list::~list()
{
	clear();
}

/*****************************************************************************/
/*!

 \fn print_list
 
 \brief
   This member function will print out all the values of each node in the list.
   
*/ 
/*****************************************************************************/
void list::print_list() const
{
  node *ptr = the_list;  // pointer to the list
  
  while (ptr)  // while list is not empty
  {
    std::cout << ptr->value << " ";  // print out the node's value
    ptr = ptr->next;  // move to the next node
  }
	std::cout << std::endl;  // print new line
}

/*****************************************************************************/
/*!

 \fn size
 
 \brief
   This member function will return the number of nodes in the list.
   
 \return
   Returns a unsigned integer.
   
*/ 
/*****************************************************************************/
unsigned list::size() const
{
  return list_size;   // returns the size of the list
}

/*****************************************************************************/
/*!

 \fn empty
 
 \brief
   This member function will check if a list is empty or filled. 
   
 \return
   Returns bool, true or false. 
   
*/ 
/*****************************************************************************/
bool list::empty() const
{
	if(the_list == nullptr)  // if list is empty, return true
		return true;
  else  // if list is not empty, return false
    return false;
}

/*****************************************************************************/
/*!

 \fn clear
 
 \brief
   This member function will clear out the list. 
   
*/ 
/*****************************************************************************/
void list::clear()
{
	node *pCurrNode = the_list;  // pointer to list
	
  while (pCurrNode)  // while list is not empty
	{
    the_list = pCurrNode->next;  // move to the next node
    delete pCurrNode;  // delete the previous node
    list_size--;  // update size of linked list
    pCurrNode = the_list;  // point to the list
  }
  the_list = nullptr;  // set pointer to nullptr after clearing all
}

/*****************************************************************************/
/*!

 \fn push_front
 
 \brief
   This member function will clear out the list. 
   
 \param val 
   val - Int that takes in a value to be stored in the Node. 
   
*/ 
/*****************************************************************************/
void list::push_front(int val)
{
  node *pNewNode = make_node(val);  // store new node into this pointer
  pNewNode->next = the_list;  // the new node will point to the list
  the_list = pNewNode;  // the list's head will point to new node
  list_size++;  // increase size of linked list count
}

/*****************************************************************************/
/*!

 \fn front
 
 \brief
   This member function will return the first node in the list.
   
 \return
   Returns a pointer to a struct node. 
   
*/ 
/*****************************************************************************/
node * list::front()
{
	if(the_list)  // if the list is not empty
		return the_list;  // return the head of the list
	else
    return nullptr;  // if list is empty, return nullptr
}

/*****************************************************************************/
/*!

 \fn erase
 
 \brief
   This member function will erase a node at the specified position. 
   
 \param pos 
   pos - Int that refers the position in the linked list. 
*/ 
/*****************************************************************************/
void list::erase(int pos)
{
	node *CurrList = the_list;  // to be used for looping
	node *PrevNode = the_list;  // to be used to track prev nodes
	int position = 0;  // to be used to keep track of node's position
  
  if(list::empty())  // if list is empty, there's nothing to erase
    return;
	
  if(pos > (int)list_size)  // if position is beyond list size, cant delete
    return;
  
	else if(pos <= 0)  // deletion is at the first node in the list
	{
		the_list = the_list->next;  // move to the next node in list
		delete CurrList;  // delete the head of the list
    list_size--;  // reduce size of linked list count
    
		return;
	}
	else if(pos >= (int)list_size)  // deletion is beyond the first node
	{
		while(CurrList->next->next)  // while there are nodes to move to
		{
			CurrList = CurrList->next;  // move to the next node
		}
		delete CurrList->next;  // delete node
    list_size--;  // decrease size of list count
		CurrList->next = nullptr;  // set tail of list to point to nothing
    
		return;
	}
	else
	{
		while(CurrList)  // while not at the end of list
		{
			PrevNode = CurrList;  // to be used as tail of list
			CurrList = CurrList->next;  // move to the next node
			position++;  // increment position counter
      
			if(position == pos)  // break once desired position is reached
				break;
		}
		PrevNode->next = CurrList->next;  // re-link nodes
		delete CurrList;  // delete the node inbetween
    list_size--;  // decrease size of list count
		return;
	}
}

/*****************************************************************************/
/*!

 \fn erase
 
 \brief
   This member function will erase nodes from a specified position to 
   another specified position. 
   
 \param first, last 
   first - Int that specifies the starting position. 
   last  - Int that specifies the ending position. 
   
 \return
   Returns a pointer to a struct node. 
   
*/ 
/*****************************************************************************/
void list::erase(int first, int last)
{
  node *CurrList = the_list;  // to be used for loops
  node *tempNode = nullptr;  // to be used to delete nodes
  node *tailOfFirst = nullptr;  // to be used as tail of first list
  int position = 0;  // to be used to keep track of node position
  
  if(first > (int)list_size || list::empty()) // list is empty or beyond list
    return;
  else if(first == 0 && last == 0) // if first and last are 0, nothing to del
    return;
    
  if(first == 0 && last == 1) // to handle first node cases or 1 node in list
  {
    tempNode = CurrList;  // point to the first node
    CurrList = CurrList->next;  // move to the next node
    delete tempNode;  // delete the first node
    list_size--;  // decrease size of list count
    
    if(!CurrList)  // if next node doesn't exist
      CurrList = nullptr;  // point to null
    
    the_list = CurrList;  // update linked list
    return;
  }
  
  else if(first == 0 && last > 1) // handle first node and delete nodes in front
  {
    while(CurrList)  // loop to reach node at desired position
    {
      tempNode = CurrList;  // point to the list
      CurrList = CurrList->next;  // move to the next node
      delete tempNode;  // delete previous node
      list_size--;  // decrease size of list count
      if(position == last - 1)  // if desired position is reached
      {
        the_list = CurrList;  // update linked list
        break;  // break out of loop
      }
      position++;  // increment position counter
    }
    if(!CurrList && position != last - 1)  // if deletion is beyond list size
      the_list = nullptr;  // set tail of list to nullptr, nothing more to del
    
    return;
  }
  else if(first > 0 && last > 1)  // handle nodes in the middle of list
  {
    while(CurrList)  // loop to reach node at first position
    {
      tailOfFirst = CurrList;  // point to the list 
      CurrList = CurrList->next;  // move to the next node 
      position++;  // increment position counter
      
      if(position == first)  // if position is reached 
      {
        break;  // stop finding position and break out of loop
      }
    }
    
    while(CurrList)  // loop to delete nodes within the range
    {
      tempNode = CurrList;  // point to the list 
      CurrList = CurrList->next;  // move to the next node 
      delete tempNode;  // delete previous node 
      list_size--;  // decrease size of list count 
      position++;  // increment position counter 
      
      if(position == last)  // if desired position is reached
      {
        break;  // stop deleting and break loop
      }
    }
    if(CurrList)  // if there are nodes after the deleted nodes
      tailOfFirst->next = CurrList;  // link the nodes back in the list
    else
      tailOfFirst->next = nullptr;  // there's no nodes after the deleted ones
    
    return;
  }
}

/*****************************************************************************/
/*!

 \fn sort
 
 \brief
		This member function will sort all the nodes in the list from lowest 
    value to highest value.

*/ 
/*****************************************************************************/
void list::sort()
{
  if(list::empty())  // if list is empty, nothing to sort
    return;
  
	node *CurrList = the_list;  // pointer to list of nodes
	node *Temp = the_list;  // to be used for the nested while loops
	int Lowest = 0;  // to store the lowest value in list
	
	if(the_list == nullptr || the_list->next == nullptr)
		return;  // return if list is empty or only has 1 node
	
	while(CurrList)  // while not at the end of the list 
	{
		Lowest = Temp->value;  // set lowest value to the value of the first node
		
		while(Temp)  // loop to find my lowest number here 
		{
			if(Temp->value < Lowest)  // if current node value is lower
			{
				Lowest = Temp->value;  // replace lowest number
			}
			Temp = Temp->next;  // move to the next node
		}
		
		Temp = CurrList;  // reset Temp pointer back to reuse for next loop
		
		while(Temp)  // loop to push my lowest value nodes infront of list
		{
			if(Temp->value == Lowest)  // if lowest value node is found
			{
				Temp->value = CurrList->value;  // swap values with current node
				CurrList->value = Lowest;  // swap values with lowest value
				CurrList = CurrList->next;  // move to next node in CurrList loop
			}
			Temp = Temp->next;  // move to the next node
		}

		Temp = CurrList;  // once lowest is shifted infront, loop from next node
	}
}

/*****************************************************************************/
/*!

 \fn resize
 
 \brief
		This member function will resize the linked list and remove nodes or
    add nodes if necessary to meet the resize criteria. 
   
 \param n, val
   n - Int that refers to the desired size of the list. 
   val - Int to be stored as the value of the Node. 

*/ 
/*****************************************************************************/
void list::resize(int n, int val)
{
  node *CurrList = the_list;  // pointer to the list of nodes
  node *tempNode = nullptr;  // to be used for node deletion
  int position = 0;  // initial position in the list

  if(n == (int)list_size)  // resize is size of list, nothing to resize
    return;
  else if(n > (int)list_size)  // if resize beyond the size of list 
  {
    if(CurrList)  // if list is not empty
    {
      while(CurrList && CurrList->next)  // loop to reach position 
      {
        CurrList = CurrList->next;  // go to the next node in the list
        position++;  // increment position counter
      }
      
      while(CurrList) // loop to create nodes 
      {
        CurrList->next = make_node(val);  // adds node at the end of list
        CurrList = CurrList->next;  // move to the next node
        list_size++;  // increase the size of list count 
        position++;  // increment position counter
        
        if(position == n - 1)  // if position reaches the end
          return;  // resize complete, return
      }
    }
    else if(CurrList == nullptr)  // if list is empty
    {
      CurrList = make_node(val);  // create first node in list
      the_list = CurrList;  // point to the new list
      position++;  // increment position counter
      list_size++;  // increase the size of list count
      while(position != n)  // resize until position reaches n position
      {
        CurrList->next = make_node(val);  // create node at the end of list
        CurrList = CurrList->next;  // move to the next node
        position++;  // increment position counter
        list_size++;  // increase the size of list count
      }
      return;
    }
  }
  else if(n < (int)list_size && n > 0)  // if resize less than the list size
  {
    while(CurrList)  // loop to find starting position
    {
      CurrList = CurrList->next;  // move to the next node
      position++;  // increment position counter
      
      if(position == n - 1)  // once at desired position, break loop
        break;
    }
    
    tempNode = CurrList->next;  // set tempnode to next node in list
    CurrList->next = nullptr;  // break the link to set up for deletion
    
    while(tempNode)  // while not at the end of the list
    {
      CurrList = tempNode->next;  // move to the next node
      delete tempNode;  // delete previous node
      tempNode = CurrList;  // point to the next node
      list_size--;  // reduce the size of list count
    }
    return;
  }
  else if(n == 0 && list_size > 0)  // if resizing it to 0, delete all
  {
    clear();
  }
  
}

/*****************************************************************************/
/*!

 \fn merge
 
 \brief
		This member function will merge linked lists together into one. 
   
 \param l2
   l2 - Reference variable that points to the 2nd list.
   

*/ 
/*****************************************************************************/
void list::merge(list &l2)
{
  node *CurrList = the_list;  // pointer to the list
  
    if(list::empty())  // if list is empty
    {
      if(l2.list_size != 0)  // if list 2 is not empty
      {
        the_list = l2.the_list;  // list 1 will point to list 2
        list_size += l2.list_size;  // change list 1 size of list count
        l2.list_size = 0;  // reset list 2 size of list count
        l2.the_list = nullptr;  // list 2 points to nothing
        return;
      }
      else
        return;  // if list 2 is empty, nothing to merge
    }
    else if(CurrList)  // while not at the end of the list
    {
      while(CurrList->next)
      {
        CurrList = CurrList->next;  // move to next node in the list
      }
      CurrList->next = l2.the_list;  // the end of list 1 will point to list 2
      list_size += l2.list_size;  // change list 1 size of list count
      l2.list_size = 0;  // reset list 2 size of list count
      l2.the_list = nullptr;  // list 2 points to nothing
      list::sort();  // sort all nodes in list 1 in ascending order
      
      return;
    }
    
  return;
}

/*****************************************************************************/
/*!

 \fn make_node
 
 \brief
   This member function allocates memory and creates a struct Node where
   each node contains a integer value and a pointer to another Node. 
   
 \param val 
   val - Int that takes in a value to be stored in the Node.
 
 \return
   Returns a pointer to a struct Node. 

*/ 
/*****************************************************************************/
node * list::make_node(int val) 
{
  node *pNode = new node;  // Creates a new node
	
  pNode->value = val;      // Stores value into new node
  pNode->next = nullptr;   // New Node will point to nothing
	
  return pNode;  // Return the pointer to the node
}