#include <fstream>
#include <iostream>
#include "list.h"

CS170::list& read_list_push_front(const char *filename,CS170::list &l)
{
  int value;
  std::ifstream fin(filename);
  if (!fin.is_open())
    std::cout <<filename<< " is not found!" << std::endl;
  else
    while (!fin.eof())
    {
      fin >> value;
      l.push_front(value);
    }

  return l;
}

int main(int argc, char *argv[])
{
  if(argc<2)
  {
    std::cerr<<"Usage: "<<argv[0]<<" <filename>\n";
    return 1;
  }
  CS170::list l1, l2;

  l1 = read_list_push_front(argv[1],l1);
  std::cout << "l1:\n";
  l1.print_list();
  
  std::cout << "\nErase l1 at 100:\n";
  l1.erase(100);
  l1.print_list();
  
  std::cout << "\nErase l1 at 200:\n";
  l1.erase(200);
  l1.print_list();

  std::cout << "\nErase l1 from 100 to before 200:\n";
  l1.erase(100, 200);
  l1.print_list();

  std::cout << "\nResize l1 to 500 elements, fill with 100:\n";
  l1.resize(500, 100);
  l1.print_list();

  std::cout << "\nResize l1 to 200 elements:\n";
  l1.resize(200);
  l1.print_list();
  
  std::cout << "\nSort l1:\n";
  l1.sort();
  l1.print_list();
  
  std::cout << "\nl2:\n";
  l2 = read_list_push_front(argv[1],l2);
  l2.print_list();
  
  std::cout << "\nSort l2:\n";
  l2.sort();
  l2.print_list();
  
  l1.merge(l2);
  std::cout << "\nl1 after merging:\n";  
  l1.print_list();
  std::cout << "\nl2 after merging:\n";  
  l2.print_list();
  
  l1.clear();
  l2.clear();
  
  return 0;
}