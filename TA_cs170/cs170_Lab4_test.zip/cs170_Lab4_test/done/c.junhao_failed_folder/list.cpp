/******************************************************************************/
/*!
\file               list.cpp
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab04
\par Course:        CS170
\date:              09/06/2019
\brief
        This file contains the implementation of the following
        functions for the Lab04.
        
Functions include:
public:
  list();
  ~list();
  void print_list() const;
  unsigned size() const;
  bool empty() const; 
  void clear();
  void push_front();
  node *front();
  void erase();
  void erase(); -> Different Functionality
  void resize();
  void sort();
  void merge();
  node *make_node();
  
Hours spent on this assignment: 6hr
Specific portions that gave you the most trouble: resize
*/
/******************************************************************************/
#include <iostream>  //cout
#include "list.h"    //Forward Declarations

namespace CS170
{
    /**************************************************************************/
    /*!
    \fn             list::list()
    \brief          Default Constructor
    */
    /**************************************************************************/
    list::list()
    {
        list_size = 0;
        the_list = nullptr;
    }
    /**************************************************************************/
    /*!
    \fn             list::~list()
    \brief          Destructor 
    */
    /**************************************************************************/
    list::~list()
    {
        clear();
    }
    /**************************************************************************/
    /*!
    \fn             void list::print_list() const
    \brief          Print the values in each node of the linked list
    */
    /**************************************************************************/
    void list::print_list() const
    {
        node* currNode = the_list;
        
        //Ensures there is a list to print
        while(currNode)
        {
            std::cout << currNode->value << " ";
            currNode = currNode->next;
        }
        
        //Formatting Purpose
        std::cout << "\n";
    }
    
    /**************************************************************************/
    /*!
    \fn                 unsigned list::size() const
    \brief              Print the values in each node of the linked list
    \return
            countNode   The amount of node in the list
    */
    /**************************************************************************/
    unsigned list::size() const
    {
        node* currNode = the_list;
        unsigned countNode = 0;
        
        //Ensures there is a list to count
        while(currNode)
        {
            ++countNode;
            currNode = currNode->next;
        }
        
        return countNode;
    }
    
    /**************************************************************************/
    /*!
    \fn             bool list::empty() const
    \brief          Checks if the list is empty
    \return
            true    The list is empty
            false   The list is not empty
    */
    /**************************************************************************/
    bool list::empty() const
    {
        if(list_size > 0)
            return true;
        else
            return false;
    }
    
    /**************************************************************************/
    /*!
    \fn             void list::clear()
    \brief          Clear the nodes in the list
    */
    /**************************************************************************/
    void list::clear()
    {
        node* currNode = the_list;
        node* tempNode = nullptr;
        
        //Ensures there is a node to clear
        while(currNode)
        {
            tempNode = currNode->next;
            delete currNode;
            currNode = nullptr;
            currNode = tempNode;
        }
        
        the_list = nullptr;
        list_size = 0;
    }
    
    /**************************************************************************/
    /*!
    \fn             node* list::make_node(int val)
    \brief          Create a new Node
    \param   val    NewNode value to create with
    \return 
            newNode The new Node created
    */
    /**************************************************************************/
    node* list::make_node(int val)
    {
        node* newNode = new node;
        newNode->value = val;
        newNode->next = nullptr;
        ++list_size;
        
        return newNode;
    }
    
    /**************************************************************************/
    /*!
    \fn             void list::push_front(int val)
    \brief          Create a new Node and push to the front
    \param  val     Value of the new Node
    */
    /**************************************************************************/
    void list::push_front(int val)
    {
        node* newNode = make_node(val);
        newNode->next = the_list;
        the_list = newNode;
    }
    /**************************************************************************/
    /*!
    \fn             node* list::front()
    \brief          Return the first node in the list 
    */
    /**************************************************************************/
    node* list::front()
    {
        return the_list;
    }
    /**************************************************************************/
    /*!
    \fn             void list::erase(int pos)
    \brief          Erase a node from the list
    \param    pos   Position to erase at
    */
    /**************************************************************************/
    void list::erase(int pos)
    {
        int tempCount = 0;
        node* prevNode = nullptr;
        node* currNode = the_list;

        //Ensures pos is a valid spot to remove from the list or if list exist
        if(pos < 0 || pos > static_cast<int>(list_size) || the_list == nullptr)
            return;

        //Delete the head - Special Case
        if(pos == 0)
        {
            currNode = the_list->next;
            delete the_list;
            the_list = nullptr;
            the_list = currNode;
            --list_size;
            return;
        }

        //Other position to delete from, move to the node to erase
        while(tempCount < pos && currNode)
        {
            ++tempCount;
            prevNode = currNode;
            currNode = currNode->next;
        }
        
        if(prevNode)
            prevNode->next = currNode->next;
        
        delete currNode;
        currNode = nullptr;
        --list_size;
    }
    
    /**************************************************************************/
    /*!
    \fn             void list::erase(int first, int last)
    \brief          Erase nodes within position of first and last-1.
    \param  first   Position to start removing from.
    \param  last    Position to stop removing at
    */
    /**************************************************************************/
    void list::erase(int first, int last)
    {
        int tempCount = 0;
        node* tempNode = nullptr;
        node* prevNode = nullptr;
        node* currNode = the_list;

        //If first is a valid spot to remove from the list
        if(first < 0 || first > static_cast<int>(list_size) || first > last || 
           the_list == nullptr)
            return;

        //Reach the place to start erasing
        while(tempCount < first)
        {
            ++tempCount;
            prevNode = currNode;
            currNode = currNode->next;
        }
        //Start Erasing
        while(tempCount < last && currNode)
        {
            ++tempCount;
            tempNode = currNode->next;
            delete currNode;
            currNode = nullptr;
            currNode = tempNode;
            --list_size;
        }
        
        //Delete starting from the head.
        if(prevNode == nullptr)
            the_list = currNode; //Head changes
        
        if(prevNode)
            prevNode->next = currNode; //Relink the list.
    }
    
    /**************************************************************************/
    /*!
    \fn             void list::resize(int n, int val)
    \brief          Resizes the list to contain n elements.
                    If n is smaller than the current size, then keep only
                    the first n elements, then destroy those beyond.
                    If n is larger than the current size, the new elements
                    are initialized as val.
    \param  n       The size to grow to.
    \param  val     The value to fill the new nodes with.
    */
    /**************************************************************************/
    void list::resize(int n, int val)
    {
        //Determines the algorithm to perform
        int amountToGrow = n - static_cast<int>(list_size);
        int nodeCount = 0;
        
        //Handles iterating list
        node* prevNode = nullptr; //Used for relinking 
        node* currNode = the_list;
        
        //Handles relinking of nodes
        node* tempNode = nullptr;
        node* newNode = nullptr;
        		
        //No amount to grow
        if(amountToGrow == 0)
            return;

        //There is amount to grow
        if(amountToGrow > 0)
        {
            //Reach till end of list
            while(currNode && currNode->next)
            {
                prevNode = currNode;
                currNode = currNode->next;
            }
            
            //Decrement the growth Amount as it grow
            while(amountToGrow > 0)
            {
                --amountToGrow;
                newNode = make_node(val);
                
                //If there is no list to grow from
                if(the_list == nullptr)
                {
                    currNode = newNode;
                    the_list = currNode; //Link the head to the list
                    
                }
                else
                {
                    currNode->next = newNode;
                    currNode = currNode->next;
                }
            }
        }
        
        //Shrink the list
        else if(amountToGrow < 0)
        {
            //Reach till the size the new list requires
            while(nodeCount < n)
            {
                ++nodeCount;
                prevNode = currNode;
                currNode = currNode->next;
            }   
                        
            //Delete rest of the nodes
            while(amountToGrow < 0)
            {
                ++amountToGrow;
                tempNode = currNode->next;
                delete currNode;
                currNode = nullptr;
                currNode = tempNode;
            }
            
            //Seg fault check
            if(prevNode)
                prevNode->next = nullptr;
            
            //New size of list
            list_size = n;
            
            //No list left
            if(list_size == 0)
                the_list = nullptr;
        }
    }
    
    /**************************************************************************/
    /*!
    \fn             void list::sort()
    \brief          Sorts the list ascendingly - Selection Sort
    */
    /**************************************************************************/
    void list::sort()
    {
        //Handles iterating through list
        node* startNode = the_list;
        node* currNode = the_list;

        //Handles swapping and relinking nodes
        node* prevStartNode = nullptr;
        node* prevCurrNode = nullptr;
        node* tempNode = nullptr;

        //Handles value checking
        int minVal = 0;
        bool firstSwap = false;

        //If the list has more than 1 node.
        if (the_list && the_list->next)
        {
            //The list is not sorted finished.
            while (startNode)
            {
                currNode = startNode;
                minVal = startNode->value;

                //Iterate through the list
                while (currNode)
                {
                    //Extracts smallest value
                    if (minVal > currNode->value)
                        minVal = currNode->value;

                    currNode = currNode->next;
                }

                //Move to the currNode to the unsorted List.
                prevCurrNode = prevStartNode;
                currNode = startNode;

                //Iterate though the list again.
                while (currNode)
                {
                    //Seeks out the smallest values
                    if (currNode->value == minVal)
                    {
                        //Swapping Nodes
                        if (prevStartNode)
                            prevStartNode->next = currNode;

                        if (prevCurrNode)
                            prevCurrNode->next = startNode;
                        
                        tempNode = currNode->next;              
                        currNode->next = startNode->next;     
                        startNode->next = tempNode;           

                        //Shifting the Nodes
                        if (firstSwap == false)
                        {
                            the_list = currNode;
                            firstSwap = true;
                        }

                        tempNode = currNode->next;

                        prevCurrNode = startNode;
                        prevStartNode = currNode;

                        currNode = startNode->next;
                        startNode = tempNode;
                    }
                    else
                    {
                        //Shifting the Nodes
                        prevCurrNode = currNode;
                        currNode = currNode->next;
                    }
                }
            }
        }   
    }
    
    /**************************************************************************/
    /*!
    \fn             void list::merge(list &l2)
    \brief          Assume the current list and l2 are both sorted ascendingly,
                    this function merges them into one, so that the elements
                    are still in ascending order.
                    The current list will store the merged elements, 
                    while l2 will become empty.
    \param l2       The second list to merge with list 1.
    */
    /**************************************************************************/
    void list::merge(list &l2)
    {
        //Size of the new list
        list_size = list_size + l2.list_size;
        
        //Handles the new list as it merges
        node* newNode = nullptr;
        node* currNode = the_list;
        
        //Handles list2
        node* currNode_2 = l2.the_list;
        
        //If there is no list1
        if(currNode == nullptr)
        {
            the_list = l2.the_list;
            list_size = l2.list_size;
            
            l2.the_list = nullptr;
            l2.list_size = 0;
            return;
        }
        
        //If there is not list2
        if(currNode_2 == nullptr)
            return;
        
        //Both list exist, merge in ascending order
        
        //First sort
        if(currNode->value > currNode_2->value)
        {
            newNode = currNode_2;
            currNode_2 = currNode_2->next;
            
            //Set new Head for the new list
            the_list = newNode;
        }
        else
        {
            newNode = currNode;
            currNode = currNode->next;
            
            //Set new Head for the new list
            the_list = newNode;
        }
        //End of first sort 
    
        //Both list exist, merge them
        while(currNode && currNode_2)
        {
            if(currNode->value > currNode_2->value)
            {
                newNode->next = currNode_2;
                newNode = newNode->next;
                currNode_2 = currNode_2->next;
            }
            else
            {
                newNode->next = currNode;
                newNode = newNode->next;
                currNode = currNode->next;
            }
        }
        
        //First list remaining
        while(currNode)
        {
            newNode->next = currNode;
            newNode = newNode->next;
            currNode = currNode->next;
        }
        
        //Second list remaining
        while(currNode_2)
        {
            newNode->next = currNode_2;
            newNode = newNode->next;
            currNode_2 = currNode_2->next;
        }

        //List 2 no longer exist.
        l2.the_list = nullptr;
        l2.list_size = 0;
    }
}