/******************************************************************************/
/*!
\file list.cpp
\author Chan Yong Ching Claudia 
\par email: c.yongchingclaudia\@digipen.edu 
\par DigiPen login: c.yongchingclaudia 
\par Course: CS170 
\par Lab #4 
\date 03/06/2019 
\brief This file contains the implementation of the following functions for the 
list assignment. This file contains functions that add nodes to the front and
end of a list, counts and prints the list. users can also erase nodes at 
specific locations or through a ceratin range
Functions include: 
list()
~list()
print_list() const
size() const
empty() const
clear()
push_front(int val)
front()
erase(int pos)
erase(int first, int last)
resize(int n, int val = 0)
sort()
merge(list &l2)
push_back(int value)
Hours spent on this assignment: 2
Specific portions that gave you the most trouble: resize
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here

namespace CS170
{
/*****************************************************************************/
/*!
 *\fn       node *list::make_node(int value) 

 *\brief    makes a node of value value
             
 *\param    value - value of the new node
  
 *\return   returns a pointer to the new node
*/
/*****************************************************************************/

  node *list::make_node(int value) 
  {
      node *pNode = new node;
      pNode->value = value;
      pNode->next = nullptr;  
      return pNode;
  }
/*****************************************************************************/
/*!
 *\fn       list::list()

 *\brief    constructor for list 
*/
/*****************************************************************************/

  // Constructor for list. Creates an empty list 
  list::list()
  {
      list_size = 0;
      the_list = nullptr;
  }

/*****************************************************************************/
/*!
 *\fn       list::~list()

 *\brief    destructor for list 
*/
/*****************************************************************************/

  /* Destructor for list. 
     Empty the list and release the allocated memory 
 */
  list::~list()
  {
      list_size = 0;
      while(the_list)
      {
          node*temp = the_list;
          the_list = the_list->next;
          delete temp;
      }
  }

/*****************************************************************************/
/*!
 *\fn       void list::print_list() const

 *\brief    prints a list of node
*/
/*****************************************************************************/

  void list::print_list() const
  {
      node*tmp = the_list;
      while (tmp) 
      {
          std::cout << tmp->value << " ";
          tmp = tmp->next;
      }
      std::cout << std::endl; 
  }

/*****************************************************************************/
/*!
 *\fn       unsigned list::size() const

 *\brief    returns the list size 
             
 *\return   the list size as the number of nodes in the list
*/
/*****************************************************************************/

  unsigned list::size() const
  {   
      return list_size;
  }

/*****************************************************************************/
/*!
 *\fn       bool list::empty() const

 *\brief    to check if the list is empty
             
 *\return   return true if the list is empty and false if it is not
*/
/*****************************************************************************/

// Returns true if list is empty, false otherwise 
  bool list::empty() const
  {
      if (the_list == nullptr)
          return true;
      else
          return false;
      
  }

/*****************************************************************************/
/*!
 *\fn       void list::clear()

 *\brief    free all the nodes in the list
*/
/*****************************************************************************/
    
  // Frees (deletes) all of the nodes in the list 
  void list::clear()
  {
      while (the_list)
      {
          node*tmp = the_list;
          the_list = the_list->next;
          delete tmp;
          --list_size;
      }
  }

/*****************************************************************************/
/*!
 *\fn       void list::push_front(int val)

 *\brief    adds a node at the front of the list
              
 *\param    val - new node with value of val to be inserted
*/
/*****************************************************************************/

  /* Creates a node with val and 
      add it to the front of the list */
  void list::push_front(int val)
  {
      ++list_size;
      node *pNewNode = this->make_node(val);
      pNewNode->next = the_list;
      the_list = pNewNode;  
  }

/*****************************************************************************/
/*!
 *\fn       void list::push_back(int value)

 *\brief    adds a node at the back of the list
             
 *\param    value - new node with value of value to be inserted
*/
/*****************************************************************************/

  void list::push_back(int value) 
  {
       ++list_size;
      node *pNewNode = this->make_node(value);
      node *pCurrNode = the_list;

      if (the_list == nullptr)
          the_list = pNewNode;
      else {
          while (pCurrNode->next)
              pCurrNode = pCurrNode->next;
          pCurrNode->next = pNewNode;
      }  
  }

/*****************************************************************************/
/*!
 *\fn       node * list::front()

 *\brief    to get the first node in the list
             
 *\return   return the first node in the list
*/
/*****************************************************************************/

  // Return the first node in the list 
  node * list::front()
  {
      if (the_list==nullptr)
          return nullptr;
      else
      {
          return the_list;
      }
  }

/*****************************************************************************/
/*!
 *\fn       void list::erase(int pos)

 *\brief    removes node at position pos
             
 *\param    pos - position to remove node from
*/
/*****************************************************************************/

  /* Removes nodes at position pos. 
      Position count starts from zero.
  */
  void list::erase(int pos)
  {
      node * tmp = the_list;
      node * prev = the_list;
      //if pos == 0
      //pos > size()
      if (the_list == nullptr)
          return;
      if (pos>static_cast<int>(size()))
          return;
      if (pos == 0)
      {
          --list_size;
          the_list = the_list->next;
          delete tmp;
      }
      for (int i = 0; i< pos; ++i)
      {
          prev = tmp;
          if (tmp->next != nullptr)
             tmp = tmp->next;
      }
      prev->next = tmp->next;
      delete tmp;
      --list_size;
  }

/*****************************************************************************/
/*!
 *\fn       void list::erase(int first, int last)

 *\brief    removes node over a range from position position first to last-1
             
 *\param    first - position to start remove node from
 
 *\param    last - marks the end of the removing of nodes, 
                   node at this position should not be removed
*/
/*****************************************************************************/

  /* Removes nodes from position first to position last-1. 
      Position count starts from zero.
  */
  void list::erase(int first, int last)
  {
      if (last < first || last == first)
          return;
      int count = last-first;
      while(count)
      {
          erase(first);
          count--;
      }
      return;
  }

/*****************************************************************************/
/*!
 *\fn       void list::resize(int n, int val)

 *\brief    resize the list to contain n numbers of nodes, remove nodes after n
            if n is bigger than list size, fill the list with nodes of value val
             
 *\param    n - number of nodes the list should have
 
 *\param    val - val of new nodes to fill the remaining nodes if n is bigger
                  than list size
*/
/*****************************************************************************/

  /* Resizes the list to contain n elements.
      If n is smaller than the current size, then keep only
      the first n elements, then destroy those beyond.
      If n is larger than the current size, the new elements
      are initialized as val.
  */
  void list::resize(int n, int val)
  {
      //first case, n < size
      //n > size
      // n==0;
      int size = static_cast<int>(list_size);
      if (the_list == nullptr)
          return;
      if(n==0)
          this->clear();
      if(n<size)
      {
          erase(n, size);
      }
      if (n>size)
      {
          int add = (n-size);
          for(int i = 0; i < add; ++i)
          {
              push_back(val);
          }
      }
  }

/*****************************************************************************/
/*!
 *\fn       void list::sort()

 *\brief    sorts the list ascendingly
*/
/*****************************************************************************/

  // Sorts the list ascendingly
  void list::sort()
  {
      if(the_list == nullptr)
          return;
          
      node *curr  = the_list;
      node *sweeper = the_list;
      int min = curr->value;
      
      while(sweeper)
      {
          curr = sweeper;
          min = curr->value;
      
          while(curr)
          {
              if(curr->value < min)
              min = curr->value;
              curr = curr->next;
          }
          
          curr = sweeper;
          
          while(curr)
          {
              if(curr->value == min)
              {
              int temp = curr->value;
              curr->value = sweeper->value;
              sweeper->value = temp;
              sweeper = sweeper->next;
              }
              curr = curr->next;
          }
      
      }
  }

/*****************************************************************************/
/*!
 *\fn       void list::merge(list &l2)

 *\brief    merge the two list together and then sort it
             
 *\param    l2 - second list to be merged
*/
/*****************************************************************************/
      
  /* Assume the current list and l2 are both sorted ascendingly,
      this function merges them into one, so that the elements
      are still in ascending order.
      The current list will store the merged elements, 
      while l2 will become empty.
  */
  void list::merge(list &l2)
  {
      node*tmp= l2.front();
      if (the_list == nullptr)
          return;
      while(tmp)
      {
          push_back(tmp->value);
          tmp = tmp->next;
      }     
      l2.clear();
      sort();   
  }

}
