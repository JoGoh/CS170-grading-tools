/******************************************************************************/
/*! 
\file   list.cpp
\author Chua Lip Ming
\par    email: l.chua\@digipen.edu 
\par    DigiPen login: l.chua
\par    Course: CS170A 
\par    Lab 04 
\date   07/06/2019 
\brief     This is the .cpp file that contains the 
instructions needed to make a list.
Functions include:
make_node(int val);
list();
~list()
void print_list() const
unsigned size() const
bool empty() const
void clear()
void push_front(int val)
node *front()
void erase(int pos)
void erase(int first, int last)
void resize(int n, int val = 0)
void sort()
void mergesort(node* &list)
void merge(list &l2)
*/ 
/******************************************************************************/
#include <iostream>
#include "list.h"

namespace CS170 {
/******************************************************************************/
/*!

  \fn list::make_node

  \brief              Allocate memory and set members

  \param val          Value used to construct node

  \return pNode       Returns node created using value
*/
/******************************************************************************/
	node *list::make_node(int val) {
		node *pNode = new node;
		pNode->value = val;
		pNode->next = nullptr;
		return pNode;
	}
  
/******************************************************************************/
/*!

  \fn list::list

  \brief              Constructor for list. Creates an empty list 
*/
/******************************************************************************/
    list::list() {
		the_list = nullptr;
		list_size = 0;
	}
  
/******************************************************************************/
/*!

  \fn list::list

  \brief              Destructor for list.
                      Empty the list and release the allocated memory
*/
/******************************************************************************/
    list::~list() {
		clear();
	}

/******************************************************************************/
/*!

  \fn list::print_list

  \brief              Prints all of the nodes values

*/
/******************************************************************************/
  
	void list::print_list() const {
		node *list = the_list;
		while (list) {
			std::cout << list->value << " ";
			list = list->next;
		}
		std::cout << std::endl;
		list = nullptr;
	}
  
/******************************************************************************/
/*!

  \fn list::size

  \brief              Returns the current size of the list

*/
/******************************************************************************/
	unsigned list::size() const{
		return list_size;
	}
  
/******************************************************************************/
/*!

  \fn list::empty

  \brief              Returns true if list is empty, false otherwise

*/
/******************************************************************************/
	bool list::empty() const
	{
		if (the_list)
			return true;
		else
			return false;
	}
  
/******************************************************************************/
/*!

  \fn list::clear

  \brief              Frees (deletes) all of the nodes in the list

*/
/******************************************************************************/
	void list::clear() {
		node *pCurrNode = the_list;
		while (pCurrNode) {
			the_list = pCurrNode->next;
			delete pCurrNode;
			pCurrNode = the_list;
		}
		the_list = nullptr;
		list_size = 0;
	}

/******************************************************************************/
/*!

  \fn list::push_front

  \brief              Adds a node to the front of the list

  \param val        value to add to pList node

*/
/******************************************************************************/
	void list::push_front(int val) {
		node *pNewNode = make_node(val);
		pNewNode->next = the_list;
		the_list = pNewNode;
		list_size++;
	}

/******************************************************************************/
/*!

  \fn list::front

  \brief              Return the first node in the list

*/
/******************************************************************************/
	node *list::front() {
		return the_list;
	}

/******************************************************************************/
/*!

  \fn list::erase(int pos)

  \brief              Removes nodes at position pos.
            Position count starts from zero.

  \param pos          Value of position to erase from the node

*/
/******************************************************************************/
	void list::erase(int pos) {
		if (the_list)
		{
			node *tempList = the_list;
			node *prev = the_list;
			for (int i = 0; i < pos; i++)
			{
				if (tempList == nullptr || tempList->next == nullptr)
					break;
				prev = tempList;
				tempList = tempList->next;
			}
			prev->next = tempList->next;
			if (list_size == 0)
				the_list = nullptr;
			else if (pos == 0)
			{
				the_list = the_list->next;
			}
			delete tempList;
			tempList = nullptr;
			list_size--;
		}
	}

/******************************************************************************/
/*!

  \fn list::erase(int first, int last)

  \brief              Removes nodes from position first to position last-1.
                      Position count starts from zero.

  \param first        Starts erase from this position

  \param last         Ends erase at this position -1

*/
/******************************************************************************/
	void list::erase(int first, int last) {
		if (the_list && list_size != 0 && first <= (int)list_size - 1)
		{
			node *tempList = the_list;
			node *leftEnd = the_list;
			if (last > (int)list_size)
				last = list_size;
			if (first == last)
			{

			}
			if(first == last - 1)
			{
				erase(first);
			}
			else if (first == 0) {
					node *rightStart = tempList;
					for (int i = 0; i < (last - first); i++)
					{
						if (rightStart == nullptr)
							break;
						tempList = rightStart;
						rightStart = rightStart->next;
						delete tempList;
						tempList = nullptr;
						list_size--;
					}
					the_list = rightStart;
			}
			else {
				for (int i = 0; i < first; i++)
				{
					if (tempList == nullptr || tempList->next == nullptr)
						break;
					leftEnd = tempList;
					tempList = tempList->next;
				}

				node *rightStart = tempList;
				for (int i = 0; i < (last - first); i++)
				{
					tempList = rightStart;
					if (rightStart->next == nullptr)
						break;
					rightStart = rightStart->next;
					delete tempList;
					tempList = nullptr;
					list_size--;
				}
				if (leftEnd)
					leftEnd->next = rightStart;
				else if (rightStart)
					the_list = rightStart;
				else
					the_list = nullptr;
			}

		}
		
	}

/******************************************************************************/
/*!

  \fn list::resize

  \brief              Resizes the list to contain n elements.
                      If n is smaller than the current size, then keep only
                      the first n elements, then destroy those beyond.
                      If n is larger than the current size, the new elements
                      are initialized as val.

  \param n            Size of the resized node

  \param val          Value of node to be amended in resized node

*/
/******************************************************************************/
	void list::resize(int n, int val) {
		if (list_size == 0)
		{
			for (int i = 0; i < n; i++)
			{
				push_front(val);
			}
		}
		else if (n == 0)
		{
			clear();
		}
		else {
			node *tempList = the_list;
			node *prev = tempList;
			int i = 0;
			if (list_size > (unsigned)n)
			{
				for (int i = 0; i < n; i++)
				{
					prev = tempList;
					tempList = tempList->next;
				}
				while (tempList) {
					prev->next = tempList->next;
					delete tempList;
					tempList = prev->next;
					//tempList = tempList->next;
					list_size--;
				}
			}
			else if (list_size < (unsigned)n)
			{
				while (n > i)
				{
                    if (tempList == nullptr)
					{
						prev->next = make_node(val);
						prev = prev->next;
						tempList = prev->next;
						list_size++;
						i++;
					}
					else
					{
						prev = tempList;
						tempList = tempList->next;
						i++;
					}
				}
			}
		}
	}
  
/******************************************************************************/
/*!

  \fn mergesort

  \brief              Merge Sort used to sort a list
  
  \param list         List to be sorted

*/
/******************************************************************************/
	void mergesort(node* &list) {
		if (list == nullptr || list->next == nullptr)
			return;

		node *left = list;
		node *middle = list;
		node *fast = list;

		while (fast->next && fast->next->next)
		{
			middle = middle->next;
			fast = fast->next->next;
		}

		node *right = middle->next;

		middle->next = nullptr;

		mergesort(left);
		mergesort(right);

		if (left != nullptr && right != nullptr)
		{
			node *tempList = nullptr;
			node *curr = nullptr;

			if (tempList == nullptr)
			{
				if (left->value < right->value)
				{
					tempList = left;
					left = left->next;
				}
				else
				{
					tempList = right;
					right = right->next;
				}
				curr = tempList;
			}

			while (left && right)
			{
				if (left->value < right->value)
				{
					curr->next = left;
					left = left->next;
				}
				else
				{
					curr->next = right;
					right = right->next;
				}

				curr = curr->next;
			}

			if (left)
				curr->next = left;
			else
				curr->next = right;

			list = tempList;
		}
	}

/******************************************************************************/
/*!

  \fn list::sort

  \brief              Sort elements in the list

*/
/******************************************************************************/
	void list::sort() {
		if (the_list == nullptr || the_list->next == nullptr)
			return;

		node *left = the_list;
		node *middle = the_list;
		node *fast = the_list;

		while (fast->next && fast->next->next)
		{
			middle = middle->next;
			fast = fast->next->next;
		}

		node *right = middle->next;

		middle->next = nullptr;

		mergesort(left);
		mergesort(right);

		if (left != nullptr && right != nullptr)
		{
			node *tempList = nullptr;
			node *curr = nullptr;

			if (tempList == nullptr)
			{
				if (left->value < right->value)
				{
					tempList = left;
					left = left->next;
				}
				else
				{
					tempList = right;
					right = right->next;
				}
				curr = tempList;
			}

			while (left && right)
			{
				if (left->value < right->value)
				{
					curr->next = left;
					left = left->next;
				}
				else
				{
					curr->next = right;
					right = right->next;
				}

				curr = curr->next;
			}

			if (left)
				curr->next = left;
			else
				curr->next = right;

			the_list = tempList;
		}
	}

/******************************************************************************/
/*!

  \fn list::merge

  \brief              Merge the_list with list l2, l2 will be empty after
  
  \param l2           The other list to be merged with the_list, l2 will be
                      Cleared after the merge.

*/
/******************************************************************************/
	void list::merge(list &l2)
	{
		node *left = the_list;
		node *right = l2.front();
		/* Initializers */
		// Keeps track of the head node
		node *tempHead = nullptr;

		// Keeps track of the current node as we iterate and add the sorted nodes
		node *curr = nullptr;
		
		if (left == nullptr && right == nullptr)
		{
			
		}
		else if (left == nullptr)
		{
			// Set left to head node 
			tempHead = make_node(right->value);
			list_size++;
			// Iterate to the next node in the list
			right = right->next;

			curr = tempHead;

			while (right)
			{
				curr->next = make_node(right->value);
				list_size++;
				right = right->next;
				curr = curr->next;
			}

		}
		else if(right == nullptr) {
			tempHead = left;
		}
		else {
			if (left->value < right->value)
			{
				// Set left to head node 
				tempHead = left;

				// Iterate to the next node in the list
				left = left->next;

				curr = tempHead;

			}
			// When right < left
			else
			{
				// Set left to head node 
				tempHead = make_node(right->value);
				list_size++;
				// Iterate to the next node in the list
				right = right->next;

				curr = tempHead;

			}

			// While left and right doesn't point to nullptr
			while (left && right)
			{
				// Does the same iteration as setting up the head node above
				// But we update the current node now
				if (left->value < right->value)
				{
					// add the left node to the list
					curr->next = left;
					left = left->next;
				}
				else
				{
					// add the right node to the list
					curr->next = make_node(right->value);
					list_size++;
					right = right->next;
				}
				// Iterate the curr node
				curr = curr->next;

			}
		}
		// In the case of different size lists
		// One list will end earlier resulting in nullptr
		// Use the one taht is not pointing to nullptr and
		// add it to the end of the list.
		if (left)
			curr->next = left;
		while (right)
		{
			curr->next = make_node(right->value);
			list_size++;
			right = right->next;
			curr = curr->next;
		}

		the_list = tempHead;
		l2.clear();
	}
}