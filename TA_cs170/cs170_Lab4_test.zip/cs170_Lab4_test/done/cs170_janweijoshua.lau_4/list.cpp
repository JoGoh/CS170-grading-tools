/******************************************************************************/
/*! 
  \file list.cpp
  \author Lau Jan Wei, Joshua
  \par email: janweijoshua.lau\@digipen.edu
  \par DigiPen login: janweijoshua.lau
  \par Course: CS170
  \par Assignment4
  \date 10/06/2019
  \brief
This file contains the implementation of the following functions for
Assignment 4.
Functions include:
1) point constructor without parameters


Hours spent on this assignment: 8
Specific portions that gave you the most trouble: erase(int first, int last)
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

namespace CS170
{
  /*************************************************************************/
  /** 
      @name make_node
      @brief Allocates memory and set members
      @param value
      @return node* pNode
  */
  /*************************************************************************/
  node* make_node(int val)
  {
    node *pNode = new node;
    pNode->value = val;
    pNode->next = nullptr;  
    return pNode;
  }
  /*************************************************************************/
  /** 
      @name list constructor
      @brief Creates an empty list
      @param none
      @return nothing
  */
  /*************************************************************************/
  list::list()
  {
    list_size = 0;
    the_list = nullptr;
    
  }
  /*************************************************************************/
  /** 
      @name list destructor
      @brief Empty the list and release the allocated memory 
      @param none
      @return nothing
  */
  /*************************************************************************/
  list::~list()
  {
    clear();
  }
  /*************************************************************************/
  /** 
      @name print_list
      @brief Prints out the values contained in the list 
      @param none
      @return nothing
  */
  /*************************************************************************/
  void list::print_list() const
  {
      while (the_list) 
      {
        std::cout << the_list->value << " ";
        the_list = the_list->next;
      }
    std::cout << std::endl;  
  }
  /*************************************************************************/
  /** 
      @name size
      @brief Returns the current size of the list
      @param none
      @return nothing
  */
  /*************************************************************************/
  unsigned list::size() const
  {
    return list_size;
  }
  /*************************************************************************/
  /** 
      @name empty
      @brief Returns true if list is empty, false otherwise 
      @param none
      @return nothing
  */
  /*************************************************************************/
  bool list::empty() const
  {
    if (list_size)
      return false;
    return true;
  }
  /*************************************************************************/
  /** 
      @name clear
      @brief Frees (deletes) all of the nodes in the list 
      @param none
      @return nothing
  */
  /*************************************************************************/
  void list::clear()
  {
    node *pCurrNode = the_list;
    while (pCurrNode) 
    {
      the_list = pCurrNode->next;
      delete pCurrNode;
      pCurrNode = the_list;
    }
    the_list=nullptr;
  }
  /*************************************************************************/
  /** 
      @name push_front
      @brief Creates a node with val and add it to the front of the list
      @param int val
      @return nothing
  */
  /*************************************************************************/
  void list::push_front(int val)
  {
    node *pNewNode = make_node(val);
    pNewNode->next = the_list;
    the_list = pNewNode; 
    ++list_size;
  }
  /*************************************************************************/
  /** 
      @name front
      @brief Return the first node in the list 
      @param none
      @return node*
  */
  /*************************************************************************/
  node* list:: front()
  {
    return the_list;
  }
  /*************************************************************************/
  /** 
      @name erase
      @brief Removes nodes at position pos
      @param int pos
      @return nothing
  */
  /*************************************************************************/
  void list::erase(int pos)
  {
    if(the_list)
      return;
    
    node* eraser = the_list;
    node* linker = the_list;
    eraser = eraser->next;
    --pos;
    while(pos || eraser->value != NULL)
    {
      eraser = eraser->next;
      linker = linker->next;
      --pos;
    }
    linker->next = linker->next->next;
    delete eraser;
    eraser = nullptr;
    --list_size;
  }
  /*************************************************************************/
  /** 
      @name erase
      @brief Removes nodes from position first to position last-1
      @param int first
      @param int last
      @return nothing
  */
  /*************************************************************************/
  void erase(int first, int last)
  {
    if(the_list)
      return;
    if(first == last)
    {
      return;
    }
    if(last == first + 1)
    {
      erase(first);
      return;
    }
    node* eraser = the_list;
    node* linker = the_list;
    eraser = eraser->next;
    --first;
    while(first != 0)
    {
      eraser = eraser->next;
      linker = linker->next;
      --first;
    }
    while(last != 0)
    {
      linker->next = linker->next->next;
      delete eraser;
      eraser = eraser->next;
      --list_size;
      --last;
    }
    eraser = nullptr;
  }
  /*************************************************************************/
  /** 
      @name resize
      @brief if n is smaller than the current size,
             keeps the first n elements and destroy those beyond
             if n is larger than the current size,
             initialize new elements as val and add them to the back
      @param int n
      @param int val
      @return nothing
  */
  /*************************************************************************/
  void resize(int n, int val = 0)
  {
    // if n > size, call push front
    // if n < size, call erase
    if(n > list_size)
    {
      while(n > list_size)
      {
        node *pNewNode = make_node(val);
        node *pCurrNode = the_list;
        if (the_list == nullptr)
          the_list = pNewNode;
        else 
        {
          while (pCurrNode->next)
            pCurrNode = pCurrNode->next;
          pCurrNode->next = pNewNode;
        }  
        --n
      }
      return;
    }
    if(n < list_size)
    {
      last = list_size - n;
      erase(n, last);
    }
  }
  /*************************************************************************/
  /** 
      @name sort
      @brief sorts the list ascendingly
      @param none
      @return nothing
  */
  /*************************************************************************/
  void list::sort()
  {
    node* plist = the_list;
    node* swapper = the_list;
    int listcount = list_size;
    while(listcount)
    {
      plist = the_list;
      while(plist != nullptr)
      {
        swapper = plist;
        plist = plist->next;
        if(swapper->next && swapper->value > swapper->next->value)
        {
          int bigtemp = swapper->value;
          int smalltemp = swapper->next->value;
          swapper->value = smalltemp;
          swapper->next->value = bigtemp;
        }
      }
      --listcount;
    }
  }
  /*************************************************************************/
  /** 
      @name merge
      @brief merges 2 lists while keeping them sorted
      @param list &l2
      @return nothing
  */
  /*************************************************************************/
  void merge(list &l2)
  {
      if(!l2)
      return;
    if(!the_list)
    {
      the_list = l2;
      return;
    }
    node * tail = the_list;
    while(tail->next != nullptr)
    {
      tail = tail->next;
    }
    tail->next = l2;
    l2 = nullptr;
    sort();
  }
}