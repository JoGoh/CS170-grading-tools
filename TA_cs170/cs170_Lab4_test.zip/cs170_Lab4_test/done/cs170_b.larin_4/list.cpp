/*****************************************************************************/
/*!
\file list.cpp
\author Benjamin Julian M. Larin
\par email:
b.larin\@digipen.edu
\par DigiPen login:
b.larin
\par Course:
CS170-A
\par Lab #4
\date 09/06/2019
\brief This file contains the implementation of the following functions for
the Lab #4.

\par Class Member Functions include:
  list();
  ~list();
  print_list();
  unsigned size();
  empty();
  clear();
  push_front();
  front();
  erase(int);
  erase(int, int);
  resize();
  sort();
  merge();
  make_node();

\par Additional funtions:
  sorted_lists_merge();
  split();
  merge_sort();

\par Hours spent on this assignment:
 20 hrs
\par Specific portions that gave you the most trouble:
  erase(int);
  erase(int, int);
  resize();
  sort();
  merge();
  test cases
*/
/*****************************************************************************/
#include <iostream>
#include "list.h"

typedef unsigned uint;



// Please fill in your code for the class functions in list.h here

namespace CS170
{
/*****************************************************************************/
  /** Additional functions delaration
  */
  node *sorted_lists_merge(node *list1, node *list2);
  void split(node *list, node **front, node **back);
  void merge_sort(node **headref);
  
/*****************************************************************************/

/*****************************************************************************/
  /** Merges the 2 smaller lists we split into 1
  
      @param list1 - pointer to the smaller list.
      @param list2 - pointer to the smaller list.
  */
/*****************************************************************************/
  node *sorted_lists_merge(node *list1, node *list2)
  {
    node* tmp = nullptr;

    if (list1 == nullptr)
      return (list2);
    else if (list2 == nullptr)
      return (list1);

    /* Pick either list1 or list2, and recur */
    if (list1->value <= list2->value) {
      tmp = list1;
      tmp->next = sorted_lists_merge(list1->next, list2);
    }
    else {
      tmp = list2;
      tmp->next = sorted_lists_merge(list1, list2->next);
    }
    return (tmp);
  }

/*****************************************************************************/
  /** Splits the list into 2 smaller lists for easier sorting
  
      @param list - pointer to the list.
      @param front - pointer to pointer to a smaller list.
      @param back - pointer to pointer to a smaller list.
  */
/*****************************************************************************/
  void split(node *list, node **front, node **back)
  {
    node *fast = list->next;
    node *slow = list;

    while (fast)
    {
      fast = fast->next;
      if (fast)
      {
        slow = slow->next;
        fast = fast->next;
      }
    }
    
    *front = list;
    *back = slow->next;
    slow->next = nullptr;
  }

/*****************************************************************************/
  /** Sorts list using merge sort method. Calls split() and recurs itself to
      make the list into single nodes then calls sorted_lists_merge() to sort
      each node and put them into 1 list then goes upwards the branching until
      all the branches are sorted and makes a full list again.
  
      @param headref - pointer to a pointer to the list
  */
/*****************************************************************************/
  void merge_sort(node **headref)
  {
    node *head = *headref;
    node *list1 = nullptr;
    node *list2 = nullptr;

    if ((head == nullptr) || (head->next == nullptr))
      return;

   //split the list into 2
    split(head, &list1, &list2);

    //call itself to sort the smaller list
    merge_sort(&list1);
    merge_sort(&list2);

    //merge sorted list
    *headref = sorted_lists_merge(list1, list2);
  }

/*****************************************************************************/
  /** Constructor for list. Creates an empty list
  */
/*****************************************************************************/
  list::list() : list_size(0), the_list(nullptr)
  {
  }

/*****************************************************************************/
  /** Destructor for list. Empty the list and release the allocated memory
  */
/*****************************************************************************/
  list::~list()
  {
    clear();
  }

/*****************************************************************************/
  /** Prints all of the nodes values
  */
/*****************************************************************************/
  void list::print_list() const
  {
    node *tmp = the_list;
    while (tmp) {
      std::cout << tmp->value << " ";
      tmp = tmp->next;
    }
    std::cout << std::endl;
    tmp = nullptr;
  }

/*****************************************************************************/
  /** Returns the current size of the list
  */
/*****************************************************************************/
  unsigned list::size() const
  {
    return list_size;
  }

/*****************************************************************************/
  /** Returns true if list is empty, false otherwise
  */
/*****************************************************************************/
  bool list::empty() const
  {
    return list_size == 0 ? true : false;
  }

/*****************************************************************************/
  /** Frees (deletes) all of the nodes in the list
  */
/*****************************************************************************/
  void list::clear()
  {
    while (the_list) 
    {
      node *pCurrNode = the_list;
      the_list = the_list->next;
      delete pCurrNode;
      --list_size;
    }
    
    the_list = nullptr;
  }

/*****************************************************************************/
  /** Adds a node to the front of the list
      @param val - data to be put in the new node added.
  */
/*****************************************************************************/
  void list::push_front(int val)
  {
    node *pNewNode = make_node(val);
    pNewNode->next = the_list;
    the_list = pNewNode;
  }

/*****************************************************************************/
  /** Return the first node in the list
  */
/*****************************************************************************/
  node* list::front()
  {
    return the_list;
  }

/*****************************************************************************/
  /** Removes nodes at position pos. Position count starts from zero
      @param pos - the position to remove a node at
  */
/*****************************************************************************/
  void list::erase(int pos)
  {
    //if outside the range of the list
    if (pos < 0 || (uint)pos > list_size || the_list == nullptr)
      return;
    else
    {
      if (pos == 0)
      {
        //delete first
        node *tmp = the_list;
        the_list = the_list->next;
        delete tmp;
        --list_size;
      }
      else if((uint)pos == list_size)
      {
        //delete last
        node *tmp = the_list;
        while(tmp->next->next)
          tmp = tmp->next;
        
        delete tmp->next;
        tmp->next = nullptr;
        
      }
      else
      {
        //delete in between
        node *tmp = the_list;
        for (int i = 0; i < pos-1; ++i)
          tmp = tmp->next;
        
        node *deleteNode = tmp->next;
        
        if(deleteNode->next != nullptr)
          tmp->next = deleteNode->next;
        else
          tmp->next = nullptr;
          
        delete deleteNode;
        --list_size;
      }
    }
  }

/*****************************************************************************/
  /** Removes nodes from position first to position last-1. Position count 
      starts from zero. 
      [   ]>[   ]>[ F ]>[   ]>[   ]>[   ]>[L-1]>[ L ]
      [   ]>[   ]>[ X ]>[ X ]>[ X ]>[ X ]>[ X ]>[ L ]
      @param first - the first position
      @param last - the last position
  */
/*****************************************************************************/
  void list::erase(int first, int last)
  {
   if(empty())
     return;
    
    node *tmp = the_list;
    node *prv = nullptr;
    
    int counter = 0;
    
    while(tmp)
    {
      if(counter >= first && counter < last)
      {
        node* del = tmp;
        
        if(prv != nullptr)
          prv->next = tmp->next;
        
        if(the_list == tmp)
          the_list = tmp->next;
        
        tmp = tmp->next;
        delete del;
        --list_size;
      }
      else
      {
        prv = tmp;
        tmp = tmp->next;
      }
      ++counter;
    }
    
  }

/*****************************************************************************/
  /** Resizes the list to contain n elements. If n is smaller than the current 
      size, then keep only the first n elements, then destroy those beyond. If 
      n is larger than the current size, the new elements are initialized as 
      val.
      @param n - new size of the list
      @param val - data to be put in the new node added. If not given, default
      is 0
  */
/*****************************************************************************/
  void list::resize(int n, int val)
  {
    if (empty())
    {
			for (int i = 0; i < n; i++)
				push_front(val);
    }
		else if (n == 0)
			clear();
    
		else 
    {
			node *tmp = the_list;
			node *prv = tmp;
			int count = 0;
      
			if (list_size > (uint)n)
			{
				for (int i = 0; i < n; i++)
				{
					prv = tmp;
					tmp = tmp->next;
				}
				while (tmp)
        {
          if(tmp->next == nullptr)
            prv->next = nullptr;
          
					prv->next = tmp->next;
					delete tmp;
          --list_size;
					tmp = prv->next;
				}
			}
			else if (list_size < (uint)n)
			{
				while (n > count)
				{
          if (tmp == nullptr)
					{
						prv->next = make_node(val);
						prv = prv->next;
						tmp = prv->next;
					}
					else
					{
						prv = tmp;
						tmp = tmp->next;
					}
          ++count;
				}
			}
		}
  }

/*****************************************************************************/
  /** Sorts the list in ascending order
  */
/*****************************************************************************/
  void list::sort()
  {
    merge_sort(&the_list);
  }

/*****************************************************************************/
  /** Assume the current list and l2 are both sorted ascendingly, this 
      function merges them into one, so that the elements are still in 
      ascending order. The current list will store the merged elements, while 
      l2 will become empty.
  
      @param l2 - referemce to the list.
  */
/*****************************************************************************/
  void list::merge(list &l2)
  {
    node *list1 = the_list;
    //the only way to access l2 is to return first node
		node *list2 = l2.front();
		node *tmp = nullptr;
		node *curr = nullptr;
		
		if (list1 == nullptr && list2 == nullptr)
			return;//return if both are empty

		else if (list1 == nullptr)
		{
      //when list1 is empty put first value of list2 as head of list1
			tmp = make_node(list2->value);
			list2 = list2->next;
			curr = tmp;

			while (list2)
			{
        //add the remaining list2 values to list1
				curr->next = make_node(list2->value);
				list2 = list2->next;
				curr = curr->next;
			}
		}
		else if(list2 == nullptr)
			tmp = list1;//if list2 is empty work is done

    
		else 
    {
      //test whose head is smaller (hehe) then make it as the head for the
      //combined lists
			if (list1->value < list2->value)
			{
				tmp = list1;
				list1 = list1->next;
				curr = tmp;
			}
			else
			{
				tmp = make_node(list2->value);
				list2 = list2->next;
				curr = tmp;
			}
			while (list1 && list2)//sorts the following nodes
			{
				if (list1->value < list2->value)
				{
					curr->next = list1;
					list1 = list1->next;
				}
				else
				{
					curr->next = make_node(list2->value);
					list2 = list2->next;
				}
				curr = curr->next;
			}
		}
		if (list1)
			curr->next = list1;
		while (list2)
		{
			curr->next = make_node(list2->value);
			list2 = list2->next;
			curr = curr->next;
		}

		the_list = tmp;
    //clear l2 as it is sorted and concatenated to the_list
		l2.clear();
  }

/*****************************************************************************/
  /** Allocate memory and set members
  
      @param val - the data to be put in.
      @return pNode - the newly created node.
  */
/*****************************************************************************/
  node* list::make_node(int val)
  {
    node *pNode = new node;
    pNode->value = val;
    pNode->next = nullptr;
    ++list_size;
    return pNode;
  }
}