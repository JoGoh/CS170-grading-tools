/*****************************************************************************/
/*!
\file list.cpp
\author Favian Goh
\par DP email duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 4
\date 10/06/2019
\brief
  This program contains a singly-linked list and functions making a new node,
  print a node's value, count the numbers of nodes, adds a new node to the
  front of the list, check if a list is empty, deallocate list, erase a node
  depending on position, erase nodes between two points in the list, resize
  the list depending on n, merge two lists and make a new node.
*/
/****************************************************************************/

#include <iostream>
#include "list.h"

namespace CS170 {

/*****************************************************************************/
/*!
  
  Default Constructor.
  
*/
/*****************************************************************************/

list::list()
{
  
  the_list = NULL; /*init the_list*/
  list_size = 0;   /*init list_size*/
  
}

/*****************************************************************************/
/*!
  
  Destructor.
  
*/
/*****************************************************************************/

list::~list()
{
  
  node *pCurrNode = the_list;   /*points to the first node of list*/
  while (pCurrNode) {           /*loop to go through all nodes in list*/
    the_list = pCurrNode->next; /*point list to the next node*/
    delete pCurrNode;           /*delete first node*/
    pCurrNode = the_list;       /*points to what list is pointing to*/
  }
  
  the_list = NULL;              /*point the_list to NULL*/
  
}

/*****************************************************************************/
/*!
  
  \fn print_list
  
  \brief
    prints out the current node's value.

  \param
  
  \return 
*/
/*****************************************************************************/

void list::print_list() const
{
  node *pCurrNode = the_list;                         /*point to head of list*/
  
  while (pCurrNode) {                  /*loop to go through all nodes in list*/
    std::cout << pCurrNode->value << " ";                     /* prints value*/
    pCurrNode = pCurrNode->next;                        /*points to next node*/
  }
  std::cout << std::endl;                                          /*new line*/
}

/*****************************************************************************/
/*!
  
  \fn size
  
  \brief
    Returns the current size of the list.

  \param
  
  \return size 
*/
/*****************************************************************************/

unsigned list::size() const
{
  node *pCurrNode = the_list;    /*point to head of list*/
  unsigned size = 0;             /*init size*/
  while (pCurrNode) {            /*loop to go through all nodes in list*/
    size++;                      /*increment size*/
    pCurrNode = pCurrNode->next; /*points to next node*/
  }
  return size;                   /*size of list*/
  
}

/*****************************************************************************/
/*!
  
  \fn empty
  
  \brief
    Returns true if list is empty, false otherwise.

  \param
  
  \return true
    Empty list
    
  \return false
    List with at least one element(node).
*/
/*****************************************************************************/

bool list::empty() const
{
  
  if (size() != 0) /*checks if list is not empty*/
    return false;  /*not empty*/
  else
    return true;   /*empty list*/
  
}

/*****************************************************************************/
/*!
  
  \fn clear
  
  \brief
    Frees (deletes) all of the nodes in the list
    
  \param
  
  \return
*/
/*****************************************************************************/

void list::clear()
{
  
  node *pCurrNode = the_list;   /*points to the first node of list*/
  while (pCurrNode) {           /*loop to go through all nodes in list*/
    the_list = pCurrNode->next; /*point list to the next node*/
    delete pCurrNode;           /*delete first node*/
    pCurrNode = the_list;       /*points to what list is pointing to*/
  }
  
  the_list = NULL;              /*points list to NULL*/
  
}

/*****************************************************************************/
/*!
  
  \fn push_front
  
  \brief
    Creates a node with val and add it to the front of the list.
    
  \param int val
  
  \return
*/
/*****************************************************************************/

void list::push_front(int val)
{
  
  node *pNewNode = make_node(val); /*create a pointer to new node*/
  pNewNode->next = the_list;       /*add node to the head of list*/
  the_list = pNewNode;             /*update new node to new head of list*/
  list_size++;                     /*increment list_size*/
  
}

/*****************************************************************************/
/*!
  
  Return the first node in the list.
  
*/
/*****************************************************************************/

node *list::front()
{
  
  return the_list; /*head of list*/
  
}

/*****************************************************************************/
/*!
  
  \fn erase
  
  \brief
    Removes nodes at position pos.
    Position count starts from zero.
    
  \param int pos
    Node position
  
  \return
*/
/*****************************************************************************/

void list::erase(int pos)
{
  
  node *pList = the_list;                  /*points to the first node of list*/
  node *temp_ptr;                                    /*temp ptr for later use*/
  int i = 0;                                                  /*for iteration*/
  
  if (pos == 0 && size() == 0);                  /*does nothing if empty list*/
  else if (pos == 0)                     /*check if pos is first node of list*/
  {
    the_list = pList->next;              /*move head of list to adjacent node*/
    delete(pList);                                /*delete previous head node*/
    list_size--;                                        /*decrement list_size*/
  }
  else {
  while (i < pos - 1)            /*move to node before the to be deleted node*/
  {
    pList = pList->next; 
    i++;
  }
  
  temp_ptr = pList->next;       /*point a temp ptr to hold to be deleted node*/
  pList->next = pList->next->next;                    /*move to adjacent node*/
  delete temp_ptr;                                   /*delete the node at pos*/
  list_size--;                                          /*decrement list_size*/
  }
}

/*****************************************************************************/
/*!
  
  \fn erase
  
  \brief
    Removes nodes from position first to position last-1. 
    Position count starts from zero.
    
  \param int first
    Start position
  
  \param int last
    End position
  
  \return
*/
/*****************************************************************************/

void list::erase(int first, int last)
{
  
  node *FirstNode = the_list;                        /*points to head of list*/
  node *pCurrNode;                                   /*temp ptr for later use*/
  node *LastNode;                                    /*temp ptr for later use*/
  node *temp_ptr;                                    /*temp ptr for later use*/
  int i = 0;                                                  /*for iteration*/
  int nodes_erase = last - first + 1;                    /*nodes to be erased*/
  
  if (the_list == NULL);                        /*do nothing if list is empty*/
  else if ((int)size() < last && first > 0);     /*do nothing if last is larger
                                                                 size of list*/
  else if ((int)size() < last && first == 0)           /*check if size < last*/
  {
    while(FirstNode)
    {
      temp_ptr = FirstNode;
      FirstNode = FirstNode->next;
      delete temp_ptr;
      list_size--;
    }
    the_list = NULL;
  }    
  else if (size() == 1)                 /*check if there is only node in list*/
  {
    clear();                                                /*delete the node*/
    list_size = 0;                                            /*list is empty*/
  }
  else if (first == 0 && last > 1)
  {
    while (i < last)
    {
      temp_ptr = FirstNode;
      FirstNode = FirstNode->next;
      delete temp_ptr;
      list_size--;
      i++;
    }
    the_list = FirstNode;
  }
  else
  {
  
    while (i < first - 1)                           /*look for the first node*/
    {
      
      FirstNode = FirstNode->next;
      i++;
      
    }
    
    LastNode = FirstNode;
    i = 0;                                         /*reset for next iteration*/
    
    while (i < nodes_erase)                              /*look for last node*/
    {
      LastNode = LastNode->next;
      i++;
    }
    
    pCurrNode = FirstNode->next;
    FirstNode->next = LastNode;
    
    while (pCurrNode != LastNode)    /*erase the nodes between first and last*/
    {
      
      temp_ptr = pCurrNode;
      pCurrNode = pCurrNode->next;
      delete temp_ptr;
      
    }
    
    list_size -= nodes_erase;            /*decrease list_size by nodes erased*/
  }
  
  
}

/*****************************************************************************/
/*!
  
  \fn erase
  
  \brief
    Resizes the list to contain n elements.
    If n is smaller than the current size, then keep only the first n elements,
    then destroy those beyond. If n is larger than the current size, the new
    elements are initialized as val.
    
  \param int n
    n elements(nodes)
    
  \param int val
    Variable to be initialized with new element(node).
  
  \return
*/
/*****************************************************************************/

void list::resize(int n, int val)
{
  
  node *pCurrNode = the_list;                        /*points to head of list*/
  int i = 0;                                                  /*for iteration*/
  
  if (size() == 0)
  {
    i = 0;
    the_list = make_node(val);
    list_size++;
    pCurrNode = the_list;
    
    while (i < n - 1)                   /*create and add nodes to end of list*/
    {
      pCurrNode->next = make_node(val);
      pCurrNode = pCurrNode->next;
      i++;
      list_size++;
    }
    
  }
  else if (n < (int)size())                /*checks if n is smaller than size*/
    erase(n, size());                              /*erase the extra elements*/
  else if (n > (int)size())                 /*checks if n is larger than size*/
  {
    
    int nodes_erase = n - size();
    i = 0;
    
    while (pCurrNode->next)                       /*move to last node of list*/
    {
      pCurrNode = pCurrNode->next; 
    }
    
    while (i < nodes_erase)             /*create and add nodes to end of list*/
    {
      pCurrNode->next = make_node(val);
      pCurrNode = pCurrNode->next;
      i++;
    }

    pCurrNode->next = NULL;
    
  }
  
  list_size = n;                                          /*resized to n size*/
  
}

/*****************************************************************************/
/*!
  
  \fn sort
  
  \brief
    Sorts the list ascendingly.
    
  \param
  
  \return
*/
/*****************************************************************************/

void list::sort()
{
  
  node *pCurrNode;
  int temp, flag = 1;
  
  if (the_list == NULL);
  else
  {
    while(flag)                         /*flag used to signify list is sorted*/
    {
      flag = 0;
      pCurrNode = the_list;                          /*points to head of list*/
      
      while(pCurrNode->next)                      /*move to last node of list*/
      {
        if(pCurrNode->value > pCurrNode->next->value)/*compare the value of two
                                                               adjacent nodes*/
        {
          temp = pCurrNode->value;                  /*swap the values if true*/
          pCurrNode->value = pCurrNode->next->value;
          pCurrNode->next->value = temp;
          flag = 1;
        }
        
        pCurrNode = pCurrNode->next;    /*move to next pair of adjacent nodes*/
      }
      
    }
  }
  
}

/*****************************************************************************/
/*!
  
  \fn merge
  
  \brief
    Merges two lists into one, so that the elements are still in ascending
    order. The current list will store the merged elements, while l2 will
    become empty.
    
  \param list &l2
  
  \return
*/
/*****************************************************************************/

void list::merge(list &l2)
{
  
  node *pCurrNode = the_list;         /*points to head of list*/
  
  if (the_list == NULL && l2.the_list != NULL)
  {
    the_list = l2.the_list;
    l2.the_list = NULL;
    sort();
  }
  else if (the_list != NULL && l2.the_list == NULL)
  {
    l2.the_list = NULL;
    sort();
  }
  else if (the_list == NULL && l2.the_list == NULL);
  else
  {
    while (pCurrNode->next)             /*move to last node of list*/
    {
      pCurrNode = pCurrNode->next; 
    }
    
    
    pCurrNode->next = l2.the_list;      /*merge both list*/

    
    l2.the_list = NULL;
    
    sort();                             /*sort the merged list*/
  }
}

/*****************************************************************************/
/*!
  \brief
    Allocates memory for a new node and initialize members.

 \param int val
    Variable to be initialized with.

 \return pNode
    Pointer to new Node.
*/
/*****************************************************************************/

node *list::make_node(int val)
{
  node *pNode = new node; /*allocate memory to pNode, a new node*/
  pNode->value = val;     /*sets pNode's value to incoming value*/
  pNode->next = NULL;     /*sets pNode's next to null pointer*/
  return pNode;           /*a new node*/
}

}