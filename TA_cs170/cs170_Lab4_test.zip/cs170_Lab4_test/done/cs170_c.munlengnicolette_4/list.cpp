/*************************************************************************/
/*!
\file list.cpp
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: CS170
\par Lab #4
\date 06/06/2019
\brief
This file contains the implementation of the functions for the
List assignment.


Hours spent on this assignment: 6 hrs
Specific portions that gave you the most trouble: sort
*/
/*************************************************************************/
#include <iostream>
#include "list.h"

namespace CS170 
{
  void sort_insert(node *& hNode, node * nNode);

  /***********************************************************************/
  /*!
    \fn make_node
    \brief
      This function allocates memory and set members

    \param value
      Value to be added Node value

    \return
      Returns pointer to Node
  */
  /***********************************************************************/
  node * list::make_node(int value) 
  {
    node *pNode = new node;
    pNode->value = value;
    pNode->next = nullptr;
    list_size++;
    return pNode;
  }
  
  /***********************************************************************/
  /*!
    \fn list
    \brief
      This function is the constructor for list class

    \return
      returns list
  */
  /***********************************************************************/
  list::list() : list_size(0), the_list(nullptr)
  {  }

  /***********************************************************************/
  /*!
    \fn ~list
    \brief
      This function is the destructor for list class

    \return
      returns list
  */
  /***********************************************************************/
  list::~list()
  {
    while(the_list != nullptr)                // List not empty
    {
      node *temp = the_list -> next;     // Temp holder for next node
      delete(the_list);                       // Delete node
      list_size--;
      the_list = temp;                        // Go to next node
    }
    the_list = nullptr;                       // Set to nullptr
    list_size = 0;
  }

  /***********************************************************************/
  /*!
    \fn print_list
    \brief
      This const function prints all of the nodes values

    \param list 
      List to be printed
  */
  /***********************************************************************/
  void list::print_list() const
  {
    // Initialisation
    node *temp = the_list;  
    while (temp)                // loop through the list
    {
      std::cout << temp->value << " ";    // print node value
      temp = temp->next;                  // go to next node
    }
    std::cout << std::endl;               // print new line
  }
  
  /***********************************************************************/
  /*!
    \fn size
    \brief
      This const function returns the list size
  */
  /***********************************************************************/
  unsigned list::size() const
  {
    return list_size;     // return size of the list
  }

  /***********************************************************************/
  /*!
    \fn empty
    \brief
      This const function returns true if the list is not empty
      and false if the list is empty
  */
  /***********************************************************************/
  bool list::empty() const
  {
    // Initialisation
    node * pNode = the_list;
    while(pNode)                // loop through the list
    {
      if(pNode)                // found node not nullptr
        return true;           // return true
      pNode = pNode -> next;   // Go to next node
    }
    return false;              // return false
  }
  
  /***********************************************************************/
  /*!
    \fn clear
    \brief
      This function clears the list
  */
  /***********************************************************************/
  void list::clear()
  {
    // Initialisation
    node *pCurrNode = the_list;   // set node to point to the_list 
    while (pCurrNode)             // loop through the list
    {
      the_list = pCurrNode->next;
      list_size--;
      delete pCurrNode;
      pCurrNode = the_list;
    }
    the_list = nullptr;
  }

  /***********************************************************************/
  /*!
    \fn push_front
    \brief
      This function adds a node in front of the list
    \param val 
      value to be added into the node
  */
  /***********************************************************************/
  void list::push_front(int val)
  {
    node *pNewNode = make_node(val);
    pNewNode->next = the_list;
    the_list = pNewNode;  
  }
  
  /***********************************************************************/
  /*!
    \fn front
    \brief
      This function returns the pointer to the first node in the list
  */
  /***********************************************************************/
  node * list::front()
  {
    return the_list;
  }
  
  /***********************************************************************/
  /*!
    \fn erase
    \brief
      This function removes nodes at position pos. 
      Position count starts from zero.
    \param pos
      The position of the node to be erased.
  */
  /***********************************************************************/
  void list::erase(int pos)
  {
    int sz = size();
    if(pos < 0 || pos > sz)
      return;
    if(the_list == nullptr)
      return;
    else if(pos == 0)
    {
      node *pList = the_list->next;    // Point to next node of list
      delete(the_list);                     // Delete list head
      list_size--;
      the_list = pList;                     // link the list
    }
    else
    {
      // Initialisation
      node *del_ptr = the_list;      // Set node to be deleted
      node *pNode = the_list;        // Set pointer node
      int index = pos;               // Set index of position
      
      while(index--)
      {
        pNode = del_ptr;        // Find previous node of specified position
        del_ptr = del_ptr -> next;    // Find specified node position
      }
      pNode -> next = del_ptr -> next;           // Linking the nodes
      delete del_ptr;
      list_size--;
      del_ptr = nullptr;
    }
  }

  /***********************************************************************/
  /*!
    \fn erase
    \brief
      This function removes nodes from position first to position last-1. 
      Position count starts from zero.
    \param first
      The position of the first node to be erased.
    \param last
      The position of the last node to be erased.
  */
  /***********************************************************************/
  void list::erase(int first, int last)
  {
    int sz = (int)list_size;
    if(last == 0 || first < 0)
      return;
    
    else if(first > sz || (first > last) )
      return;
    
    else if(last > sz)
      clear();
    
    else
    {
      if(first == 0)
      {
        for(int i = 0; i < last; i++)
        {
          node *pList = the_list->next;    // Point to next node of list
          delete(the_list);                     // Delete list head
          list_size--;
          the_list = pList;                     // link the list
        }
      }
      
      else
      {
        node *del_ptr = the_list;      // Set node to be deleted
        node *pNode = the_list;        // Set pointer node
        int index = first;
        // find the last node before first pos
        while(index--)
        {
          pNode = del_ptr;             // last node before first pos
          del_ptr = del_ptr -> next;   // node after first pos
        }
        // delete in range
        for(int i = first; i < last; i++)
        {
          node * tmp = del_ptr -> next;
          delete del_ptr;
          del_ptr = tmp;
          list_size--;
        }
        pNode -> next = del_ptr;
      }
    }
  }
 
  /***********************************************************************/
  /*!
    \fn resize
    \brief
      This function resizes the list to contain n elements.
      
      If n is smaller than the current size, then keep only
      the first n elements, then destroy those beyond.
      
      If n is larger than the current size, the new elements
      are initialized as val.
      
    \param n
      Number of nodes to be resized to.
    \param val
      Value to be added into the new nodes. Default is 0.
  */
  /***********************************************************************/
  void list::resize(int n, int val)
  { 
    int sz = size();
    node * pNode = the_list;
    
    if(n == 0)
    {
      clear();
      return;
    }
    if(n == sz)
      return;

    if(n < sz)
    {
      int counter = n;
      node * del = nullptr;
      node * prev = the_list;

      // traverse through the list
      while(counter--)
      {
        prev = pNode;
        pNode = pNode -> next;
      }
      prev -> next = nullptr;
      while(pNode)
      {
        del = pNode;
        pNode = pNode -> next;
        delete del;
        list_size--;
        del = nullptr;
      }
    }
    if(n > sz)
    {
      if(the_list == nullptr)
      {
        for(int i = 0; i < n - sz; ++i)      
          push_front(val);
      }
      else
      {
        // find the end of the list
        while(pNode->next)
          pNode = pNode -> next;
        // add to end of the list
        for(int i = 0; i < n - sz; ++i)      
        {
          pNode -> next = make_node(val);
          pNode = pNode -> next;
        } 
      }
    }
  }
  
  /***********************************************************************/
  /*!
    \fn sort
    \brief
      This function sorts the list ascendingly
  */
  /***********************************************************************/
  void list::sort()
  {
    // Check if the inputed list is nullptr
    if(the_list == nullptr || the_list->next == nullptr)
      return;                                       // return the list

    else
    {
      node * curr = the_list;
      node * pNode = nullptr;
      node * nextptr = nullptr;
      
      while(curr)
      {
        nextptr = curr -> next;
        
        sort_insert(pNode, curr);
        
        curr = nextptr;
      }
      the_list = pNode;
    }
  }
  
  /***********************************************************************/
  /*!
    \fn merge
    \brief
      This function assume the current list and l2 are both
      sorted ascendingly, this function merges them into one,
      so that the elements are still in ascending order.
     
      The current list will store the merged elements, 
      while l2 will become empty.
      
    \param l2
      The second list to be merged.
  */
  /***********************************************************************/
  void list::merge(list &l2)
  {
    node * list1 = the_list;
		node * list2 = l2.the_list;
    node * res = nullptr;
    node ** tmp = &res;
    
    if(the_list == nullptr)
    {
      while(list2)
      {
        *tmp = list2;
        tmp = &((*tmp) -> next);
        list2 = list2 -> next;
      }
      the_list = res;
    }
		
		if(list2 != nullptr)
		{
			/* make a pointer point to the last node of the list
			   make last node of list next point to first node of l2
     */
			while(list1->next)
			{
				list1 = list1->next;
			}
			list1->next = list2;
		}
    // l2.clear();
    // change to nullptr instead
    list_size += l2.size();
    sort();
    l2.the_list = nullptr;
    l2.list_size = 0;
  }
  
  /***********************************************************************/
  /*!
    \fn sort_insert
    \brief
      This function is a utility function to help sort the list in
      ascending order by inserting the numbers in position
      
    \param hNode
      The header node
    
    \param nNode
      The new node
  */
  /***********************************************************************/
  void sort_insert(node *& hNode, node * nNode)
  {
    if(hNode == nullptr || hNode -> value >= nNode -> value)
    {
      nNode -> next = hNode;
      hNode = nNode;
    }
    else
    {
      node * curr = hNode;
      while(curr -> next && curr -> next -> value < nNode -> value)
        curr = curr -> next;
      nNode -> next = curr -> next;
      curr -> next = nNode;
    }
  }
}