/******************************************************************************/
/*!
\file list.cpp
\author Khoo Teng Yen
\par email: tengyen.khoo\@digipen.edu
\par DigiPen login: tengyen.khoo
\par Course: CS170
\par Lab 04
\date 07/06/2019
\brief
Contains the function definition for a single link list
CS170::list::list
CS170::list::~list
CS170::list::print_list
CS170::list::size
CS170::list::empty
CS170::list::clear
CS170::list::push_front
CS170::list::front
CS170::list::erase(int pos)
CS170::list::erase(int first, int last)
CS170::list::resize
CS170::list::sort
CS170::list::merge
CS170::list::make_node
*/
/******************************************************************************/
#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here
namespace CS170
{
/******************************************************************************/
/*!
\fn list::list

\brief
  Constructor for list. 
  Creates an empty list 
*/
/******************************************************************************/
  list::list()
  {
    the_list = nullptr;
    list_size = 0;
  }

/******************************************************************************/
/*!
\fn list::~list()

\brief
  Destructor for list. 
  Empty the list and release the allocated memory 
*/
/******************************************************************************/
  list::~list()
  {
    clear();
  }

/******************************************************************************/
/*!
\fn list::print_list

\brief
  Prints out the values contained in the list 
*/
/******************************************************************************/
  void list::print_list() const
  {
    node *list = the_list;
    while (list)
    {
      std::cout << list->value << " ";
      list = list->next;
    }
    std::cout << std::endl;
  }

/******************************************************************************/
/*!
\fn list::size

\brief
  Returns the current size of the list

\return
  Returns the size of the list
*/
/******************************************************************************/
  unsigned list::size() const
  {
    return list_size;
  }

/******************************************************************************/
/*!
\fn list::empty

\brief
  Returns true if list is empty, false otherwise 

\return
  Returns true if list is empty. Returns false if lisths something in it
*/
/******************************************************************************/
  bool list::empty() const
  {
    if (the_list)
      return false;
    
    return true;
  }

/******************************************************************************/
/*!
\fn list::clear

\brief
  Frees (deletes) all of the nodes in the list 
*/
/******************************************************************************/
  void list::clear()
  {
    node *pCurrNode = the_list;
    while (pCurrNode)
    {
      the_list = pCurrNode->next;
      delete pCurrNode;
      --list_size;
      pCurrNode = the_list;
    }
    the_list = nullptr;
  }

/******************************************************************************/
/*!
\fn list::push_front

\brief
  Creates a node with val and add it to the front of the list

\param val
  the value of the new node
*/
/******************************************************************************/
  void list::push_front(int val)
  {
    node *pNewNode = make_node(val);
    pNewNode->next = the_list;
    the_list = pNewNode;
  }

/******************************************************************************/
/*!
\fn list::front

\brief
  Return the first node in the list 

\return
  Returns a pointer to the first node in the list
*/
/******************************************************************************/
  node* list::front()
  {
    return the_list;
  }

/******************************************************************************/
/*!
\fn list::erase(int pos)

\brief
  Removes nodes at position pos. 
  Position count starts from zero.

\param pos
  position of the node that will be deleted
*/
/******************************************************************************/
  void list::erase(int pos)
  {
    if(!empty())
    {
      int length = size();
      
      if(pos < 0 || pos > length)
        return;
      
      if (pos == 0)
      {
        node *pDelNode = the_list;
        the_list = the_list->next;
        delete pDelNode;
        --list_size;
        pDelNode = nullptr;
      }
      
      else
      {
        node *pCurrNode = the_list;
        node *pPrevNode = nullptr;
        node *pDelNode = nullptr;
        
        for(int i = 0; i < pos; ++i)
        {
          pPrevNode = pCurrNode;
          pCurrNode = pCurrNode->next;
        }
        pPrevNode->next = pCurrNode->next;
        pDelNode = pCurrNode;
        delete pDelNode;
        --list_size;
        pDelNode = nullptr;
      }
    }
  }

/******************************************************************************/
/*!
\fn list::erase(int first, int last)

\brief
  Removes nodes from position first to position last-1.
  Position count starts from zero.

\param first
  the position of the first node in the range to be erase
  
\param last
  the position of the last node in the range to be erase
*/
/******************************************************************************/
  void list::erase(int first, int last)
  {
    if(!empty())
    {
      if (first == 0)
      {
        node *pDelNode = nullptr;
        
        for(int i = 0; i < last && the_list; ++i)
        {
          pDelNode = the_list;
          the_list = the_list->next;
          delete pDelNode;
          --list_size;
          pDelNode = nullptr;
        }
      }
      
      else
      {
        int i = first;
        while(i < last)
        {
          erase(first);
          ++i;
        }
      }
    }
  }

/******************************************************************************/
/*!
\fn list::resize

\brief
  Resizes the list to contain n elements.
  If n is smaller than the current size, only the
  first n elements are kept, the rest are destroyed.
  If n is larger than the current size, the new elements
  are initialized as val.

\param n
  the new size of the list
  
\param val
  value of the new node
*/
/******************************************************************************/
  void list::resize(int n, int val)
  {
    int length = size();
    
    if(n == 0)
      clear();
    
    else if(n < length)
      erase(n, length);
    
    else if(n > length)
    {
      node *pCurrNode = nullptr;
      int i = 1;
      
      if(the_list == nullptr)
      {
        the_list = make_node(val);
        pCurrNode = the_list;
      }
      
      else
      {
        pCurrNode = the_list;
        while(pCurrNode->next)
        {
          pCurrNode = pCurrNode->next;
          ++i;
        }
      }
      
      while(i < n)
      {
        pCurrNode->next = make_node(val);
        pCurrNode = pCurrNode->next;
        ++i;
      }
    }
  }

/******************************************************************************/
/*!
\fn list::sort

\brief
  Sorts the list in an ascending order
*/
/******************************************************************************/
  void list::sort()
  {
    node *sorted = nullptr;
    node *pCurrNode = the_list;
    
    while(pCurrNode)
    {
      node *pNextNode = pCurrNode->next;
      
      node *pTempCurr; 
      if(sorted == nullptr || sorted->value >= pCurrNode->value)
      {
        pCurrNode->next = sorted; 
        sorted = pCurrNode; 
      }
      else
      {
        pTempCurr = sorted; 
        while (pTempCurr->next != nullptr && 
               pTempCurr->next->value < pCurrNode->value) 
        { 
            pTempCurr = pTempCurr->next; 
        } 
        pCurrNode->next = pTempCurr->next; 
        pTempCurr->next = pCurrNode; 
      }
      
      pCurrNode = pNextNode;
    }
    the_list = sorted;
  }

/******************************************************************************/
/*!
\fn list::merge

\brief
  this function merges two list into one, so that the elements
  are still in ascending order.
  The current list will store the merged elements, 
  while l2 will become empty.

\param l2
  the second list to be merge
*/
/******************************************************************************/
  void list::merge(list &l2)
  {
    node *result = nullptr;
    node **lastPtrRef = &result;  
    node *list1 = the_list;
    node *list2 = l2.front();
    
    while(1)
    {
      if (list1 == nullptr)
      {
        *lastPtrRef = list2;
        break;
      }
      else if (list2 == nullptr)
      {
        *lastPtrRef = list1;
        break;
      }

      if (list1->value <= list2->value)
      {
        *lastPtrRef = list1;
        list1 = list1->next;
      }

      else
      {
        *lastPtrRef = list2;
        list2 = list2->next;
      }
      lastPtrRef = &((*lastPtrRef)->next);
    }
    
    list_size += l2.size();
    l2.list_size = 0;
    l2.the_list = nullptr;
    the_list = result;
  }

/******************************************************************************/
/*!
\fn list::make_node

\brief
  Allocate memory and set members

\param val
  the value of the new node
  
\return
  Returns a pointer to a node
*/
/******************************************************************************/
  node* list::make_node(int val)
  {
    node *pNode = new node;
    pNode->value = val;
    pNode->next = nullptr;
    ++list_size;
    return pNode;
  }
}