/******************************************************************************/
/*! 
\file   list.cpp 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 04
\date   10/06/2019 
\brief
     This is file contains the function definitions for list.cpp.
*/ 
/******************************************************************************/
#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here
namespace CS170{
/******************************************************************************/
/*! 
  \fn          node* list::make_node(int val)
  \brief       Allocate memory and set members
  \param       val
  \return      node*
*/ 
/******************************************************************************/
  node* list::make_node(int val)
  {
    node *new_node = new node;
    new_node->value = val;
    new_node->next = nullptr;
    ++list_size;
    return new_node;
  }
/******************************************************************************/
/*! 
  \fn          list::list()
  \brief       Constructor for list. Creates an empty list
  \return      void
*/ 
/******************************************************************************/
  list::list()
  {
    list_size = 0;
    the_list = nullptr;
  }
/******************************************************************************/
/*! 
  \fn          list::~list()
  \brief       Destructor for list. 
  \return      void
*/ 
/******************************************************************************/
  list::~list()
  {
    clear();
  }
/******************************************************************************/
/*! 
  \fn          void list::print_list() const
  \brief       Prints out the values contained in the list
  \return      void
*/ 
/******************************************************************************/
  void list::print_list() const
  {
    node *list = the_list;
    while (list) 
    {
      std::cout << list->value << " ";
      list = list->next;
    }
  std::cout << std::endl;   
  }
/******************************************************************************/
/*! 
  \fn          unsigned list::size() const
  \brief       Returns the current size of the list
  \return      unsigned
*/ 
/******************************************************************************/
  unsigned list::size() const
  {
    return list_size;
  }
/******************************************************************************/
/*! 
  \fn          bool list::empty() const
  \brief       Returns true if list is empty, false otherwise 
  \return      bool
*/ 
/******************************************************************************/
  bool list::empty() const
  {
    return !list_size;
  }
/******************************************************************************/
/*! 
  \fn          void list::clear()
  \brief       Frees (deletes) all of the nodes in the list 
  \return      void
*/ 
/******************************************************************************/
  void list::clear()
  {
    node *pCurrNode = the_list;
    while (pCurrNode) 
    {
      the_list = pCurrNode->next;
      delete pCurrNode;
      list_size--;
      pCurrNode = the_list;
    }
    the_list=nullptr;
  }
/******************************************************************************/
/*! 
  \fn          void list::push_front(int val)
  \brief       Creates a node with val and add it to the front of the list
  \param       val
  \return      void
*/ 
/******************************************************************************/
  void list::push_front(int val)
  {
    node *pNewNode = make_node(val);
    pNewNode->next = the_list;
    the_list = pNewNode;  
  }
/******************************************************************************/
/*! 
  \fn          node* list::front()
  \brief       Return the first node in the list 
  \return      node*
*/ 
/******************************************************************************/
  node* list::front()
  {
    return the_list;
  }
/******************************************************************************/
/*! 
  \fn          void list::erase(int pos)
  \brief       Removes nodes at position pos. 
  \param       pos
  \return      void
*/ 
/******************************************************************************/
  void list::erase(int pos)
  {
    //checks if listptr is empty
    if (empty()||pos<0) return;
    node* listptr = the_list;
    //check for position 0
    if (pos == 0) 
    {
      the_list = listptr->next;
      delete listptr;
      list_size--;
      return;
    }
    //else go to the position specified
    for (int i = 0; i < pos-1; i++) 
    {
      //check if the position is within bounds (in a way)
      if(listptr->next == nullptr) return;
      listptr = listptr->next;
    }
    node* temp = listptr->next;
    listptr->next = temp->next;
    delete temp;
    list_size--;
  }
/******************************************************************************/
/*! 
  \fn          void list::erase(int first, int last)
  \brief       Removes nodes from position first to position last-1. 
  \param       first
  \param       last
  \return      void
*/ 
/******************************************************************************/
  void list::erase(int first, int last)
  {
    for (int i = 0; i < last-first; i++) erase(first);
  }
/******************************************************************************/
/*! 
  \fn          void list::resize(int n, int val)
  \brief       Resizes the list to contain n elements
  \param       n
  \param       val
  \return      node*
*/ 
/******************************************************************************/
  void list::resize(int n, int val)
  {
	//checks if n is negative
	if (n < 0) clear();
    //checks if the list size is bigger than n
    else if(n < (int)list_size) erase(n,(int)list_size);
    //else add the extra new nodes of val to the end of the list
    else 
      for (int i = (int)list_size; i < n; i++) 
      {
        node *pCurrNode = front();
        if (the_list == nullptr) the_list = make_node(val);
        else 
        {
          while (pCurrNode->next) pCurrNode = pCurrNode->next;
          pCurrNode->next = make_node(val);
        }
      }
  }

//helper functions
namespace{
  node *getEnd(node *end)
  {
    //gets find the end of the list and return it
    while (end != nullptr && end->next) end = end->next;
    return end;
  }
  //partition
  node *partition(node* head, node* end, node **newhead, node **newend)
  {
    node *pivot = end;
    node *prev = nullptr;
    node *curr = head;
    node *tail = end;
    while (curr != pivot)
    {
      //checks if the value is less then pivot value 
      if (curr->value < pivot->value)
      {
        //if there's no newhead, set curr as newhead
        if ((*newhead) == nullptr ) (*newhead) = curr;
        if(curr->value < (*newhead)->value)
        {
          node* tmp = (*newhead);
          while(tmp->next!= curr) tmp = tmp->next;
          tmp->next=curr->next;
          curr->next = (*newhead);
          (*newhead) = curr;
        }
        prev = curr;
        curr = curr->next;
      }
      //else add tail to end
      else
      {
        if (prev) prev->next = curr->next;
        node *temp = curr->next;
        curr->next = nullptr;
        tail->next = curr;
        tail = curr;
        curr = temp;
      }
    }
    //update head if it's nullptr
    if ((*newhead) == nullptr) (*newhead) = pivot;
    //update end
    (*newend) = tail;
    return pivot;
  }
  //quicksort
  node *quicksort(node* head, node* end)
  {
    //check if the list has no nodes or if the start of the list is equal to the
    //end of the list
    if (head == nullptr || head == end) return head;
    node *newhead = nullptr;
    node *newend = nullptr;
    node *pivot = partition(head, end, &newhead, &newend);
    //then check if pivot is the smallest value
    if (newhead == pivot) pivot->next = quicksort(pivot->next, newend);
    //else sort the left side then the right
    else
    {
      node *temp = newhead;
      while (temp->next != pivot) temp = temp->next;
      temp->next = nullptr;
      newhead = quicksort(newhead, temp);
      temp = getEnd(newhead);
      temp->next = pivot;
      pivot->next = quicksort(pivot->next, newend);
    }
    return newhead;
  }
}

  // Sorts the list ascendingly
  void list::sort()
  {
    //if list is empty or have only 1 node, return
    if (the_list == nullptr || the_list->next == nullptr) return;
    the_list = quicksort(front(), getEnd(front()));
  }
      
  /* Assume the current list and l2 are both sorted ascendingly,
     this function merges them into one, so that the elements
     are still in ascending order.
     The current list will store the merged elements, 
     while l2 will become empty.
  */
/******************************************************************************/
/*! 
  \fn          void list::merge(list &l2)
  \brief       merge 2 list into 1
  \param       l2
  \return      void
*/ 
/******************************************************************************/  
  void list::merge(list &l2)
  {
    //checks if l2 is empty
    if (l2.empty()) return;
    node* list2 = l2.front();
    node* list1 = front();
    node* prev = list1;
    //while l2 is not empty, merge it into list1
    while(!l2.empty())
    {
      //reset list2
      list2 = l2.front();
      //checks if list1 is empty
      if (empty())
      {
        push_front(list2->value);
        list1=front();
        l2.erase(0);
      }
      //checks if the value of list2 is less than list1
      else if(list2->value <= list1->value) 
      { 
        //checks if list1 is currently the first in the list
        if(list1 == front())
        {
          push_front(list2->value);
          prev=front();
        }
        //else insert the value of list2 as a new node into list1
        else
        {
          prev->next = make_node(list2->value);
          prev->next->next = list1;
          prev = prev->next;
        }
        l2.erase(0);
      }
      //else move on through list1
      else
      {
        //checks if it's the end of list1
        if (list1->next == nullptr && list2->value > list1->value) 
        {
          list1->next = make_node(list2->value);
          l2.erase(0);
        }
        prev = list1;  
        list1=list1->next;
      }
    }
  }
}