/******************************************************************************/
/*!
\file   list.cpp
\author Teh Yu Yin
\par    email: t.yuyin\@digipen.edu
\par    DigiPen login: t.yuyin
\par    Course: CS170A
\par    Lab 04
\date   10/06/2019
\brief
  This file contains the function definitions for handling a basic linked list.
Functions:
list
~list
make_node
print_list
size
empty
clear
push_front
front
erase(1 position parameter)
erase(2 position parameters)
resize
sort
merge
*/
/******************************************************************************/

#include <iostream>
#include "list.h"

namespace CS170
{

/******************************************************************************/
/*!
  \fn list::list()
  
  \brief
    Constructor for list. Creates an empty list 
*/
/******************************************************************************/
list::list()
{
    list_size = 0;
    the_list = nullptr;
}

/******************************************************************************/
/*!
  \fn list::~list()
  
  \brief
    Destructor for list. Empty the list and release the allocated memory.
*/
/******************************************************************************/
list::~list()
{
    clear(); // Function call to empty the list if required
}

/******************************************************************************/
/*!
  \fn node* list::make_node(int val)
  
  \brief
    Makes a new Node based on given integer value and returns a pointer to it.
    
  \param val
    An integer value passed into the function to make the new Node.
    
  \return
    Returns a pointer to the newly created Node.
*/
/******************************************************************************/
node* list::make_node(int val)
{
    // Allocate memory and set members
    node* pNode = new node;
    pNode->value = val;
    pNode->next = nullptr;

    return pNode;
}

/******************************************************************************/
/*!
  \fn void list::print_list() const
  
  \brief
    Prints the values of every node in the list provided for the function.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::print_list() const
{
    node* currNode = the_list;
    while (currNode) 
    {
    std::cout << currNode->value << " ";
    currNode = currNode->next;
    }
  std::cout << std::endl;   
}

/******************************************************************************/
/*!
  \fn unsigned list::size() const
  
  \brief
    Returns the current size of the list.

  \return
    Unsigned int representing the list size.
*/
/******************************************************************************/
unsigned list::size() const
{
    return list_size;
}

/******************************************************************************/
/*!
  \fn bool list::empty() const
  
  \brief
    Checks if list is empty.

  \return
    Returns true if list is empty, false otherwise.
*/
/******************************************************************************/
bool list::empty() const
{
    return (the_list == nullptr? true : false);
}
    
/******************************************************************************/
/*!
  \fn void list::clear()
  
  \brief
    Frees all allocated nodes in the provided list.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::clear()
{
    node* pCurrNode = the_list;
    while (pCurrNode) 
    {
        the_list = pCurrNode->next;
        delete pCurrNode;
        pCurrNode = the_list;
    }
    // After clearing, reset the pointer and list sizing
    the_list = nullptr;
    list_size = 0;
}

/******************************************************************************/
/*!
  \fn void list::push_front(int val)
  
  \brief
    Creates a new Node based on the integer value passed into the function and
    adds it to the front of the list.
    In cases where the provided list is empty, the new node will simply be added
    as the first node in the list.
    
  \param val
    An integer value passed into the function to make the new Node.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::push_front(int val)
{
    node* pNewNode = make_node(val);
    pNewNode->next = the_list;
    the_list = pNewNode;
    
    // Update list size after adding new node
    ++list_size;
}

/******************************************************************************/
/*!
  \fn node* list::front()
  
  \brief
    Return the first node in the list.
    
  \return
    Return the first node in the list.
*/
/******************************************************************************/
// 
node* list::front()
{
    return the_list;
}

/******************************************************************************/
/*!
  \fn void list::erase(int pos)
  
  \brief
    Removes nodes at position pos. Position count starts from zero.
    
  \param pos
    An integer value passed into the function representing position.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::erase(int pos)
{
    node *chkNode = the_list;  // Used to point to target node for deletion
    node *trkNode = nullptr; // Used to realign list after deletion
    
    if(pos == 0)
    {
        the_list = chkNode->next;
        delete chkNode;
    }
    // Check that parameters provided are not ridiculous or out of bounds
    else if(pos > 0 && pos < (int)size())
    {
        // Keep running through the list until pos is reached
        for(int i = 0; i < pos; ++i)
        {
            trkNode = chkNode;
            chkNode = chkNode->next;
        }
        
        // If there are other nodes following the node to be deleted,
        // reconnect the list before deletion
        trkNode->next = trkNode->next->next;
        
        // Delete node accordingly via deallocation
        delete chkNode;
        --list_size;
    }
}

/******************************************************************************/
/*!
  \fn void list::erase(int first, int last)
  
  \brief
    Removes nodes from position first to position last-1. 
    Position count starts from zero.
    
  \param first
    An integer value passed into the function representing first position.
    
  \param last
    An integer value passed into the function representing last position.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::erase(int first, int last)
{
    node* startNode = the_list; // Pointer to starting position for deletion
    node* trkNode = the_list;   // Helper for reordering list
    node* dltNode = nullptr;    // Helper for deleting nodes
    node* endNode = nullptr;    // Pointer to ending position for deletion
    int total = (last-1) - first;   // Used for deletion iteration
    
    // Check that parameters provided are not ridiculous or out of bounds
    if(first >= 0 && last >= 0 && last < (int)size() && first < last)
    {
        
        // First have the helpers point to the correct positions
        for(int i = 0; i < first; ++i)
        {
            trkNode = startNode;
            startNode = startNode->next;
        }
        
        endNode = startNode;
        
        for(int j = first; j < last-1; ++j)
            endNode = endNode->next;
        
        // Reorder the list
        trkNode->next = endNode->next;
        
        
        // Delete separated nodes
        for(int k = 0; k <= total; ++k)
        {
            dltNode = startNode->next;
            delete startNode;
            startNode = dltNode;
            --list_size;
        }
    }
}

/******************************************************************************/
/*!
  \fn void list::resize(int n, int val)
  
  \brief
    Resizes the list to contain n elements.
    If n is smaller than the current size, then keep only
    the first n elements, then destroy those beyond.
    If n is larger than the current size, the new elements
    are initialized as val.
    
  \param n
    An integer value passed into the function representing the limit.
    
  \param val
    An integer value passed into the function representing values to be
    inserted if required.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::resize(int n, int val)
{
    node* chkNode = the_list; // Pointer for clearing or initializing nodes
    
    if(n <= 0) // Zero would mean list should be cleared
    {
        clear();
    }
    // From here, it is assumed that n must be more than zero
    else if(n < (int)size() && n > 0)
    {
        node* trkNode = nullptr;  // Helper for deleting nodes
        node* trkNode2 = nullptr; // Extra helper for deleting nodes
        
        // Have chkNode point to nth position in the list
        for(int i = 1; i != n; ++i)
            chkNode = chkNode->next;
        
        trkNode = chkNode->next;
        chkNode->next = nullptr; // Separate the other nodes from current list
        
        // Delete all separated nodes
        while(trkNode)
        {
            trkNode2 = trkNode->next;
            delete trkNode;
            trkNode = trkNode2;
        }
    }
    else if(n > (int)size() && n > 0)
    {
        int listsize = static_cast<int>(size());
        if(!listsize)
        {
            chkNode = the_list = make_node(val);
            listsize = 1;
        }
        else
        {
            // Have chkNode point to the last node of the current list
            while(chkNode->next != nullptr)
            chkNode = chkNode->next;
        }
        // Then add new nodes of values 'val' until size 'n' is reached
        for(int i = listsize; i < n; ++i)
        {
            chkNode->next = make_node(val);
            ++listsize;
            chkNode = chkNode->next;
        }
    }
    // Else, if n and list_size are the same, do nothing
    
    // Update the list size with new sizing
    list_size = n;
}

/******************************************************************************/
/*!
  \fn void list::sort()
  
  \brief
    Sort elements in the list ascendingly.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::sort()
{
    int helper = 0;            // Helper for swapping node values
    int chkswap = 0;           // Used to account for checking swap iterations
    node *chkValue = the_list; // Moving ptr used to check against values
    
    // Checks if list is empty, proceed only if list has more than 1 node
    if(chkValue != nullptr)
    {
        if(chkValue->next != nullptr)
        {
            do
            {
                chkswap = 0;
                chkValue = the_list;
                
                // Runs through the list for swapping
                while(chkValue->next != nullptr)
                {
                    if(chkValue->value > chkValue->next->value)
                    {
                        helper = chkValue->value;
                        chkValue->value = chkValue->next->value;
                        chkValue->next->value = helper;
                        chkswap = 1;
                    }
                    chkValue = chkValue->next;
                }
            }while(chkswap); // Repeat until no swapping occurs/list is sorted
        }
    }
}

/******************************************************************************/
/*!
  \fn void list::merge(list &l2)
  
  \brief
    Assume the current list and l2 are both sorted ascendingly,
    this function merges them into one, so that the elements
    are still in ascending order.
    The current list will store the merged elements, while l2 will become empty.
    
  \param l2
    A pointer to a node list which is passed into the function.
    
  \return
    Nothing is returned.
*/
/******************************************************************************/
void list::merge(list &l2)
{
    // If current list is empty
    if(the_list == nullptr)
    {
        the_list = l2.the_list;

        // Ensure l2 points to nothing after merging nodes to current list
        l2.the_list = nullptr;
    }
    else if(the_list != nullptr) // If current list is not empty
    {
        node *concatHelper = the_list; // Pointer for last node of current list

        // Locate the last node of current list
        while(concatHelper->next != nullptr)
        {
            concatHelper = concatHelper->next;
        }

        // Connect the two lists by pointing the "next" member of the last node
        // of current list to the first node of l2
        concatHelper->next = l2.the_list;

        l2.the_list = nullptr;
    }
    // Add on the list size to current list and make l2's list size zero
    list_size += l2.size();
    l2.list_size = 0;
    
    // Call 'sort' function to check for any unsorted nodes after merge
    sort();
}
}
