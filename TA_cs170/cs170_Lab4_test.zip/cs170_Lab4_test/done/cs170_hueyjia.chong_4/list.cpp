/******************************************************************************/ 
/*! 
 \file   list.cpp
 \author Chong Huey Jia
 \par    email: hueyjia.chong\@digipen.edu 
 \par    DigiPen login: hueyjia.chong 
 \par    Course: CS170L 
 \par    Lab 04 
 \date   3/06/2011 
 \brief     This is a linked list
*/ 
/******************************************************************************/

#include <iostream>
#include "list.h"

// Please fill in your code for the class functions in list.h here

namespace CS170
{
/******************************************************************************/ 
/*! 
	\fn list::list()

	\brief this function creates an empty list
*/
/******************************************************************************/
	// default constructor
	list::list() : list_size{0},
	               the_list{nullptr}
	{}
/******************************************************************************/ 
/*! 
	\fn list::~list()

	\brief this function empty the list and release the allocated memory

	\return void
*/
/******************************************************************************/	
	// destructor
	list::~list()
	{
		while(size() != 0)
		{
			if(the_list == nullptr)
			{
				return;
			}
			
			else
			{
				node *curr = the_list;
				the_list = the_list->next;
				delete curr;
				
				list_size--;
			}
		}
	}
/******************************************************************************/ 
/*! 
 
  \fn void list::print_list() const
 
  \brief this is a function prints out the values contained in the list
  
  \return void
*/ 
/******************************************************************************/	
	void list::print_list() const
	{
		node *curr = the_list;
		
		// while curr is not nullptr, print out what is in the list
		while(curr)
		{
			std::cout << curr->value << " ";
			curr = curr->next;
		}
		std::cout << std::endl;
	}
/******************************************************************************/ 
/*! 
	\fn unsigned list::size() const
	
	\brief this function returns the current size of the list

	\return list_size
*/
/******************************************************************************/	
	unsigned list::size() const
	{
		return list_size;
	}
/******************************************************************************/ 
/*! 
	\fn bool list::empty() const

	\brief this function returns true if list is empty, false otherwise

	\return true
	\return false
*/
/******************************************************************************/	
	bool list::empty() const
	{
		if(size() == 0)
		{
			return true;
		}
		
		return false;
	}
/******************************************************************************/ 
/*! 
 
  \fn void list::clear()
 
  \brief this is a function frees (deletes) all of the nodes in the list
  
  \return void
*/ 
/******************************************************************************/	
	void list::clear()
	{
		node *curr = the_list;
		
		while(curr)
		{
			// deleting the nodes until there is no nodes in the list
			the_list = curr->next;
			delete curr;
			curr = the_list;
			
			list_size--;
		}
		
		// as the list is empty, set the_list to be nullptr
		the_list = nullptr;
	}
/******************************************************************************/ 
/*! 
	\fn void list::push_front(int val)
	
	\brief this function creates a node with val and 
	       add it to the front of the list 

	\param val

	\return void
*/
/******************************************************************************/	
	void list::push_front(int val)
	{
		node *newNode = make_node(val);
		
		if(the_list == nullptr)
		{
			the_list = newNode;
		}
		
		else
		{
			/* if the_list is not a nullptr,
			   make the newNode next point to the_list
			   and make the_list point to newNode
			*/
			node *curr = the_list;
			newNode->next = curr;
			the_list = newNode;
		}
		
		list_size++;
	}
/******************************************************************************/ 
/*! 
	\fn node *list::front()

	\brief this function return the first node in the list 

	\return node*
*/
/******************************************************************************/ 	
	node *list::front()
	{
		return the_list;
	}
/******************************************************************************/ 
/*! 
	\fn void list::erase(int pos)

	\brief this function removes nodes at position pos. 
	            Position count starts from zero.
		

	\param pos

	\return void
*/ 
/******************************************************************************/	
	void list::erase(int pos)
	{
		unsigned num = pos;
		
		if((the_list == nullptr) ||
		   (pos < 0) ||
		   (pos > static_cast<int>(size())))
		{
			return;
		}
		
		// if pos is 0, remove the first node in the list
		if(pos == 0)
		{
			node *curr = the_list;
			the_list = the_list->next;
			delete curr;
			
			list_size--;
		}
		
		// if pos is beigger than the size, remove the last node in the list
		else if(num == size())
		{
			if(the_list->next == nullptr)
			{
				node *curr = the_list;
				the_list = the_list->next;
				delete curr;
			}
			
			else
			{
				node *curr = the_list;
				node *prev = the_list;
				
				// curr will go to the last node
				while(curr->next)
				{
					prev = curr;
					curr = curr->next;
				}
				
				/* before deleting the last node, 
				   let prev next point to nullptr
				*/
				prev->next = curr->next;
				delete curr;
			}
			
			list_size--;
		}
		
		else
		{
			node *curr = the_list;
			node *prev = the_list;
			
			// curr will move to the pos that is going to be deleted
			while(pos--)
			{
				prev = curr;
				curr = curr->next;
			}
			
			prev->next = curr->next;
			delete curr;
			curr = nullptr;
			
			list_size--;
		}
	}
/******************************************************************************/ 
/*! 
	\fn void list::erase(int first, int last)

	\brief this function removes nodes from position first to position last-1. 
	       Position count starts from zero.
		   
	\param first
	\param last

	\return void
*/
/******************************************************************************/	
	void list::erase(int first, int last)
	{
		node *curr = the_list;
		int num = last - first;
		
		if((the_list == nullptr) ||
		   (first > last) ||
		   (last == first) ||
		   (first > static_cast<int>(size())))
   	    {
			return;
		}
		
		for(int i = first; i > 0; --i)
		{
			curr = curr->next;
		}
		
		for(int i = 0; i < num; ++i)
		{
			erase(first);
		}
	}
/******************************************************************************/ 
/*! 
	\fn void list::resize(int n, int val)

	\brief this function resizes the list to contain n elements.
	       If n is smaller than the current size, then keep only
	       the first n elements, then destroy those beyond.
	       If n is larger than the current size, the new elements
	       are initialized as val.
		   
	\param n
	\param val

	\return void
*/
/******************************************************************************/	
	void list::resize(int n, int val)
	{
		if(n == static_cast<int>(size()))
		{
			return;
		}
		
		else if(n < static_cast<int>(size()))
		{
			int num = list_size - n;
			for(int i = num; i > 0; --i)
			{
				erase(n);
			}
		}
		
		else
		// if(n > static_cast<int>size())
		{
			int num = n - list_size;
			for(int i = 0; i < num; ++i)
			{
				if(the_list == nullptr)
				{
					node *newNode = make_node(val);
					the_list = newNode;
				}
				
				else
				{
					node *curr = the_list;
					while(curr->next)
					{
						curr = curr->next;
					}
					node *newNode = make_node(val);
					curr->next = newNode;
				}
				
				list_size++;
			}
		}
	}
/******************************************************************************/ 
/*! 
 
  \fn void list::sort()
 
  \brief this is a function to sorts the list ascendingly
 
  \return void
*/ 
/******************************************************************************/		
	void list::sort()
	{
		// if there are nodes in the list
		if(list_size != 0)
		{
			node *sorted = the_list;
			node *check = the_list;
			int smallest = the_list->value;
			int temp = 0;
			
			while(sorted)
			{
				check = sorted;
				smallest = sorted->value;
				
				while(check)
				{
					if(check->value < smallest)
					{
						smallest = check->value;
					}
					check = check->next;
				}
				check = sorted;
				
				while(check)
				{
					if(check->value == smallest)
					{
						temp = sorted->value;
						sorted->value = check->value;
						check->value = temp;
						sorted = sorted->next;
					}
					check = check->next;
				}
			}
		}
	}
/******************************************************************************/ 
/*! 
	\fn void list::merge(list &l2)

	\brief this function merges them into one, so that the elements
	       are still in ascending order.
	       The current list will store the merged elements, 
	       while l2 will become empty.

	\param l2

	\return void
*/
/******************************************************************************/	
	void list::merge(list &l2)
	{
		node *curr = l2.the_list;
		
		if(l2.front() != nullptr)
		{
			while(curr)
			{
				push_front(curr->value);
				curr = curr->next;
			}
			l2.clear();
			l2.the_list = nullptr;
			this->sort();
		}
	}
/******************************************************************************/ 
/*! 
	\fn node *list::make_node(int val)

	\brief this function creates a new node

	\param val

	\return node
*/
/******************************************************************************/	
	node *list::make_node(int val)
	{
		node *newNode = new node;
		newNode->value = val;
		newNode->next = nullptr;
		return newNode;
	}
}