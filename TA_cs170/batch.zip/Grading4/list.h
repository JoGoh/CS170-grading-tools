//////////////////////////////////////////////////////////////////////////
#ifndef LIST_H
#define LIST_H
//////////////////////////////////////////////////////////////////////////

namespace CS170 
{
  struct node 
  {
    int value;
    node *next;
  };

class list 
{
  public:
  // Constructor for list. Creates an empty list 
  list();

  /* Destructor for list. 
     Empty the list and release the allocated memory 
  */
  ~list();

  // Prints out the values contained in the list 
  void print_list() const;

  // Returns the current size of the list 
  unsigned size() const;

  // Returns true if list is empty, false otherwise 
  bool empty() const;
      
  // Frees (deletes) all of the nodes in the list 
  void clear();

  /* Creates a node with val and 
     add it to the front of the list */
  void push_front(int val);

  // Return the first node in the list 
  node *front();

  /* Removes nodes at position pos. 
     Position count starts from zero.
  */
  void erase(int pos);

  /* Removes nodes from position first to position last-1. 
     Position count starts from zero.
  */
  void erase(int first, int last);

  /* Resizes the list to contain n elements.
     If n is smaller than the current size, then keep only
     the first n elements, then destroy those beyond.
     If n is larger than the current size, the new elements
     are initialized as val.
  */
  void resize(int n, int val = 0);

  // Sorts the list ascendingly
  void sort();
      
  /* Assume the current list and l2 are both sorted ascendingly,
     this function merges them into one, so that the elements
     are still in ascending order.
     The current list will store the merged elements, 
     while l2 will become empty.
  */
  void merge(list &l2);

  private:
    unsigned list_size;
    node *the_list;

    node *make_node(int val);
  };
}
#endif              // LIST_H
