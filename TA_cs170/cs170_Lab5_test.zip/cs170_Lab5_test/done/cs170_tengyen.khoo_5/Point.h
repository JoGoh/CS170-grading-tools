/******************************************************************************/
/*!
\file Point.h
\author Khoo Teng Yen
\par email: tengyen.khoo\@digipen.edu
\par DigiPen login: tengyen.khoo
\par Course: CS170
\par Lab 05
\date 13/06/2019
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
      // Constructors (2)
      Point();
      
      Point(double xcoord, double ycoord);
      
      Point(const Point &p1);
      
      // Overloaded operators (14 member functions)
      Point operator% (const double angle) const; // Rotation
      
      double operator- (const Point RHS) const; // Distance(Binary operator)
      
      Point operator^ (const Point RHS) const; // Midpoint
      
      Point& operator+= (const Point RHS); // Translation
      
      Point& operator+= (const double length); // Translation
      
      Point operator- (const double length) const; // Translation
      
      Point& operator++(); // Pre-Increment
      
      Point operator++(int); // Post-Increment
      
      Point& operator--(); // Pre-Decrement
      
      Point operator--(int); // Post-Decrement
      
      Point operator-() const; // Unary Negation
      
      Point operator+(const Point RHS) const; // Translation
      
      Point operator+(const double length) const; // Translation
      
      Point operator*(const double scale) const; // Scale
      
      Point operator=(const Point &p1); // Assignment
      
      // Overloaded operators (2 friend functions)
      friend std::ostream& operator<< (std::ostream& os, const Point &p1); // Output
      
      friend std::istream& operator>> (std::istream& is, Point &p1); // Input
      
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

      // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
  // Overloaded operators (2 non-member, non-friend functions)
  Point operator+(const double length, const Point p1); // Translation
  
  Point operator*(const double scale, const Point p1); // Scale
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
