/******************************************************************************/
/*!
\file Point.cpp
\author Khoo Teng Yen
\par email: tengyen.khoo\@digipen.edu
\par DigiPen login: tengyen.khoo
\par Course: CS170
\par Lab 05
\date 13/06/2019
\brief
Contains the function definition and operator overloading for Point class
Point::DegreesToRadians
Point::RadiansToDegrees
Point::Point()
Point::Point(double xcoord, double ycoord)
Point::Point(const Point &p1)
Point::operator% (const double angle) const
Point::operator- (const Point RHS) const
Point::operator^ (const Point RHS) const
Point::operator+= (const Point RHS)
Point::operator+= (const double length)
Point::operator- (const double length) const
Point::operator++()
Point::operator++(int)
Point::operator--()
Point::operator--(int)
Point::operator-() const
Point::operator+(const Point RHS) const
Point::operator+(const double length) const
Point::operator*(const double scale) const
Point::operator=(const Point &p1)
operator<< (std::ostream& os, const Point &p1)
operator>> (std::istream& is, Point &p1)
operator+(const double length, const Point p1)
operator*(const double scale, const Point p1)
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{
  const double PI = 3.1415926535897;
  const double EPSILON = 0.00001;

  /****************************************************************************/
  /*!
  \fn Point::DegreesToRadians

  \brief
    Converts degree to radians.

  \param degrees
    The degree to be converted.
    
  \return
    Returns degree in radians.
  */
  /****************************************************************************/
  double Point::DegreesToRadians(double degrees) const
  {
    return (degrees * PI / 180.0);
  }

  /****************************************************************************/
  /*!
  \fn Point::RadiansToDegrees

  \brief
    Converts radians to degree.

  \param radians
    The radians to be converted.
    
  \return
    Returns radians in degree.
  */
  /****************************************************************************/
  double Point::RadiansToDegrees(double radians) const
  {
    return (radians * 180.0 / PI);
  }

  /****************************************************************************/
  /*!
  \fn Point::Point()

  \brief
    Default constructor for point class.
  */
  /****************************************************************************/
  // Constructors (2)
  Point::Point()
  {
    x = 0;
    y = 0;
  }

  /****************************************************************************/
  /*!
  \fn Point::Point(double xcoord, double ycoord)

  \brief
    Constructor for point class that assigns the x and y values.

  \param xcoord
    The x coordinate.
    
  \param ycoord
    The y coordinate.
  */
  /****************************************************************************/
  Point::Point(double xcoord, double ycoord)
  {
    x = xcoord;
    y = ycoord;
  }

  /****************************************************************************/
  /*!
  \fn Point::Point(const Point &p1)

  \brief
    Copy constructor for Point class.

  \param p1
    The point to be copied.
  */
  /****************************************************************************/
  Point::Point(const Point &p1)
  {
    x = p1.x;
    y = p1.y;  
  }

  /****************************************************************************/
  /*!
  \fn Point::operator% (const double angle) const

  \brief
    Rotates a Point about the origin by the specified number of degrees.

  \param angle
    The angle of rotation.
    
  \return
    Returns the rotated Point.
  */
  /****************************************************************************/
  Point Point::operator% (const double angle) const
  {
    Point p1(cos(DegreesToRadians(angle))*x - sin(DegreesToRadians(angle))*y,
             sin(DegreesToRadians(angle))*x + cos(DegreesToRadians(angle))*y);
    
    if(fabs(p1.x - 0.0) <= EPSILON)
      p1.x = fabs(p1.x);
    
     if(fabs(p1.y - 0.0) <= EPSILON)
      p1.y = fabs(p1.y);
    
    return p1;
  }

  /****************************************************************************/
  /*!
  \fn Point::operator- (const Point RHS) const

  \brief
    Calculates the distance between two Points.

  \param RHS
    The second point.
    
  \return
    Returns the distance between two Points.
  */
  /****************************************************************************/
  double Point::operator- (const Point RHS) const
  {
    return sqrt((RHS.x-x)*(RHS.x-x) + (RHS.y-y)*(RHS.y-y));
  }

  /****************************************************************************/
  /*!
  \fn Point::operator^ (const Point RHS) const

  \brief
    Calculates the midpoint between two Points.

  \param RHS
    The second point.
    
  \return
    Returns the midpoint between two Points.
  */
  /****************************************************************************/
  Point Point::operator^ (const Point RHS) const
  {
    return Point((x+RHS.x)/2, (y+RHS.y)/2);
  }

  /****************************************************************************/
  /*!
  \fn Point::operator+= (const Point RHS)

  \brief
    Adds two Points together and saves it to the left-hand operand.

  \param RHS
    The second point.
    
  \return
    Returns a reference to the left-hand operand which has been modified.
  */
  /****************************************************************************/
  Point& Point::operator+= (const Point RHS)
  {
    x += RHS.x;
    y += RHS.y;
    
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn Point::operator+= (const double length)

  \brief
    Adds a Point and a double together and saves it to the left-hand operand.

  \param length
    The double to be added to the point.
    
  \return
    Returns a reference to the left-hand operand which has been modified.
  */
  /****************************************************************************/
  Point& Point::operator+= (const double length)
  {
    x += length;
    y += length;
    
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn Point::operator- (const double length) const

  \brief
    Subtracts a double from a Point.

  \param length
    The double to be subtracted from the point.
    
  \return
    Returns a Point after subtracting.
  */
  /****************************************************************************/
  Point Point::operator- (const double length) const
  {
    return Point(x-length, y-length);
  }

  /****************************************************************************/
  /*!
  \fn Point::operator++()

  \brief
    Increments the value.

  \return
    Returns a reference to the incremented Point.
  */
  /****************************************************************************/
  Point& Point::operator++()
  {
    ++x;
    ++y;
    
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn Point::operator++(int)

  \brief
    Increments the value.

  \return
    Returns the value of the Point before incrementing.
  */
  /****************************************************************************/
  Point Point::operator++(int)
  {
    Point temp = *this;
    ++x;
    ++y;
    return temp;
  }

  /****************************************************************************/
  /*!
  \fn Point::operator--()

  \brief
    Decrements the value.

  \return
    Returns a reference to the decremented Point.
  */
  /****************************************************************************/
  Point& Point::operator--()
  {
    --x;
    --y;
    
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn Point::operator--(int)

  \brief
    Decrements the value.

  \return
    Returns the value of the Point before decrementing.
  */
  /****************************************************************************/
  Point Point::operator--(int)
  {
    Point temp = *this;
    --x;
    --y;
    return temp;
  }

  /****************************************************************************/
  /*!
  \fn Point::operator-() const

  \brief
    Negates the value of the input.

  \return
    Returns the negated value.
  */
  /****************************************************************************/
  Point Point::operator-() const
  {
    return Point(-x, -y);
  }

  /****************************************************************************/
  /*!
  \fn Point::operator+(const Point RHS) const

  \brief
    Adds two Points together.

  \param RHS
    The second point to be added.

  \return
    Returns the added point.
  */
  /****************************************************************************/
  Point Point::operator+(const Point RHS) const
  {
    return Point(x+RHS.x, y+RHS.y);
  }

  /****************************************************************************/
  /*!
  \fn Point::operator+(const double length) const

  \brief
    Adds a Point and a double together.

  \param length
    The double to be added to the point.

  \return
    Returns an added point.
  */
  /****************************************************************************/
  Point Point::operator+(const double length) const
  {
    return Point(x+length, y+length);
  }

  /****************************************************************************/
  /*!
  \fn Point::operator*(const double scale) const

  \brief
    Multiplies a Point by some numeric factor.

  \param scale
    The numeric factor to be multiplied to the point.

  \return
    Returns a multiplied point.
  */
  /****************************************************************************/
  Point Point::operator*(const double scale) const
  {
    return Point(x*scale, y*scale);
  }

  /****************************************************************************/
  /*!
  \fn Point::operator=(const Point &p1)

  \brief
    Assigns a Point to another Point.

  \param p1
    The Point that is being assigned.

  \return
    Returns an assigned point.
  */
  /****************************************************************************/
  Point Point::operator=(const Point &p1)
  {
    x = p1.x;
    y = p1.y;
    
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn operator<< (std::ostream& os, const Point& p1)

  \brief
    Outputs a Point in the form of a string: (x, y), where x and y are the
    coordinates.

  \param os
    The reference to the output stream.

  \param p1
    The reference to the point to be printed out.

  \return
    Returns a reference to the output stream.
  */
  /****************************************************************************/
  std::ostream& operator<< (std::ostream& os, const Point& p1)
  {
    return os << "(" << p1.x << ", " << p1.y << ")";
  }

  /****************************************************************************/
  /*!
  \fn operator>> (std::istream& is, Point& p1)

  \brief
    Inputs a Point. Allows two numbers (separated by whitespace) to be entered.

  \param is
    The reference to the input stream.

  \param p1
    The reference to the point to be printed out.

  \return
    Returns a reference to the input stream.
  */
  /****************************************************************************/
  std::istream& operator>> (std::istream& is, Point& p1)
  {
    return is >> p1.x >> std::skipws >> p1.y;
  }

  /****************************************************************************/
  /*!
  \fn operator+(const double length, const Point p1)

  \brief
    Adds a Point and a double together.

  \param length
    The double to be added to the point.

  \param p1
    The Point that will be added.

  \return
    Returns the added point.
  */
  /****************************************************************************/
  Point operator+(const double length, const Point p1)
  {
    Point result = p1 + length;
    
    return result;
  }

  /****************************************************************************/
  /*!
  \fn operator*(const double scale, const Point p1)

  \brief
    Multiplies a Point by some numeric factor.

  \param scale
    The numeric factor to be multiplied to the point.

  \param p1
    The Point that will be multiplied.

  \return
    Returns a multiplied point.
  */
  /****************************************************************************/
  Point operator*(const double scale, const Point p1)
  {
    Point result = p1 * scale;
    
    return result;
  }
} // namespace CS170



