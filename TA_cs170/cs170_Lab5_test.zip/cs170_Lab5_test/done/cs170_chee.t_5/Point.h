/******************************************************************************/
/*!
\file Point.h
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: CS170
\par Lab 05
\date 24/6/2019
\brief
This file contains the implementation of the following functions for
Lab 5.

Hours spent on this assignment: 5
Specific portions that gave you the most trouble: Friend functions
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
        Point();
        Point(double _x, double _y);

        // Overloaded operators (14 member functions)
    		Point operator % (const double &rhs);
    		double operator - (const Point &rhs);
    		Point operator ^ (const Point &rhs);
    		Point& operator += (const Point &rhs);
        Point& operator += (const double rhs);
    		Point operator - (const double rhs);
    		Point& operator ++ ();
    		Point operator ++ (int);
    		Point& operator -- ();
    		Point operator -- (int);
    		Point operator - ();
        Point operator + (const Point &rhs);
        Point operator + (const double &rhs);
        Point operator * (const double rhs);

        // Overloaded operators (2 friend functions)
      friend std::ostream& operator << (std::ostream& out, const Point& rhs);
      friend std::istream& operator >> (std::istream& input, Point& rhs);

    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };

    // Overloaded operators (2 non-member, non-friend functions)
    Point operator + (const double rhs, const Point &point);
    Point operator * (const double rhs, const Point &point);

} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
