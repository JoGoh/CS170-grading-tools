/******************************************************************************/
/*!
\file Point.cpp
\author Damian Chee Tai Ming
\par email: chee.t\@digipen.edu
\par DigiPen login: chee.t
\par Course: CS170
\par Lab 05
\date 24/6/2019
\brief
This file contains the implementation of the following functions for
Lab 5.

Functions include:
Point()
Point(double _x, double _y)

// Overloaded operators (14 member functions)
Point operator % (const double &rhs)
double operator - (const Point &rhs)
Point operator ^ (const Point &rhs)
Point& operator += (const Point &rhs)
Point& operator += (const double rhs)
Point operator - (const double rhs)
Point& operator ++ ()
Point operator ++ (int)
Point& operator -- ()
Point operator -- (int)
Point operator - ()
Point operator + (const Point &rhs)
Point operator + (const double &rhs)
Point operator * (const double rhs)

// Overloaded operators (2 friend functions)
friend std::ostream& operator << (std::ostream& out, const Point& rhs)
friend std::istream& operator >> (std::istream& input, Point& rhs)

// Helper functions
double DegreesToRadians(double degrees) const
double RadiansToDegrees(double radians) const

// Overloaded operators (2 non-member, non-friend functions)
Point operator + (const double rhs, const Point &point)
Point operator * (const double rhs, const Point &point)

Hours spent on this assignment: 5
Specific portions that gave you the most trouble: Friend functions
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

  const double PI = 3.1415926535897;
  const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions
/******************************************************************************/
/*!
\brief Converts Degrees to Radians

\fn double Point::DegreesToRadians(double degrees) const

\param degrees
*/
/******************************************************************************/
  double Point::DegreesToRadians(double degrees) const
  {
    return (degrees * PI / 180.0);
  }

/******************************************************************************/
/*!
\brief Converts Radians to Degrees

\fn double Point::RadiansToDegrees(double radians) const

\param radians
*/
/******************************************************************************/
  double Point::RadiansToDegrees(double radians) const
  {
    return (radians * 180.0 / PI);
  }


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators)

/******************************************************************************/
/*!
\brief Default Constructors

\fn Point::Point()
*/
/******************************************************************************/
  Point::Point()
  {
    x = 0;
    y = 0;
  }

/******************************************************************************/
/*!
\brief Default Constructors

\fn Point::Point(double _x, double _y)

\param _x, _y
*/
/******************************************************************************/
  Point::Point(double _x, double _y)
  {
		x = _x;
		y = _y;
  }

/******************************************************************************/
/*!
\brief Member function that rotates a Point about the origin by the specified
number of degrees. Returns a new Point.

\fn Point Point::operator % (const double &rhs)

\param rhs
*/
/******************************************************************************/
  Point Point::operator % (const double &rhs)
  {
    double radian = DegreesToRadians(rhs);
    Point newPoint( (x * cos(radian)) - (y * sin(radian)),
    (x * sin(radian)) + (y * cos(radian)) );

    if (newPoint.x > -EPSILON && newPoint.x < EPSILON)
      newPoint.x = 0.0;
    if (newPoint.y > -EPSILON && newPoint.y < EPSILON)
      newPoint.y = 0.0;

    return newPoint;
  }

/******************************************************************************/
/*!
\brief Member function that calculates the difference between two Points and
returns the distance (type double).

\fn double Point::operator - (const Point &rhs)

\param rhs
*/
/******************************************************************************/
  double Point::operator - (const Point &rhs)
  {
    double _x = x - rhs.x;
    double _y = y - rhs.y;

    return sqrt(_x * _x + _y * _y);
  }

/******************************************************************************/
/*!
\brief Member function that calculates the midpoint between two Points. Returns
a new Point.

\fn Point Point::operator ^ (const Point &rhs)

\param rhs
*/
/******************************************************************************/
  Point Point::operator ^ (const Point &rhs)
  {
    Point midPoint( (x + rhs.x) / 2.0, (y + rhs.y) / 2.0 );
    return midPoint;
  }

/******************************************************************************/
/*!
\brief  Add two Points returns a reference to the lefthand operand which has
been modified. These are both member functions

\fn Point& Point::operator += (const Point &rhs)

\param rhs
*/
/******************************************************************************/
  Point& Point::operator += (const Point &rhs)
  {
    x += rhs.x;
    y += rhs.y;
    return *this;
  }

/******************************************************************************/
/*!
\brief Add a Point and a double and returns a reference to the lefthand operand
which has been modified. These are both member functions.

\fn Point& Point::operator += (const double rhs)

\param rhs
*/
/******************************************************************************/
  Point& Point::operator += (const double rhs)
  {
    x += rhs;
    y += rhs;
    return *this;
  }

/******************************************************************************/
/*!
\brief Member function that subtracts a double from a Point and returns a new
Point.

\fn Point Point::operator - (const double rhs)

\param rhs
*/
/******************************************************************************/
  Point Point::operator - (const double rhs)
  {
    Point newPoint(x - rhs, y - rhs);
    return newPoint;
  }

/******************************************************************************/
/*!
\brief Preincrement. Add one to the x/y values of the object. Returns a
reference to the incremented Point.

\fn Point& Point::operator ++ ()
*/
/******************************************************************************/
  Point& Point::operator ++ ()
  {
    ++x, ++y;
    return *this;
  }

/******************************************************************************/
/*!
\brief Postincrement. Add one to the x/y values of the object. Returns a new
Point with the value of the "before incremented point".

\fn Point Point::operator ++ (int)
*/
/******************************************************************************/
  Point Point::operator ++ (int)
  {
    Point newPoint = *this;
    ++x, ++y;
    return newPoint;
  }

/******************************************************************************/
/*!
\brief Predecrement. Subtract one to the x/y values of the object. Returns a
reference to the subtracted point.

\fn Point& Point::operator -- ()
*/
/******************************************************************************/
  Point& Point::operator -- ()
  {
    --x, --y;
    return *this;
  }

/******************************************************************************/
/*!
\brief Postdecrement. Subtract one to the x/y values of the object. Returns
a new Point with the value of the "before decremented point".

\fn Point Point::operator -- (int)
*/
/******************************************************************************/
  Point Point::operator -- (int)
  {
    Point newPoint = *this;
    --x, --y;
    return newPoint;
  }

/******************************************************************************/
/*!
\brief Member function that returns a new Point with the x/y values of input
Point negated.

\fn Point Point::operator - ()
*/
/******************************************************************************/
  Point Point::operator - ()
  {
    Point newPoint = *this;
    newPoint.x = -x;
    newPoint.y = -y;
    return newPoint;
  }

/******************************************************************************/
/*!
\brief Adds two Points and returns a new Point.

\fn Point Point::operator + (const Point &rhs)

\param rhs
*/
/******************************************************************************/
  Point Point::operator + (const Point &rhs)
  {
    Point newPoint = *this;
    newPoint += rhs;
    return newPoint;
  }

/******************************************************************************/
/*!
\brief Adds a Point and a double and returns a new Point.

\fn Point Point::operator + (const double &rhs)

\param rhs
*/
/******************************************************************************/
  Point Point::operator + (const double &rhs)
  {
    Point newPoint = *this;
    newPoint += rhs;
    return newPoint;
  }

/******************************************************************************/
/*!
\brief Multiplies a Point by some numeric factor of type double and returns a
new Point.

\fn Point Point::operator * (const double rhs)

\param rhs
*/
/******************************************************************************/
  Point Point::operator * (const double rhs)
  {
    Point newPoint = *this;
    newPoint.x *= rhs;
    newPoint.y *= rhs;
    return newPoint;
  }

/******************************************************************************/
/*!
\brief Outputs a Point in the form of a string: (x, y), where x and y are the
coordinates, e.g. (4, 7).

\fn std::ostream& operator << (std::ostream& out, const Point& rhs)

\param out, rhs
*/
/******************************************************************************/
  std::ostream& operator << (std::ostream& out, const Point& rhs)
  {
    out << "(" << rhs.x << ", " << rhs.y << ")";
    return out;
  }

/******************************************************************************/
/*!
\brief Inputs a Point. Allows two numbers (separated by whitespace) to be
entered, e.g. 4 7.

\fn std::istream& operator >> (std::istream& input, Point& rhs)

\param input, rhs
*/
/******************************************************************************/
  std::istream& operator >> (std::istream& input, Point& rhs)
  {
    input >> rhs.x >> rhs.y;
    return input;
  }

/******************************************************************************/
/*!
\brief Adds a Point and a double and returns a new Point.

\fn Point operator + (const double rhs, const Point &point)

\param rhs, point
*/
/******************************************************************************/
  Point operator + (const double rhs, const Point &point)
  {
    Point newPoint = point;
    return (newPoint + rhs);
  }

/******************************************************************************/
/*!
\brief Multiplies a Point by some numeric factor of type double and returns a
new Point.

\fn Point operator * (const double rhs, const Point &point)

\param rhs, point
*/
/******************************************************************************/
  Point operator * (const double rhs, const Point &point)
  {
    Point newPoint = point;
    return (newPoint * rhs);
  }


} // namespace CS170
