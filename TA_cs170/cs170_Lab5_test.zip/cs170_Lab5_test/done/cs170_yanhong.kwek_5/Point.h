/******************************************************************************/
/*!
\file Point.h
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 05
\date 24/06/2019
\brief
Header file for a Point class
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
        Point ();
        Point(double x, double y);

        // Overloaded operators (14 member functions)
        Point operator% (double angle) const;
        double operator- (const Point &rhs);
        Point operator^ (Point const &rhs) const;
        Point & operator+= (double value);
        Point & operator+= (const Point &rhs);
        Point operator- (double value) const;
        Point & operator++ ();
        Point operator++ (const int);
        Point & operator-- ();
        Point operator--(const int);
        Point operator- () const;
        Point operator+ (double value) const;
        Point operator+ (const Point &rhs) const;
        Point operator* (double value) const;
        
        // Overloaded operators (2 friend functions)
        friend std::ostream& operator << (std::ostream &out, const Point &rhs);
        friend std::istream& operator >>(std::istream &in,Point &rhs);
        
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
        Point operator+ ( double value, Point const &rhs);
        Point operator* ( double value, Point const &rhs);
        
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
