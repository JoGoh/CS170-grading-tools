/******************************************************************************/
/*!
\file Point.cpp
\author Kwek Yan Hong
\par email: yanhong.kwek\@digipen.edu
\par DigiPen login: yanhong.kwek
\par Course: CS170
\par Lab 05
\date 24/06/2019
\brief
Functions for a Point class
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
/******************************************************************************/
/*!
    \brief
    Constructor for list
*/
/******************************************************************************/
Point::Point (): x(0), y(0) {}

/******************************************************************************/
/*!
    \brief
    Parameter constructor
*/
/******************************************************************************/
Point::Point(double x, double y) : x(x), y(y) {} 

/******************************************************************************/
/*!
    \brief
    Rotates a point about the origin by the specified number of degrees
    
    \param angle
    Angle given in degrees
    
    \return
    The point after rotation
*/
/******************************************************************************/
Point Point:: operator% (double angle) const
{
    Point rotate;
    double Rad=DegreesToRadians(angle);
    rotate.x=cos(Rad)*x - sin(Rad)*y;
    rotate.y=sin(Rad)*x + cos(Rad)*y;
    
    // If value is between -EPSILON and +EPSILON, make it 0.0
    if (rotate.x > -EPSILON && rotate.x < EPSILON)
    {
        rotate.x = 0.0;
    }
    if (rotate.y > -EPSILON && rotate.y < EPSILON)
    {
        rotate.y = 0.0;
    }
    return rotate;
}

/******************************************************************************/
/*!
    \brief
    Calculates the distance between two points
    
    \param rhs
    points to a coordinate on the right hand side
    
    \return
    The distance between both coordinates
*/
/******************************************************************************/
double Point :: operator- (const Point &rhs)
{
    Point temp;
    //difference in value
    temp.x = x-rhs.x;
    temp.y = y-rhs.y;
    double distance = sqrt(temp.x * temp.x + temp.y * temp.y);
    return distance;
}

/******************************************************************************/
/*!
    \brief
    Calculates the midpoint between two points
    
    \param rhs
    points to a coordinate on the right hand side
    
    \return 
    The midpoint between two points
*/
/******************************************************************************/
Point Point:: operator^ (Point const &rhs) const
{
    Point temp;
    //get midpoint value
    temp.x = (x + rhs.x)/2.0;
    temp.y = (y + rhs.y)/2.0;
    return temp; 
} 

/******************************************************************************/
/*!
    \brief
    Adds a point and a double
    
    \param value
    Value to be added to the coordinate
    
    \return
    Updated value
*/
/******************************************************************************/
Point & Point:: operator+= (double value)
{
    x += value;
    y += value;
    return *this;
}

/******************************************************************************/
/*!
    \brief
    Adds two points
    
    \param rhs
    points to a coordinate on the right hand side
    
    \return
    Updated value
*/
/******************************************************************************/
Point & Point:: operator+= (const Point &rhs)
{
    x += rhs.x;
    y += rhs.y;
    return *this;
}

/******************************************************************************/
/*!
    \brief
    Subtracts a double from a point
    
    \param value
    value to be subtracted from the coordinate
    
    \return
    The subtracted point
*/
/******************************************************************************/
Point Point:: operator- (double value) const
{
    return Point(x-value, y-value);
}

/******************************************************************************/
/*!
    \brief
    Pre-increment. Adds one to the coordinate
    
    \return
    The value the has been incremented
*/
/******************************************************************************/
Point & Point :: operator++ ()
{
    x++;
    y++;
    return *this;
}

/******************************************************************************/
/*!
    \brief
    Post-increment. Adds one to the coordinate after executing expression
    
    \return
    The original value
*/
/******************************************************************************/
Point Point :: operator++ (const int)
{
    Point temp(x,y);
    x++;
    y++;
    return temp;
}

/******************************************************************************/
/*!
    \brief
    Pre-decrement. Adds one to the coordinate
    
    \return
    The value the has been decremented
*/
/******************************************************************************/
Point & Point:: operator-- () 
{
    x--;
    y--;
    return *this;
}

/******************************************************************************/
/*!
    \brief
    Post-decrement. Subtracts one from the coordinate after executing expression
    
    \return
    The original value
*/
/******************************************************************************/
Point Point:: operator-- (const int)
{
    Point temp(x,y);
    x--;
    y--;
    return temp;
}

/******************************************************************************/
/*!
    \brief
    Negates the value
    
    \return
    The negated value
*/
/******************************************************************************/
Point Point:: operator- () const
{
    Point negative(-x,-y);
    return negative;
}

/******************************************************************************/
/*!
  \brief
    Adds a point to a double value
    
    \param value
    value to be added to the coordinate x & y
    
    \return
    Return the point with the added value
*/
/******************************************************************************/
Point Point:: operator+ (double value) const
{
    return Point(x+value, y+value);
}

/******************************************************************************/
/*!
    \brief
    Adds a point to a double value
    
    \param rhs
    Point to the coordinate on the right hand side
    
    \return
    The point with the value added
*/
/******************************************************************************/
Point Point:: operator+ (const Point &rhs) const
{
    return Point(x+rhs.x, y+rhs.y);
}

/******************************************************************************/
/*!
    \brief
    Multiplies a point to a double value
    
    \param value
    alue to be multiplied to the coordinate
    
    \return
    The point with the multiplied value
*/
/******************************************************************************/
Point Point:: operator* (double value) const
{
    return Point(x*value, y*value);
}

///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
/******************************************************************************/
/*!
    \brief
    Outputs a point in a form of string for coordinates x & y
    
    \param out
    Outputs the desired string
    
    \param rhs
    Point to the coordinate on the right hand side
    
    \return
    Output in the form of a string
*/
/******************************************************************************/
std::ostream & operator<<(std::ostream &out, const Point &rhs) 
{
   out << "(" << rhs.x << ", " << rhs.y << ")";
   return out;
}

/******************************************************************************/
/*!
    \brief
    Inputs a point, allowing two numbers
    
    \param in
    Inputs the desired string
    
    \param rhs
    Point to the coordinate on the right hand side
    
    \return
    Input in the form of a string
*/
/******************************************************************************/
std::istream & operator>>(std::istream &in, Point &rhs)
{
   in >> rhs.x >> rhs.y;
   return in;
}

///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
/******************************************************************************/
/*!
    \brief
    Adds a point to a double value
    
    \param value
    Value to be added to the coordinate
    
    \param rhs
    Point to the coordinate on the right hand side
    
    \return
    The point with the added value
*/
/******************************************************************************/
Point operator+ ( double value, Point const &rhs)
{
    return rhs + value;
}

/******************************************************************************/
/*!
    \brief
    Multiplys a double value to a point
    
    \param value
    the point after it rotatesalue to be multiplied to the coordinate
    
    \param rhs
    Point to the coordinate on the right hand side
    
    \return
    The point with the multiplied value
*/
/******************************************************************************/
Point operator* ( double value, Point const &rhs)
{
    return rhs * value;
}

} // namespace CS170



