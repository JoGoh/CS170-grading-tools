/******************************************************************************/
/*! 
\file   point.h
\author Chua Lip Ming
\par    email: l.chua\@digipen.edu 
\par    DigiPen login: l.chua
\par    Course: CS170A 
\par    Lab 05
\date   16/06/2019 
\brief     This is the .h file that contains the 
operators required for driver.cpp
*/ 
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
/******************************************************************************/
/*!

  \fn Point()

  \brief              Default constructor

*/
/******************************************************************************/
        Point();
/******************************************************************************/
/*!

  \fn Point(int _x, int _y)

  \brief              Overloaded constructor

  \param _x           parameter set into x

  \param _y           parameter set into y
*/
/******************************************************************************/
        Point(int _x, int _y);
/******************************************************************************/
/*!

  \fn Point(const Point& p)

  \brief              Overloaded constructor

  \param p            Point to set to this point.
*/
/******************************************************************************/
        Point(const Point& p);
        
/******************************************************************************/
/*!

  \fn Get_X()

  \return x
*/
/******************************************************************************/
        double Get_X() const;
/******************************************************************************/
/*!

  \fn Get_Y()

  \return y
*/
/******************************************************************************/
        double Get_Y() const;
/******************************************************************************/
/*!

  \fn operator%(const double& rhs) const

  \brief              Member function that rotates a Point about the 
                      origin by the specified number of degrees. 
  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator%(const double& rhs) const;
/******************************************************************************/
/*!

  \fn operator-(const Point& rhs) const

  \brief              Member function that calculates the difference between 
  two Points and returns the distance (type double). 
  
  \param rhs          Right hand side of the point

  \return distance     Returns the distance
*/
/******************************************************************************/
        double operator-(const Point& rhs) const;
/******************************************************************************/
/*!

  \fn operator^(const Point& rhs) const

  \brief              Member function that calculates the midpoint between two 
  Points. Returns a new Point.

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator^(const Point & rhs) const;
/******************************************************************************/
/*!

  \fn operator+=(const Point& rhs)

  \brief              Add two Points or a Point and a double and returns a 
  reference to the lefthand operand which has been modified. 

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator+=(const Point& rhs);
/******************************************************************************/
/*!

  \fn operator+=(const double& rhs)

  \brief              Add two Points or a Point and a double and returns a 
  reference to the lefthand operand which has been modified. 

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator+=(const double& rhs);
/******************************************************************************/
/*!

  \fn operator-(const double & rhs) const

  \brief              Member function that subtracts a double from a Point and 
  returns a new Point. 

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator-(const double & rhs) const;
/******************************************************************************/
/*!

  \fn operator++()

  \brief              Add one to the x/y values of the object.

  

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point& operator++();    
/******************************************************************************/
/*!

  \fn operator++(int)

  \brief              Add one to the x/y values of the object.

  \return newPoint     Returns a new Point
*/
/******************************************************************************/        
        Point operator++(int);
/******************************************************************************/
/*!

  \fn operator--()

  \brief              Subtracts one from the x/y values of the object

  

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point& operator--();   
/******************************************************************************/
/*!

  \fn operator--(int)

  \brief              Subtracts one from the x/y values of the object

  \return newPoint     Returns a new Point
*/
/******************************************************************************/        
        Point operator--(int);
/******************************************************************************/
/*!

  \fn operator-() const  

  \brief              Member function that returns a new Point with 
  the x/y values of input Point negated.

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator-() const;
/******************************************************************************/
/*!

  \fn operator+(const Point& rhs) const

  \brief              Adds two Points or a Point and a double and returns a 
  new Point

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator+(const Point & rhs) const;
/******************************************************************************/
/*!

  \fn operator+(const double& rhs) const

  \brief              Adds two Points or a Point and a double and returns a 
  new Point

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator+(const double & rhs) const;
/******************************************************************************/
/*!

  \fn operator*(const double& rhs) const

  \brief              Multiplies a Point by some numeric factor of type double 
  and returns a new Point.

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
        Point operator*(const double& rhs) const;
/******************************************************************************/
/*!

  \fn std::ostream &operator<< (std::ostream &os, const Point &point)

  \brief              Outputs a Point in the form of a string: (x, y)

  \param os           cout stream
  
  \param point        point to cout

  \return os           return cout stream
*/
/******************************************************************************/
        friend std::ostream &operator<< (std::ostream &os, const Point &point);
/******************************************************************************/
/*!

  \fn std::istream &operator>> (std::istream &is, Point &point)

  \brief              Outputs a Point in the form of a string: (x, y)

  \param is           cin stream
  
  \param point        point to cin

  \return is           return cin stream
*/
/******************************************************************************/
        friend std::istream &operator>> (std::istream &is, Point &point);
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
/******************************************************************************/
/*!

  \fn operator+(const double &lhs, const Point &rhs)

  \brief              Adds two Points or a Point and a double and returns a 
  new Point

  \param lhs          Left hand side of the point
  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
    Point operator+ (const double &lhs, const Point &rhs);
/******************************************************************************/
/*!

  \fn operator*(const double &lhs, const Point &rhs)

  \brief              Multiplies a Point by some numeric factor of type double 
  and returns a new Point.

  \param lhs          Left hand side of the point
  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
    Point operator* (const double &lhs, const Point &rhs);
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
