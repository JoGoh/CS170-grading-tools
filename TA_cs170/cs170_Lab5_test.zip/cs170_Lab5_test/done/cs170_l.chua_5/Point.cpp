/******************************************************************************/
/*! 
\file   point.cpp
\author Chua Lip Ming
\par    email: l.chua\@digipen.edu 
\par    DigiPen login: l.chua
\par    Course: CS170A 
\par    Lab 05
\date   16/06/2019 
\brief     This is the .cpp file that contains the 
operators required for driver.cpp
*/ 
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}

/******************************************************************************/
/*!

  \fn Point::Get_X()

  \return x
*/
/******************************************************************************/
double Point::Get_X() const
{
  return x;
}

/******************************************************************************/
/*!

  \fn Point::Get_Y()

  \return y
*/
/******************************************************************************/
double Point::Get_Y() const
{
  return y;
}
/******************************************************************************/
/*!

  \fn Point::Point()

  \brief              Default constructor

*/
/******************************************************************************/

Point::Point()
{
  x = 0;
  y = 0;
}
/******************************************************************************/
/*!

  \fn Point::Point(int _x, int _y)

  \brief              Overloaded constructor

  \param _x           parameter set into x

  \param _y           parameter set into y
*/
/******************************************************************************/ 
Point::Point(int _x, int _y)
{
  x = _x;
  y = _y;
}
/******************************************************************************/
/*!

  \fn Point::Point(const Point& p)

  \brief              Overloaded constructor

  \param p            Point to set to this point.
*/
/******************************************************************************/
Point::Point(const Point& p)
{
  x = p.x;
  y = p.y;
}
/******************************************************************************/
/*!

  \fn Point::operator%(const double& rhs) const

  \brief              Member function that rotates a Point about the 
                      origin by the specified number of degrees. 
  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator%(const double& rhs) const
{
  Point newPoint;
    
  // Convert the input from degrees to radians
  double rhs_rad = rhs * ((atan(1)*4) / 180.0);
  
  newPoint.x = (cos(rhs_rad) * x + (-sin(rhs_rad)) * y);
  newPoint.y = (sin(rhs_rad) * x + (cos(rhs_rad)) * y);
  
  // Check if the X and Y coordinates are very small floating point numbers
  if (newPoint.x > -0.0001 && newPoint.x < 0.0001)
    newPoint.x = 0;
  
  if (newPoint.y > -0.0001 && newPoint.y < 0.0001)
    newPoint.y = 0;
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator-(const Point& rhs) const

  \brief              Member function that calculates the difference between 
  two Points and returns the distance (type double). 
  
  \param rhs          Right hand side of the point

  \return distance     Returns the distance
*/
/******************************************************************************/
 double Point::operator-(const Point& rhs) const
{
  double distance = sqrt((x - rhs.x) * (x - rhs.x) +
                           (y - rhs.y) * (y - rhs.y));
    
  return distance;
}
/******************************************************************************/
/*!

  \fn Point::operator^(const Point& rhs) const

  \brief              Member function that calculates the midpoint between two 
  Points. Returns a new Point.

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator^(const Point & rhs) const
{
  Point newPoint;
  
  newPoint.x = (x + rhs.x)/2;
  newPoint.y = (y + rhs.y)/2;
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator+=(const Point& rhs)

  \brief              Add two Points or a Point and a double and returns a 
  reference to the lefthand operand which has been modified. 

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator+=(const Point& rhs)
{
  x+=rhs.x;
  y+=rhs.y;
  
  return *this;
}
/******************************************************************************/
/*!

  \fn Point::operator+=(const double& rhs)

  \brief              Add two Points or a Point and a double and returns a 
  reference to the lefthand operand which has been modified. 

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator+=(const double& rhs)
{
  x+=rhs;
  y+=rhs;
  
  return *this;
}
/******************************************************************************/
/*!

  \fn Point::operator-(const double & rhs) const

  \brief              Member function that subtracts a double from a Point and 
  returns a new Point. 

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator-(const double & rhs) const
{
  Point newPoint;
  
  newPoint.x = x-rhs;
  newPoint.y = y-rhs;
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator++()

  \brief              Add one to the x/y values of the object.

  

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point& Point::operator++()
{
  
  x+=1;
  y+=1;
  
  return *this;
}
/******************************************************************************/
/*!

  \fn Point::operator++(int)

  \brief              Add one to the x/y values of the object.

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator++(int)
{
  Point newPoint (*this);
  
  ++x;
  ++y;
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator--()

  \brief              Subtracts one from the x/y values of the object

  

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point& Point::operator--()
{
  x-=1;
  y-=1;
  
  return *this;
}
/******************************************************************************/
/*!

  \fn Point::operator--(int)

  \brief              Subtracts one from the x/y values of the object

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator--(int)
{
  Point newPoint (*this);
    
    --x;
    --y;
    
    return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator-() const  

  \brief              Member function that returns a new Point with 
  the x/y values of input Point negated.

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator-() const
{
  Point newPoint;
    
  newPoint.x = -x;
  newPoint.y = -y;
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator+(const Point& rhs) const

  \brief              Adds two Points or a Point and a double and returns a 
  new Point

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator+(const Point & rhs) const
{
  Point newPoint;
  
  newPoint.x = (x+rhs.x);
  newPoint.y = (y+rhs.y);
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator+(const double& rhs) const

  \brief              Adds two Points or a Point and a double and returns a 
  new Point

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator+(const double & rhs) const
{
  Point newPoint;
  
  newPoint.x = (x+rhs);
  newPoint.y = (y+rhs);
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn Point::operator*(const double& rhs) const

  \brief              Multiplies a Point by some numeric factor of type double 
  and returns a new Point.

  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point Point::operator*(const double& rhs) const
{
  Point newPoint;
  
  newPoint.x = (x*rhs);
  newPoint.y = (y*rhs);
  
  return newPoint;
}
/******************************************************************************/
/*!

  \fn std::ostream &operator<< (std::ostream &os, const Point &point)

  \brief              Outputs a Point in the form of a string: (x, y)

  \param os           cout stream
  
  \param point        point to cout

  \return os           return cout stream
*/
/******************************************************************************/
std::ostream& operator<< (std::ostream &os, const Point &point)
{
  os << "(" << point.x << ", " << point.y << ")";
  
  return os;
}
/******************************************************************************/
/*!

  \fn std::istream &operator>> (std::istream &is, Point &point)

  \brief              Outputs a Point in the form of a string: (x, y)

  \param is           cin stream
  
  \param point        point to cin

  \return is           return cin stream
*/
/******************************************************************************/
std::istream& operator>> (std::istream &is, Point &point)
{
  is >> point.x;
  is >> point.y;
  
  return is;
}
/******************************************************************************/
/*!

  \fn operator+(const double &lhs, const Point &rhs)

  \brief              Adds two Points or a Point and a double and returns a 
  new Point

  \param lhs          Left hand side of the point
  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point operator+ (const double &lhs, const Point &rhs)
{
  Point newPoint(lhs + rhs.Get_X(), lhs + rhs.Get_Y());
    
  return newPoint;
}
/******************************************************************************/
/*!

  \fn operator*(const double &lhs, const Point &rhs)

  \brief              Multiplies a Point by some numeric factor of type double 
  and returns a new Point.

  \param lhs          Left hand side of the point
  
  \param rhs          Right hand side of the point

  \return newPoint     Returns a new Point
*/
/******************************************************************************/
Point operator* (const double &lhs, const Point &rhs)
{
  Point newPoint(lhs * rhs.Get_X(), lhs * rhs.Get_Y());
  
  return newPoint;
} 

} // namespace CS170



