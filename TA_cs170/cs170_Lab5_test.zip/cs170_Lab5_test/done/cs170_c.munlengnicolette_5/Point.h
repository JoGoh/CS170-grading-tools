/*************************************************************************/
/*!
\file Point.h
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: CS170
\par Lab #5
\date 11/06/2019
Brief Description:
Declarations of the Point class methods for Point.cpp.

Hours spent on this assignment: 6 hrs
Specific portions that gave you the most trouble: operator%
*/
/*************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
        /* Conversion constructor */
        Point(const double _x = 0, const double _y = 0);
        /* Copy constructor */
        Point(const Point &rhs);
        // Overloaded operators (14 member functions)
        /* Overload operator = */
        Point &operator=(const Point &rhs);
        /* Overloads Operator %. Rotates a point about the origin
           by the angle specified in degrees. */
        Point operator%(const double angle);
        
        /* Overloads Operator -. Calculates the
           difference between two points. */
        double operator-(const Point &rhs);
        
        /* Overloads Operator ^. Calculates the midpoint
           between two points. */
        Point operator^(const Point &rhs);
        
        /* Overloads Operator +=. Adds two points. */
        Point &operator+=(const Point &rhs);
        
        /* Overloads Operator +=. Adds a point and a double. */
        Point &operator+=(const double _double);
        
        /* Overloads Operator -. Subtracts a double from a point.  */
        Point operator-(const double _double);
        
        /* Overloads Pre-increment Operator ++. Adds one to (x, y)
           coordinates of a point and returns a reference to the incremented point. */
        Point &operator++();
        
        /* Overloads Post-increment Operator ++. Adds one to (x, y)
           coordinates of a point and returns the old value before increment. */
        Point operator++(int);

        /* Overloads Pre-decrement Operator --. Subtracts one to (x, y)
           coordinates of a point and returns a reference to the decrement point. */
        Point &operator--();
        
        /* Overloads Post-decrement Operator --. Adds one to (x, y)
           coordinates of a point and returns the old value before decrement. */
        Point operator--(int);
        
        /* Overloads Operator +. Adds two points. */
        Point operator+(const Point &rhs);
        
        /* Overloads Operator +. Adds a point and a double. */
        Point operator+(const double _double);
        
        /* Overloads Operator *. Multiplies a point by
           some numeric factor of type double. */
        Point operator*(double _double);
        
        /* Overloads Unary Operator -. Negates both coordinates of a point. */
        Point operator-();
        // Overloaded operators (2 friend functions)
        /* Overloads Operator <<. Inserts a string representing a point
           in a form: (x, y) into a data stream, generally std::cout. */
        friend std::ostream &operator<<(std::ostream &os, const Point &rhs);
        
        /* Overloads Operator >>. Extracts a point from a data stream,
           generally std::cin, as two floating point numbers separated
           by a whitespace. */
        friend std::istream &operator>>(std::istream &in, Point &rhs);
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    /* Overloads Operator +. Adds a double and a point. */
    Point operator+(const double _double, Point &rhs);
    
    /* Overloads Operator *. Multiplies a double and a point. */
    Point operator*(const double _double, Point &rhs);
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
