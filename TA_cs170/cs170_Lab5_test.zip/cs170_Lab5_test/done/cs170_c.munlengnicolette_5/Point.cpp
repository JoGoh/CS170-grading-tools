/*************************************************************************/
/*!
\file Point.cpp
\author Chan Mun Leng Nicolette
\par email: c.munlengnicolette\@digipen.edu
\par DigiPen login: c.munlengnicolette
\par Course: CS170
\par Lab #5
\date 11/06/2019
Brief Description:
Implementation of the Point class methods.

Hours spent on this assignment: 6 hrs
Specific portions that gave you the most trouble: operator%
*/
/*************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{
  const double PI = 3.1415926535897;            // Defining PI
  const double EPSILON = 0.00001;               // Defining Epsilon

  /////////////////////////////////////////////////////////////////////////
  // private member functions 
  /***********************************************************************/
  /*!
    \fn Point::DegreesToRadians(double degrees) const
    \brief
      Converting degree angle to radian angle.
    \param degrees
      The degree to be converted.
  */
  /***********************************************************************/
  double Point::DegreesToRadians(double degrees) const
  {
    return (degrees * PI / 180.0);
  }
  /***********************************************************************/
  /*!
    \fn Point::RadiansToDegrees(double radians) const
    \brief
      Converting radian angle to degree angle.
    \param radians
      The radian to be converted.
  */
  /***********************************************************************/
  double Point::RadiansToDegrees(double radians) const
  {
    return (radians * 180.0 / PI);
  }
///////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
  
  /***********************************************************************/
  /*!
    \fn Point::Point(const double _x, const double _y)
    \brief
      Conversion constructor for Point, initialises variables x and y.
    
    \param _x
      The value to initialise x with.
      
    \param _y
      The value to initialise y with.
  */
  /***********************************************************************/
  Point::Point(const double _x, const double _y):
    x { _x },                               // Initalise x to be _x
    y { _y }                                // Initalise y to be _y
  { }
  
  /***********************************************************************/
  /*!
    \fn Point::Point(const Point &rhs)
    \brief
      Copy constructor for Point, initialises variables x and y.

    \param rhs
      The Point that is to be copied.
  */
  /***********************************************************************/
  Point::Point(const Point &rhs):
    x { rhs.x },                               // Initalise x to be _x
    y { rhs.y }                                // Initalise y to be _y
  { }
  
  /***********************************************************************/
  /*!
    \fn Point::operator=(const Point &rhs)
    \brief
      Overloads Operator =, assigns Point's x and y into an
      existing Point's x and y.
     
    \param rhs
      The Point that is to be copied.
  */
  /***********************************************************************/
   Point &Point::operator=(const Point &rhs)
  {
    /*Copies values of right-hand side members
      into left-hand side members */
    x = rhs.x;                           // assigns right-hand side x to x
    y = rhs.y;                           // assigns right-hand side y to y
    
    return *this;
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator%(const double angle)
    \brief
      Overloads Operator %. Rotates a point about the origin
      by the angle specified in degrees.      
     
    \param angle
      The angle to be rotated in degree.
  */
  /***********************************************************************/
  Point Point::operator%(const double angle)
  {
    // Converts given angle degree into radian
    double radian = DegreesToRadians(angle);
    // Rotation matrix formula
    // New x = cos(angle) * old x - sin(angle) * old y
    double _x = ((cos(radian)) * x) + ((- sin(radian)) * y);
    // New y = sin(angle) * old x + cos(angle) * old y
    double _y = (x * sin(radian) + (y * cos(radian)));

    if (fabs(_x - 0.0) <= EPSILON)
      _x = 0.0;
    if (fabs(_y - 0.0) <= EPSILON)
      _y = 0.0;
    // Craeates a new Point with new values _x and _y
    Point result(_x, _y);
    
    return result;                   // Returns the result of rotation
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator-(const Point &rhs) 
    \brief
      Overloads Operator -. Calculates the difference between two points.     
     
    \param rhs
      The Point on the right-hand side of operator.
  */
  /***********************************************************************/
  double Point::operator-(const Point &rhs) 
  {
    double distance = 0;
    // Check if left-hand side point is origin
    if(x == 0 && y == 0) 
    { 
      /* Formula for calculating distance 
         if one is at origin */
      distance = sqrt(pow(rhs.x, 2) + pow(rhs.y, 2));
    }
    else
    {
      /* Formula for calculating distance if none are
         at origin or if lhs is at origin */
      distance = sqrt(pow(rhs.x - x , 2) + pow(rhs.y - y , 2));
    }
    return distance;                      // Returns distance calculated
  }
 
  /***********************************************************************/
  /*!
    \fn Point::operator^(const Point &rhs) 
    \brief
      Overloads Operator ^. Calculates the midpoint between two points.     
     
    \param rhs
      The Point on the right-hand side of operator.
  */
  /***********************************************************************/
  Point Point::operator^(const Point &rhs) 
  {
    // Create a new point
    Point midpoint;
    // Formula for calculating midpoints
    midpoint.x = ((x + rhs.x)/2);             // Mid point of x
    midpoint.y = ((y + rhs.y)/2);             // Mid point of y
    
    return midpoint;                      // Return midpoint of two points
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator+=(const Point &rhs) 
    \brief
      Overloads Operator +=. Adds two points.     
     
    \param rhs
      The Point on the right-hand side of operator.
  */
  /***********************************************************************/
  Point &Point::operator+=(const Point &rhs) 
  {
    // Add point x and right-hand side x
    x += rhs.x;
    // Add point y and right-hand side y
    y += rhs.y;
   
    return *this;                              // Return this
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator+=(const double _double) 
    \brief
      Overloads Operator +=. Adds a point and a double.     
     
    \param _double
      The double value that is to be added.
  */
  /***********************************************************************/
  Point &Point::operator+=(const double _double) 
  {
    // Adds point x and double
    x += _double;
    // Adds point yand double
    y += _double;
    
    return *this;                              // Return this
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator-(const double _double)
    \brief
      Overloads Operator -. Subtracts a double from a point.     
     
    \param _double
      The double value that is to be subtracted.
  */
  /***********************************************************************/
  Point Point::operator-(const double _double)
  {
    // Create new point
    Point result;
    // Subtract double from point x
    result.x = x - _double;
    // Subtract double from point y
    result.y = y - _double;
    
    return result;                              // Return point
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator++() 
    \brief
      Overloads Pre-increment Operator ++. Adds one to (x, y)
      coordinates of a point and returns a reference 
      to the incremented point.     
  */
  /***********************************************************************/
  Point &Point::operator++() 
  {
    // Incrementing x 
    x += 1;
    // Incrementing y 
    y += 1;
    
    return *this;                              // Return this
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator++(int) 
    \brief
      Overloads Post-increment Operator ++. Adds one to (x, y)
      coordinates of a point and returns the old value before increment. 
  */
  /***********************************************************************/
  Point Point::operator++(int) 
  {
    // Create a point to hold the old value
    Point old_value(x , y);
    // Increment this value
    ++(*this);
    
    return old_value;                        // Return the original value
  }

  /***********************************************************************/
  /*!
    \fn Point::operator--() 
    \brief
      Overloads Pre-decrement Operator --. Subtracts one to (x, y)
      coordinates of a point and returns a 
      reference to the decrement point.     
  */
  /***********************************************************************/
  Point &Point::operator--() 
  {
    // Decrement values x
    x -= 1;
    // Decrement values y
    y -= 1;
    
    return *this;                                 // Return this
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator--() 

    \brief
      Overloads Post-decrement Operator --. Adds one to (x, y)
      coordinates of a point and returns the old value before decrement.
  */
  /***********************************************************************/
  Point Point::operator--(int) 
  {
    // Create point to hold old value
    Point old_value(x , y);
    // Decrement this
    --(*this);
    
    return old_value;                          // Return original value
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator+(const Point &rhs)
    \brief
      Overloads Operator +. Adds two points.    
     
    \param rhs
      The point on the right-hand side of the operator that
      is to be added to the point on the left-hand side of the operator.
  */
  /***********************************************************************/
  Point Point::operator+(const Point &rhs)
  {
    // Create new point
    Point result;
    // new point x is x added with right-hand side x
    result.x = x + rhs.x;
    // new point y is y added with right-hand side y
    result.y = y + rhs.y;
    
    return result;                                 // Return result
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator+(const double _double)
    \brief
      Overloads Operator +. Adds a point and a double.    
     
    \param _double
      The double value that is to be added.
  */
  /***********************************************************************/
  Point Point::operator+(const double _double)
  {
    // Create new point
    Point result;
    // new point x is x added with a double value
    result.x = x + _double;
    // new point y is y added with a double value
    result.y = y + _double;
    
    return result;                                 // Return result
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator*(double _double)
    \brief
      Overloads Operator *. Multiplies a point by
      some numeric factor of type double.
     
    \param _double
      The double value that is to be multiplied.
  */
  /***********************************************************************/
  Point Point::operator*(double _double)
  {
    // Create new point
    Point result;
    // new point x is x scaled with a double value
    result.x = x * _double;
    // new point x is x scaled with a double value
    result.y = y * _double;
    
    return result;                                 // Return result
  }
  
  /***********************************************************************/
  /*!
    \fn Point::operator-()
    \brief
      Overloads Unary Operator -. Negates both coordinates of a point.
  */
  /***********************************************************************/
  Point Point::operator-()
  {
    // Create new point with x and y values
    Point negate(x, y);
    // Negate point x
    negate.x *= -1;
    // Negate point y
    negate.y *= -1;
    
    return negate;                             // Return negated result
  }


///////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
/*************************************************************************/
  /*!
    \fn operator<<(std::ostream &os, const Point &rhs)
    \brief
      Friend function of Point.
      Overloads Operator <<. Inserts a string representing a point
      in a form: (x, y) into a data stream, generally std::cout.
     
    \param os
      The output stream.
      
    \param rhs
      The right-hand side point that is to be inserted.
  */
  /***********************************************************************/
  std::ostream &operator<<(std::ostream &os, const Point &rhs)
  {
    // Return the output stream
    return os << "(" << rhs.x << ", " << rhs.y << ")";
  }
  
   /**********************************************************************/
  /*!
    \fn operator>>(std::istream &in, Point &rhs)
    \brief
      Friend function of Point.
      Overloads Operator >>. Extracts a point from a data stream,
      generally std::cin, as two floating point numbers separated
      by a whitespace.
     
    \param in
      The input stream.
      
    \param rhs
      The right-hand side point that is to be exstracted.
  */
  /***********************************************************************/
  std::istream &operator>>(std::istream &in, Point &rhs)
  {
    // Return the input stream
    return in >> rhs.x >> std::ws >> rhs.y;
  }



///////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
/*************************************************************************/
  /*!
    \brief
      Overloads Operator +. Adds a double and a point.    
     
    \param _double
      The double value that is to be added.
      
    \param rhs
      The Point that is to be added with the double value.
  */
  /***********************************************************************/
  Point operator+(const double _double, Point &rhs)
  {
    // Create a new point with right-hand side values
    Point result = rhs;
    // Add double and a point
    result = result.operator+(_double);
    
    return result;                                 // Return result
  }
  
  /***********************************************************************/
  /*!
    \brief
      Overloads Operator *. Multiplies a double and a point.    
     
    \param _double
      The double value that is to be multiplied.
      
    \param rhs
      The Point that is to be multiplied with the double value.
  */
  /***********************************************************************/
  Point operator*(const double _double, Point &rhs)
  {
    // Create a new point with right-hand side values
    Point result = rhs;
    // Scale double and a point
    result = result.operator*(_double);
    
    return result;                                 // Return result
  }

} // namespace CS170



