/*****************************************************************************/
/*!
\file Point.cpp
\author Benjamin Julian M. Larin
\par email:
b.larin\@digipen.edu
\par DigiPen login:
b.larin
\par Course:
CS170-A
\par Lab #5
\date 22/06/2019
\brief This file contains the implementation of the following overloaded 
functions for Lab #5.

\par Constructors include:
  
  Point();
  
  Point(double _x, double _y);

\par Class Public Member Functions include:
  
  Point operator%(const double &angle) const;
  
  Point operator+(const Point &rhs) const;
  
  Point operator+(const double &value) const;
  
  Point operator-(const double &value) const;
  
  double operator-(const Point &rhs);
  
  Point operator*(const double &value) const;
  
  Point operator^(const Point &rhs) const;
  
  Point& operator+=(const double &value);
  
  Point& operator+=(const Point &rhs);
  
  Point& operator++();
  
  Point operator++(int);
  
  Point& operator--();
  
  Point operator--(int);
  
  Point operator-();

\par Friend functions include:
  
  std::ostream& operator << (std::ostream &out, const Point &pt);
  
  std::istream& operator >> (std::istream &in, Point &pt);

\par Class Additional Private Member funtions:
  
  double DegreesToRadians(double degrees) const;
  
  double RadiansToDegrees(double radians) const;

\par Non-member, Non-friend Functions include:

  Point operator+(const double &value, const Point &rhs);
  
  Point operator*(const double &value, const Point &rhs);

\par Hours spent on this assignment:
 3 hrs
\par Specific portions that gave you the most trouble:
  ..
*/
/*****************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 

/*****************************************************************************/
  /** Converts given angle from degrees to radians

      @param degrees - the angle in degrees
      @return the angle in radians 
  */
/*****************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

/*****************************************************************************/
  /** Converts given angle from radians to degrees

      @param radians - the angle in radians
      @return the angle in degrees
  */
/*****************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators)

/*****************************************************************************/
  /** Default Constructor
  */
/*****************************************************************************/
Point::Point() : x{0}, y{0}
{

}

/*****************************************************************************/
  /** Overloaded Constructor
  */
/*****************************************************************************/
Point::Point(double _x, double _y) : x{_x}, y{_y}
{

}

/*****************************************************************************/
  /** Performs the rotation of a point by a given angle. It also makes 
      negative zero into a positive zero. The negative zero is not really zero 
      but a very small negative number but since we are printing in a specific 
      precision, it shows a negative zero.

      @param angle - the angle given
      @return a point rotated by an angle
  */
/*****************************************************************************/
Point Point::operator%(const double &angle) const
{
  double rad = DegreesToRadians(angle);

  double x = std::cos(rad) * this->x - std::sin(rad) * this->y;
  double y = std::sin(rad) * this->x + std::cos(rad) * this->y;
  return Point{ std::abs(x) < EPSILON ? 0.0 : x,
                std::abs(y) < EPSILON ? 0.0 : y };
}
///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Translates a point by adding another point.
      
      @param rhs - the point on the rhs
      @return a translated point
  */
/*****************************************************************************/
Point Point::operator+(const Point &rhs) const
{
  return Point{ this->x + rhs.x, this->y + rhs.y };
}

/*****************************************************************************/
  /** Translates a point by adding a number to the coordinates of the point.
      
      @param value - the number to be added
      @return a translated point
  */
/*****************************************************************************/
Point Point::operator+(const double &value) const
{
  return Point{ this->x + value, this->y + value };
}

///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Translates a point by subtracting a number to the coordinates of the 
      point.

      @param value - the number to be subtracted
      @return a translated point
  */
/*****************************************************************************/
Point Point::operator-(const double &value) const
{
  return Point{ this->x - value, this->y - value };
}

/*****************************************************************************/
  /** Finds the distance between two points using the Pythagoras Theorem.
      
      @param rhs - the point on the rhs
      @return distance between the points
  */
/*****************************************************************************/
double Point::operator-(const Point &rhs)
{
  return std::sqrt((this->x - rhs.x)*(this->x - rhs.x) + 
              (this->y - rhs.y)*(this->y - rhs.y));
}

///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Scales a point by multiplying a number to the coordinates of the point.

      @param value - the number to be multiplied
      @return a scaled point
  */
/*****************************************************************************/
Point Point::operator*(const double &value) const
{
  return Point{ this->x * value, this->y * value };
}

///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Finds the midpoint between two points.
     
      @param rhs - the point on the rhs
      @return midpoint between the points
  */
/*****************************************************************************/
Point Point::operator^(const Point &rhs) const
{
  return Point{ (this->x + rhs.x) / 2, (this->y + rhs.y) / 2 };
}

///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Translates a point by adding a number and the result is stored on the 
      object holding the first point.

      @param value - the number to be added
      @return translated point
  */
/*****************************************************************************/
Point& Point::operator+=(const double &value)
{
  this->x += value;
  this->y += value;
  return *this;
}

/*****************************************************************************/
  /** Translates a point by adding another point and the result is stored on 
      the object holding the first point.
    
      @param rhs - the point on the rhs
      @return translated point
  */
/*****************************************************************************/
Point& Point::operator+=(const Point &rhs)
{
  this->x += rhs.x;
  this->y += rhs.y;
  return *this;
}

///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Increments the coordinates of a point by 1 and returns the new value.
      
      @return incremented point
  */
/*****************************************************************************/
Point& Point::operator++()//Pre
{
  ++this->x;
  ++this->y;
  return *this;
}

/*****************************************************************************/
  /** Makes a copy of the point then increments the coordinates by 1 and 
      returns the copy with the old value of the point. The int parameter is 
      for the compiler to distinguish pre from post.
      
      @return copy of the point with the old value
  */
/*****************************************************************************/
Point Point::operator++(int)//Post
{
  Point tmp = *this;
  ++this->x;
  ++this->y;
  return tmp;
}

///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Decrements the coordinates of a point by 1 and returns the new value.

      @return decremented point
  */
/*****************************************************************************/
Point& Point::operator--()//Pre
{
  --this->x;
  --this->y;
  return *this;
}

/*****************************************************************************/
  /** Makes a copy of the point then decrements the coordinates by 1 and
      returns the copy with the old value of the point. The int parameter is
      for the compiler to distinguish pre from post.

      @return copy of the point with the old value
  */
/*****************************************************************************/
Point Point::operator--(int)//Post
{
  Point tmp = *this;
  --this->x;
  --this->y;
  return tmp;
}

///////////////////////////////////////////////////////////////////////////////

/*****************************************************************************/
  /** Gives the opposite sign of the point.
    
      @return point with the opposite sign
  */
/*****************************************************************************/
Point Point::operator-()
{
  return Point{-this->x, -this->y};
}

///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

/*****************************************************************************/
  /** Allows us to print a point with this format: (x, y).
      
      @param out - the console output
      @param pt - the point we want to print
      @return the console out
  */
/*****************************************************************************/
std::ostream& operator<< (std::ostream &out, const Point &pt)
{
  out << "(" << pt.x << ", " << pt.y << ")";
  return out;
}

/*****************************************************************************/
  /** Allows us to receive input to get a point.
      
      @param in - the console input
      @param pt - the point we want to input
      @return the console in
  */
/*****************************************************************************/
std::istream& operator>> (std::istream &in, Point &pt)
{
  in >> pt.x >> pt.y;
  return in;
}


///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)

/*****************************************************************************/
  /** Translates a point by adding a number to the coordinates of the point.
      
      @param value - the number to be added
      @param rhs - the point on the rhs
      @return a translated point
  */
/*****************************************************************************/
Point operator+(const double &value, const Point &rhs)
{
  return rhs + value;
}

/*****************************************************************************/
  /** Scales a point by multiplying a number to the coordinates of the point.
      
      @param value - the number to be miltiplied
      @param rhs - the point on the rhs
      @return a scaled point
  */
/*****************************************************************************/
Point operator*(const double &value, const Point &rhs)
{
  return rhs * value;
}

} // namespace CS170



