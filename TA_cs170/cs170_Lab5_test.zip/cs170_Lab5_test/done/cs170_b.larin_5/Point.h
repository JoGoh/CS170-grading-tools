/*****************************************************************************/
/*!
\file Point.h
\author Benjamin Julian M. Larin
\par email:
b.larin\@digipen.edu
\par DigiPen login:
b.larin
\par Course:
CS170-A
\par Lab #5
\date 22/06/2019
\brief This file contains the declaration of the following overloaded 
functions for Lab #5.

\par Constructors include:
  
  Point();
  
  Point(double _x, double _y);

\par Class Public Member Functions include:
  
  Point operator%(const double &angle) const;
  
  Point operator+(const Point &rhs) const;
  
  Point operator+(const double &value) const;
  
  Point operator-(const double &value) const;
  
  double operator-(const Point &rhs);
  
  Point operator*(const double &value) const;
  
  Point operator^(const Point &rhs) const;
  
  Point& operator+=(const double &value);
  
  Point& operator+=(const Point &rhs);
  
  Point& operator++();
  
  Point operator++(int);
  
  Point& operator--();
  
  Point operator--(int);
  
  Point operator-();

\par Friend functions include:
  
  std::ostream& operator << (std::ostream &out, const Point &pt);
  
  std::istream& operator >> (std::istream &in, Point &pt);

\par Class Additional Private Member funtions:
  
  double DegreesToRadians(double degrees) const;
  
  double RadiansToDegrees(double radians) const;

\par Non-member, Non-friend Functions include:

  Point operator+(const double &value, const Point &rhs);
  
  Point operator*(const double &value, const Point &rhs);

\par Hours spent on this assignment:
 3 hrs
\par Specific portions that gave you the most trouble:
  Testing one by one which operator overloading I needed as member, friend or
  non-member.
*/
/*****************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
      // Constructors (2)

      Point();//Default Constructor
      Point(double _x, double _y);//Overloaded constructor

      // Overloaded operators (14 member functions)

      //Rotation
      Point operator%(const double &angle) const;

      //Translation
      Point operator+(const Point &rhs) const;
      Point operator+(const double &value) const;

      //Translation
      Point operator-(const double &value) const;
      
      //Distance between points
      double operator-(const Point &rhs);

      //Scaling
      Point operator*(const double &value) const;
      
      //Midpoint
      Point operator^(const Point &rhs) const;
      
      //Translation
      Point& operator+=(const double &value);
      Point& operator+=(const Point &rhs);

      Point& operator++();//Pre increment
      Point operator++(int);//Post increment

      Point& operator--();//Pre decrement
      Point operator--(int);//Post decrement

      //Negation
      Point operator-();

      // Overloaded operators (2 friend functions)
      friend std::ostream& operator << (std::ostream &out, const Point &pt);
      friend std::istream& operator >> (std::istream &in, Point &pt);

    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

      // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
  // Overloaded operators (2 non-member, non-friend functions)
  
  //Translation
  Point operator+(const double &value, const Point &rhs);
  
  //Scaling
  Point operator*(const double &value, const Point &rhs);

} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
