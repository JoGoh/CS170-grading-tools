/*****************************************************************************/
/*!
\file Point.h
\author Favian Goh
\par DP email duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 5
\date 24/06/2019
\brief
  This file contains a Point class to represent points in a two-dimensional
  Cartesian coordinate system.
  
  It contains the following class members:
  
  double _x;                           - The x-coordinate of a Point
  double _y;                           - The y-coordinate of a Point
  
  double getX()                        - Return _x
  double getY()                        - Return _y
  
  double Point::DegreesToRadians(double degrees) const
                                       - Degrees to Radians
  
  double Point::RadiansToDegrees(double radians) const
                                       - Radians to Degrees
  
  Point()                              - Default Constructor
  Point(const Point& rhs)              - Copy Constructor
  Point(double x, double y);           - Direct Initialization
  Point operator+(const Point rhs)     - Translation
  Point operator+(const double rhs)    - Translation
  Point operator-(const double rhs)    - Translation
  Point operator*(const double rhs)    - Scaling
  Point operator%(const double angle)  - Rotation
  double operator-(const Point rhs)    - Distance between two points
  Point operator^(const Point rhs)     - point of two points' mid-point
  void operator+=(Point rhs)           - Assignment
  void operator+=(double rhs)          - Assignment
  Point& operator++()                  - Pre-increment
  Point& operator--()                  - Pre-decrement
  Point operator++(const int)          - Post-increment
  Point operator--(const int)          - Post-decrement
  Point operator-() const              - Unary
  
  Point operator+(const double lhs, const Point rhs)            - Translation
  Point operator*(const double lhs, const Point rhs)            - Scaling
  std::istream& operator>>(std::istream& os, Point& rhs)        - istream
  std::ostream& operator<<(std::ostream& os, Point const &rhs)  - ostream
  
*/
/*****************************************************************************/

///////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
///////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    double _x; // The x-coordinate of a Point
    double _y; // The y-coordinate of a Point
    
    public:
    
        double getX() const; // Return _x
        
        double getY() const; // Return _y
        
        // Constructors (2)
        Point();
        
        Point(const Point& rhs); // Copy Constructor
        
        Point(double x, double y); // Direct Initialization
        
        // Overloaded operators (14 member functions)
        // Operator  point + point   (Translation)
        Point operator+(const Point rhs);
        // Operator  point + double  (Translation)
        Point operator+(const double rhs);
        // Operator  point - double  (Translation)
        Point operator-(const double rhs);

        // Operator  point * double  (Scaling)
        Point operator*(const double rhs);

        // Operator  point % double  (Rotation)
        Point operator%(const double angle);

        // Operator  point - Point   (Distance)
        double operator-(const Point rhs);
        
        // Operator  point ^ point   (Mid-point)
        Point operator^(const Point rhs);

        // Operator  point += point  (Assignment)
        void operator+=(Point rhs);
        // Operator  point += double (Assignment)
        void operator+=(double rhs);
        
        // Operator  ++point         (Pre-increment)
        Point& operator++();
        // Operator  --point         (Pre-decrement)
        Point& operator--();
        // Operator  point++         (Post-increment)
        Point operator++(const int);
        // Operator  point--         (Post-decrement)
        Point operator--(const int);
        
        // Operator  -point          (Unary)
        Point operator-() const;
        
        // Overloaded operators (2 friend functions)
        // Operator cout >> Position (istream)
        friend std::istream& operator>>(std::istream& cin, Point& rhs);
        // Operator cin << position (ostream)
        friend std::ostream& operator<<(std::ostream& cout, Point const &rhs);
        
    private:
      
      // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    Point operator+(const double lhs, const Point rhs);
    // Operator  double * Point  (Scaling)
    Point operator*(const double lhs, const Point rhs);
} // namespace CS170

#endif
///////////////////////////////////////////////////////////////////////////////