/*****************************************************************************/
/*!
\file Point.cpp
\author Favian Goh
\par DP email duoyoufavian.goh\@digipen.edu
\par DigiPen login: duoyoufavian.goh
\par Course: CS170
\par Lab 5
\date 24/06/2019
\brief
  This file contains a Point class to represent points in a two-dimensional
  Cartesian coordinate system.
  
  It contains the following class functions:
  
  double getX()                        - Return _x
  double getY()                        - Return _y
  
  double Point::DegreesToRadians(double degrees) const
                                       - Degrees to Radians
  
  double Point::RadiansToDegrees(double radians) const
                                       - Radians to Degrees
  
  Point()                              - Default Constructor
  Point(const Point& rhs)              - Copy Constructor
  Point(double x, double y);           - Direct Initialization
  Point operator+(const Point rhs)     - Translation
  Point operator+(const double rhs)    - Translation
  Point operator-(const double rhs)    - Translation
  Point operator*(const double rhs)    - Scaling
  Point operator%(const double angle)  - Rotation
  double operator-(const Point rhs)    - Distance between two points
  Point operator^(const Point rhs)     - point of two points' mid-point
  void operator+=(Point rhs)           - Assignment
  void operator+=(double rhs)          - Assignment
  Point& operator++()                  - Pre-increment
  Point& operator--()                  - Pre-decrement
  Point operator++(const int)          - Post-increment
  Point operator--(const int)          - Post-decrement
  Point operator-() const              - Unary
  
  Point operator+(const double lhs, const Point rhs)            - Translation
  Point operator*(const double lhs, const Point rhs)            - Scaling
  std::istream& operator>>(std::istream& os, Point& rhs)        - istream
  std::ostream& operator<<(std::ostream& os, Point const &rhs)  - ostream
  
*/
/*****************************************************************************/

#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

/*****************************************************************************/
    /*!
      \brief
        get value of X
      
      \return 
        _x
    */
/*****************************************************************************/

double Point::getX() const
{
  return _x;
}

/*****************************************************************************/
    /*!
      \brief
        get value of y
      
      \return 
        _y
    */
/*****************************************************************************/
double Point::getY() const
{
  return _y;
}

///////////////////////////////////////////////////////////////////////////////
// private member functions

double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}

///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 

/*****************************************************************************/
    /*!
      \brief
        Default constructor.
        Constructs an object represented with zero value.
    */
/*****************************************************************************/

Point::Point()
{
  _x = 0; // initialize _x to 0
  _y = 0; // initialize _y to 0
}

/*****************************************************************************/
    /*!
      \brief
        Copy constructor.
        Constructs an object by copying a value from another object.
      
      \param rhs
        Point to copy from
    */
/*****************************************************************************/

Point::Point(const Point& rhs)
{
  _x = rhs._x; // copy from rhs._x to _x
  _y = rhs._y; // copy from rhs._y to _y
}

/*****************************************************************************/
    /*!
      \brief
        Direct Initialization
        Initialize members from parameters
      
      \param x
        x-coordinate
        
      \param y
        y-coordinate
    */
/*****************************************************************************/

Point::Point(double x, double y)
{
  _x = x; // initialize _x to x
  _y = y; // initialize _y to y
}

/*****************************************************************************/
    /*!
      \brief
        Operator +
        Adds two Points
        Translation
      
      \param rhs
        point to add

      \return
        point after translation
    */
/*****************************************************************************/

Point Point::operator+(const Point rhs)
{
  Point result(0,0);       // declare new point
  result._x = _x + rhs._x; // store x into new point
  result._y = _y + rhs._y; // store y into new point
  return result;           // return new point
}
 
/*****************************************************************************/
    /*!
      \brief
        Operator +
        point + double
        Translation
      
      \param rhs
      value to add

      \return
        point after translation
    */
/*****************************************************************************/

Point Point::operator+(const double rhs)
{
  Point result(0,0);    // declare new point
  result._x = _x + rhs; // store x into new point
  result._y = _y + rhs; // store y into new point
  return result;        // return new point
}

/*****************************************************************************/
    /*!
      \brief
        Operator -
        point - double
        Translation
      
      \param rhs
        value to subtract

      \return
        point after translation
    */
/*****************************************************************************/

Point Point::operator-(const double rhs)
{
  Point result(0,0);    // declare new point
  result._x = _x - rhs; // store x into new point
  result._y = _y - rhs; // store y into new point
  return result;        // return new point
}

/*****************************************************************************/
    /*!
      \brief
        Operator *
        point * double
        Scaling
      
      \param rhs
        value to scale

      \return
        point after translation
    */
/*****************************************************************************/

Point Point::operator*(const double rhs)
{
  Point result(0,0);    // declare new point
  result._x = _x * rhs; // store x into new point
  result._y = _y * rhs; // store y into new point
  return result;        // return new point
}

/*****************************************************************************/
    /*!
      \brief
        Operator %
        point % double
        Rotation
      
      \param angle
        angle to rotate by

      \return
        point after rotation
    */
/*****************************************************************************/

Point Point::operator%(const double angle)
{
  Point result(0,0);                     // declare new point
  double rad = DegreesToRadians(angle);  // convert angle to radians
  result._x = _x*cos(rad) - _y*sin(rad); // x point multiplied by matrix
  result._y = _x*sin(rad) + _y*cos(rad); // y point multiplied by matrix
  
  if (result._x > -EPSILON && result._x < EPSILON)
    result._x = 0.0;
  if (result._y > -EPSILON && result._y < EPSILON)
    result._y = 0.0;
  
  return result;                         // return result of rotation
}

/*****************************************************************************/
    /*!
      \brief
        Operator -  
        point - point   
        Distance between two points
      
      \param rhs
        second point

      \return
        value of distance between two points
    */
/*****************************************************************************/

double Point::operator-(const Point rhs)
{
  // formula for distance , return result
  return sqrt(pow(_x - rhs._x , 2.0) + pow( _y - rhs._y , 2.0));
}

/*****************************************************************************/
    /*!
      \brief
        Operator ^
        point ^ point
        Mid-point
      
      \param rhs
        second point

      \return
        point of two points' mid-point
    */
/*****************************************************************************/

Point Point::operator^(const Point rhs)
{
  Point result(0,0);              // declare new point
  result._x = (_x + rhs._x) / 2;  // store x into new point
  result._y = (_y + rhs._y) / 2;  // store y into new point
  return result;                  // return new point
}

/*****************************************************************************/
    /*!
      \brief
        Operator +=
        Point += Point
        Assignment
      
      \param rhs
        point to add 
    */
/*****************************************************************************/

void Point::operator+=(Point rhs)
{
  _x += rhs._x; // assign result of addition to _x
  _y += rhs._y; // assign result of addition to _y
}
 
/*****************************************************************************/
    /*!
      \brief
        Operator +=
        point += double
        Assignment
      
      \param rhs
        double to add
    */
/*****************************************************************************/
 
void Point::operator+=(double rhs)
{
  _x += rhs; // assign result of addition to _x
  _y += rhs; // assign result of addition to _y
}

/*****************************************************************************/
    /*!
      \brief
        Operator ++
        ++point
        Pre-increment

      \return
        incremented point
    */
/*****************************************************************************/

Point& Point::operator++()
{
  _x++;         // increment _x
  _y++;         // increment _y
  return *this; // return result point
}

/*****************************************************************************/
    /*!
      \brief
        Operator --
        --Point
        Pre-decrement

      \return
        decremented point
    */
/*****************************************************************************/

Point& Point::operator--()
{
  _x--;         // decrement _x
  _y--;         // decrement _y
  return *this; // return result point
}

/*****************************************************************************/
    /*!
      \brief
        Operator ++
        Point++
        Post-increment

      \return
        original point
    */
/*****************************************************************************/

Point Point::operator++(const int)
{
  Point result(_x,_y); // declare new point
  _x++;                // increment _x
  _y++;                // increment _y
  return result;       // return original point
}

/*****************************************************************************/
    /*!
      \brief
        Operator --
        Point--
        Post-decrement

      \return
        original point
    */
/*****************************************************************************/

Point Point::operator--(const int)
{
  Point result(_x,_y); // declare new point
  _x--;                // decrement _x
  _y--;                // decrement _y
  return result;       // return original point
}

/*****************************************************************************/
    /*!
      \brief
        Operator -
        -Point
        Unary

      \return
        point after unary operation
    */
/*****************************************************************************/

Point Point::operator-() const
{
  Point result(0,0); // declare new point
  result._x = -_x;   // store x into new point
  result._y = -_y;   // store y into new point
  return result;     // return new point
}
  
///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

/*****************************************************************************/
    /*!
      \brief
        Operator >>
        cin >> Position
        istream  

      \param cin
        istream
        
      \param rhs
        point to insert to istream

      \return
        istream with input
    */
/*****************************************************************************/

std::istream& operator>>(std::istream& cin, Point& rhs)
{
  cin >> rhs._x; // insert rhs._x to istream
  cin >> rhs._y; // insert rhs._y to istream 
  return cin;    // return istream 
}

/*****************************************************************************/
    /*!
      \brief
        Operator <<
        cout << Position
        istream  

      \param cout
        ostream
        
      \param rhs
        point to insert to ostream

      \return
        ostream with input
    */
/*****************************************************************************/

std::ostream& operator<<(std::ostream& cout, Point const &rhs)
{
  // insert rhs._x , rhs._y and format into ostream
  cout << "(" << rhs._x << ", " << rhs._y << ")";  
  return cout; // return ostream 
}

///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)

/*****************************************************************************/
    /*!
      \brief
        Operator +
        double + point
        Translation

      \param lhs
        double to add to point
        
      \param rhs
        point to add by

      \return 
        point after translation
    */
/*****************************************************************************/

Point operator+(const double lhs, const Point rhs)
{
  // initialize new point to store result of scaling
  Point result(lhs + rhs.getX(),lhs + rhs.getY());
  // return new point    
  return result;                
}

/*****************************************************************************/
    /*!
      \brief
        Operator *
        double * point
        Scaling

      \param lhs
        double to scale point
        
      \param rhs
        point to scale by

      \return 
        point after scaling
    */
/*****************************************************************************/

Point operator*(const double lhs, const Point rhs)
{
  // initialize new point to store result of scaling
  Point result(lhs * rhs.getX(),lhs * rhs.getY());
  // return new point      
  return result;     
}

} // namespace CS170