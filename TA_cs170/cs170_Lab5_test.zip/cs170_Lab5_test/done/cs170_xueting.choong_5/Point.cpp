/******************************************************************************/
/*!
\file Point.cpp
\author Choong Xue Ting 
\par email: xueting.choong\@digipen.edu
\par DigiPen login: xueting.choong
\par Course: CS170
\par Lab 05
\date 24/06/2019
\brief
    This file consists of 
    (1) Private member functions
    (2) 16 public member functions
    (3) 2 friend functions
    (4) 2 non-member, non-friends operators
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
    /**************************************************************************/
    /*!
    \brief	
        Constructor(default) a , b
    */
    /**************************************************************************/
    Point::Point():x(0), y(0)
    {}
    /**************************************************************************/
    /*!
    \brief	
        Constructor with parameters
    \param 	x, y
        Values of x and y
    */
    /**************************************************************************/
    Point::Point(double x, double y)
    {
        this->x = x;
        this->y = y;
    }
    
    /**************************************************************************/
    /*!
    \brief	
        Operator % function which rotates the point using the given angle.
    \param deg
        Double value that holds the amount of degree to be rotated.
    \return
        A new Point.
    */
    /**************************************************************************/
    Point Point::operator %(double deg)
    {
        double rad = DegreesToRadians(deg);
        double a = (x*cos(rad)) + (y*-sin(rad));
        double b = (y*sin(rad)) + (y*cos(rad));
        
        if(a > -EPSILON && a < EPSILON)
            a = 0.0;
        if(b > -EPSILON && b < EPSILON)
            b = 0.0;
        return Point(a, b);
    }
    
    /**************************************************************************/
    /*!
    \brief
        Operator - function which finds the distance in between two points.
    \param &rhs
        The rhs point for calculation
    \return
        Double that of the distance
    */
    /**************************************************************************/
    double Point::operator -(const Point &rhs)
    {
        double a = x - rhs.x;
        double b = y - rhs.y;
        double dist = 0;
        
        dist = sqrt((a*a)+(b*b));
        return dist;
    }

    /**************************************************************************/
    /*!
    \brief
        Operator ^ function which gets the midpoint of two points.
    \param &rhs
        The rhs point for calculation
    \return
        Point that holds the coordinates of two points
    */
    /**************************************************************************/
    Point Point::operator ^(const Point &rhs)
    {
        double a = (x + rhs.x)/2;
        double b = (y + rhs.y)/2;
        return Point(a, b);
    }

    /**************************************************************************/
    /*!
    \brief
        Operator += function which gets the reference that holds the 
        coordinates after the addition.
    \param value
        Double value to be added to point
    \return
        Reference of current point
    */
    /**************************************************************************/
    Point &Point::operator +=(double value)
    {
        x += value;
        y += value;
        return *this;
    }

    /**************************************************************************/
    /*!
    \brief
        Operator += function which gets a new point after adding two points 
        together.
    \param &rhs
        The rhs point for calculation
    \return
        Reference of current point
    */
    /**************************************************************************/
    Point &Point::operator +=(const Point &rhs)
    {
        x += rhs.x;
        y += rhs.y;
        return *this;
    }

    /**************************************************************************/
    /*!
    \brief
        Operator - function which returns a new point after subtracting value.
    \param value 
        The value to be subtracted
    \return
        A new Point after subtraction
    */
    /**************************************************************************/
    Point Point::operator -(double value)
    {
        double a = x - value;
        double b = y - value;
        return Point(a, b);
    }

    /**************************************************************************/
    /*!
    \brief
        Operator ++(pre) function which returns a reference of a point
        after an increment.
    \return
        A reference of the current point after increment
    */
    /**************************************************************************/
    Point &Point::operator ++()
    {
        x++;
        y++;
        return *this;
    }

    /**************************************************************************/
    /*!
    \brief	
        Operator ++(post) function which returns a new point after an increment.
    \return
        A new Point before increment
    */
    /**************************************************************************/
    Point Point::operator ++(int)
    {
        Point result(x, y);
        x++;
        y++;
        return result;
    }

    /**************************************************************************/
    /*!
    \brief
        Operator --(pre) function which returns a reference of a point
        after a decrement.
    \return
        A reference of the current point after decrement
    */
    /**************************************************************************/
    Point &Point::operator --()
    {
        x--;
        y--;
        return *this;
    }

    /**************************************************************************/
    /*!
    \brief
        Operator --(post) function which returns a new point after a decrement.
    \return
        A point before decrement
    */
    /**************************************************************************/
    Point Point::operator --(int)
    {
        Point result(x, y);
        x--;
        y--;
        return result;
    }

    /**************************************************************************/
    /*!
    \brief	
        Operator - function which returns the negative point of the current 
        point.
    \return
        A point that holds the new values
    */
    /**************************************************************************/
    Point Point::operator -()
    {
        return Point(-x, -y);
    }

    /**************************************************************************/
    /*!
    \brief	
        Operator + function that adds a point and a value together.
    \param value
        The value to be added
    \return
        A point that holds the new values
    */
    /**************************************************************************/
    Point Point::operator +(double value)
    {
        double a = x + value;
        double b = y + value;
        return Point(a, b);
    }

    /**************************************************************************/
    /*!
    \brief	
        Operator + function that adds two point together.
    \param &rhs
        The rhs point to be added
    \return
        A point that holds the new values
    */
    /**************************************************************************/
    Point Point::operator +(const Point &rhs)
    {
        double a = x + rhs.x;
        double b = y + rhs.y;
        return Point(a, b);
    }

    /**************************************************************************/
    /*!
    \brief	
        Operator * function that scales a point to a value
    \param value
        The value to be scaled by
    \return
        A point that holds the new values
    */
    /**************************************************************************/
    Point Point::operator *(double value)
    {
        double a = x * value;
        double b = y * value;
        return Point(a, b);
    }
///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
    /**************************************************************************/
    /*!
    \brief
        Functions that scans the point value.
    \param &cin, &pointy
        Reference of cin and current point
    \return
        Reference of cin
    */
    /**************************************************************************/
    std::istream &operator >> (std::istream &cin, Point &pointy)
    {
        std::cin >> pointy.x >> pointy.y;
        return cin;
    }

    /**************************************************************************/
    /*!
    \brief	
        Function that print out the point
    \return
        The reference of cout
    */
    /**************************************************************************/
    std::ostream &operator << (std::ostream &cout, const Point &pointy)
    {
        std::cout << "(" << pointy.x << ", " << pointy.y << ")";
        return cout;
    }


///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
    /**************************************************************************/
    /*!
    \brief	
        A non friend/memeber function that adds a point with a value together.
    \param value, pointy
        Double value and a Point
    \return
        A point that holds the new values
    */
    /**************************************************************************/
    Point operator +(double value, Point pointy)
    {
        Point result = pointy + value;
        return result;
    }

    /**************************************************************************/
    /*!
    \brief	
        A non friend/member function that multiplies a point with a value.
    \param value, pointy
        Double value and a Point
    \return
        A point that holds the new values
    */
    /**************************************************************************/
    Point operator *(double value, Point pointy)
    {
        Point result = pointy * value;
        return result;
    }
    
} // namespace CS170