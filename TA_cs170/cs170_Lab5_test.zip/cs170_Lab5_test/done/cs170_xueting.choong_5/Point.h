/******************************************************************************/
/*!
\file Point.h
\author Choong Xue Ting 
\par email: xueting.choong\@digipen.edu
\par DigiPen login: xueting.choong
\par Course: CS170
\par Lab 05
\date 24/06/2019
\brief
    This file contains headers for Operator function for the point class.
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
        Point ();
        Point (double x, double y);

        // Overloaded operators (14 member functions)
        Point operator %(double deg);
        double operator -(const Point &rhs);
        Point operator ^(const Point &rhs);
        Point &operator +=(double value);
        Point &operator +=(const Point &rhs);
        Point operator -(double value);
        Point &operator ++();
        Point operator ++(int);
        Point &operator --();
        Point operator --(int);
        Point operator -();
        Point operator +(double value);
        Point operator +(const Point &rhs);
        Point operator *(double value);
        
        // Overloaded operators (2 friend functions)
        friend std::ostream& operator<<(std::ostream &ouut, const Point &pointy);
        friend std::istream& operator>>(std::istream &cin, Point &pointy);
        
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    Point operator +(double value, Point pointy);
    Point operator *(double vlaue, Point pointy); 
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
