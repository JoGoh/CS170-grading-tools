/******************************************************************************/ 
/*! 
\file Point.h
\author Koh Joon Yee Marcus 
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: CS170
\par Assignment : 03
\date 24/06/2019
\brief
This file contains the declaration of the following Point class methods,
including operators:<br>
	% Rotation<br>
	- Distance <br>
	^ Midpoint <br>
	+= Translation(add two points) <br>
	+= Translation (add a point and a double)<br>
	- Translation (subtract a double from a point)<br>
	+ Translation (add two points)<br>
	+ Translation (add a point and a double)<br>
	++ Pre-Increment<br>
	++ Post-Increment<br>
	-- Pre-Decrement<br>
	-- Post-Decrement<br>
	- Unary Negation<br>
	* Scale<br>
	>> Input (declared as friend function)<br>
	<< Output (declared as friend function)<br>
	
	+ Translation (add a point and a double, non-member function)<br>
	* Scale (non-member function)<br>


\par Hours spent on this assignment: 2

*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
		Point(const double x_coord= 0, const double y_coord= 0);
		
		Point();

        // Overloaded operators (14 member functions)
        Point operator%(const double rhs) const;
		
		double operator-(const Point& rhs) const;
		
		Point operator^(const Point & rhs) const;
		
		Point& operator+=(const Point& rhs);
		
		Point& operator+=(const double rhs);
		
		Point operator-(const double rhs) const;
		
		Point& operator++();
		const Point operator++(int);
		
		Point& operator--();
		const Point operator--(int);

		Point operator-() const ;
		
		Point operator+(const Point &rhs) const;
		Point operator+(const double rhs) const;
		
		Point operator*(const double rhs) const;
        // Overloaded operators (2 friend functions)
		friend std::ostream & operator<<(std::ostream& os, const Point &rhs);
		friend std::istream & operator>>(std::istream& is, Point &rhs);
		
		
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
	Point operator+(const double lhs, Point& rhs);
	Point operator*(const double lhs, Point& rhs);
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
