/******************************************************************************/ 
/*! 
\file Point.cpp
\author Koh Joon Yee Marcus 
\par email: k.joonyeemarcus\@digipen.edu
\par DigiPen login: k.joonyeemarcus
\par Course: CS170
\par Assignment : 05
\date 24/06/2019
\brief
This file contains the implementation of the following Point class methods,
including operators:<br>
	% Rotation<br>
	- Distance <br>
	^ Midpoint <br>
	+= Translation(add two points) <br>
	+= Translation (add a point and a double)<br>
	- Translation (subtract a double from a point)<br>
	+ Translation (add two points)<br>
	+ Translation (add a point and a double)<br>
	++ Pre-Increment<br>
	++ Post-Increment<br>
	-- Pre-Decrement<br>
	-- Post-Decrement<br>
	- Unary Negation<br>
	* Scale<br>
	>> Input (declared as friend function)<br>
	<< Output (declared as friend function)<br>
	
	+ Translation (add a point and a double, non-member function)<br>
	* Scale (non-member function)<br>


\par Hours spent on this assignment: 2

*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
/**
	\brief Point Constuctor
	\param x_coord - the value x is to be initialized to
	\param y_coord - the value y is to be initialized to
*/
Point::Point(const double x_coord, const double y_coord) :
	x{ x_coord },
	y{ y_coord }
{}


/**
	\brief The Point class constructor
*/
Point::Point()
{}



/**
    \fn Point Point::operator%(const double rhs) const
    \brief 
       This function rotates a point about the origin about the angle specified
	in degrees then returns the new rotated point.
	\param
	  rhs - a read-only double representing angle of which the point is to be
	   rotated by.
*/
Point Point::operator%(const double rhs) const
{
	double C = std::cos(rhs*PI/180.0);
	double S = std::sin(rhs*PI/180.0);
	

	
	Point P1;
			
	P1.x  = (x * C) + (-y * S);
	if (P1.x > -EPSILON && P1.x < EPSILON)
		P1.x= 0.0;
	

	P1.y = (x * S) + (y * C);
	if ( P1.y> -EPSILON && P1.y < EPSILON)
		P1.y = 0.0;
	return P1;
}


/**
  \fn 	double Point::operator-(const Point& rhs) const
  \brief 
   This function calculates the distance between two points and returns the
	  distance as a double.
  \param
  rhs - a read-only reference to type Point that represents the Point to be 
   rotated.
  \return
  distance - a double representing the distance between the 2 points
*/
double Point::operator-(const Point& rhs) const
{
	double distance= 0;
	double _Xdist = (rhs.x -x) *(rhs.x -x);
	double _Ydist = (rhs.y -y) *(rhs.y -y);
	distance  = std::sqrt(_Xdist + _Ydist);
	return distance;
}


/**
  \fn Point Point::operator^(const Point & rhs) const
  \brief 
   This function calculates the midpoint between 2 points and returns a new
	  point.
  \param
  rhs - a read-only reference to type Point that represents the other Point
   to be used to calculate the midpoint
  \return
  P1 - a new point that is the midpoint.
*/
Point Point::operator^(const Point & rhs) const
{
	Point P1;
	P1.x = (x + rhs.x)/2;
	P1.y = (y + rhs.y)/2;
	return P1;
}


/**
  \fn Point& Point::operator+=(const Point& rhs)
  \brief 
   This function adds two points and returns a reference to the point on the
	 left hand operand.
  \param
  rhs - a read-only reference to type Point that represents the Point to be 
   rotated.
  \return
  P1 - a new point that is the midpoint.
*/
Point& Point::operator+=(const Point& rhs)
{
	x = x + rhs.x;
	y = y + rhs.y;
	return *this;
}


/**
 \fn Point& Point::operator+=(const double rhs)
 \brief 
 This function adds a point with a double and then returns the point
 \param
 rhs - a read-only double that represents the value to be added to the point.
 \return
 *this -  the current point reference after adding the double.
*/
Point& Point::operator+=(const double rhs)
{
	x += rhs;
	y += rhs;
	return *this;
}

/**
 \fn 	Point Point::operator-(const double rhs) const
 \brief 
 This function subtracts a double from a point and returns a new Point.
 \param
 rhs - a read-only double that represents the value to be subtracted from the
 point.
 \return
 P1 -  the new point after subtracting the double.
*/
Point Point::operator-(const double rhs) const
{
	Point P1;
	P1.x = x - rhs;
	P1.y = y - rhs;
	return P1;
}

/**
 \fn	Point& Point::operator++()
 \brief 
 This function pre-increments a point and returns a reference to the point
 \return
 *this -  the current point reference after pre-incrementing
*/
Point& Point::operator++()
{
	x= x+1;
	y= y+1;
	return *this;
}


/**
 \fn	const Point Point::operator++(int)
 \brief 
 This function post-increments a point and returns a reference to the point
 \return
 temp -  a new point before the incrementing was performed
*/
const Point Point::operator++(int)
{
	Point temp(*this);
	++x;
	++y;
	return temp;
}

/**
 \fn	Point& Point::operator--()
 \brief 
 This function pre-decrements a point and returns a reference to the point
 \return
 *this -  the current point reference after pre-decrementing
*/
Point& Point::operator--()
{
	x= x-1;
	y= y-1;
	return *this;
}

/**
 \fn	const Point Point::operator--(int)
 \brief 
 This function post-increments a point and returns a reference to the point
 \return
 temp -  a new point before the decrementing was performed
*/
const Point Point::operator--(int)
{
	Point temp(*this);
	--x;
	--y;
	return temp;
}

/**
 \fn	Point Point::operator-() const
 \brief 
 This function negates both coordinates of a point and returns a new point.
 \return
 newPoint -  a new point that is the negated point.
*/
Point Point::operator-() const
{
	Point newPoint(*this);
	newPoint.x = -x;
	newPoint.y = -y;
	return newPoint;
}


/**
 \fn	Point Point::operator+(const Point &rhs) const
 \brief 
 This function adds two points and returns a new Point.
 \param
 rhs - a read-only reference to type Point that represents the Point to be 
 rotated.	   
 \return
 newPoint -  a new point after adding the rhs point
*/
Point Point::operator+(const Point &rhs) const
{
	Point newPoint(rhs);
	newPoint.x = x+ rhs.x;
	newPoint.y = y+ rhs.y;
	return newPoint;
}


/**
 \fn	Point Point::operator+(const double rhs) const
 \brief 
 This function adds a point and a double and returns a new Point.
 \param
 rhs - a read-only double that represents the value to be added to the
 point.		 
 \return
 newPoint -  a new point after adding the double
*/
Point Point::operator+(const double rhs) const
{
	Point newPoint = *this;
	newPoint.x =( this->x + rhs);
	newPoint.y = (this->y + rhs);
	return newPoint;
}



/**
 \fn	Point Point::operator*(const double rhs) const
 \brief 
 This function multplies a  point by the specified double and returns a
 new point.
 \param
 rhs - a read-only double that represents the value the point is to be
 multiplied by.
 \return
 newPoint -  a new point after adding the double
*/
Point Point::operator*(const double rhs) const
{
	Point newPoint = *this;
	newPoint.x = x * rhs;
	newPoint.y = y * rhs;
	return newPoint;
}


///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

/**
 \fn	std::ostream &operator<<(std::ostream& os, const Point &rhs)
 \brief 
 This function overloads the input stream operator to accept user defined
 type Point.
 \param
 rhs - a read-only reference to the point
 \param 
 os -  a reference to the output stream type
 
 \return
 newPoint -  a new point after adding the double
*/
std::ostream &operator<<(std::ostream& os, const Point &rhs)
{
	os << "(" << rhs.x << ", " << rhs.y << ")" ;
	return os;
}


/**
 \fn	std::istream &operator>>(std::istream& is, Point &rhs)
 \brief 
 This function overloads the input stream operator to accept user defined
 type Point.
 \param
 rhs - a reference to the point
 \param
 is  - a reference to input stream type.
 \return
 is - the input stream 
*/
std::istream &operator>>(std::istream& is, Point &rhs)
{
	is >> rhs.x;
	is >> rhs.y;
	return is;
}

///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)


/**
 \fn	Point operator*(const double lhs, Point& rhs)
 \brief 
 This function multplies a  point by the specified double and returns a
 new point.
 \param
 lhs - a read-only double that represents the value the point is to be
 multiplied by.
 \param
 rhs - a reference to the Point
 \return
 newPoint -  a new point after adding the double
*/
Point operator*(const double lhs, Point& rhs)
{
	Point newPoint(rhs);
	return newPoint* lhs;
}


/**
 \fn	Point operator+(const double lhs, Point& rhs)
 \brief 
 This function adds a point and a double and returns a new Point.
 \param
 lhs - a read-only double that represents the value to be added to the
 point.
 \param
 rhs - a read-only reference to type Point that represents the Point to be 
 added.
 \return
 newPoint -  a new point after adding the double
*/
Point operator+(const double lhs, Point& rhs)
{
	Point newPoint(rhs);
	return newPoint +lhs;
}	

} // namespace CS170



