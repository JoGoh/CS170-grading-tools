/******************************************************************************/ 
/*! 
 \file   Point.cpp
 \author Chong Huey Jia
 \par    email: hueyjia.chong\@digipen.edu 
 \par    DigiPen login: hueyjia.chong 
 \par    Course: CS170L 
 \par    Lab 05 
 \date   21/06/2011 
 \brief     This is a class for creating a point
*/ 
/******************************************************************************/

#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
/******************************************************************************/ 
/*! 
	\fn double Point::DegreesToRadians(double degrees) const

	\brief this function is to convert from degree to radians
	
	\param degrees
	
	\return the value of degree in radians, double
*/
/******************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

/******************************************************************************/ 
/*! 
	\fn double Point::RadiansToDegrees(double radians) const

	\brief this function is to convert from radians to degree
	
	\param radians
	
	\return the value of radians in degree, double
*/
/******************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}

///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators)
// Constructors (2)
/******************************************************************************/ 
/*! 
	\fn Point::Point()

	\brief this is a default constructor
*/
/******************************************************************************/
		Point::Point():
				x{0.0},
				y{0.0}
		{}

/******************************************************************************/ 
/*! 
	\fn Point::Point(const double x, const double y)

	\brief this function is a consructor
	
	\param x, y
*/
/******************************************************************************/		
		Point::Point(const double x, const double y):
				x{x}, 
				y{y}
		{}


/******************************************************************************/ 
/*! 
	\fn Point Point::operator%(double deg) const 

	\brief this is a function that rotates a point about the origin
	
	\param deg
	
	\return pt, Point
*/
/******************************************************************************/
        // Overloaded operators (14 member functions)
		Point Point::operator%(double deg) const               //rotation
		{
			double rad = DegreesToRadians(deg);
			
			Point pt;
			
			pt.x = (cos(rad) * x) - (sin(rad) * y);
			if(pt.x > -EPSILON && pt.x < EPSILON)
			{
				pt.x = 0.0;
			}
			
			pt.y = (sin(rad) * x) + (cos(rad) * y);
			if(pt.y > -EPSILON && pt.y < EPSILON)
			{
				pt.y = 0.0;
			}
			
			return pt;
		}

/******************************************************************************/ 
/*! 
	\fn double Point::operator-(const Point& rhs)

	\brief this function is to calculate the distance between 2 points
	
	\param rhs
	
	\return the distance of 2 points, double
*/
/******************************************************************************/		
		double Point::operator-(const Point& rhs)              //distance
		{
			return (sqrt(((rhs.x - x) * (rhs.x - x)) + ((rhs.y - y) * (rhs.y - y))));
		}
		
/******************************************************************************/ 
/*! 
	\fn Point Point::operator^(const Point& rhs) 
	
	\brief this function is to find the midpoint between 2 points
	
	\param rhs
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator^(const Point& rhs)               //midpoint
		{
			Point pt;
			
			pt.x = (x + rhs.x) / 2;
			pt.y = (y + rhs.y) / 2;
			
			return pt;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point& Point::operator+=(const Point& rhs)

	\brief this function is a translation that adds 2 points
	
	\param rhs
	
	\return Point
*/
/******************************************************************************/		
		Point& Point::operator+=(const Point& rhs)             //translation +=
		{
			x += rhs.x;
			y += rhs.y;
			
			return *this;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point& Point::operator+=(double num)

	\brief this function is a translation that adds a point and a double
	
	\param num
	
	\return *this, Point&
*/
/******************************************************************************/		
		Point& Point::operator+=(double num)                   //translation +=
		{
			x += num;
			y += num;
			
			return *this;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point Point::operator-(double num) 

	\brief this function is a translation that subtracts a double from a point
	
	\param num
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator-(double num)                     //translation -
		{
			Point pt;
			
			pt.x = x - num;
			pt.y = y - num;
			
			return pt;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point& Point::operator++() 

	\brief this is a pre-increment function
	
	\return *this, Point&
*/
/******************************************************************************/		
		Point& Point::operator++()                             //pre-increment
		{
			x++;
			y++;
			
			return *this;
		}

/******************************************************************************/ 
/*! 
	\fn Point Point::operator++(int)

	\brief this is a post-increment function
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator++(int)                           //post-increment
		{
			Point pt;
			
			pt.x = x++;
			pt.y = y++;
			
			return pt;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point& Point::operator--()

	\brief this is a pre-decrement function
	
	\return *this, Point&
*/
/******************************************************************************/		
		Point& Point::operator--()                             //pre-decrement
		{
			x--;
			y--;
			
			return *this;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point Point::operator--(int)

	\brief this is a post-decrement function
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator--(int)                           //post-decrement
		{
			Point pt;
			
			pt.x = x--;
			pt.y = y--;
			
			return pt;
		}

/******************************************************************************/ 
/*! 
	\fn Point Point::operator-()

	\brief this is a function thta negates the value of x and y
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator-()                               //unary negation
		{
			Point pt;
			
			if(x != 0.0)
			{
				pt.x = -x;
			}
			
			if(y != 0.0)
			{
				pt.y = -y;
			}
			
			return pt;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point Point::operator+(const Point& rhs)

	\brief this is a translation function that adds 2 points 
	
	\param rhs
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator+(const Point& rhs)               //translation +
		{
			Point pt;
			
			pt.x = x + rhs.x;
			pt.y = y + rhs.y;
			
			return pt;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point Point::operator+(double num)

	\brief this is a translation function that adds a double to a point
	
	\param num
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator+(double num)                     //translation +
		{
			Point pt;
			
			pt.x = x + num;
			pt.y = y + num;
			
			return pt;
		}
		
/******************************************************************************/ 
/*! 
	\fn Point Point::operator*(double num)

	\brief this is a function for scale that multiplies a double to a point
	
	\param num
	
	\return pt, Point
*/
/******************************************************************************/		
		Point Point::operator*(double num)                     //scale * 
		{
			
			Point pt;
			
			pt.x = x * num;
			pt.y = y * num;
			
			return pt;
		}




///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
// Overloaded operators (2 friend functions)
/******************************************************************************/ 
/*! 
	\fn std::istream& operator>>(std::istream& is, Point& rhs)

	\brief this is to input a point 
	
	\param is, rhs
	
	\return is
*/
/******************************************************************************/
		std::istream& operator>>(std::istream& is, Point& rhs)          //input
		{
			is >> rhs.x;
			is >> rhs.y;
			
			return is;
		}
/******************************************************************************/ 
/*! 
	\fn std::ostream& operator<<(std::ostream& os, const Point& rhs)

	\brief this is to output a point in a form of a string
	
	\param os, rhs
	
	\return os
*/
/******************************************************************************/		
		std::ostream& operator<<(std::ostream& os, const Point& rhs)    //output
		{
			os << "(" << rhs.x << ", " << rhs.y << ")";
			return os;
		}




///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
// Overloaded operators (2 non-member, non-friend functions)
/******************************************************************************/ 
/*! 
	\fn Point operator+(double num, const Point& rhs)

	\brief this is a translation function that adds a double to a point
	
	\param num, rhs
	
	\return pt, Point
*/
/******************************************************************************/
	Point operator+(double num, const Point& rhs)    //translation +
	{
		Point pt(rhs);
		pt += num;
		
		return pt;
	}

/******************************************************************************/ 
/*! 
	\fn Point operator*(double num, const Point& rhs)

	\brief this is a scale function that multiplies a double to a point
	
	\param num, rhs
	
	\return pt, Point
*/
/******************************************************************************/	
	Point operator*(double num, const Point& rhs)    //scale *
	{
		Point pt(rhs);
		pt = pt * num;
		
		return pt;
	}



} // namespace CS170



