/******************************************************************************/ 
/*! 
 \file   Point.h
 \author Chong Huey Jia
 \par    email: hueyjia.chong\@digipen.edu 
 \par    DigiPen login: hueyjia.chong 
 \par    Course: CS170L 
 \par    Lab 05
 \date   21/06/2011 
 \brief     This is a class for creating a point
*/ 
/******************************************************************************/

////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
		Point();
		Point(const double x, const double y);
		
        // Overloaded operators (14 member functions)
		Point operator%(double deg) const;  //rotation
		double operator-(const Point& rhs);        //distance		
		Point operator^(const Point& rhs);         //midpoint		
		Point& operator+=(const Point& rhs);   //translation +=
		Point& operator+=(double num);            //translation +=		
		Point operator-(double num);   //translation -	
		Point& operator++();   //pre-increment
		Point operator++(int);   //post-increment		
		Point& operator--();   //pre-decrement
		Point operator--(int);   //post-decrement		
		Point operator-();   //unary negation		
		Point operator+(const Point& rhs);   //translation +
		Point operator+(double num);         //translation +		
		Point operator*(double num);         //scale *
		
        // Overloaded operators (2 friend functions)
		friend std::istream& operator>>(std::istream& is, Point& rhs);   //input
		friend std::ostream& operator<<(std::ostream& os, const Point& rhs);   //output
        
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
	Point operator+(double num, const Point& rhs);   //translation +
	Point operator*(double num, const Point& rhs);   //scale *
	
	
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
