/******************************************************************************/ 
/*! 
\file Point.h
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 05
\date 13/06/2019 
\brief This file contains the declaration of the following functions for
CS170 Lab 5: Point Class
\par Constructors/Destructors include:
Point()
Point(double, double)
\par Overloaded functions include
operator%
operator-
operator^
operator+=
operator++
operator--
operator-
operator+
operator*
friend operator>>
friend operator<<

\par Hours spent on this assignment: 3 hours
\par Specific portions that gave you the most trouble: Ensuring there is no
leftover dangling values
*/ 
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
	class Point
	{
	public:
/*****************************************************************************/
/*!
	\brief
		Default constructor, creates a Point at coordinates 0,0
*/
/*****************************************************************************/
		Point();
/*****************************************************************************/
/*!
	\brief
		Conversion constructor, creates a Point at given coordinates
	\param xVal
		X Coordinate of new point
	\param yVal
		Y Coordinates of new point
*/
/*****************************************************************************/
		Point(double xVal, double yVal);
// Overloaded operators (14 member functions)
/*****************************************************************************/
/*!
	\brief
		Calculates the new value of a Point after rotation about origin by 
	the degree value
	\return Point
		The new Point after rotation
*/
/*****************************************************************************/
		Point operator%(const double rotDeg) const;
/*****************************************************************************/
/*!
	\brief
		Calculates distance between two points and return that value
	\return double
		Distance between the two points
*/
/*****************************************************************************/
		double operator-(const Point &rhs) const;
/*****************************************************************************/
/*!
	\brief
		Calculates midpoint of two points and return that Point
	\return Point
		Midpoint of two points
*/
/*****************************************************************************/
		Point operator^(const Point &rhs) const;
/*****************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by another Point. Changes
		current point's value
	\return Point&
		Reference to Point after translation
*/
/*****************************************************************************/
		Point& operator+=(const Point &rhs);
/*****************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by a double. Changes
		current point's value
	\return Point&
		Reference to Point after translation
*/
/*****************************************************************************/
		Point& operator+=(const double rhs);
/*****************************************************************************/
/*!
	\brief
		Calculates the negative translation of the current Point by a double
	\return Point&
		Reference to Point after translation
*/
/*****************************************************************************/
		Point operator-(const double rhs) const;
/*****************************************************************************/
/*!
	\brief
		Pre-Increment the current point and returns the new value
	\return Point&
		Reference to Point after increment
*/
/*****************************************************************************/
		Point& operator++();
/*****************************************************************************/
/*!
	\brief
		Post-Increment the current point and returns the old value
	\return Point
		Point before increment
*/
/*****************************************************************************/
		Point operator++(int);
/*****************************************************************************/
/*!
	\brief
		Pre-Decrement the current point and returns the new value
	\return Point&
		Reference to Point after decrement
*/
/*****************************************************************************/
		Point& operator--();
/*****************************************************************************/
/*!
	\brief
		Post-Decrement the current point and returns the old value
	\return Point
		Point after decrement
*/
/*****************************************************************************/
		Point operator--(int);
/*****************************************************************************/
/*!
	\brief
		Unary negation of the point, flipping it about origin
	\return Point
		Point after negation
*/
/*****************************************************************************/
		Point operator-() const;
/*****************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by another Point. Does not
		change current point value.
	\return Point
		Point values after translation
*/
/*****************************************************************************/
		Point operator+(const Point &rhs) const;
/*****************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by another double. Does not
		change current point value
	\return Point
		Point's value after translation
*/
/*****************************************************************************/
		Point operator+(const double rhs) const;
/*****************************************************************************/
/*!
	\brief
		Calculates the scaling of the current Point by a double
	\return Point&
		Point value after scaling
*/
/*****************************************************************************/
		Point operator*(const double rhs) const;
		
// Overloaded operators (2 friend functions)
/******************************************************************************/
/*!
	\brief
		The overloading of << in the ostream to print out the Point when input it
		into the ostream
	\param cout
		The ostream that is printing out the value of the Point
	\param rhs
		The Point to print out value
	\return std::ostream&
		The reference to the ostream after adding in Point
*/
/******************************************************************************/
friend std::ostream& operator<<(std::ostream &cout, const Point &rhs);
/******************************************************************************/
/*!
	\brief
		The overloading of >> in the istream to take in input to calculate a Point
	\param cin
		The istream that is accepting values of the Point
	\param rhs
		The Point to takae in values from the istream	
	\return std::istream&
		The reference to the istream after giving values of to the Point
*/
/******************************************************************************/
friend std::istream& operator>>(std::istream &cin, Point &rhs);

	private:
		double x; // The x-coordinate of a Point
		double y; // The y-coordinate of a Point

		// Helper functions
/******************************************************************************/
/*!
	\brief
		Converts a double value from degrees to radians
	\param degrees
		The value in degrees to change to radians
	\return double
		The radian value after conversion
*/
/******************************************************************************/
		double DegreesToRadians(double degrees) const;
/******************************************************************************/
/*!
	\brief
		Converts a double value from radians to degrees

	\param radians
		The value in radians to change to degrees
		
	\return double
		The degree value after conversion
*/
/******************************************************************************/
		double RadiansToDegrees(double radians) const;
	};

	// Overloaded operators (2 non-member, non-friend functions)
/******************************************************************************/
/*!
	\brief
		Calculates the translation of the Point by a double
	\param lhs
		The double value to translate
	\param rhs
		The Point value to translate
	\return Point
		The value of the new point after translation
*/
/******************************************************************************/
	Point operator+(const double lhs, const Point &rhs);
/******************************************************************************/
/*!
	\brief
		Calculates the scale of the Point by a double
	\param lhs
		The double value to scale
	\param rhs
		The Point value to scale	
	\return Point
		The value of the new point after scaling
*/
/******************************************************************************/
	Point operator*(const double lhs, const Point &rhs);
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
