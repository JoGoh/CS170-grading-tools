/******************************************************************************/ 
/*! 
\file Point.cpp
\author Chan Wai Kit Terence 
\par email: c.terence\@digipen.edu
\par DigiPen login: c.terence
\par Course: CS170 
\par Lab 05
\date 13/06/2019 
\brief This file contains the implementation of the following functions for
CS170 Lab 5: Point Class
\par Constructors/Destructors include:
Point()
Point(double, double)
\par Overloaded functions include
operator%
operator-
operator^
operator+=
operator++
operator--
operator-
operator+
operator*
friend operator>>
friend operator<<

\par Hours spent on this assignment: 3 hours
\par Specific portions that gave you the most trouble: Ensuring there is no
leftover dangling values
*/ 
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{
//Absolute values as a reference
const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
/******************************************************************************/
/*!
	\brief
		Converts a double value from degrees to radians

	\param degrees
		The value in degrees to change to radians
		
	\return double
		The radian value after conversion
*/
/******************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}
/******************************************************************************/
/*!
	\brief
		Converts a double value from radians to degrees

	\param radians
		The value in radians to change to degrees
		
	\return double
		The degree value after conversion
*/
/******************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}
///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
/******************************************************************************/
/*!
	\brief
		Default constructor for Point. Creates a Point at (0,0)
*/
/******************************************************************************/
Point::Point(): x(0), y(0)
{
}
/******************************************************************************/
/*!
	\brief
		Conversion constructor, Creates a point from two double values.
*/
/******************************************************************************/
Point::Point(double xVal, double yVal): x(xVal), y(yVal)
{
}
/******************************************************************************/
/*!
	\brief
		Returns value of a rotation of a point about the origin (0,0) by the 
		degree value

	\param rotDeg
		The value of rotation to rotate the member point
		
	\return Point
		The new Point after rotation
*/
/******************************************************************************/
Point Point::operator%(const double rotDeg) const
{
	double rotRad = DegreesToRadians(rotDeg);
	double newX = cos(rotRad) * x - sin(rotRad) * y;
	double newY = sin(rotRad) * x + cos(rotRad) * y;
	
	//To check for floating point value if any
	if (newX > -EPSILON && newX < EPSILON)
		newX = 0.0;
	if (newY > -EPSILON && newY < EPSILON)
		newY = 0.0;
	
	Point toReturn(newX, newY);
	return toReturn;
}
/******************************************************************************/
/*!
	\brief
		Calculates the distance between two points and returns that double

	\param rhs
		The second Point to calculate the distance
		
	\return double
		The calculated distance between two points
*/
/******************************************************************************/
double Point::operator-(const Point &rhs) const
{
	double length = (x - rhs.x) * (x - rhs.x) + (y - rhs.y) * (y-rhs.y);
	return sqrt(length);
}
/******************************************************************************/
/*!
	\brief
		Calculates the midpoint of two points and returns that point

	\param rhs
		The second point to calculate the midpoint from
	
	\return Point
		The calculated midpoint value of the two Points
*/
/******************************************************************************/
Point Point::operator^(const Point &rhs) const
{
	double midX = (x + rhs.x) / 2;
	double midY = (y + rhs.y) / 2;
	
	Point midPt(midX, midY);
	return midPt;
}
/******************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by another Point

	\param rhs
		The second Point to translate the current Point by
	
	\return Point&
		The reference to the new point after translation
*/
/******************************************************************************/
Point& Point::operator+=(const Point &rhs)
{
	x += rhs.x;
	y += rhs.y;
	
	return *this;
}
/******************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by a double

	\param rhs
		The double value to translate the current Point by
	
	\return Point
		The value of the new point after translation
*/
/******************************************************************************/
Point& Point::operator+=(const double rhs)
{
	x += rhs;
	y += rhs;
	
	return *this;
}
/******************************************************************************/
/*!
	\brief
		Calculates the negative translation of the current Point by a double

	\param rhs
		The double value to negatively translate the current Point by
	
	\return Point&
		The reference to the new point after translation
*/
/******************************************************************************/
Point Point::operator-(const double rhs) const
{
	double newX = x - rhs;
	double newY = y - rhs;
	
	Point newPt(newX, newY);
	return newPt;
}
/******************************************************************************/
/*!
	\brief
		The pre-increment operator to translate by one in both axis to the 
		current point
	
	\return Point&
		The reference to the new point after translation
*/
/******************************************************************************/
Point& Point::operator++()
{
	++x;
	++y;
	return *this;
}
/******************************************************************************/
/*!
	\brief
		The post-increment operator to translate by one in both axis to the
		current Point
	
	\return Point
		The value of the old point before translation
*/
/******************************************************************************/
Point Point::operator++(int)
{
	Point newPt(*this);
	++x;
	++y;
	return newPt;
}
/******************************************************************************/
/*!
	\brief
		Decrements the Point, and returns the reference to it
	
	\return Point&
		The reference to the Point after decrement
*/
/******************************************************************************/
Point& Point::operator--()
{
	--x;
	--y;
	return *this;
}
/******************************************************************************/
/*!
	\brief
		Decrement the Point, but returns the value before decrement
	
	\return Point
		The value of the old point before translation
*/
/******************************************************************************/
Point Point::operator--(int)
{
	Point newPt(*this);
	--x;
	--y;
	return newPt;
}
/******************************************************************************/
/*!
	\brief
		Unary negation which negates the value of the Point
	
	\return Point
		The new Point after the negation
*/
/******************************************************************************/
Point Point::operator-() const
{
	double newX = x * -1;
	double newY = y * -1;
	
	Point newPt(newX, newY);
	return newPt;
}
/******************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by a Point

	\param rhs
		The Point value that is translated by the Point
	
	\return Point
		The value of the new point after translation
*/
/******************************************************************************/
Point Point::operator+(const Point &rhs) const
{
	double newX = x + rhs.x;
	double newY = y + rhs.y;
	
	Point newPt(newX, newY);
	return newPt;
}
/******************************************************************************/
/*!
	\brief
		Calculates the translation of the current Point by a double

	\param rhs
		The double value to translate the current Point by
	
	\return Point
		The value of the new point after translation
*/
/******************************************************************************/
Point Point::operator+(const double rhs) const
{
	double newX = x + rhs;
	double newY = y + rhs;
	
	Point newPt(newX, newY);
	return newPt;
}
/******************************************************************************/
/*!
	\brief
		Calculates the scaling of the Point by a double value

	\param rhs
		The double value to scale the current Point by
	
	\return Point
		The value of the new Point after scaling
*/
/******************************************************************************/
Point Point::operator*(const double rhs) const
{
	double newX = x * rhs;
	double newY = y * rhs;
	
	Point newPt(newX, newY);
	return newPt;
}

///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

/******************************************************************************/
/*!
	\brief
		The overloading of << in the ostream to print out the Point when input it
		into the ostream

	\param cout
		The ostream that is printing out the value of the Point
		
	\param rhs
		The Point to print out value
	
	\return std::ostream&
		The reference to the ostream after adding in Point
*/
/******************************************************************************/
std::ostream& operator<<(std::ostream& cout, const Point& rhs)
{
	cout << "(" << rhs.x << ", " << rhs.y << ")";
	
	return cout;
}
/******************************************************************************/
/*!
	\brief
		The overloading of >> in the istream to take in input to calculate a Point

	\param cin
		The istream that is accepting values of the Point
		
	\param rhs
		The Point to takae in values from the istream
	
	\return std::istream&
		The reference to the istream after giving values of to the Point
*/
/******************************************************************************/
std::istream& operator>>(std::istream& cin, Point &rhs) 
{
	cin >> rhs.x;
	cin >> rhs.y;
	return cin;
}


///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)

/******************************************************************************/
/*!
	\brief
		Calculates the translation of the Point by a double

	\param lhs
		The double value to translate
		
	\param rhs
		The Point value to translate
	
	\return Point
		The value of the new point after translation
*/
/******************************************************************************/
Point operator+(const double lhs, const Point &rhs)
{
	Point newPt(rhs);
	newPt += lhs;
	return newPt;
}
/******************************************************************************/
/*!
	\brief
		Calculates the scale of the Point by a double

	\param lhs
		The double value to scale
		
	\param rhs
		The Point value to scale
	
	\return Point
		The value of the new point after scaling
*/
/******************************************************************************/
Point operator*(const double lhs, const Point &rhs)
{
	Point newPt(rhs);
	return newPt * lhs;
}

} // namespace CS170



