/******************************************************************************/
/*!
\file Point.cpp 
\author Chan Yong Ching Claudia 
\par email: c.yongchingclaudia\@digipen.edu 
\par DigiPen login: c.yongchingclaudia 
\par Course: CS170 
\par Assignment 5
\date 24/06/2019 
\brief This file contains the implementation of the following functions for the 
Point assignment. This file contains the implementations of the operators as 
defined in the interface for the class Point in Point.h. 
The Point class can be used to represent a point in the Cartesian coordinate 
system. The overloaded operators can be used to perform algebraic operations on 
points including: rotation, scaling, translation, addition, and subtraction. 
It can also be used to find the distance or midpoint to two points. 
Functions include: 
Point()
Point(double x, double y)
~Point()
operator%(double deg) const
operator-(const Point & point) const
operator^(const Point & point) const
operator+=(Point point)
operator+=(double pt)
operator-(double pt)
operator++()
operator++(int unused)
operator--()
operator--(int unused)
operator-() const
operator+(const Point & point) const
operator+(double x) const
operator*(double x) const
operator<<(std::ostream &lhs, const Point &rhs)
operator>>(std::istream &lhs, Point &rhs)
DegreesToRadians(double degrees)
RadiansToDegrees(double radians)
operator+(double lhs, Point & rhs)
operator*(double lhs, Point & rhs)
Hours spent on this assignment: 8
Specific portions that gave you the most trouble: rotation
*/
/******************************************************************************/ 

#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
/******************************************************************************/
/*!
*\fn            double Point::DegreesToRadians(double degrees) const

*\brief         converts degree to radian

*\param         degrees - value to convert

*\return        return the value in radian mode
*/
/******************************************************************************/

double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

/******************************************************************************/
/*!
*\fn            double Point::RadiansToDegrees(double radians) const

*\brief         converts radian to degree

*\param         radians - value to convert

*\return        return the value in degree mode
*/
/******************************************************************************/

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 

/******************************************************************************/
/*!
*\fn            Point::Point()

*\brief         default constructor creating a point with a x and y at (0, 0)
*/
/******************************************************************************/

Point::Point()
{
  this->x = 0;
  this->y = 0;
}

/******************************************************************************/
/*!
*\fn            Point::Point(double x, double y)

*\brief         conversion constructor that takes in 2 doubles used to
                initialise a point's
*/
/******************************************************************************/

Point::Point(double x, double y)
{
  this->x = x;
  this->y = y;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator%(double deg) const

*\brief         Rotates a point about the origin by deg. function will convert
                deg into radian before using for cos and sin. if a coordinate is
                0, consider precision error and force negation.

*\param         deg - degree to rotate the point by

*\return        return a new Point
*/
/******************************************************************************/

Point Point::operator%(double deg) const
{
  Point newpoint = *this;
  double degree = DegreesToRadians(deg);
  newpoint.x = ( (cos(degree) * x) - (sin(degree) * y) );
  newpoint.y = ( (sin(degree) *x) + (cos(degree) * y) );
  
  if (newpoint.x <0.0 && newpoint.x > (-1*EPSILON))
      newpoint.x*=-1;
  if (newpoint.y <0.0 && newpoint.y > (-1*EPSILON))
      newpoint.y*=-1;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            double Point::operator-(const Point & point) const

*\brief         Calculates the difference between two points

*\param         point - second point for calculation

*\return        return the distance between the two points
*/
/******************************************************************************/

double Point::operator-(const Point & point) const
{
  double _x;
  double _y;
  double distance;
  _x = pow((this->x - point.x) , 2);
  _y = pow((this->y - point.y) , 2);
  distance = _x + _y;
  return (sqrt(distance));
}

/******************************************************************************/
/*!
*\fn            Point Point::operator^(const Point & point) const

*\brief         Calculates the midpoint between two points

*\param         point - second point for calculation

*\return        return the midpoint between both points
*/
/******************************************************************************/

Point Point::operator^(const Point & point) const
{
  Point newpoint;
  newpoint.x = (this->x + point.x)/2;
  newpoint.y = (this->y + point.y)/2;

  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point & Point::operator+=(Point point) //add two point 

*\brief         Adds the coordinates of two points

*\param         point - second point for calculation

*\return        return a reference to the point that asked for the adding
*/
/******************************************************************************/

Point & Point::operator+=(Point point)
{
  this->x += point.x;
  this->y += point.y;
  return *this;
}

/******************************************************************************/
/*!
*\fn            Point & Point::operator+=(double pt)

*\brief         Adds a double to the coordinates of a point

*\param         pt - number used to add to the point

*\return        return a reference to the point that asked for the adding
*/
/******************************************************************************/

Point & Point::operator+=(double pt)
{
  this->x += pt;
  this->y += pt;
  return *this;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator-(double pt)

*\brief         Subtracts a double from a point to get a new point

*\param         pt - number used to subtract from the point

*\return        return a new point
*/
/******************************************************************************/

Point Point::operator-(double pt)
{
  Point newpoint = *this;
  newpoint.x -= pt;
  newpoint.y -= pt;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point & Point::operator++()

*\brief         Pre increment and adds one to both x and y of a point 

*\return        return a reference to the incremented point
*/
/******************************************************************************/

Point & Point::operator++()
{
  this->x += 1;
  this->y += 1;
  return *this;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator++(int unused)

*\brief         post increment and adds one to the x and y of a point

*\param         unused - allows compiler to distinguish this function from the 
                pre increment function

*\return        return a reference to the incremented point
*/
/******************************************************************************/

Point Point::operator++(int unused)
{
  (void) unused;
  Point newpoint = *this;
  this->x += 1;
  this->y += 1;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point & Point::operator--()

*\brief         Pre decrement and minus one from both x and y of a point 

*\return        return a reference to the decremented point
*/
/******************************************************************************/

Point & Point::operator--()
{
  this->x -= 1;
  this->y -= 1;
  return *this;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator++(int unused)

*\brief         post decrement and minus one from the x and y of a point

*\param         unused - allows compiler to distinguish this function from the 
                pre decrement function

*\return        return a reference to the decremented point
*/
/******************************************************************************/

Point Point::operator--(int unused)
{
  (void) unused;
  Point newpoint = *this;
  this->x -= 1;
  this->y -= 1;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator-() const

*\brief         turns a positive coordinate negative, keeping its numeric value

*\return        return a new point
*/
/******************************************************************************/

Point Point::operator-() const
{
  Point newpoint = *this;;
  newpoint.x *= -1;
  newpoint.y *= -1;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator+(const Point & point) const

*\brief         adds two point by adding both their x to get a new x coordinate,
                and both their y to get a new y coordinate

*\param         point - second point used for adding

*\return        return a new point
*/
/******************************************************************************/

Point Point::operator+(const Point & point) const
{
  Point newpoint = *this;
  newpoint.x += point.x;
  newpoint.y += point.y;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator+(double val) const

*\brief         create a new point by adding x to the called point's x and y

*\param         val - double used for adding 

*\return        return a new point
*/
/******************************************************************************/

Point Point::operator+(double val) const
{
  Point newpoint = *this;
  newpoint.x += val;
  newpoint.y += val;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point operator+(double lhs, Point & rhs)

*\brief         create a new point by adding a double to a point's x and y

*\param         lhs - double used for adding 

*\param         rhs - point used for adding and to get an initial x and y

*\return        return a new point
*/
/******************************************************************************/

Point operator+(double lhs, Point & rhs)
{
  Point newpoint = rhs;
  newpoint += lhs;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point Point::operator*(double val) const

*\brief         create a new point by multiplying a double to the called point's
                x and y

*\param         val - double used for multiplying 

*\return        return a new point
*/
/******************************************************************************/

Point Point::operator*(double val) const
{
  Point newpoint = *this;
  newpoint.x *= val;
  newpoint.y *= val;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            Point operator*(double lhs, Point & rhs)

*\brief         create a new point by multiplying a double to the called point's 
                x and y

*\param         lhs - double used for multiplying 

*\param         rhs - point used for multiplying and to get an initial x and y

*\return        return a new point
*/
/******************************************************************************/

Point operator*(double lhs, Point & rhs)
{
  Point newpoint;
  newpoint = rhs * lhs;
  return newpoint;
}

/******************************************************************************/
/*!
*\fn            std::ostream & operator<<(std::ostream &lhs, const Point &rhs)

*\brief         overloading the << function to allow the Point class to be 
                printed on a screen

*\param         lhs - ostream object used to push out a Point object

*\param         rhs - point object that requires printing

*\return        return an ostream object
*/
/******************************************************************************/

std::ostream & operator<<(std::ostream &lhs, const Point &rhs)
{
  lhs << "(" <<rhs.x << ", " <<rhs.y << ")";
  return lhs;
}

/******************************************************************************/
/*!
*\fn            std::istream & operator>>(std::istream &lhs, Point &rhs)

*\brief         overloading the >> function to allow values to be registered in 
                the Point class

*\param         lhs - sstream object used to take in values for a Point class

*\param         rhs - point object that is going to take from the istream

*\return        return an istream object
*/
/******************************************************************************/

std::istream & operator>>(std::istream &lhs, Point &rhs)
{
  lhs >> rhs.x >> rhs.y;
  return lhs;
}

///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)




///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)



} // namespace CS170



