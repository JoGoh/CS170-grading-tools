/******************************************************************************/
/*!
\file Point.cpp 
\author Chan Yong Ching Claudia 
\par email: c.yongchingclaudia\@digipen.edu 
\par DigiPen login: c.yongchingclaudia 
\par Course: CS170 
\par Assignment 5
\date 24/06/2019 
\brief This file contains the implementation of the following functions for the 
Point assignment. This file contains the implementations of the operators as 
defined in the interface for the class Point in Point.h. 
The Point class can be used to represent a point in the Cartesian coordinate 
system. The overloaded operators can be used to perform algebraic operations on 
points including: rotation, scaling, translation, addition, and subtraction. 
It can also be used to find the distance or midpoint to two points. 
Functions include: 
Point()
Point(double x, double y)
~Point()
operator%(double deg) const
operator-(const Point & point) const
operator^(const Point & point) const
operator+=(Point point)
operator+=(double pt)
operator-(double pt)
operator++()
operator++(int unused)
operator--()
operator--(int unused)
operator-() const
operator+(const Point & point) const
operator+(double x) const
operator*(double x) const
operator<<(std::ostream &lhs, const Point &rhs)
operator>>(std::istream &lhs, Point &rhs)
DegreesToRadians(double degrees)
RadiansToDegrees(double radians)
operator+(double lhs, Point & rhs)
operator*(double lhs, Point & rhs)
Hours spent on this assignment: 8
Specific portions that gave you the most trouble: rotation
*/
/******************************************************************************/ 

////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)

        // Overloaded operators (14 member functions)
        
        // Overloaded operators (2 friend functions)
      Point();
      Point(double x, double y);
      ~Point() = default;
      Point operator%(double deg) const;
      double operator-(const Point & point) const;
      Point operator^(const Point & point) const;
      Point & operator+=(Point point); 
      Point & operator+=(double pt); 
      Point operator-(double pt);
      Point & operator++();
      Point operator++(int unused);
      Point & operator--();
      Point operator--(int unused);
      Point operator-() const;
      Point operator+(const Point & point) const;
      Point operator+(double val) const;
      Point operator*(double val) const;
      friend std::ostream & operator<<(std::ostream &lhs, const Point &rhs);
      friend std::istream & operator>>(std::istream &lhs, Point &rhs);

        
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
    Point operator+(double lhs, Point & rhs);
    Point operator*(double lhs, Point & rhs);
    // Overloaded operators (2 non-member, non-friend functions)
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
