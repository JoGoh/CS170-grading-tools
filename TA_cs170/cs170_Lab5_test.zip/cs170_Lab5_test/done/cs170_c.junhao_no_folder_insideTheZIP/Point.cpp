/******************************************************************************/
/*!
\file               Point.cpp
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab05
\par Course:        CS170
\date:              10/06/2019
\brief
        This file contains the implementation of the following
        functions for the Lab05.
        
Functions include:
	Point();                    //Default Constructor
	Point(double X,double Y); //Parameterized Constructor

	// Overloaded operators (14 member functions)
	Point operator%(double);  //Rotation
	double operator-(Point);  //Distance(Binary Operator)
	Point operator^(Point);   //Midpoint
	Point& operator+=(Point);  //Translation
	Point& operator+=(double); //Translation
	Point operator-(double); //Translation
	Point& operator++();  //Pre Increment
	Point operator++(int);  //Post Increment
	Point& operator--();  //Pre Decrement
	Point operator--(int);  //Post Decrement
	Point operator-();   //Negation
	Point operator+(Point); //Translation
	Point operator+(double); //Translation
	Point operator*(double); //Scale
	
	// Overloaded operators (2 friend functions)
	friend std::ostream& operator<<(std::ostream&, Point);
	friend std::istream& operator>>(std::istream&, Point&);
	
	// Helper functions
	double DegreesToRadians(double degrees) const;
	double RadiansToDegrees(double radians) const;

    // Overloaded operators (2 non-member, non-friend functions)
    Point operator+(double, Point);  //Translation
    Point operator*(double, Point);  //Scale

Hours spent on this assignment: 6hr
Specific portions that gave you the most trouble: ostream, istream
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 

    /**************************************************************************/
    /*!
    \fn             double Point::DegreesToRadians(double degrees) const
    \brief          Convert degrees to radians
    \param degrees  The degrees to convert to radian
    */
    /**************************************************************************/
    double Point::DegreesToRadians(double degrees) const
    {
      return (degrees * PI / 180.0);
    }

    /**************************************************************************/
    /*!
    \fn             double Point::RadiansToDegrees(double radians) const
    \brief          Convert Radian to Degrees
    \param radians  The radian to convert
    */
    /**************************************************************************/
    double Point::RadiansToDegrees(double radians) const
    {
      return (radians * 180.0 / PI);
    }

///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
//  2 constructors    

    /**************************************************************************/
    /*!
    \fn             Point::Point()
    \brief          Default Constructor
    */
    /**************************************************************************/
    Point::Point() 
         :x(0), y(0)
    {
             
    }
    
    /**************************************************************************/
    /*!
    \fn             Point::Point(double X,double Y)
    \brief          Parameterized Constructor
    \param  X       The value to initialized x with
    \param  Y       The value to initialized y with
    */
    /**************************************************************************/    
    Point::Point(double X,double Y)
         :x(X) ,y(Y)
    {
             
    }
    
// 14 operators
    /**************************************************************************/
    /*!
    \fn             Point Point::operator%(double degree)
    \brief          Rotates a Point about the origin by the 
                    specified number of degrees. 
    \param  degree  The amount of degree rotate by.
    \return 
            newPoint The point after rotating
    */
    /**************************************************************************/
    Point Point::operator%(double degree) const
    {
        double rad = DegreesToRadians(degree);
        Point newPoint{};
        
        newPoint.x = x * std::cos(rad) - y * std::sin(rad);
        newPoint.y = y * std::cos(rad) + y * std::cos(rad);
        
        if(newPoint.x > -EPSILON && newPoint.x < EPSILON)
            newPoint.x = 0.0;
        if(newPoint.y > -EPSILON && newPoint.y < EPSILON)
            newPoint.y = 0.0;
        
        return newPoint;
    }
    
    /**************************************************************************/
    /*!
    \fn             double Point::operator-(Point pt)
    \brief          Calculates distance between two points
    \param  pt      The point that it is away from.
    */
    /**************************************************************************/
    double Point::operator-(Point pt) const
    {
        double x_Dist = x - pt.x;
        double y_Dist = y - pt.y;
        double distance = sqrt( (x_Dist * x_Dist) + (y_Dist * y_Dist) );
        
        return distance;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator^(Point pt)
    \brief           Calculates midPoints between two points
    \param  pt       The other Point.
    \return
            newPoint The point that has the location inbetween these two points.
    */
    /**************************************************************************/
    Point Point::operator^(Point pt) const
    {
        Point newPoint{};
        
        newPoint.x = (x + pt.x) * 0.5;
        newPoint.y = (y + pt.y) * 0.5;
        
        return newPoint;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point& Point::operator+=(Point pt)
    \brief           Adds two points
    \param  pt       The other Point.
    \return
            newPoint The point that has the location inbetween these two points.
    */
    /**************************************************************************/
    Point& Point::operator+=(Point pt)
    {
        x += pt.x;
        y += pt.y;
        
        return *this;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point& Point::operator+=(double amount)
    \brief           Adds two points
    \param  amount   The amount to add.
    \return
            this     The Point that was changed. C++ convention
    */
    /**************************************************************************/
    Point& Point::operator+=(double amount)
    {
        x += amount;
        y += amount;
        
        return *this;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator-(double amount)
    \brief           Translation, subtracts from a Point
    \param  amount   The amount to subtract from.
    \return
            newPoint The point that has the location of the translation
    */
    /**************************************************************************/
    Point Point::operator-(double amount) const
    {
        Point newPoint{};
        newPoint.x = x - amount;
        newPoint.y = y - amount;
        
        return newPoint;
    }
    /**************************************************************************/
    /*!
    \fn              Point& Point::operator++()
    \brief           Pre Increment of a Point
    \return
            this     The Point that was changed. C++ convention
    */
    /**************************************************************************/
    Point& Point::operator++()
    {
        ++x;
        ++y;
        
        return *this;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator++(int)
    \brief           Post Increment of a Point
    \return
            newPoint The Point that contains the value before it was incremented
    */
    /**************************************************************************/
    Point Point::operator++(int)
    {
        Point newPoint{x++,y++};        
        return newPoint;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point& Point::operator--()
    \brief           Pre Decrement of a Point
    \return
            this     The Point that was changed. C++ convention
    */
    /**************************************************************************/
    Point& Point::operator--()
    {
        --x;
        --y;
        
        return *this;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator--(int)
    \brief           Post Decrement of a Point
    \return
            newPoint The Point that contains the value before it was decremented
    */
    /**************************************************************************/
    Point Point::operator--(int)
    {
        Point newPoint{x--,y--};        
        return newPoint;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator-()
    \brief           Negation of the values of the point
    \return
            newPoint The Point that contains the value after negation.
    */
    /**************************************************************************/
    Point Point::operator-() const
    {
        Point newPoint{x,y};
        newPoint.x = -x;
        newPoint.y = -y;
        
        return newPoint;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator+(Point pt)
    \brief           Translation
    \param   pt      The point to add with
    \return
            newPoint The Point that contains the value after adding up.
    */
    /**************************************************************************/
    Point Point::operator+(Point pt) const
    {
        Point newPoint{x,y};
        
        newPoint.x += pt.x;
        newPoint.y += pt.y;
        
        return newPoint;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator+(double amount)
    \brief           Translation
    \param  amount   The amount to add with
    \return
            newPoint The Point that contains the value after adding up.
    */
    /**************************************************************************/
    Point Point::operator+(double amount) const
    {
        Point newPoint{x,y};
        
        newPoint.x += amount;
        newPoint.y += amount;
        
        return newPoint;
    }
    
    /**************************************************************************/
    /*!
    \fn              Point Point::operator*(double amount)
    \brief           Scale point value with that amount
    \param   amount  The amount to scale with
    \return
            newPoint The Point that contains the value after scaling up.
    */
    /**************************************************************************/
    Point Point::operator*(double amount) const
    {
        Point newPoint{x,y};
        
        newPoint.x = x * amount;
        newPoint.y = y * amount;
        
        return newPoint;
    }
    
///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

    /**************************************************************************/
    /*!
    \fn              std::ostream& operator<<(std::ostream& oStream, Point pt)
    \brief           Outputs the Point value
    \param  oStream  The stream to output
    \param  pt       The Point to have the value output with
    */
    /**************************************************************************/
    std::ostream& operator<<(std::ostream& oStream, Point pt)
    {
        oStream << "(" << pt.x << ", " << pt.y << ")" ;
        
        return oStream;
    }
    
    /**************************************************************************/
    /*!
    \fn              std::istream& operator>>(std::istream& iStream, Point& pt)
    \brief           Takes in the doubles and set as the point value.
    \param iStream   The input stream to extract from
    \param pt        The Point to have the value output with
    */
    /**************************************************************************/
    std::istream& operator>>(std::istream& iStream, Point& pt)
    {
        iStream >> pt.x >> pt.y;
        
        return iStream;
    }

///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
    /**************************************************************************/
    /*!
    \fn              Point operator+(double amount, Point pt)
    \brief           Add amount to the Point.
    \param  amount   The amount to add with
    \param  pt       The pt to translate with
    \return
            newPoint The Point that contains the value after scaling up.
    */
    /**************************************************************************/
    Point operator+(double amount, Point pt)
    {
        Point newPoint;

        newPoint = pt + amount;
        
        return newPoint;
    }
    /**************************************************************************/
    /*!
    \fn              Point operator*(double amount, Point pt)
    \brief           Scaling the pt value
    \param   amount  The amount to scale with
    \param   pt      The pt to translate with
    \return
            newPoint The Point that contains the value after scaling up.
    */
    /**************************************************************************/
    Point operator*(double amount, Point pt)
    {
        Point newPoint;
        
        newPoint = pt * amount;
        
        return newPoint;
    }
} // namespace CS170