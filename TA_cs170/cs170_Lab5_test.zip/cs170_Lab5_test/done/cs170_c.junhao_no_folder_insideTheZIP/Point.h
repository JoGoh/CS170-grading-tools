/******************************************************************************/
/*!
\file               Point.h
\author             Chue Jun Hao
\par email:         c.junhao\@digipen.edu
\par DigiPen login: c.junhao
\par Assignment     Lab05
\par Course:        CS170
\date:              10/06/2019
\brief
        This file contains the declaration of the following
        functions for the Lab05.
        
Functions include:
	Point();                  //Default Constructor
	Point(double X,double Y); //Parameterized Constructor

	// Overloaded operators (14 member functions)
	Point operator%(double);   //Rotation
	double operator-(Point);   //Distance(Binary Operator)
	Point operator^(Point);    //Midpoint
	Point& operator+=(Point);  //Translation
	Point& operator+=(double); //Translation
	Point operator-(double);   //Translation
	Point& operator++();       //Pre Increment
	Point operator++(int);     //Post Increment
	Point& operator--();       //Pre Decrement
	Point operator--(int);     //Post Decrement
	Point operator-();         //Negation
	Point operator+(Point);    //Translation
	Point operator+(double);   //Translation
	Point operator*(double);   //Scale
	
	// Overloaded operators (2 friend functions)
	friend std::ostream& operator<<(std::ostream&, Point);
	friend std::istream& operator>>(std::istream&, Point&);
	
	// Helper functions
	double DegreesToRadians(double degrees) const;
	double RadiansToDegrees(double radians) const;

    // Overloaded operators (2 non-member, non-friend functions)
    Point operator+(double, Point);  //Translation
    Point operator*(double, Point);  //Scale

Hours spent on this assignment: 6hr
Specific portions that gave you the most trouble: ostream, istream
*/
/******************************************************************************/

#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
		Point();  				  //Default Constructor
		Point(double X,double Y); //Parameterized Constructor
		
        // Overloaded operators (14 member functions)
        Point operator%(double) const;  //Rotation
		double operator-(Point) const;  //Distance(Binary Operator)
		Point operator^(Point) const;   //Midpoint
		
		Point& operator+=(Point);  //Translation
		Point& operator+=(double); //Translation
		 
		Point operator-(double) const;  //Translation
		
		Point& operator++(); 	 //Pre Increment
		Point operator++(int);   //Post Increment
		
		Point& operator--(); 	 //Pre Decrement
		Point operator--(int);   //Post Decrement
		
		Point operator-()const;       //Negation
		
		Point operator+(Point) const;  //Translation
		Point operator+(double) const; //Translation
		
		Point operator*(double) const; //Scale
		
        // Overloaded operators (2 friend functions)
        friend std::ostream& operator<<(std::ostream&, Point);
		friend std::istream& operator>>(std::istream&, Point&);
		
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

      // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
	Point operator+(double, Point);  //Translation
    Point operator*(double, Point);  //Scale
	
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
