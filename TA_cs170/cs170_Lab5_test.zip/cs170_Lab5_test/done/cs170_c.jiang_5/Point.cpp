/*****************************************************************************/
/*!
\file Point.cpp
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
05
\par Date:
20 June 2019
\par Brief:

	This file contains the implementation of the following functions
	for CS170 Lab 05 - Point Class

	Functions given: \n
	double DegreesToRadians(double degrees) const; \n
  double RadiansToDegrees(double radians) const; \n
	
	\n
	Functions written: \n 
	Point (double a, double b); \n
	Point (const Point& rhs); \n
	Point operator%(double degrees); \n
	double operator-(const Point& rhs) const; \n
	Point operator^(const Point& rhs) const; \n
	Point& operator+=(const Point& rhs); \n
	Point& operator+=(double value); \n
	Point operator-(double value) const; \n
	Point& operator++(); \n
	Point operator++(int); \n
	Point& operator--(); \n
	Point operator--(int); \n
	Point operator-() const; \n
	Point operator+(const Point& rhs) const; \n
	Point operator+(double value) const; \n
	Point operator*(double value) const; \n
	friend std::ostream& operator<<(std::ostream& out, const Point& rhs); \n
	friend std::istream& operator>>(std::istream& in, Point& rhs); \n
	Point operator+(double val, Point& rhs); \n
	Point operator*(double val, Point& rhs); \n

	\n 
	Hours spent on this assignment: 
	2.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 

/*****************************************************************************/
/*!
	\brief Converts degrees to radians

	\param degrees
		Double value in degrees format.
	\return radians
		Double value in radians format.
*/
/*****************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

/*****************************************************************************/
/*!
	\brief Converts radians to degrees

	\param radians
		Double value in radians format.
	\return degrees
		Double value in degrees format.
*/
/*****************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 

/*****************************************************************************/
/*!
	\brief Default Constructor
*/
/*****************************************************************************/
Point::Point(): x(0), y(0) {}

/*****************************************************************************/
/*!
	\brief Paramatrized Constructor

	\param a
		Double value that stores into x.
	\param b
		Double value that stores into y.
*/
/*****************************************************************************/
Point::Point(double a, double b): x(a), y(b) {}

/*****************************************************************************/
/*!
	\brief Rotation % operator overload
	
	Member function that rotates a Point about the origin 
	by the specified number of degrees. Returns a new Point.
	\param degrees
		Degrees to rotate by, in degrees format.
	\retval retpt
		Returns the Point class that has been rotated.
*/
/*****************************************************************************/
Point Point::operator%(double degrees) const {
	
	double radian = DegreesToRadians(degrees);
	
	double new_x = std::cos(radian) * x - std::sin(radian) * y ;
	double new_y = std::sin(radian) * x + std::cos(radian) * y ;
		
	if (new_x > -EPSILON && new_x < EPSILON) {
		new_x = 0.0;
	}
	
	if (new_y > -EPSILON && new_y < EPSILON) {
		new_y = 0.0;
	}
	
	Point retpt(new_x, new_y);
	
	return retpt;
} //end function

/*****************************************************************************/
/*!
	\brief Distance - operator overload
	
	Member function that calculates the difference between 
	two Points and returns the distance (type double).
	\param rhs
		The second point on the right hand side.
	\return distance
		Distance between the points.
*/
/*****************************************************************************/
double Point::operator-(const Point& rhs) const {
	return std::sqrt( (rhs.x - x)*(rhs.x - x) +
										(rhs.y - y)*(rhs.y - y) );
}

/*****************************************************************************/
/*!
	\brief Midpoint ^ operator overload
	
	Member function that calculates the midpoint between two Points. 
	Returns a new Point.
	\param rhs
		The second point on the right hand side.
	\retval retpt
		The mid-point between both points.
*/
/*****************************************************************************/
Point Point::operator^(const Point& rhs) const {
	double midpt_x = (x + rhs.x) / 2;
	double midpt_y = (y + rhs.y) / 2;

	Point retpt(midpt_x, midpt_y);
	
	return retpt;
}

/*****************************************************************************/
/*!
	\brief Translation += operator overload
	
	Adds two Points and returns a reference 
	to the lefthand operand which has been modified. 
	\param rhs
		The second point on the right hand side.
	\retval this
		The lefthand operand after the operation.
*/
/*****************************************************************************/
Point& Point::operator+=(const Point& rhs) {
	x += rhs.x;
	y += rhs.y;
	return *this;
}

/*****************************************************************************/
/*!
	\brief Translation += operator overload
	
	Adds a Point and a double and returns a reference 
	to the lefthand operand which has been modified. 
	\param value
		Double value to be added to the Point.
	\retval this
		The lefthand operand after the operation.
*/
/*****************************************************************************/
Point& Point::operator+=(double value) {
	x += value;
	y += value;
	return *this;
}

/*****************************************************************************/
/*!
	\brief Translation - operator overload
	
	Member function that subtracts a double from a Point 
	and returns a new Point. 
	\param value
		Double value to be subtracted from the Point.
	\retval retpt
		The new Point after the operation.
*/
/*****************************************************************************/
Point Point::operator-(double value) const {
	double new_x = x - value;
	double new_y = y - value;
	
	Point retpt(new_x, new_y);
	
	return retpt;
}

/*****************************************************************************/
/*!
	\brief Pre-Increment ++ operator overload
	
	Adds one to the x/y values of the object. 
	Pre-increment returns a reference to the incremented Point.
	\retval this
		The lefthand operand after the operation.
*/
/*****************************************************************************/
Point& Point::operator++() {
	++(x);
	++(y);

	return *this;
}

/*****************************************************************************/
/*!
	\brief Post-Increment ++ operator overload
	
	Adds one to the x/y values of the object. 
	Post-increment returns a new Point with the value of the Point before
	increment.
	\retval retpt
		A copy of the lefthand operand before the operation.
*/
/*****************************************************************************/
Point Point::operator++(int) {
	
	Point retpt(x, y);
	++(x);
	++(y);
	
	return retpt;
}

/*****************************************************************************/
/*!
	\brief Pre-Decrement -- operator overload
	
	Subtracts one from the x/y values of the object. 
	Pre-decrement returns a reference to the decremented Point.
	\retval this
		The lefthand operand after the operation.
*/
/*****************************************************************************/
Point& Point::operator--() {
	--(x);
	--(y);
	
	return *this;
}

/*****************************************************************************/
/*!
	\brief Post-Decrement -- operator overload
	
	Subtracts one from the x/y values of the object. 
	Post-decrement returns a new Point with the value of the Point before
	decrement.
	\retval retpt
		A copy of the lefthand operand before the operation.
*/
/*****************************************************************************/
Point Point::operator--(int) {
	Point retpt(x, y);
	--(x);
	--(y);
	
	return retpt;
}

/*****************************************************************************/
/*!
	\brief Unary Negation - operator overload
	
	Member function that returns a new Point with the 
	x/y values of input Point negated.
	\retval retpt
		A copy of the lefthand operand with negated values.
*/
/*****************************************************************************/
Point Point::operator-() const {
	double neg_x = -1 * (x);
	double neg_y = -1 * (y);
	
	Point retpt(neg_x, neg_y);
	
	return retpt;
}

/*****************************************************************************/
/*!
	\brief Translation + operator overload
	
	Adds two Points and returns a new Point.
	\param rhs
		The second Point.
	\retval retpt
		The new Point with the added values.
*/
/*****************************************************************************/
Point Point::operator+(const Point& rhs) const {
	double new_x = x + rhs.x;
	double new_y = y + rhs.y;
	
	Point retpt(new_x, new_y);
	
	return retpt;
}

/*****************************************************************************/
/*!
	\brief Translation + operator overload
	
	Adds a Point and a double and returns a new Point.
	\param value
		The value to be added to the Point.
	\retval retpt
		The new Point with the added values.
*/
/*****************************************************************************/
Point Point::operator+(double value) const {
	double new_x = x + value;
	double new_y = y + value;
	
	Point retpt(new_x, new_y);
	
	return retpt;
}

/*****************************************************************************/
/*!
	\brief Scale * operator overload
	
	Multiplies a Point by some numeric factor of type 
	double and returns a new Point.
	\param value
		The value to be multiplied with the Point.
	\retval retpt
		The new Point with the multiplied values.
*/
/*****************************************************************************/
Point Point::operator*(double value) const {
	double new_x = x * value;
	double new_y = y * value;
	
	Point retpt(new_x, new_y);
	
	return retpt;
}


///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

/*****************************************************************************/
/*!
	\brief Output << operator overload
	
	Outputs a Point in the form of a string: (x, y), 
	where x and y are the coordinates, e.g. (4, 7). 
	This is a friend function.
	\param out
		The output stream that the Point should be written into.
	\param rhs
		The Point provided.
	\retval out
		The reference to the output stream with values written.
*/
/*****************************************************************************/
std::ostream& operator<<(std::ostream& out, const Point& rhs) {

	out << "(" << rhs.x << ", " << rhs.y << ")";
	
	return out;
}

/*****************************************************************************/
/*!
	\brief Input >> operator overload
	
	Inputs a Point. 
	Allows two numbers (separated by whitespace) to be entered, e.g. 4 7. 
	This is a friend function.
	\param in
		The input stream to be read from.
	\param rhs
		The Point provided.
	\retval in
		The reference to the input stream with values written.
*/
/*****************************************************************************/
std::istream& operator>>(std::istream& in, Point &rhs) {

	in >> rhs.x;
	in >> rhs.y;
	
	return in;
}

///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)

/*****************************************************************************/
/*!
	\brief Translation + operator overload
	
	Adds a Point and a double and returns a new Point.
	\param value
		The value to be added to the Point.
	\param rhs
		Reference to the Point.
	\retval retpt
		The new Point with the added values.
*/
/*****************************************************************************/
Point operator+(double value, Point& rhs) {

	Point retpt;
	
	retpt = rhs + value;
	
	return retpt;
}


/*****************************************************************************/
/*!
	\brief Scale * operator overload
	
	Multiplies a Point by some numeric factor of type 
	double and returns a new Point.
	\param value
		The value to be multiplied with the Point.
	\param rhs
		Reference to the Point.
	\retval retpt
		The new Point with the multiplied values.
*/
/*****************************************************************************/
Point operator*(double value, Point& rhs) {

	Point retpt = rhs * value;
	
	return retpt;
}


} // namespace CS170



