/*****************************************************************************/
/*!
\file Point.h
\par Author:
Jiang Chuqiao
\par Email:
c.jiang\@digipen.edu
\par DigiPen login:
c.jiang
\par Course:
CS170
\par Lab:
05
\par Date:
20 June 2019
\par Brief:

	This file contains the header of functions implemented in Point.cpp
	for CS170 Lab 05 - Point Class

	Functions given: \n
	double DegreesToRadians(double degrees) const; \n
  double RadiansToDegrees(double radians) const; \n
	
	\n
	Functions written: \n 
	Point (double a, double b); \n
	Point (const Point& rhs); \n
	Point operator%(double degrees); \n
	double operator-(const Point& rhs) const; \n
	Point operator^(const Point& rhs) const; \n
	Point& operator+=(const Point& rhs); \n
	Point& operator+=(double value); \n
	Point operator-(double value) const; \n
	Point& operator++(); \n
	Point operator++(int); \n
	Point& operator--(); \n
	Point operator--(int); \n
	Point operator-() const; \n
	Point operator+(const Point& rhs) const; \n
	Point operator+(double value) const; \n
	Point operator*(double value) const; \n
	friend std::ostream& operator<<(std::ostream& out, const Point& rhs); \n
	friend std::istream& operator>>(std::istream& in, Point& rhs); \n
	Point operator+(double val, Point& rhs); \n
	Point operator*(double val, Point& rhs); \n
	
	\n 
	Hours spent on this assignment: 
	2.0 \n 
	Specific portions that gave you the most trouble: 
	None.
*/
/*****************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
      // Constructors (2)
			Point();
			Point(double a, double b);
			
      // Overloaded operators (14 member functions)
			Point operator%(double degrees) const;
			double operator-(const Point& rhs) const;
			Point operator^(const Point& rhs) const;
			Point& operator+=(const Point& rhs);
			Point& operator+=(double value);
			Point operator-(double value) const;
			Point& operator++();
			Point operator++(int);
			Point& operator--();
			Point operator--(int);
			Point operator-() const;
			Point operator+(const Point& rhs) const;
			Point operator+(double value) const;
			Point operator*(double value) const;
			
			
      // Overloaded operators (2 friend functions)
      friend std::ostream& operator<<(std::ostream& out, const Point& rhs);
			friend std::istream& operator>>(std::istream& in, Point& rhs);
			
			
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

      // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
		//+ overload, double + point
		Point operator+(double val, Point& rhs); 
		//* overload, double * point
		Point operator*(double val, Point& rhs); 
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
