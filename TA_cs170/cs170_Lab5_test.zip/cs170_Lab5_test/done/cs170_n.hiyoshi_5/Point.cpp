/*****************************************************************************/
/*! 
\file   Point.cpp 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 05
\date   24/06/2019
\brief     
This program contains the various operator overloading functions that are
applied to a 2D point in a two-dimensional cartesian coordinate system. 
*/ 
/*****************************************************************************/

#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

/*****************************************************************************/

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

/*****************************************************************************/
/*!

\fn DegreesToRadians
 
\brief
This private member function will convert a degree value to a radian value.

\return
Returns a double.

*/ 
/*****************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

/*****************************************************************************/
/*!

\fn RadiansToDegrees
 
\brief
This private member function will convert a radian value to a degree value.

\return
Returns a double.

*/ 
/*****************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}

/*****************************************************************************/
/*!

\brief
This is the default constructor for the Point object. 

*/ 
/*****************************************************************************/
Point::Point()
{
  x = 0;
  y = 0;
}

/*****************************************************************************/
/*!

\brief
This is the parameterized constructor for the Point object.

*/ 
/*****************************************************************************/
Point::Point(double _x, double _y)
{
  x = _x;
  y = _y;
}

/*****************************************************************************/
/*!

\fn operator%
 
\brief
This overloaded operator member function rotates a point about the origin
by the specified number of degrees and returns a new point. 

\param 
angle - double

\return
Returns a Point object.

*/ 
/*****************************************************************************/
Point Point::operator%(double angle)
{
  double AngleInRad = DegreesToRadians(angle); // Convert degree to radian
  Point result( std::cos(AngleInRad) * x + -std::sin(AngleInRad) * y,
                std::sin(AngleInRad) * x +  std::cos(AngleInRad) * y );
                
  // If value is between -EPSILON and +EPSILON, make it 0.0
  if (result.x > -EPSILON && result.x < EPSILON)
    result.x = 0.0;
  if (result.y > -EPSILON && result.y < EPSILON)
    result.y = 0.0;
  
  return result; // Returns the calculated result
}

/*****************************************************************************/
/*!

\fn operator-
 
\brief
This overloaded operator member function calculates the distance between
two points.

\param
rhs - const reference to Point

\return
Returns a double.

*/ 
/*****************************************************************************/
double Point::operator-(const Point& rhs) const
{
  Point result((x - rhs.x) * (x - rhs.x),  // Perform calculation for x value
               (y - rhs.y) * (y - rhs.y)); // Perform calculation for y value
  
  return sqrt(result.x + result.y); // Return distance between 2 Points
}

/*****************************************************************************/
/*!

\fn operator^
 
\brief
This overloaded operator member function calculates the midpoint between
Two Points. 

\param
rhs - const reference to Point

\return
Returns a Point object. 

*/ 
/*****************************************************************************/
Point Point::operator^(const Point& rhs) const
{
  Point result( (rhs.x + x) / 2, (rhs.y + y) / 2 ); // Calculate midpoint
  
  return result; // Returns the calculated result
}

/*****************************************************************************/
/*!

\fn operator+=
 
\brief
This overloaded operator member function adds two Points together. 

\param
rhs - const reference to Point

\return
Returns a reference to the left hand operand which has been modified. 

*/ 
/*****************************************************************************/
Point& Point::operator+=(const Point& rhs)
{
  x += rhs.x, y += rhs.y; // Adds two points together
  
  return *this; // Returns the first point with new x & y value
}

/*****************************************************************************/
/*!

\fn operator+=
 
\brief
This overloaded operator member function adds a Point and a double together. 

\param
value - double

\return
Returns a reference to the left hand operand which has been modified. 

*/ 
/*****************************************************************************/
Point& Point::operator+=(const double value)
{
  x += value, y += value; // Adds a point's x & y and a value together
  
  return *this; // Returns the point with new x & y value
}

/*****************************************************************************/
/*!

\fn operator-
 
\brief
This overloaded operator member function subtracts a double from a Point.

\param
double - value

\return
Returns a Point object. 

*/ 
/*****************************************************************************/
Point Point::operator-(double value) const
{
  Point result(x - value, y - value); // Subtracts a value from a point
  
  return result; // Returns the calculated result
}

/*****************************************************************************/
/*!

\fn operator++
 
\brief
This overloaded operator member function adds one to the x and y value of
the Point object. It is a pre-increment operator.

\return
Returns a reference to the incremented Point. 

*/ 
/*****************************************************************************/
Point& Point::operator++()
{
  x++; // Add one to the x value of the point
  y++; // Add one to the y value of the point
  
  return *this; // Returns the point with new x & y value
}

/*****************************************************************************/
/*!

\fn operator++
 
\brief
This overloaded operator member function adds one to the x and y value of
the Point object. It is a post-increment operator. 

\param
dummy parameter - int to distinguish between pre and post increment. 

\return
Returns a Point object. 

*/ 
/*****************************************************************************/
Point Point::operator++(int)
{
  Point result(x++, y++); // New point with the before incremented x & y
  
  return result; // Returns the new point
}

/*****************************************************************************/
/*!

\fn operator--
 
\brief
This overloaded operator member function subtracts one from the x and y value
of the Point object. It is a pre-decrement operator. 

\return
Returns a reference to the decremented Point.

*/ 
/*****************************************************************************/
Point& Point::operator--()
{
  x--; // Subtracts one to the x value of the point
  y--; // Subtracts one to the x value of the point
  
  return *this; // Returns the point with new x & y value
}

/*****************************************************************************/
/*!

\fn operator--
 
\brief
This overloaded operator member function subtracts one from the x and y value
of the Point object. It is a post-decrement operator. 

\param
dummy parameter - int to distinguish between pre and post increment. 

\return
Returns a Point object. 

*/ 
/*****************************************************************************/
Point Point::operator--(int)
{
  Point result(x--, y--); // New point with the before decremented x & y
  
  return result; // Returns the new point
}

/*****************************************************************************/
/*!

\fn operator-
 
\brief
This overloaded operator member function negates the x and y values of the
Point object. 

\return
Returns a point object. 

*/ 
/*****************************************************************************/
Point Point::operator-()
{
  Point result(-x, -y); // New point with the negated x & y
  
  return result; // Returns the new point
}

/*****************************************************************************/
/*!

\fn operator+
 
\brief
This overloaded operator member function adds two Points together. 

\param
rhs - const reference to Point

\return
Returns a Point object.

*/ 
/*****************************************************************************/
Point Point::operator+(const Point& rhs) const
{
  Point result(x + rhs.x, y + rhs.y); // Adds two points
  
  return result; // Returns the calculated point
}

/*****************************************************************************/
/*!

\fn operator+
 
\brief
This overloaded operator member function adds a Point and a double together.

\param
value - double 

\return
Returns a Point object. 

*/ 
/*****************************************************************************/
Point Point::operator+(double value) const
{
  Point result(x + value, y + value); // Adds a point and a value
  
  return result; // Returns the calculated point
}

/*****************************************************************************/
/*!

\fn operator*
 
\brief
This overloaded operator member function multiplies a Point by some numeric
factor of type double. 

\param
value - double 

\return
Returns a Point object.

*/ 
/*****************************************************************************/
Point Point::operator*(double value) const
{
  Point result(x * value, y * value); // Multiplies a point and a value
  
  return result; // Returns the calculated point
}

/*****************************************************************************/
/*!

\fn operator<<
 
\brief
This overloaded operator friend function will output a Point in the form
of a string.

\param
os - reference to the ostream object. 
pt - const reference to Point object.

\return
Returns a reference to the original ostream object. 

*/ 
/*****************************************************************************/
std::ostream& operator<<(std::ostream& os, const Point& pt)
{
  os << "(" << pt.x << "," << " " << pt.y << ")"; // format of output
  
  return os; // Returns reference to ostream object
}

/*****************************************************************************/
/*!

\fn operator>>
 
\brief
This overloaded operator friend function will allow two numbers seperated
by white space to be entered as a Point object. 

\param
in - reference to the istream object. 
pt - reference to Point object.

\return
Returns a reference to the original istream object. 

*/ 
/*****************************************************************************/
std::istream& operator>>(std::istream& in, Point& pt)
{
  in >> pt.x; // Takes in the x coordinate of a point
  in >> pt.y; // Takes in the y coordinate of a point
  
  if(in) // If it's a valid input
    return in; // Return reference to the istream object
  else
    pt = Point(); // Set x and y to 0 if it's a invalid input
  
  return in;  // Return reference to the istream object
}

/*****************************************************************************/
/*!

\fn operator+
 
\brief
This overloaded operator function adds a double and a Point together.

\param
value - double
rhs - const reference to Point object

\return
Returns a Point object. 

*/ 
/*****************************************************************************/
Point operator+(double value, const Point& rhs)
{
  Point result = rhs; // Create a new point with the same x and y values
  
  return result + value; // Return the point added with value
}

/*****************************************************************************/
/*!

\fn operator*
 
\brief
This overloaded operator function multiplies a Point by some numeric
factor of type double. 

\param
value - double 
rhs - const reference to Point object

\return
Returns a Point object.

*/ 
/*****************************************************************************/
Point operator*(double value, const Point& rhs)
{
  Point result = rhs; // Create a new point with the same x and y values
  
  return result * value; // Return the point multiplied by value
}


} // namespace CS170
