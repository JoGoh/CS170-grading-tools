/*****************************************************************************/
/*! 
\file   Point.h 
\author Hiyoshi Nobuaki 
\par    email: n.hiyoshi\@digipen.edu 
\par    DigiPen login: n.hiyoshi 
\par    Course: CS170 
\par    Lab 05
\date   24/06/2019
\brief     
This header file contains the Point class and various function prototypes.
*/ 
/*****************************************************************************/

////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
        Point(); // Default constructor
        Point(double _x, double _y); // Parameterized constructor
        
        // Overloaded operators (14 member functions)
        Point operator%(double angle);   // Rotates a point about the origin
        double operator-(const Point& rhs) const;    // Distance of 2 Points
        Point operator^(const Point& rhs) const;     // Midpoint of 2 Points
        Point& operator+=(const Point& rhs);         // Translation of Point
        Point& operator+=(double value);             // Translation of Point
        Point operator-(double value) const;         // Translation of Point
        Point& operator++();    // Pre-Increment x & y coordinate of a Point
        Point operator++(int); // Post-Increment x & y coordinate of a Point
        Point& operator--();    // Pre-Decrement x & y coordinate of a Point
        Point operator--(int); // Post-Decrement x & y coordinate of a Point
        Point operator-();       // Negates both x & y coordinate of a Point
        Point operator+(const Point& rhs) const;     // Translation of Point
        Point operator+(double value) const;         // Translation of Point
        Point operator*(double value) const;               // Scales a Point
        
        // Overloaded operators input and output (2 friend functions)
        friend std::ostream& operator<<(std::ostream& os, const Point& pt);
        friend std::istream& operator>>(std::istream& in, Point& pt);
        
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

      // Helper functions, convert degree to radian and vice versa
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
      // Overloaded operators (2 non-member, non-friend functions)
      Point operator+(double value, const Point& rhs); // Translation of Point
      Point operator*(double value, const Point& rhs);       // Scales a Point
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
