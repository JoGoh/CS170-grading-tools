/******************************************************************************/
/*!
\file Point.h
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par Lab #05
\date 10/06/2019
\brief This file contains the implementation of the Point class to represent
points in a two-dimension Cartesian coordinate system (x, y). This class will
support a number of overload operators to satisfy the requirements.
Functions include:
Point()
Point(double, double)
Point(Point)
~Point()
operator=(Point)
operator+(Point)
operator+(double)
operator-(double)
operator*(double)
operator%(double)
operator^(Point)
operator-(Point)
operator+=(Point)
operator+=(double)
operator++(void)
operator--(void)
operator++(int)
operator--(int)
operator-(void)
operator<<(ostream, Point)
operator>>(istream, Point)
operator+(double, Point)
operator*(double, Point)
Hours spent on this assignment: 6hr
Specific portions that gave you the most trouble:
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (4)
		Point();								// Default Constructor
		Point(double, double);					// Parameterized Constructor
		Point(const Point&);					// Copy Constructor
		~Point();								// Destructor
		
        // Overloaded operators (14 member functions)
        Point& operator=(const Point&);			// Operator = (Copy Assignment)
		Point operator+(const Point&) const;	// Operator + (Point)
		Point operator+(double) const;			// Operator + (double)
		Point operator*(double) const;			// Operator * (double)		
		Point operator-(double) const;			// Operator - (double)
		
		Point operator%(double) const;			// Rotate function
		double operator-(const Point&) const;	// Distance function
		Point operator^(const Point&) const;	// Midpoint function
		
		Point& operator+=(const Point&);		// Operator += (Point)
		Point& operator+=(double);				// Operator += (double)

		Point& operator++(void);				// Operator ++ (pre)
		Point operator++(int);					// Operator ++ (post)
		
		Point& operator--(void);				// Operator -- (pre)
		Point operator--(int);					// Operator -- (post)
		
		Point operator-(void);					// Operator - (Unary)
		
        // Overloaded operators (2 friend functions)
        friend std::ostream& operator<< (std::ostream&, const Point&);
        friend std::istream& operator>> (std::istream&, Point&);
		
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

      // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    Point operator+(double, const Point&);	// Operator + (double into Point)
    Point operator*(double, const Point&);	// Operator * (double into Point)
	
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
