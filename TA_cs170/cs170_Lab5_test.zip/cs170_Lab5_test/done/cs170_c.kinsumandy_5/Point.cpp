/******************************************************************************/
/*!
\file Point.cpp
\author Andy Chan
\par email: c.kinsumandy\@digipen.edu
\par DigiPen login: c.kinsumandy
\par Course: CS170
\par Lab #05
\date 10/06/2019
\brief This file contains the implementation of the Point class to represent
points in a two-dimension Cartesian coordinate system (x, y). This class will
support a number of overload operators to satisfy the requirements.
Functions include:
Point()
Point(double, double)
Point(Point)
~Point()
operator=(Point)
operator+(Point)
operator+(double)
operator-(double)
operator*(double)
operator%(double)
operator^(Point)
operator-(Point)
operator+=(Point)
operator+=(double)
operator++(void)
operator--(void)
operator++(int)
operator--(int)
operator-(void)
operator<<(ostream, Point)
operator>>(istream, Point)
operator+(double, Point)
operator*(double, Point)
Hours spent on this assignment: 6hr
Specific portions that gave you the most trouble:
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

////////////////////////////////////////////////////////////////////////////////
// private member functions 
////////////////////////////////////////////////////////////////////////////////
/******************************************************************************/
/*!
    \brief DegreesToRadians
        To convert degrees into radians

    \param degrees
        The desired value to convert

    \return
        double
*/
/******************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}
/******************************************************************************/
/*!
    \brief RadiansToDegrees
        To convert radians into degrees

    \param radians
        The desired value to convert

    \return
        double
*/
/******************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


////////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
////////////////////////////////////////////////////////////////////////////////
/******************************************************************************/
/*!
    \brief Point
        Default Constructor. To initialise the class members
		
    \return
		No return type
*/
/******************************************************************************/
Point::Point()
	: x(0), y(0)
{
}
/******************************************************************************/
/*!
    \brief Point
        Parameterized Constructor. To initialise the class members
	
    \param x
        The desired value to init the x-member

    \param y
        The desired value to init the y-member
	
    \return
		No return type
*/
/******************************************************************************/
Point::Point(double x, double y)
{
	// Set the member value to be the same as desired value
	this->x = x;
	this->y = y;
}
/******************************************************************************/
/*!
    \brief Point
        Copy Constructor. Copy another Point into Point
	
    \param rhs
		Point's reference to copy from
	
    \return
		No return type
*/
/******************************************************************************/
Point::Point(const Point& rhs)
{
	// Copy from another Point class
	this->x = rhs.x;
	this->y = rhs.y;
}
/******************************************************************************/
/*!
    \brief Point
        Destructor.
		
    \return
		No return type
*/
/******************************************************************************/
Point::~Point()
{
}
/******************************************************************************/
/*!
    \brief operator=
        Copy assignment operator. Copy another Point into Point
	
    \param rhs
		Point's reference to copy from
	
    \return
		Point&
*/
/******************************************************************************/
Point& Point::operator=(const Point& rhs)
{
	this->x = rhs.x;
	this->y = rhs.y;
	
	return *this;
}
/******************************************************************************/
/*!
    \brief operator+ (Point)
        To add two Point class's member together
	
    \param rhs
		Point's reference to be added into Point
	
    \return
		Point
*/
/******************************************************************************/
Point Point::operator+(const Point& rhs) const
{
	Point newPoint;
	newPoint.x = this->x + rhs.x;
	newPoint.y = this->y + rhs.y;
	
	return newPoint;
}
/******************************************************************************/
/*!
    \brief operator+ (double)
        To add Point with another double together
	
    \param value
		The desired value required for addition
	
    \return
		Point
*/
/******************************************************************************/
Point Point::operator+(double value) const
{
	Point newPoint;
	newPoint.x = this->x + value;
	newPoint.y = this->y + value;
	
	return newPoint;
}
/******************************************************************************/
/*!
    \brief operator* (double)
        To multiply Point with another double together
	
    \param value
		The desired value required for multiplication
	
    \return
		Point
*/
/******************************************************************************/
Point Point::operator*(double value) const
{
	Point newPoint;
	newPoint.x = this->x * value;
	newPoint.y = this->y * value;
	
	return newPoint;
}
/******************************************************************************/
/*!
    \brief operator- (double)
        To multiply Point with another double together
	
    \param value
		The desired value required for subtraction
	
    \return
		Point
*/
/******************************************************************************/
Point Point::operator-(double value) const
{
	Point newPoint;
	newPoint.x = this->x - value;
	newPoint.y = this->y - value;
	
	return newPoint;
}
/******************************************************************************/
/*!
    \brief operator% (Rotation)
        To rotate a Point about the origin by the degrees
	
    \param degree
		The desired degree required for rotation
	
    \return
		Point
*/
/******************************************************************************/
Point Point::operator%(double degree) const
{
	double rad = DegreesToRadians(degree);

	Point newPoint(((cos(rad) * this->x) - (sin(rad) * this->y)),
				   ((sin(rad) * this->x) + (cos(rad) * this->y)));

	if (newPoint.x > -EPSILON && newPoint.x < EPSILON)
		newPoint.x = 0.0;
	if (newPoint.y > -EPSILON && newPoint.y < EPSILON)
		newPoint.y = 0.0;

	return newPoint;
}
/******************************************************************************/
/*!
    \brief operator- (Distance)
        To calculate the difference between two Points and return the distance
	
    \param rhs
		Point's reference required for calculation
	
    \return
		double
*/
/******************************************************************************/
double Point::operator-(const Point& rhs) const
{
	return sqrt((this->x - rhs.x) * (this->x - rhs.x) + 
				(this->y - rhs.y) * (this->y - rhs.y));
}
/******************************************************************************/
/*!
    \brief operator^ (Midpoint)
        To calculate the midpoint between two Points
	
    \param rhs
		Point's reference required for calculation
	
    \return
		Point
*/
/******************************************************************************/
Point Point::operator^(const Point& rhs) const
{
	Point newPoint;
	
	newPoint.x = (this->x + rhs.x) * 0.5f;
	newPoint.y = (this->y + rhs.y) * 0.5f;
	
	return newPoint;
}
/******************************************************************************/
/*!
    \brief operator+= (Point)
        To add from another Point into the Point
	
    \param rhs
		Point's reference required for addition
	
    \return
		Point&
*/
/******************************************************************************/
Point& Point::operator+=(const Point& rhs)
{
	this->x += rhs.x;
	this->y += rhs.y;
	
	return *this;
}
/******************************************************************************/
/*!
    \brief operator+= (double)
        To add from a desired value into the Point
	
    \param value
		The desired value required for addition
	
    \return
		Point&
*/
/******************************************************************************/
Point& Point::operator+=(double value)
{
	this->x += value;
	this->y += value;
	
	return *this;
}
/******************************************************************************/
/*!
    \brief operator++ (pre-increment)
        Add one to the x/y values of the Point
	
    \return
		Point
*/
/******************************************************************************/
Point& Point::operator++(void)
{
	++this->x;
	++this->y;

	return *this;
}
/******************************************************************************/
/*!
    \brief operator++ (post-increment)
        Add one to the x/y values of the Point
	
    \return
		Point&
*/
/******************************************************************************/
Point Point::operator++(int)
{
	Point tempPoint = *this;
	++this->x;
	++this->y;
	
	return tempPoint;
}
/******************************************************************************/
/*!
    \brief operator-- (pre-decrement)
        Subtract one from the x/y values of the Point
	
    \return
		Point
*/
/******************************************************************************/
Point& Point::operator--(void)
{
	--this->x;
	--this->y;
	
	return *this;
}
/******************************************************************************/
/*!
    \brief operator-- (post-increment)
        Subtract one from the x/y values of the Point
	
    \return
		Point&
*/
/******************************************************************************/
Point Point::operator--(int)
{
	Point tempPoint = *this;
	--this->x;
	--this->y;
	
	return tempPoint;
}
/******************************************************************************/
/*!
    \brief operator- (unary)
        Negate the x/y values of the Point
	
    \return
		Point
*/
/******************************************************************************/
Point Point::operator-(void)
{
	Point newPoint = *this;
	newPoint.x = -newPoint.x;
	newPoint.y = -newPoint.y;
	
	return newPoint;
}
////////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
////////////////////////////////////////////////////////////////////////////////
/******************************************************************************/
/*!
    \brief operator<< (ostream)
        Allow for the output of a Point in the form of a string
	
	\param os
		The ostream's reference required for returning

	\param rhs
		The Point's reference required for data stream
		
    \return
		ostream&
*/
/******************************************************************************/
std::ostream& operator<<(std::ostream& os, const Point& rhs)
{
	return os << "(" << rhs.x << ", " << rhs.y << ")";
}
/******************************************************************************/
/*!
    \brief operator>> (istream)
        Allows for the input of a Point
	
	\param is
		The istream's reference required for input

	\param rhs
		The Point's reference required for data stream
		
    \return
		istream&
*/
/******************************************************************************/
std::istream& operator>>(std::istream& is, Point& rhs)
{
	return is >> rhs.x >> rhs.y;
}
////////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
////////////////////////////////////////////////////////////////////////////////
/******************************************************************************/
/*!
    \brief operator+ (double, Point)
        Add the desired value into a Point
	
	\param value
		The desired value required for addition

	\param rhs
		The Point's reference required for addition
		
    \return
		Point
*/
/******************************************************************************/
Point operator+(double value, const Point& rhs)
{
	return rhs + value;
}
/******************************************************************************/
/*!
    \brief operator* (double, Point)
        Multiply the desired value into a Point
	
	\param value
		The desired value required for multiplication

	\param rhs
		The Point's reference required for multiplication
		
    \return
		Point
*/
/******************************************************************************/
Point operator*(double value, const Point& rhs)
{
	return rhs * value;
}
} // namespace CS170



