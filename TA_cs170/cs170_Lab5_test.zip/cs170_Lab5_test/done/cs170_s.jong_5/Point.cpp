/******************************************************************************/
/*!
\file Point.cpp
\author Jong Sze kuan Melvin
\par email: s.jong\@digipen.edu
\par DigiPen login: s.jong
\par Course: CS170a
\par Lab 05
\date 24/06/2019
\brief
 This files contain functions
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
/******************************************************************************/
/*!
 \fn DegreesToRadians
 \brief
  convert an angle from degree to radian.
 \param double degrees
\return
Return degrees * PI / 180.0
*/
/******************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}
/******************************************************************************/
/*!
 \fn RadiansToDegrees
 \brief
  convert an angle from radian to degree.
 \param double radians
\return
Return radians * 180.0 / PI
*/
/******************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
/******************************************************************************/
/*!
 \fn Point
 \brief
  default constructor.
*/
/******************************************************************************/
Point::Point()
{
  x=0;
  y=0;
}
/******************************************************************************/
/*!
 \fn Point
 \brief
  constructor for points.
 \param double X, double Y
*/
/******************************************************************************/
Point::Point(double X, double Y)
{
  x=X;
  y=Y;
}
/******************************************************************************/
/*!
 \fn operator%
 \brief
  Member function that rotates a Point about the origin by the 
  specified number of degrees. Returns a new Point. 
 \param double angle
\return
Return Point(x1, y1)
*/
/******************************************************************************/
Point Point::operator%(double angle) const
{
  double rad = DegreesToRadians(angle);
  double x1 = -((x * cos(rad)) - (y * sin(rad)));
  double y1 = (x * cos(rad)) + (y * cos(rad));
  return Point(x1, y1);
}
/******************************************************************************/
/*!
 \fn operator-
 \brief
  Member function that calculates the difference between two Points and
  returns the distance(type double).
 \param const Point& rhs
\return
Return distance
*/
/******************************************************************************/
double Point::operator-(const Point& rhs)
{
  double dis_x = x - rhs.x; //difference between x value
  double dis_y = y -rhs.y; //difference between y value
  double distance = sqrt(dis_x * dis_x + dis_y * dis_y); 
  return distance;
}
/******************************************************************************/
/*!
 \fn operator^
 \brief
  Member function that calculates the midpoint between two Points. Returns a
new Point.
 \param const Point& rhs
\return
Return midpoint
*/
/******************************************************************************/
Point Point::operator^(const Point& rhs)
{
  Point midpoint;
  midpoint.x = (x + rhs.x)/2; 
  midpoint.y = (y + rhs.y)/2;
  return midpoint;
}
/******************************************************************************/
/*!
 \fn operator+=
 \brief
  Add two Points or a Point and a double and returns a reference to the 
  lefthand operand which has been modified. These are both member functions.
 \param const Point& rhs
\return
Return *this
*/
/******************************************************************************/
Point& Point::operator+=(const Point& rhs)
{
  x += rhs.x;
  y += rhs.y;
  return *this;
}
/******************************************************************************/
/*!
 \fn operator+=
 \brief
 Add two Points or a Point and a double and returns a reference to the left
 hand operand which has been modified. These are both member functions.
 \param double value
\return
Return *this
*/
/******************************************************************************/
Point& Point::operator+=(double value)
{
  x +=value;
  y +=value;
  return *this;
}
/******************************************************************************/
/*!
 \fn operator-
 \brief
  Member function that subtracts a double from a Point and returns a new 
  Point.
 \param double value
\return
Return Point(x - value, y- value)
*/
/******************************************************************************/
Point Point::operator-(double value)
{
  return Point(x - value, y - value);
}
/******************************************************************************/
/*!
 \fn operator++
 \brief
  post-increment return a new Point with the value of the
  "before increment Point".
 \param int
\return
Return tmp
*/
/******************************************************************************/
Point Point::operator++(int) //post
{
  Point tmp(*this);
  ++(*this);
  return tmp;
}
/******************************************************************************/
/*!
 \fn operator++
 \brief
  Pre-increment returns a reference to the increment Point.
\return
Return *this
*/
/******************************************************************************/
Point& Point::operator++() //pre
{
  ++x;
  ++y;
  return *this;
}
/******************************************************************************/
/*!
 \fn operator--
 \brief
  post-decrement returns a new Point with the value of the
  "before decremented Point".
 \param int 
\return
Return tmp
*/
/******************************************************************************/
Point Point::operator--(int) //post
{
  Point tmp(*this);
  --(*this);
  return tmp;
}
/******************************************************************************/
/*!
 \fn operator--
 \brief
  Pre-decrement returns a reference to the decrement Point.
\return
Return *this
*/
/******************************************************************************/
Point& Point::operator--() //pre
{
  --x;
  --y;
  return *this;
}
/******************************************************************************/
/*!
 \fn operator-
 \brief
  Member function that returns a new Point with the x/y values 
  of input Point negated.
\return
Return Point(-x, -y)
*/
/******************************************************************************/
Point Point::operator-()
{
  return Point(-x, -y);
}
/******************************************************************************/
/*!
 \fn operator+
 \brief
  Addition of operator overloading with another point.
 \param const Point& rhs
\return
Return tmp
*/
/******************************************************************************/
Point Point::operator+(const Point& rhs) const
{
  Point tmp(*this);
  tmp += rhs;
  return tmp;
}
/******************************************************************************/
/*!
 \fn operator+
 \brief
  Addition of operator overloading with value.
 \param double data
\return
Return Point(x + data, y + data)
*/
/******************************************************************************/
Point Point::operator+(double data)
{
  return Point(x + data, y + data);
}
/******************************************************************************/
/*!
 \fn operator*
 \brief
  Multiplies a Point by some numeric factor of type double 
  and returns a new Point.
 \param double data
\return
Return tmp
*/
/******************************************************************************/
Point Point::operator*(double data)
{
  Point tmp;
  tmp.x = x * data;
  tmp.y = y * data;
  return tmp;
}
///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
/******************************************************************************/
/*!
 \fn operator<<
 \brief
  Outputs a Point in the form of a string.
 \param &output, const Point &point
\return
Return output
*/
/******************************************************************************/
std::ostream& operator<<(std::ostream &output, const Point &point)
{
  output << "(" << point.x << ", " << point.y << ")";
  return output;
}
/******************************************************************************/
/*!
 \fn operator>>
 \brief
  Input Point.
 \param &input, Point &point
\return
Return input
*/
/******************************************************************************/
std::istream& operator>>(std::istream &input, Point &point)
{
  input >> point.x >> point.y;
  return input;
}



///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
/******************************************************************************/
/*!
 \fn operator+
 \brief
  Addition of operator overloading with another value.
 \param double value, const Point& rhs
Return tmp
*/
/******************************************************************************/
Point operator+(double value, const Point& rhs)
{
  Point tmp(rhs);
  tmp += value;
  return tmp;
}
/******************************************************************************/
/*!
 \fn operator*
 \brief
  Multiplies a Point by some numeric factor of type double and
  return a new Point.
 \param double value, const Point& rhs
\return
Return tmp
*/
/******************************************************************************/
Point operator*(double value, const Point& rhs)
{
  Point tmp(rhs);
  tmp = tmp * value;
  return tmp;
}


} // namespace CS170



