////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream
using namespace std;
namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
    Point();
    Point(double X, double Y);
        // Overloaded operators (14 member functions)
    Point operator%(double angle) const;
    double operator-(const Point& rhs);
    Point operator^(const Point& rhs);
    Point& operator+=(const Point& rhs);
    Point& operator+=(double value);
    Point operator-(double value);
    Point operator++(int); //post
    Point& operator++(); //pre
    Point operator--(int); //post
    Point& operator--(); //pre
    Point operator-();
    Point operator+(const Point& rhs) const;
    Point operator+(double data);
    Point operator*(double data);
        // Overloaded operators (2 friend functions)
    friend std::ostream& operator<< (std::ostream &output, const Point &point);
    friend std::istream& operator>> (std::istream &input, Point &point);
    
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    Point operator+ (double value, const Point& rhs);
    Point operator* (double value, const Point& rhs);
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
