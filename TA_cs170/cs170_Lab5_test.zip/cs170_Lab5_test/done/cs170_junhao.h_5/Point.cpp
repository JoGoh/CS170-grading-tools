/******************************************************************************/
/*! 
\file   Point.cpp
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 05 
\date   24/6/2019 
\brief  Implemention of a Point in a 2D coordinate system.
*/ 
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
/******************************************************************************/
/*!   
  This is a Default constructor.
  It constructs an object with both parameter set to zero. 
*/ 
/******************************************************************************/
Point::Point()
: x(0),y(0){}

/******************************************************************************/
/*!   
  This is a Conversion constructor.
  It takes in 2 double and use it as the Point coordinates. 

  \param _x      
  The x coordinate for point
  \param _y      
  The y coordinate for point
*/ 
/******************************************************************************/
Point::Point(double _x, double _y)
: x(_x),y(_y){}

/******************************************************************************/
/*!   
  Function rotates a Point about the origin by the specified number of degrees.
   Returns a new Point. 

  \param degrees      
  The degree specified for the point to rotate about
*/ 
/******************************************************************************/
Point Point::operator%(double degrees) const
{
  double radians = DegreesToRadians(degrees);
  double _x = x*std::cos(radians) - y*std::sin(radians);
  double _y = x*std::sin(radians) + y*std::cos(radians);
  if (_x > -EPSILON && _x < EPSILON)
    _x = 0.0;
  if (_y > -EPSILON && _y < EPSILON)
    _y = 0.0;
  return Point(_x,_y);
}

/******************************************************************************/
/*!   
  Function that calculates the distance between 2 points (type double). 

  \param rhs      
  The 2nd point to compare the coordinates with.
*/ 
/******************************************************************************/
double Point::operator-(const Point& rhs) const
{
  double distance = sqrt( (x-rhs.x)*(x-rhs.x) + (y-rhs.y)*(y-rhs.y) );
  return distance;
}

/******************************************************************************/
/*!   
  Function that calculates the midpoint between two Points. Returns a new Point.

  \param rhs      
  The 2nd point to compare the coordinates with.
*/ 
/******************************************************************************/
Point Point::operator^(const Point& rhs) const
{
  double _x = (x + rhs.x)/2;
  double _y = (y + rhs.y)/2;
  return Point(_x,_y);
}

/******************************************************************************/
/*!   
  Add two Points and returns a reference to the lhs which has been modified. 

  \param rhs      
  The 2nd point to compare the coordinates with.
*/ 
/******************************************************************************/
Point& Point::operator+=(const Point& rhs)
{
  x += rhs.x;
  y += rhs.y;
  return *this;
}

/******************************************************************************/
/*!   
  Add a Point and a double and returns a reference to the lhs 

  \param rhs      
  The double to add with
*/ 
/******************************************************************************/
Point& Point::operator+=(const double rhs)
{
  x += rhs;
  y += rhs;
  return *this;
}

/******************************************************************************/
/*!   
  Function that subtracts a double from a Point and returns a new Point. 

  \param rhs      
  The double to subtract with
*/ 
/******************************************************************************/
Point Point::operator-(const double rhs) const
{
  return Point(x-rhs,y-rhs);
}

/******************************************************************************/
/*!   
  Add one to the x/y values of the object. 
  Pre-increment returns a reference to the incremented Point.
*/ 
/******************************************************************************/
Point& Point::operator++()
{
  ++x;
  ++y;
  return *this;
}

/******************************************************************************/
/*!   
  Add one to the x/y values of the object. 
  Post-increment returns a new Point with the value “before incremented”. 
*/ 
/******************************************************************************/
  Point Point::operator++(int)
  {
    Point tmp(x,y);
    x++;
    y++;
    return tmp;
  }

/******************************************************************************/
/*!   
  Subtracts one from the x/y values of the object. 
  Pre-decrement returns a reference to the decremented Point.
*/ 
/******************************************************************************/
Point& Point::operator--()
{
  x--;
  y--;
  return *this;
}

/******************************************************************************/
/*!   
  Subtracts one from the x/y values of the object. 
  Post-decrement returns a new Point with the value “before decremented”.
*/ 
/******************************************************************************/
Point Point::operator--(int)
{
    Point tmp(x,y);
    x--;
    y--;
    return tmp;
}

/******************************************************************************/
/*!   
  Function that returns a new Point with the x/y values of input Point negated.
*/ 
/******************************************************************************/
Point Point::operator-() const
{
  return Point(-x,-y);
}

/******************************************************************************/
/*!   
  Adds two Points and returns a new Point.

  \param rhs      
  The 2nd point to compare the coordinates with.
*/ 
/******************************************************************************/
Point Point::operator+(const Point& rhs) const
{
  return Point(x+rhs.x, y+rhs.y);
}

/******************************************************************************/
/*!   
  Adds a double and returns a new Point. 

  \param rhs      
  The value to add to coordinates.
*/ 
/******************************************************************************/
Point Point::operator+(const double rhs) const
{
  return Point(x+rhs, y+rhs);
}

/******************************************************************************/
/*!   
  Multiplies a Point by some numeric factor (double) and returns a new Point. 

  \param rhs      
  The numeric factor to multiply with
*/ 
/******************************************************************************/
Point Point::operator*(const double rhs) const
{
  return Point(x*rhs, y*rhs);
}

///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
/******************************************************************************/
/*!   
  Outputs a Point in the form of a string: (x, y).

  \param lhs      
  The reference to the ostream , to be modified.
  \param rhs
  The point to inject into the ostream
*/ 
/******************************************************************************/
std::ostream& operator<<(std::ostream& lhs, const Point& rhs)
{
  lhs << "(" << rhs.x << ", " << rhs.y << ")";
  return lhs;
}

/******************************************************************************/
/*!   
  Inputs a Point. Allows two numbers (separated by whitespace) to be entered.

  \param lhs      
  The reference to the istream , to be modified.
  \param rhs
  The point to inject into the istream
*/ 
/******************************************************************************/

std::istream &operator>>(std::istream& lhs, Point& rhs)
{
  double _x, _y;
  lhs >> _x >> _y;

  rhs = Point(_x,_y);
  return lhs;
}

///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
/******************************************************************************/
/*!   
  Adds a Point and a double and returns a new Point.

  \param lhs      
  The value to add to coordinates.
  \param rhs      
  The point to compare the coordinates with.
*/ 
/******************************************************************************/
Point operator+(const double lhs, const Point& rhs)
{
  return rhs+lhs;
}

/******************************************************************************/
/*!   
  Multiplies a Point by some numeric factor (double) and returns a new Point. 

  \param lhs      
  The numeric factor to multiply with
  \param rhs      
  The point to compare the coordinates with.
*/ 
/******************************************************************************/
Point operator*(const double lhs, const Point& rhs)
{
  return rhs*lhs;
}


} // namespace CS170



