/******************************************************************************/
/*! 
\file   Point.h
\author Ho Jun Hao 
\par    email: junhao.h\@digipen.edu 
\par    DigiPen login: junhao.h 
\par    Course: CS170 
\par    Lab 05 
\date   24/6/2019 
\brief  Interface of a Point in a 2D coordinate system.
*/ 
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
      // Constructors (2)        
      Point();
      Point(double _x , double _y);

      // Overloaded operators (14 member functions)
      Point operator%(double degrees) const;
      double operator-(const Point& rhs) const;
      Point operator^(const Point& rhs) const;
      Point& operator+=(const Point& rhs);
      Point& operator+=(const double rhs);
      Point operator-(const double rhs) const;
      Point& operator++();
      Point operator++(int);
      Point& operator--();
      Point operator--(int);
      Point operator-() const;
      Point operator+(const Point& rhs) const;
      Point operator+(const double rhs) const;
      Point operator*(const double rhs) const;


      // Overloaded operators (2 friend functions)
      friend std::ostream& operator<<(std::ostream& lhs, const Point& rhs);
      friend std::istream& operator>>(std::istream& lhs, Point& rhs);

    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    Point operator+(const double lhs, const Point& rhs);
    Point operator*(const double lhs, const Point& rhs);
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
