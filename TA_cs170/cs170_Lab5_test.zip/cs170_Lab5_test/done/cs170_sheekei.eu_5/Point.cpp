/******************************************************************************/
/*!
\file Point.cpp
\author Eu Shee Kei
\par email: sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course: CS170
\par Lab: 5
\date 24/06/2019
\brief
This file contains the implementation of the following functions for the
Point assignment.
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

  const double PI = 3.1415926535897;
  const double EPSILON = 0.00001;

////////////////////////////////////////////////////////////////////////////////
// private member functions 

  /****************************************************************************/
  /*!
  \fn     double Point::DegreesToRadians(double degrees) const
  \brief  Converts angle degree to radian
  \param  degree          angle to be converted from degree to radian
  \return radian in degree
  */
  /****************************************************************************/
  double Point::DegreesToRadians(double degrees) const
  {
    return (degrees * PI / 180.0);
  }

  /****************************************************************************/
  /*!
  \fn     double Point::RadiansToDegrees(double radians) const
  \brief  Converts radians to degree
  \param  radians         a double which is angle in radian
  \return degree in radian
  */
  /****************************************************************************/
  double Point::RadiansToDegrees(double radians) const
  {
    return (radians * 180.0 / PI);
  }


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 

  /****************************************************************************/
  /*!
  \fn     Point::Point()
  \brief  Default constructor
  */
  /****************************************************************************/
  Point::Point()
  : x(0), y(0)
  {
  }

  /****************************************************************************/
  /*!
  \fn     Point::Point(double _x, double _y)  
  \brief  Conversion constructor
  */
  /****************************************************************************/
  Point::Point(double _x, double _y)
  : x(_x), y(_y)
  {
    
  }

  /****************************************************************************/
  /*!
  \fn     Point::~Point()
  \brief  Destructor
  */
  /****************************************************************************/
  Point::~Point()
  {
    
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator+(const Point &rhs) const
  \brief  Operator overload for +, adds two points together
  \param  rhs     A reference to a point object
  \return Point   A point object
  */
  /****************************************************************************/
  Point Point::operator+(const Point &rhs) const
  {
    return Point((x + rhs.x), (y + rhs.y));
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator+(double rhs) const
  \brief  Operator overload for +, adds double to a point
  \param  rhs             double to be added to a point object
  \return A point object
  */
  /****************************************************************************/
  Point Point::operator+(double rhs) const
  {
    return Point((x+rhs), (y+rhs));
  }

  /****************************************************************************/
  /*!
  \fn     double Point::operator-(const Point & rhs) const
  \brief  operator overload for -, distance beween two Points
  \param  rhs     A reference to a read-only Point object
  \return A double
  */
  /****************************************************************************/
  double Point::operator-(const Point & rhs) const
  {
    return sqrt((rhs.x - x)*(rhs.x - x) + (rhs.y - y)*(rhs.y - y));
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator-(double rhs)
  \brief  operator overload for -, subtraction for Point components
  \param  rhs     double
  \return A Point object
  */
  /****************************************************************************/
  Point Point::operator-(double rhs)
  {
    return Point((x-rhs), (y-rhs));
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator-() const
  \brief  operator overload for -, unary negative Point
  \return A Point object
  */
  /****************************************************************************/
  Point Point::operator-() const
  {
    return Point(-x, -y);
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator*(const double &rhs) const
  \brief  operator overload for *, multiplication of Point objects
  \param  rhs     a reference to a read-only double
  \return A Point object
  */
  /****************************************************************************/
  Point Point::operator*(const double &rhs) const
  {
    return Point((x*rhs), (y*rhs));
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator%(const double & deg) const
  \brief  Operator overload for %, rotates a point about the origin
  \param  deg     A reference to a read-only double
  \return A Point object
  */
  /****************************************************************************/
  Point Point::operator%(const double & deg) const
  {
    double rotatedX = x*cos(deg * PI / 180) - y*sin(deg * PI /180);
    double rotatedY = x*sin(deg * PI / 180) + y*cos(deg * PI / 180);
    
    // check if absolute value of rotated x and y is smaller than epsilon,
    // make it zero
    if(abs(rotatedX) < EPSILON)
      rotatedX = 0.0;
    
    if(abs(rotatedY) < EPSILON)
      rotatedY = 0.0;
    
    return Point(rotatedX, rotatedY);
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator^(const Point & rhs)
  \brief  operator overload for ^, mid point between two points
  \param  rhs     A reference to a read-only Point object
  \return A point object
  */
  /****************************************************************************/
  Point Point::operator^(const Point & rhs)
  {
    return Point(((x + rhs.x) / 2), ((y + rhs.y) / 2));
  }

  /****************************************************************************/
  /*!
  \fn     Point & Point::operator+=(const Point & rhs)
  \brief  operator overload for +=, compound addition for Point
  \param  rhs     A reference to a point object
  \return A reference to a point object
  */
  /****************************************************************************/
  Point & Point::operator+=(const Point & rhs)
  {
    x = x + rhs.x;
    y = y + rhs.y;
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn     Point & Point::operator+=(double rhs)
  \brief  operator overload for +=, compound addition for Point component
  \param  rhs     A double to be added to Point
  \return A reference to a point object
  */
  /****************************************************************************/
  Point & Point::operator+=(double rhs)
  {
    x = x + rhs;
    y = y + rhs;
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn     Point & Point::operator++()
  \brief  operator overload for ++, pre-increment
  \return A reference to a point object
  */
  /****************************************************************************/
  Point & Point::operator++()
  {
    ++x;
    ++y;
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator++(int)
  \brief  operator overload for ++, post-increment
  \return A point object
  */
  /****************************************************************************/
  Point Point::operator++(int)
  {
    return Point( x++, y++ );
  }

  /****************************************************************************/
  /*!
  \fn     Point & Point::operator--()
  \brief  operator overload for --, post-decrement
  \return A reference to a point object
  */
  /****************************************************************************/
  Point & Point::operator--()
  {
    --x;
    --y;
    return *this;
  }

  /****************************************************************************/
  /*!
  \fn     Point Point::operator--(int)
  \brief  operator overload for --, pre-decrement
  \return Point   A Point object
  */
  /****************************************************************************/
  Point Point::operator--(int)
  {
    return Point(x--, y--);
  }


///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

  /****************************************************************************/
  /*!
  \fn                           std::ostream & operator<<(std::ostream& out, 
                                const Point & rhs)
  \brief                        Operator overload for << Stream output
  \param out                    a reference to ostream
  \param rhs                    a reference to a Point object
  \return std::ostream &        output stream
  */
  /****************************************************************************/
  std::ostream & operator<<(std::ostream& out, const Point & rhs)
  {
    out << "(" << rhs.x << ", " << rhs.y << ")";
    return out;
  }

  /****************************************************************************/
  /*!
  @fn                           std::istream & operator>>(std::istream& in, 
                                Point & rhs)
  @brief                        Operator overload for >> Stream input
  @param rhs                    a reference to istream
  @param in                     a reference to a Point object
  @return std::istream &        input stream       
  */
  /****************************************************************************/
  std::istream & operator>>(std::istream& in, Point & rhs)
  {
    in >> rhs.x >> rhs.y;
    return in;
  }

///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)

  /****************************************************************************/
  /*!                                                                        
  \fn                           Point operator+(double lhs, const Point & rhs)
  \brief                        Operator overload for + Translation
  \param rhs                    double
  \param lhs                    a reference to a read-only Point object
  \return double                a double                        
  */                                                                         
  /****************************************************************************/
  Point operator+(double lhs, const Point & rhs)
  {
    return rhs+lhs;
  }

  /****************************************************************************/
  /*!
  \fn                           operator*(const double & rhs, const Point & 
                                lhs)
  \brief                        Operator overload for *
  \param rhs                    a reference to a read-only double
  \param lhs                    a reference to a read-only Point object
  \return Point                 a new Point object
  */
  /****************************************************************************/
  Point operator*(const double & lhs, const Point & rhs)
  {
    return rhs*lhs;
  }
} // namespace CS170



