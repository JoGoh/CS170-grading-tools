/******************************************************************************/
/*!
\file Point.h
\author Eu Shee Kei
\par email: sheekei.eu\@digipen.edu
\par DigiPen login: sheekei.eu
\par Course: CS170
\par Lab: 5
\date 24/06/2019
\brief
This file contains the header functions of the following functions for the
Point assignment.
*/
/******************************************************************************/

////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
      // Constructors (2)
      /************************************************************************/
      /*!
      \fn     Point::Point()
      \brief  Default constructor
      */
      /************************************************************************/
      Point();
      
      /************************************************************************/
      /*!
      \fn     Point::Point(double _x, double _y)  
      \brief  Conversion constructor
      */
      /************************************************************************/
      Point(double x, double y);
      
      /************************************************************************/
      /*!
      \fn     Point::~Point()
      \brief  Destructor
      */
      /************************************************************************/
      ~Point();

      // Overloaded operators (14 member functions)
      /************************************************************************/
      /*!
      \fn     Point operator+(const Point &rhs) const
      \brief  Operator overload for +, adds two points together
      \param  rhs     A reference to a point object
      \return Point   A point object
      */
      /************************************************************************/
      Point operator+(const Point &rhs) const;
      
      /************************************************************************/
      /*!
      \fn     Point operator+(double rhs) const
      \brief  Operator overload for +, adds double to a point
      \param  rhs             double to be added to a point object
      \return A point object
      */
      /************************************************************************/
      Point operator+(double rhs) const;
      
      /************************************************************************/
      /*!
      \fn     double operator-(const Point & rhs) const
      \brief  operator overload for -, distance beween two Points
      \param  rhs     A reference to a read-only Point object
      \return A double
      */
      /************************************************************************/
      double operator-(const Point & rhs) const;
      
      /************************************************************************/
      /*!
      \fn     Point operator-(double rhs)
      \brief  operator overload for -, subtraction for Point components
      \param  rhs     double
      \return A Point object
      */
      /************************************************************************/
      Point operator-(double rhs);
      
      /************************************************************************/
      /*!
      \fn     Point operator-() const
      \brief  operator overload for -, unary negative Point
      \return A Point object
      */
      /************************************************************************/
      Point operator-() const;
      
      /************************************************************************/
      /*!
      \fn     Point operator*(const double &rhs) const
      \brief  operator overload for *, multiplication of Point objects
      \param  rhs     a reference to a read-only double
      \return A Point object
      */
      /************************************************************************/
      Point operator*(const double &rhs) const;
      
      /************************************************************************/
      /*!
      \fn     Point operator%(const double & deg) const
      \brief  Operator overload for %, rotates a point about the origin
      \param  deg     A reference to a read-only double
      \return A Point object
      */
      /************************************************************************/
      Point operator%(const double & deg) const;
      
      /************************************************************************/
      /*!
      \fn     Point operator^(const Point & rhs)
      \brief  operator overload for ^, mid point between two points
      \param  rhs     A reference to a read-only Point object
      \return A point object
      */
      /************************************************************************/
      Point operator^(const Point & rhs);
      
      /************************************************************************/
      /*!
      \fn     Point & operator+=(const Point & rhs)
      \brief  operator overload for +=, compound addition for Point
      \param  rhs     A reference to a point object
      \return A reference to a point object
      */
      /************************************************************************/
      Point & operator+=(const Point & rhs);
      
      /************************************************************************/
      /*!
      \fn     Point & operator+=(double rhs)
      \brief  operator overload for +=, compound addition for Point component
      \param  rhs     A double to be added to Point
      \return A reference to a point object
      */
      /************************************************************************/
      Point & operator+=(double);
      
      /************************************************************************/
      /*!
      \fn     Point & operator++()
      \brief  operator overload for ++, pre-increment
      \return A reference to a point object
      */
      /************************************************************************/
      Point & operator++();
      
      /************************************************************************/
      /*!
      \fn     Point operator++(int)
      \brief  operator overload for ++, post-increment
      \return A point object
      */
      /************************************************************************/
      Point operator++(int);
      
      /************************************************************************/
      /*!
      \fn     Point & operator--()
      \brief  operator overload for --, post-decrement
      \return A reference to a point object
      */
      /************************************************************************/
      Point & operator--();
      
      /************************************************************************/
      /*!
      \fn     Point operator--(int)
      \brief  operator overload for --, pre-decrement
      \return Point   A Point object
      */
      /************************************************************************/
      Point operator--(int);
      
      // Overloaded operators (2 friend functions)
      
      /************************************************************************/
      /*!
      \fn                           std::ostream & operator<<(std::ostream& out, 
                                    const Point & rhs)
      \brief                        Operator overload for << Stream output
      \param out                    a reference to ostream
      \param rhs                    a reference to a Point object
      \return std::ostream &        output stream
      */
      /************************************************************************/
      friend std::ostream & operator<<(std::ostream& out, const Point & rhs);

      /************************************************************************/
      /*!
      @fn                           std::istream & operator>>(std::istream& in, 
                                    Point & rhs)
      @brief                        Operator overload for >> Stream input
      @param rhs                    a reference to istream
      @param in                     a reference to a Point object
      @return std::istream &        input stream       
      */
      /************************************************************************/
      friend std::istream & operator>>(std::istream& in, Point & rhs);
      
    private:
      double x;           ///< The x-coordinate of a Point
      double y;           ///< The y-coordinate of a Point

      // Helper functions
      
      /************************************************************************/
      /*!
      \fn     double Point::DegreesToRadians(double degrees) const
      \brief  Converts angle degree to radian
      \param  degree          angle to be converted from degree to radian
      \return radian in degree
      */
      /************************************************************************/
      double DegreesToRadians(double degrees) const;
      
      /************************************************************************/
      /*!
      \fn     double Point::RadiansToDegrees(double radians) const
      \brief  Converts radians to degree
      \param  radians         a double which is angle in radian
      \return degree in radian
      */
      /************************************************************************/
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    
    /**************************************************************************/
    /*!
    \fn                           Point operator+(double lhs, const Point & rhs)
    \brief                        Operator overload for + Translation
    \param rhs                    double
    \param lhs                    a reference to a read-only Point object
    \return double                a double                        
    */
    /**************************************************************************/
    Point operator+(double rhs, const Point & lhs);
    
    /**************************************************************************/
    /*!
    \fn                           operator*(const double & rhs, const Point & 
                                  lhs)
    \brief                        Operator overload for *
    \param rhs                    a reference to a read-only double
    \param lhs                    a reference to a read-only Point object
    \return Point                 a new Point object
    */
    /**************************************************************************/
    Point operator*(const double &rhs, const Point & lhs);
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
