/******************************************************************************/
/*! 
  \file point.cpp
  \author Lau Jan Wei, Joshua
  \par email: janweijoshua.lau\@digipen.edu
  \par DigiPen login: janweijoshua.lau
  \par Course: CS170
  \par Lab 05
  \date 24/06/2019
  \brief
This file contains the implementation of the following functions for Lab 05.
Functions include:
1) point constructor without parameters
2) point constructor with parameters
3) operator % Rotation
4) operator - (Binary) Distance
5) operator ^ Midpoint
6) operator += Translation Adding two points
7) operator += Translation point and a double
8) operator - Translation
9) operator ++ pre-increment
10) operator ++ post-increment
11) operator -- pre-decrement
12) operator -- post-decrement
13) operator - (Unary) Negation
14) operator + Translation Adding two points, point+point as a member function
15) operator + Translation point and a double, point+double as member function
16) operator * Scaling point*double as a member function
17) operator << Stream output
18) operator >> Stream input
19) operator + Translation double+point as a non-member, non-friend function
20) operator * Scaling double*point as a non-member, non-friend function

Hours spent on this Lab assignment: 6
Specific portions that gave you the most trouble: mostly everything
*/
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

const double PI = 3.1415926535897;
const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
double Point::DegreesToRadians(double degrees) const
{
  return (degrees * PI / 180.0);
}

double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 
/** 
    @name Point constructor with no parameters
    @brief initialise Point with no parameters
    @param none
    @return nothing
*/
    Point::Point() : x{0}, y{0}{}
/** 
    @name Point constructor with parameters
    @brief initialise Point with 2 parameters
    @param px
    @param py
    @return nothing
*/
    Point::Point(const double px, const double py) : x{px}, y{py}{}
/** 
    @name operator %
    @brief Rotation about the origin
    @param degree
    @return Point
*/
    Point Point::operator%(double degree) const
    {
      Point newpt;
      double radians = DegreesToRadians(degree);
      newpt.x = (cos(radians)*x) + (-1*(sin(radians))*y);
      newpt.y = (sin(radians)*x) + (cos(radians)*y);
      if (newpt.x < EPSILON && newpt.x > -EPSILON)
        newpt.x = 0;
      if (newpt.y < EPSILON && newpt.y > -EPSILON)
        newpt.y = 0;
      return newpt;
    }
/** 
    @name operator -
    @brief Finds the distance between two points
    @param rhs
    @return double
*/
    double Point::operator-(Point rhs) const
    {
      // C = sqrt (A^2 + B^2)
      return sqrt((x - rhs.x) * (x - rhs.x) + (y - rhs.y) * (y - rhs.y));
    }
/** 
    @name operator ^
    @brief Finds the midpoint between two points
    @param &rhs
    @return Point
*/
    Point Point::operator^(const Point &rhs) const
    {
      Point newpt;
      newpt.x = (x + rhs.x)/2;
      newpt.y = (y + rhs.y)/2;
      return newpt;
    }
/** 
    @name operator +=
    @brief Adds the right hand operand to the left
    @param rhs
    @return Point
*/
		Point& Point::operator+=(Point rhs)
		{
      x += rhs.x;
      y += rhs.y;
      return *this;
		}
/** 
    @name operator +=
    @brief Adds the right hand operand to the left
    @param rhs
    @return double
*/
    Point& Point::operator+=(double rhs)
    {
      x += rhs;
      y += rhs;
      return *this;
    }
/** 
    @name operator -
    @brief Subtraction
    @param rhs
    @return Point
*/
    Point Point::operator-(double rhs) const
    {
      Point lhs(*this);
      lhs.x -= rhs;
      lhs.y -= rhs;
      return lhs;
    }
/** 
    @name operator ++
    @brief Pre-increment Point by 1
    @param none
    @return Point&
*/
    Point& Point::operator++()
    {
      ++x;
      ++y;
      return *this;
    }
/** 
    @name operator ++
    @brief Post-increment Point by 1
    @param none
    @return nothing
*/
    Point Point::operator++(int)
    {
      Point inc(*this);
      ++*this;
      return inc;
    }
/** 
    @name operator --
    @brief Pre-decrement Point by 1
    @param none
    @return Point&
*/
    Point& Point::operator--()
    {
      --x;
      --y;
      return *this;
    }
/** 
    @name operator --
    @brief Post-decrement Point by 1
    @param none
    @return nothing
*/
    Point Point::operator--(int)
    {
      Point dec(*this);
      --*this;
      return dec;
    }
/** 
    @name operator -
    @brief Unary - negation
    @param none
    @return nothing
*/
    Point Point::operator-()
    {
      Point sign(*this);
      sign.x *= -1;
      sign.y *= -1;
      return sign;
    }
/** 
    @name operator +
    @brief Translation addition of Point with Point
    @param rhs
    @return Point
*/
    Point Point::operator+(Point rhs) const
    {
      Point lhs(*this);
      lhs.x += rhs.x;
      lhs.y += rhs.y;
      return lhs;
    }
/** 
    @name operator +
    @brief Translation addition of Point with double
    @param rhs
    @return Point
*/
    Point Point::operator+(double rhs) const
    {
      Point lhs(*this);
      lhs.x += rhs;
      lhs.y += rhs;
      return lhs;
    }
/** 
    @name operator *
    @brief Scaling member
    @param rhs
    @return Point
*/
    Point Point::operator*(double rhs) const
    {
      Point lhs(*this);
      lhs.x *= rhs;
      lhs.y *= rhs;
      return lhs;
    }
///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)
/** 
    @name operator <<
    @brief Stream output operator
    @param lhs
    @param rhs
    @return ostream&
*/
    std::ostream& operator<<(std::ostream& lhs, const Point& rhs)
    {
      lhs << "(" << rhs.x << ", " << rhs.y << ")";
      return lhs;
    }
/** 
    @name operator >>
    @brief Stream input operator
    @param lhs
    @param rhs
    @return istream&
*/
    std::istream& operator>>(std::istream& lhs, Point& rhs)
    {
      lhs >> rhs.x >> rhs.y;
      return lhs;
    }
///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)
/** 
    @name operator +
    @brief Translation addition non-member function
    @param lhs
    @param rhs
    @return Point
*/
    Point operator+(const double lhs, const Point& rhs)
    {
      Point add = rhs + lhs;
      return add;
    }
/** 
    @name operator *
    @brief Scaling non-member function
    @param lhs
    @param rhs
    @return Point
*/
    Point operator*(const double lhs, const Point& rhs)
    {
      Point multiply = rhs * lhs;
      return multiply;
    }
} // namespace CS170



