/******************************************************************************/
/*! 
  \file point.h
  \author Lau Jan Wei, Joshua
  \par email: janweijoshua.lau\@digipen.edu
  \par DigiPen login: janweijoshua.lau
  \par Course: CS170
  \par Lab 05
  \date 24/06/2019
  \brief
This file contains the Declaration of the following functions for Lab 05.
Functions include:
1) point constructor without parameters
2) point constructor with parameters
3) operator % Rotation
4) operator - (Binary) Distance
5) operator ^ Midpoint
6) operator += Translation Adding two points
7) operator += Translation point and a double
8) operator - Translation
9) operator ++ pre-increment
10) operator ++ post-increment
11) operator -- pre-decrement
12) operator -- post-decrement
13) operator - (Unary) Negation
14) operator + Translation Adding two points, point+point as a member function
15) operator + Translation point and a double, point+double as member function
16) operator * Scaling point*double as a member function
17) operator << Stream output
18) operator >> Stream input
19) operator + Translation double+point as a non-member, non-friend function
20) operator * Scaling double*point as a non-member, non-friend function

Hours spent on this Lab assignment: 6
Specific portions that gave you the most trouble: mostly everything
*/
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
#include <iostream>			// std::cout, std::cin
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
        // 1) constructor without parameters
        Point();
        // 2) constructor with parameters
        Point(const double px, const double py);

        // Overloaded operators (14 member functions)
        // Rotation
        Point operator%(double degree) const; // radians = degree * pi/180
        // 1) Distance
        double operator-(Point rhs) const;
        // 2) Midpoint
        Point operator^(const Point &rhs) const;
        // 3) Translation += Point to Point
        Point& operator+=(Point rhs);
        // 4) Translation += Point to double
        Point& operator+=(double rhs);
        // 5) Translation - 
        Point operator-(double rhs) const;
        // 6) Increment ++ pre-increment
        Point& operator++();
        // 7) Increment ++ post-increment
        Point operator++(int);
        // 8) Decrement -- pre-decrement
        Point& operator--();
        // 9) Decrement -- post-decrement
        Point operator--(int);
        // 10) Unary Negation
        Point operator-();
        // 11) Translation +
        Point operator+(Point rhs) const;
        // 12) Translation +
        Point operator+(double rhs) const;
        // 13) Scaling *
        Point operator*(double rhs) const;
        
        // Overloaded operators (2 friend functions)
        // 1) Stream output
        friend std::ostream& operator<<(std::ostream& lhs, const Point& rhs);
        // 2) Stream input
        friend std::istream& operator>>(std::istream& lhs, Point& rhs);
        
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    // 1) Translation +
    Point operator+(const double lhs, const Point& rhs);
    // 2) Scaling
    Point operator*(const double lhs, const Point& rhs);
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
