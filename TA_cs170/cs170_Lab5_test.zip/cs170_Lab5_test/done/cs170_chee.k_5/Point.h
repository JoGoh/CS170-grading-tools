////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
    class Point
    {
    public:
        // Constructors (2)
        Point();
        Point(const double x,const double y);
        
        // Overloaded operators (14 member functions)
        
        //Rotation operator to rotate a point by an angle
        Point operator%(const double rhs) const;
        //Operator to find distance between two points
        double operator-(const Point& rhs ) const;
        //Operator to find midpoint between two points
        Point operator^(const Point& rhs ) const;
        //Translation operators
        Point& operator+=(const Point& rhs );
        Point& operator+=(const double rhs);
        Point operator-(const double rhs) const;
        
        //Pre-inc operator
        Point& operator++();
        //Post-inc operator
        Point operator++( int );
        
        //Pre-dec operator
        Point& operator--();
        //Post-dec operator
        Point operator--( int );
        //Unary
        Point operator-() const;
        //Translation operator
        Point operator+(const Point& rhs);
        Point operator+(const double rhs );
        //Scaling operator
        Point operator*(const double rhs );
        
        // Overloaded operators (2 friend functions)
        
        //Output,input stream
        friend std::ostream& operator<<(std::ostream& output, Point pt);
        friend std::istream& operator>>(std::istream& input, Point pt);
        
    private:
        double x; // The x-coordinate of a Point
        double y; // The y-coordinate of a Point
    
            // Helper functions
        double DegreesToRadians(double degrees) const;
        double RadiansToDegrees(double radians) const;
    };
  
    // Overloaded operators (2 non-member, non-friend functions)
    //Non-friend, non-member functions for scaling and translation
    Point operator*(const double lhs, Point& rhs);
    Point operator+(const double lhs,const Point& rhs);
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
