#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{

    const double PI = 3.1415926535897;
    const double EPSILON = 0.00001;

///////////////////////////////////////////////////////////////////////////////
// private member functions 
    double Point::DegreesToRadians(double degrees) const
    {
        return (degrees * PI / 180.0);
    }

    double Point::RadiansToDegrees(double radians) const
    {
        return (radians * 180.0 / PI);
    }


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 

/******************************************************************************/
/*!
    \brief
        Constructs a point with coordinates set to origin
*/
/******************************************************************************/
    
    Point::Point()
    {
        x=0;//X coord
        y=0;//Y coord
    }
/******************************************************************************/
/*!
    \brief
        Constructs a point with coordinates set to x and y accordingly.
        
    \param Pos_x
        Value to be used to set the X position of the coords
        
    \param Pos_y
        Value to be used to set the Y position of the coords
*/
/******************************************************************************/
    Point::Point(const double Pos_x ,const double Pos_y)
    {
        x=Pos_x;
        y=Pos_y;
    }

/******************************************************************************/
/*!
    \brief
        Operator to perform rotation on a point using a double as an angle
        
    \param rhs
        Double to be used as angle given in degrees

*/
/******************************************************************************/
    Point Point::operator%(const double rhs) const
    {
        Point nPoint;
        //Convert angle to radians
        double rads = DegreesToRadians( rhs);
        nPoint.x=cos(rads)*x-sin(rads)*y;
        //Guard against infintesimally small numbers
        if(nPoint.x>-EPSILON && nPoint.x<EPSILON)
            nPoint.x=0;
        nPoint.y=sin(rads)*x+cos(rads)*y;
        if(nPoint.y>-EPSILON && nPoint.y<EPSILON)
            nPoint.y=0;
        return nPoint;
    }
    
    /******************************************************************************/
/*!
    \brief
        Operator to find the distance betwee two points 
        
    \param rhs
        Reference to point to be used in operation along with current point.
        
    \return double
        Distance between the two points 
*/
/******************************************************************************/
    double Point::operator-(const Point& rhs) const
    {
        
        double dist=sqrt((rhs.x-x)*(rhs.x-x)
                        +(rhs.y-y)*(rhs.y-y));
        return dist;
    }

/******************************************************************************/
/*!
    \brief
        Operator to find midpoint between two points 
        
    \param rhs
        Reference to point to be used in operation along with current point.
        
    \return Point
        Returns a new point which is the midpoint between the two points used
        in operation.
*/
/******************************************************************************/
    Point Point::operator^(const Point& rhs) const
    {
        Point nPoint;
        nPoint.x=(x+rhs.x)/2;
        nPoint.y=(y+rhs.y)/2;
        return nPoint;
    }

/******************************************************************************/
/*!
    \brief
        Operator to perform translation between a two points
        
    \param rhs
        Reference to point to be used in operation along with current point.
        
    \return Point&
        Returns a reference to lhs point
*/
/******************************************************************************/
    Point& Point::operator+=(const Point& rhs)
    {
        x+=rhs.x;
        y+=rhs.y;
        return *this;
    }

/******************************************************************************/
/*!
    \brief
        Operator to perform translation between a point and a double
        
    \param rhs
        A const double to be provided
        
    \return Point&
        Returns a reference to lhs point
*/
/******************************************************************************/
    Point& Point::operator+=(const double rhs)
    {
        x+=rhs;
        y+=rhs;
        return *this;
    }
    
/******************************************************************************/
/*!
    \brief
        Operator to perform translation between a point and a double
        
    \param rhs
        A const double to be provided
        
    \return Point
        Returns a new point from the operation
*/
/******************************************************************************/
    Point Point::operator-(const double rhs) const
    {
        Point nPoint;
        nPoint.x=x-rhs;
        nPoint.y=y-rhs;
        return nPoint;
    }

/******************************************************************************/
/*!
    \brief
        Operator to perform pre-increment on a point
        
    \return Point&
        Returns a reference to lhs point
*/
/******************************************************************************/
    Point& Point::operator++()
    {
        x++;
        y++;
        return *this;
    }
    
/******************************************************************************/
/*!
    \brief
        Operator to perform post-increment on a point
       
    \return Point
        Returns a new point
*/
/******************************************************************************/
    Point Point::operator++( int )
    {
        Point nPoint=*this;
        x++;
        y++;
        return nPoint;
    }
/******************************************************************************/
/*!
    \brief
        Operator to perform pre-decrement on a point
        
    \return Point&
        Returns a reference to lhs point
*/
/******************************************************************************/

    Point& Point::operator--()
    {
        x--;
        y--;
        return *this;
    }

/******************************************************************************/
/*!
    \brief
        Operator to perform post-decrement on a point

        
    \return Point
        Returns a new point
*/
/******************************************************************************/
    Point Point::operator--( int)
    {
        Point nPoint=*this;
        x--;
        y--;
        return nPoint;
    }
    
/******************************************************************************/
/*!
    \brief
        Operator for unary - ,this operator negates the x and y coords of a 
        point.
        
    \return Point
        Returns a new point with the negated values.
*/
/******************************************************************************/
    Point Point::operator-() const
    {
        Point nPoint= *this;
        nPoint.x=-x;
        nPoint.y=-y;
        return nPoint;
    }
    
/******************************************************************************/
/*!
    \brief
        Operator to perform translation by adding two points
        
    \param rhs
        A const point reference used in translation operation
        
    \return Point
        Returns a new point with the added coords 
*/
/******************************************************************************/
    Point Point::operator+(const Point&rhs)
    {
        Point nPoint=*this;
        nPoint+=rhs;
        return nPoint;
    }
    
/******************************************************************************/
/*!
    \brief
        Operator to perform translation by adding a point and a double in
        said sequence
        
    \param rhs
        A const double input to be added to point
        
    \return Point
        Returns a new point with the added coords 
*/
/******************************************************************************/
    Point Point::operator+(const double rhs)
    {
        Point nPoint=*this;
        nPoint.x+=rhs;
        nPoint.y+=rhs;
        return nPoint;
    }
    

/******************************************************************************/
/*!
    \brief
        Operator to perform scaling by multiplying a point with a double 
        
    \param rhs
        A const double input to be used to multiply point coords.
        
    \return Point
        Returns a new point with the scaled coords 
*/
/******************************************************************************/
    Point Point::operator*(const double rhs)
    {
        Point nPoint=*this;
        nPoint.x*=rhs;
        nPoint.y*=rhs;
        return nPoint;
    }

///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

/******************************************************************************/
/*!
    \brief
        Operator overload to push point coords in format (x, y) into output 
        stream.
        
    \param output
        output stream variable
        
    \param pt
        Point to read coords and printed.
        
    \return std::ostream&
        
*/
/******************************************************************************/
     std::ostream& operator<<(std::ostream& output,  Point pt)
    {
       output<<"("<< pt.x<<", "<<pt.y<<")";
       return output;
    }

/******************************************************************************/
/*!
    \brief
        Operator overload to read in point coords into input 
        stream.
        
    \param input
        input stream variable
        
    \param pt
        Point to input read coords
        
    \return std::istream&
        
*/
/******************************************************************************/
     std::istream& operator>>(std::istream& input,  Point pt)
    {
        input>>pt.x>>pt.y;
        return input;
    }


///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)


/******************************************************************************/
/*!
    \brief
        Non member function
        Operator overload to perform scaling by taking in a double and a point
        and multiplying them in said sequence
        
    \param lhs
        A const double input to be used in scaling operation
        
    \param rhs
        A reference to a point to be used in scaling operation
        
    \return Point
        Returns a new point with the scaled coords 
*/
/******************************************************************************/
    Point operator*(const double lhs, Point& rhs)
    {
        Point nPoint=rhs*lhs;
        return nPoint;
    }

/******************************************************************************/
/*!
    \brief
        Non-member function 
        Operator overload to perform translation by adding a double and a point
        in that sequence.
    
    \param lhs
        double to be used together with a second param in translation
        
    \param rhs
        A const point reference used in translation operation
        
    \return Point
        Returns a new point with the added coords 
*/
/******************************************************************************/
    Point operator+(const double lhs, const Point& rhs)
    {
        Point nPoint=rhs;
        nPoint+=lhs;
        return nPoint;
    }
} // namespace CS170



