/******************************************************************************/
/*! 
\file   Point.cpp 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 05
\date   24/06/2019 
\brief
     This is file contains the function definitions for point.cpp
*/ 
/******************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{
  
  const double PI = 3.1415926535897;
  const double EPSILON = 0.00001;
  
  //////////////////////////////////////////////////////////////////////////////
  // private member functions 
  /****************************************************************************/
  /*! 
    \fn          double Point::DegreesToRadians(double degrees) const
    \brief       convert degrees to radians
    \param       degrees
    \return      double
  */ 
  /****************************************************************************/
  double Point::DegreesToRadians(double degrees) const
  {
    return (degrees * PI / 180.0);
  }
  /****************************************************************************/
  /*! 
    \fn          double Point::RadiansToDegrees(double radians) const
    \brief       convert radians to degrees
    \param       radians
    \return      double
  */ 
  /****************************************************************************/
  double Point::RadiansToDegrees(double radians) const
  {
    return (radians * 180.0 / PI);
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // 16 public member functions (2 constructors, 14 operators) 
  /****************************************************************************/
  /*! 
    \fn          Point::Point()
    \brief       default constructor
    \return      void
  */ 
  /****************************************************************************/
  Point::Point() :x{ 0 }, y{ 0 }
  {
  }
  /****************************************************************************/
  /*! 
    \fn          Point::Point(double X, double Y)
    \brief       conversion constructor
    \param       X
    \param       Y
    \return      void
  */ 
  /****************************************************************************/
  Point::Point(double X, double Y):x{ X }, y{ Y }
  {
  }
  /****************************************************************************/
  /*! 
    \fn          Point& Point::operator=(const Point &pt)
    \brief       copies rhs to lhs 
    \param       pt
    \return      Point&
  */ 
  /****************************************************************************/
  Point& Point::operator=(const Point &pt)
  {
    x = pt.x;
    y = pt.y;
    return *this;
  }
  /****************************************************************************/
  /*! 
    \fn          Point& Point::operator%(double angle)
    \brief       rotates the point by the angle 
    \param       angle
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator%(double angle)
  {
    Point temp(x*cos(DegreesToRadians(angle))-y*sin(DegreesToRadians(angle)),
              x*sin(DegreesToRadians(angle))+y*cos(DegreesToRadians(angle)));
    if (temp.x - EPSILON <= 0.0 && temp.x > -EPSILON) temp.x = 0.0;
    if (temp.y - EPSILON <= 0.0 && temp.y > -EPSILON) temp.y = 0.0;
    return temp; 
  }
  /****************************************************************************/
  /*! 
    \fn          Point& Point::operator*(double scale)
    \brief       multiply the point by the scale 
    \param       scale
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator*(double scale)
  {
    Point temp(x*scale, y*scale);
    return temp;
  }
  /****************************************************************************/
  /*! 
    \fn          Point Point::operator^(Point& pt)
    \brief       find the midpoint of 2 points 
    \param       pt
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator^(Point& pt)
  {
    Point temp((x + pt.x)/2, (y + pt.y)/2);
    return temp;
  }
  /****************************************************************************/
  /*! 
    \fn          double Point::operator-(Point& pt)
    \brief       find the distance between 2 points 
    \param       pt
    \return      double
  */ 
  /****************************************************************************/
  double Point::operator-(Point& pt)
  {
    return sqrt((x-pt.x)*(x-pt.x) + (y-pt.y)*(y-pt.y));
  }
  /****************************************************************************/
  /*! 
    \fn          Point& Point::operator+=(const Point& pt)
    \brief       adds 2 points together
    \param       pt
    \return      Point&
  */ 
  /****************************************************************************/
  Point& Point::operator+=(const Point& pt)
  {
    x += pt.x;
    y += pt.y;
    return *this;
  }
  /****************************************************************************/
  /*! 
    \fn          Point& Point::operator+=(double num)
    \brief       adds a point and a number
    \param       num
    \return      Point&
  */ 
  /****************************************************************************/
  Point& Point::operator+=(double num)
  {
    x += num;
    y += num;
    return *this;	
  }
  /****************************************************************************/
  /*! 
    \fn          Point& Point::operator++()
    \brief       prefix increment
    \return      Point&
  */ 
  /****************************************************************************/
  Point& Point::operator++()
  {
    x++;
    y++;
    return *this;
  }
  /****************************************************************************/
  /*! 
    \fn          Point Point::operator++(int)
    \brief       postfix increment
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator++(int)
  {
    Point temp(*this);
    ++(*this);
    return temp;
  }
  /****************************************************************************/
  /*! 
    \fn          Point& Point::operator--()
    \brief       prefix decrement
    \return      Point&
  */ 
  /****************************************************************************/
  Point& Point::operator--()
  {
    x--;
    y--;
    return *this;
  }
  /****************************************************************************/
  /*! 
    \fn          Point Point::operator--(int)
    \brief       postfix decrement
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator--(int)
  {
    Point temp(*this);
    --(*this);
    return temp;
  }
  /****************************************************************************/
  /*! 
    \fn          Point Point::operator-()
    \brief       unary minus
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator-()
  {
    Point temp(-x,-y);
    return temp;
  }
  /****************************************************************************/
  /*! 
    \fn          Point Point::operator+(Point& pt)
    \brief       adds 2 points together
    \param       pt
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator+(Point& pt)
  {
    Point temp(x+pt.x,y+pt.y);
    return temp;
  }
  /****************************************************************************/
  /*! 
    \fn          Point Point::operator+(double dist)
    \brief       moves the point by dist in both directions(positive)
    \param       dist
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator+(double dist)
  {
    Point temp(x+dist,y+dist);
    return temp; 
  }
  /****************************************************************************/
  /*! 
    \fn          Point Point::operator-(double dist)
    \brief       moves the point by dist in both directions(negative)
    \param       dist
    \return      Point
  */ 
  /****************************************************************************/
  Point Point::operator-(double dist)
  {
    Point temp(x-dist,y-dist);
    return temp; 
  }
  //////////////////////////////////////////////////////////////////////////////
  // 2 friend functions (operators)
  /****************************************************************************/
  /*! 
    \fn          std::ostream& operator<<(std::ostream& os, const Point& pt)
    \brief       left shift operator for output
    \param       os
    \param       pt
    \return      std::ostream&
  */ 
  /****************************************************************************/
  std::ostream& operator<<(std::ostream& os, const Point& pt)
  {
    os << "(" << pt.x << ", " << pt.y << ")";
    return os;
  }
  /****************************************************************************/
  /*! 
    \fn          std::istream& operator>> (std::istream &in, Point &pt)
    \brief       right shift operator for input
    \param       in
    \param       pt
    \return      std::istream&
  */ 
  /****************************************************************************/
  std::istream& operator>> (std::istream &in, Point &pt)
  {
    in >> pt.x;
    in >> pt.y;
    return in;
  }
  
  //////////////////////////////////////////////////////////////////////////////
  // 2 non-members, non-friends (operators)
  /****************************************************************************/
  /*! 
    \fn          Point operator*(double scale, Point& pt)
    \brief       scales a point
    \param       pt
    \param       scale
    \return      Point
  */ 
  /****************************************************************************/
  Point operator*(double scale, Point& pt)
  {
    Point temp = pt * scale;
    return temp;
  }
  /****************************************************************************/
  /*! 
    \fn          Point operator+(double dist, Point& pt)
    \brief       move a point by dist on both axis
    \param       pt
    \param       dist
    \return      Point
  */ 
  /****************************************************************************/
  Point operator+(double dist, Point& pt)
  {
    Point temp = pt + dist;
    return temp;
  }
} // namespace CS170



