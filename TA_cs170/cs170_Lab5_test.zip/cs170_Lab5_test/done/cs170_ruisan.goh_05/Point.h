/******************************************************************************/
/*! 
\file   Point.h 
\author Goh Rui San 
\par    email: ruisan.goh\@digipen.edu 
\par    DigiPen login: ruisan.goh 
\par    Course: CS170 
\par    Lab 05
\date   24/06/2019 
\brief
     This is file contains the function declarations for list.cpp.
*/ 
/******************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

namespace CS170
{
  class Point
  {
    public:
        // Constructors (2)
        Point();
        Point(double X,double Y);
        // Overloaded operators (14 member functions)
        Point& operator=(const Point &pt);
        Point operator%(double angle);
        Point operator*(double scale);
        Point operator^(Point& pt);
        double operator-(Point& pt);
        Point& operator+=(const Point& pt);
        Point& operator+=(double num);
        Point& operator++();     //prefix
        Point operator++(int); //postfix
        Point& operator--();     //prefix
        Point operator--(int); //postfix
        Point operator-();
        Point operator+(Point& pt);
        Point operator+(double dist);
        Point operator-(double dist);
        // Overloaded operators (2 friend functions)
        friend std::ostream& operator<<(std::ostream& os, const Point& pt);
        friend std::istream& operator>> (std::istream &in, Point &pt);
        
    private:
      double x; // The x-coordinate of a Point
      double y; // The y-coordinate of a Point

        // Helper functions
      double DegreesToRadians(double degrees) const;
      double RadiansToDegrees(double radians) const;
  };
  
    // Overloaded operators (2 non-member, non-friend functions)
    Point operator*(double scale, Point& point);
    Point operator+(double distance, Point& point);
    
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
