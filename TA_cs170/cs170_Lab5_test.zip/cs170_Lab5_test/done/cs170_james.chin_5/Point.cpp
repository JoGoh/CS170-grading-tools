/**************************************************************************************************************/
/*!
\file   Point.cpp
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 05
\date   24/6/2019
\brief
  Definition of member operator overloads found in Point.h
*/
/**************************************************************************************************************/
#include "Point.h"  // Point members
#include <cmath>    // sqrt, atan, sin, cos

namespace CS170
{
//! Constant defining Pi value, used for the converting Degrees and Radians functions
const double PI = 3.1415926535897;
//! Constant defining the EPSILON value, used to check how small a value is
const double EPSILON = 0.00001; 

///////////////////////////////////////////////////////////////////////////////
// Helper Function

/**************************************************************************************************************/
/*!

  \fn inline double epsilon_check(double val)

  \brief Using the given EPSILON Constant, checks how small a value is. If it is very small, it can be considered as 0.0 
  and will be returned as such

  \param val double value to be checked with EPSILON

  \return Returns a double, either the original value itself, or if it is very small, 0.0 will be returned instead

*/
/**************************************************************************************************************/
double epsilon_check(double val) {
	if ((val > -EPSILON) && (val < EPSILON)) {
		return 0.0;
	}
	else {
		return val;
	}
}

///////////////////////////////////////////////////////////////////////////////
// private member functions 

/**************************************************************************************************************/
/*!

  \fn double Point::DegreesToRadians(double degrees) const

  \brief Converts Degrees to Radians

  \param degrees double value representing the angle in degrees

  \return Returns a double representing the angle in radians

*/
/**************************************************************************************************************/
double Point::DegreesToRadians(double degrees) const
{
	return (degrees * PI / 180.0);
}

/**************************************************************************************************************/
/*!

  \fn double Point::RadiansToDegrees(double radians) const

  \brief Converts Radians to Degrees

  \param radians double value representing the angle in radians

  \return Returns a double representing the angle in degrees

*/
/**************************************************************************************************************/
double Point::RadiansToDegrees(double radians) const
{
  return (radians * 180.0 / PI);
}


///////////////////////////////////////////////////////////////////////////////
// 16 public member functions (2 constructors, 14 operators) 

/////////////////////////////////////////// Constructors (2) //////////////////////////////////////////////

/**************************************************************************************************************/
/*!

  \fn Point::Point(const double x, const double y) 

  \brief Parameterized Constructor for Point

  \param x, x value of Point

  \param y, y value of Point

*/
/**************************************************************************************************************/
Point::Point(const double x, const double y) : x(x), y(y) {}

/**************************************************************************************************************/
/*!

  \fn Point::Point()

  \brief Default Constructor for Point

*/
/**************************************************************************************************************/
Point::Point() : x(0), y(0) {}

///////////////////////////// Overloaded operators (14 member functions) ////////////////////////////////////

/**************************************************************************************************************/
/*!

  \fn Point Point::operator% (const double degrees)

  \brief Member function that rotates a Point about the origin by the specified number of degrees.

  Calls epsilon_check to check for small values

  \param rhs double value representing the angle in degrees

  \return Returns a new Reversed Point

*/
/**************************************************************************************************************/
Point Point::operator% (const double rhs) const {
	double radians = DegreesToRadians(rhs);
	return Point( epsilon_check( x * std::cos(radians) + y * -std::sin(radians) ), epsilon_check( x * std::sin(radians) + y * std::cos(radians) ) );

}

/**************************************************************************************************************/
/*!

  \fn double Point::operator-(const Point& rhs) const

  \brief Member function that calculates the difference between two Points.

  \param rhs Reference to the other point to calculate the distance inbetween.

  \return Returns the distance (type double)

*/
/**************************************************************************************************************/
double Point::operator-(const Point& rhs) const {
	return std::sqrt( std::pow( (x - rhs.x), 2) + std::pow( (y - rhs.y), 2) );
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator^(const Point& rhs) const

  \brief Member function that calculates the midpoint between two Points.

  \param rhs Reference to the other point to calculate the midpoint.

  \return Returns the Midpoint (Point obj)

*/
/**************************************************************************************************************/
Point Point::operator^(const Point& rhs) const {
	return Point( ( (x + rhs.x)/2 ) , ( (y + rhs.y)/2 ) );
}

/**************************************************************************************************************/
/*!

  \fn Point& Point::operator+= (const Point& rhs)

  \brief Member function that adds two Points.

  \param rhs Reference to the other point to add.

  \return Returns Reference to the lefthand(this) Pointer which has been modified.

*/
/**************************************************************************************************************/
Point& Point::operator+= (const Point& rhs) {
	x += rhs.x;
	y += rhs.y;
	return *this;
}

/**************************************************************************************************************/
/*!

  \fn Point& Point::operator+= (const double rhs)

  \brief Member function that adds a Point and double (add to x and y).

  \param rhs double to add.

  \return Returns Reference to the lefthand(this) Pointer which has been modified

*/
/**************************************************************************************************************/
Point& Point::operator+= (const double rhs) {
	x += rhs;
	y += rhs;
	return *this;
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator- (const double rhs) const

  \brief Member function that subtracts a Point with double (subtract to x and y).

  \param rhs double to subtract.

  \return Returns a Pointer which has been modified

*/
/**************************************************************************************************************/
Point Point::operator- (const double rhs) const {
	return Point(x - rhs, y - rhs);
}

/**************************************************************************************************************/
/*!

  \fn Point& Point::operator++()

  \brief Member function that adds one to the x/y values of the object.

  \return Returns Reference to the Pointer(this) which has been incremented by one

*/
/**************************************************************************************************************/
Point& Point::operator++() {
	x++;
	y++;
	return *this;
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator++(int)

  \brief Member function that adds one to the x/y values of the object.

  \return Returns a new Point with the value of the before incremented Point

*/
/**************************************************************************************************************/
Point Point::operator++(int) {
	Point p(x,y);
	x++;
	y++;
	return p;
}

/**************************************************************************************************************/
/*!

  \fn Point& Point::operator--()

  \brief Member function that subtracts one to the x/y values of the object.

  \return Returns Reference to the Pointer(this) which has been decremented by one

*/
/**************************************************************************************************************/
Point& Point::operator--() {
	x--;
	y--;
	return *this;
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator--(int)

  \brief Member function that subtracts one to the x/y values of the object.

  \return Returns a new Point with the value of the before decremented Point

*/
/**************************************************************************************************************/
Point Point::operator--(int) {
	Point p(x, y);
	x--;
	y--;
	return p;
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator-() const

  \brief Member function that returns a new Point with the x/y values of input Point negated.

  \return Returns a Pointer which has been negated

*/
/**************************************************************************************************************/
Point Point::operator-() const {
	return Point(-x, -y);
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator+(const Point& rhs) const

  \brief Member function that adds two Points by x/y values.

  \param rhs Reference to a Point to be added.

  \return Returns a Pointer which is a sumation of the two.

*/
/**************************************************************************************************************/
Point Point::operator+(const Point& rhs) const {
	return Point((x + rhs.x), (y + rhs.y));
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator+(const double rhs) const

  \brief Member function that adds a Point and a double by x/y values.

  \param rhs double value to be added

  \return Returns a Pointer which is a sumation of the two.

*/
/**************************************************************************************************************/
Point Point::operator+(const double rhs) const {
	return Point((x + rhs), (y + rhs));
}

/**************************************************************************************************************/
/*!

  \fn Point Point::operator*(const double rhs) const

  \brief Member function that multiplies a Point and a double by x/y values.

  \param rhs double value to multiply by

  \return Returns a Pointer of the result.

*/
/**************************************************************************************************************/
Point Point::operator*(const double rhs) const {
	return Point((x * rhs), (y * rhs));
}
///////////////////////////////////////////////////////////////////////////////
// 2 friend functions (operators)

/**************************************************************************************************************/
/*!

  \fn std::ostream& operator<<(std::ostream& os, const Point& pt)

  \brief Friend function that outputs a Point in the form of a string: (x, y), where x and y are the coordinates.

  \param os Reference to the outstream object

  \param pt Reference to the Point object being printed

  \return Returns modified outstream

*/
/**************************************************************************************************************/
std::ostream& operator<<(std::ostream& os, const Point& pt) {
	os << "(" << pt.x << ", " << pt.y << ")";
	return os;
}

/**************************************************************************************************************/
/*!

  \fn std::istream& operator<<(std::istream& is, const Point& pt)

  \brief Friend function inputs a Point. Allows two numbers (separated by whitespace) to be entered.

  \param os Reference to the istream object

  \param pt Reference to the Point object to recieve input 

  \return Returns modified istream

*/
/**************************************************************************************************************/
std::istream& operator>>(std::istream& is, Point& pt) {
	is >> pt.x;
	is >> pt.y;
	return is;
}


///////////////////////////////////////////////////////////////////////////////
// 2 non-members, non-friends (operators)

/**************************************************************************************************************/
/*!

  \fn Point operator+(const double lhs, const Point& rhs)

  \brief Non-Member, non-friend function that adds one Point and a double by the Point's x/y value

  \param lhs Double to be added 

  \param rhs Reference to Point object to be added 

  \return Returns Point Object with the sumation

*/
/**************************************************************************************************************/
Point operator+(const double lhs, const Point& rhs) {
	return (rhs + lhs);
}

/**************************************************************************************************************/
/*!

  \fn Point operator*(const double lhs, const Point& rhs)

  \brief Non-Member, non-friend function that multiplies one Point and a double by the Point's x/y value

  \param lhs Double to be multiplied

  \param rhs Reference to Point object to be multiplied

  \return Returns Point Object with the result

*/
/**************************************************************************************************************/
Point operator*(const double lhs, const Point& rhs) {
	return (rhs * lhs);
}

} // namespace CS170


