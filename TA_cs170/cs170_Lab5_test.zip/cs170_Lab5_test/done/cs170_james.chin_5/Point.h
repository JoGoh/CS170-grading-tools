/**************************************************************************************************************/
/*!
\file   Point.h
\author James Chin Jia Jun
\par    email: james.chin\@digipen.edu
\par    Digipen login: james.chin
\par    Course: CS170L
\par    Lab 05
\date   24/6/2019
\brief
  List of functions defined in Point.cpp
*/
/**************************************************************************************************************/
////////////////////////////////////////////////////////////////////////////////
#ifndef POINT_H
#define POINT_H
////////////////////////////////////////////////////////////////////////////////

#include <iostream> // istream, ostream

/**************************************************************************************************************/
/*!
  \namespace CS170
  \brief Namespace that contains the class list, struct node and definitions of other functions used for the list
*/
/**************************************************************************************************************/
namespace CS170
{

/**************************************************************************************************************/
/*!
  \class Point
  \brief Simple Class Representing a Point. Holds simple functions that change the x and y values in the Point
*/
/**************************************************************************************************************/
class Point
{
public:

    /////////////////////////////////////////// Constructors (2) //////////////////////////////////////////////

	//Parameterized Constructor for Point
	Point(double x, double y);

	//Default Constructor for Point
	Point();
    
	
	///////////////////////////// Overloaded operators (14 member functions) ////////////////////////////////////
	
	//Rotation: Member function that rotates a Point about the origin by the specified number of degrees. Returns a new Point. 
	Point operator% (double rhs) const; 
	
	//Distance (Binary operator): Member function that calculates the difference between two Points and returns the distance (type double). 
	double operator- (const Point& rhs) const;

	//Midpoint: Member function that calculates the midpoint between two Points. Returns a new Point. 
	Point operator^ (const Point& rhs) const;
	
	//Translation: Member function that adds two Points and returns a reference to the lefthand operand which has been modified. 
	Point& operator+= (const Point& rhs);

	//Translation: Member function that adds a Point and double and returns a reference to the lefthand operand which has been modified. 
	Point& operator+= (double rhs);
	
	//Translation: Member function that subtracts a double from a Point and returns a new Point. 
	Point operator- (double rhs) const;

	//Pre-increment: Member function that adds one to the x/y values of the object, returns a reference to the incremented Point.
	Point& operator++();
	//Post-increment: Member function that adds one to the x/y values of the object, returns a new Point with the value of the before incremented Point
	Point operator++(int);

	//Pre-decrement: Member function that minuses one to the x/y values of the object, returns a reference to the decremented Point.
	Point& operator--();
	//Post-decrement: Member function that minuses one to the x/y values of the object, returns a new Point with the value of the before decremented Point
	Point operator--(int);

	//Unary Negation: Member function that returns a new Point with the x/y values of input Point negated. 
	Point operator-() const;

	//Translation: Member function that adds two Points and returns a new Point. 
	Point operator+(const Point& rhs) const;

	//Translation: Member function that adds one Point and a double, returns a new Point. 
	Point operator+(double rhs) const;

	//Scale: Member function that multiplies a Point by some numeric factor of type double and returns a new Point. 
	Point operator*(double rhs) const;

    ////////////////////////////// Overloaded operators (2 friend functions) ///////////////////////////////////////
	
	//Output: Friend function that outputs a Point in the form of a string: (x, y), where x and y are the coordinates.
	friend std::ostream& operator<<(std::ostream& os, const Point& pt);

	//Input: Friend function inputs a Point. Allows two numbers (separated by whitespace) to be entered.
	friend std::istream& operator>>(std::istream& is, Point& pt);

private:
    double x; // The x-coordinate of a Point
    double y; // The y-coordinate of a Point

    // Helper functions
    double DegreesToRadians(double degrees) const;
    double RadiansToDegrees(double radians) const;
};
  
    // Overloaded operators (2 non-member, non-friend functions)
	//Translation: Non-Member, non-friend function that adds one Point and a double, returns a new Point. 
	Point operator+(double lhs, const Point& rhs);

	//Scale: Non-Member, non-friend function that multiplies a Point by some numeric factor of type double and returns a new Point. 
	Point operator*(double lhs, const Point& rhs);
} // namespace CS170

#endif
////////////////////////////////////////////////////////////////////////////////
