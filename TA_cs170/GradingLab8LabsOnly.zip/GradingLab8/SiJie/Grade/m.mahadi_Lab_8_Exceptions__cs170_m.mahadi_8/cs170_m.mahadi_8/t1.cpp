/******************************************************************************/
/*!
\file  t1.cpp
\author Muhammad Syahiddin Bin Mahadi
\par    email: m.mahadi\@digipen.edu
\par    DigiPen login: m.mahadi
\par    Course: CS170
\par    Lab 8
\date   23/3/2019 
\brief  This program calculate how much memory (in MB) can be allocated in a
program
*/
/******************************************************************************/
#include <iostream>
#include <exception>

using  namespace std;

int main(void)
{
	int counter = 0;
	
	try
	{
		while(1)
		{
			new char [1024 * 1000]; // memory allocation
			counter++; // counts the size of the program
		}
	}
	catch(...)
	{
		cout << "The amount of memory is " << counter << "MB" << endl;
	}
	return 0;
}