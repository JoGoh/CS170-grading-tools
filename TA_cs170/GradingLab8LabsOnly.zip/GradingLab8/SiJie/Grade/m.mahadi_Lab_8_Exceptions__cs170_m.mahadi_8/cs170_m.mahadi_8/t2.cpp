/******************************************************************************/
/*!
\file  t2.cpp
\author Muhammad Syahiddin Bin Mahadi
\par    email: m.mahadi\@digipen.edu
\par    DigiPen login: m.mahadi
\par    Course: CS170
\par    Lab 8
\date   23/3/2019 
\brief  This program calculates and show sum of 10 positive inputs and does not 
allow negative numbers or not-a-numbers, exits the program if it encounters one.
*/
/******************************************************************************/
#include <iostream>
#include <exception>
using  namespace std;

int main ()
{
	double input_num;
	double sum = 0;
	int counter = 0;
	
	try
	{
		cout << "Please enter 10 positive inputs: " << endl;
		
		while(counter < 10)
		{
			cin >> input_num;			
			// checks if user uses a negative number
			if (input_num < 0 || cin.fail())
			{
				cin.clear();
				cin.ignore(10000, '\n');
				throw ("This input is not allowed");
			}
			
			sum += input_num;
			counter++;
		}
		cout << "Sum of 10 positive inputs: " << sum << endl;
	}
	
	catch( const char * wrong_input )
	{
		cout << wrong_input << endl; // prints out when an invalid input is used
		cout << "Doesn't allow negative numbers or not-a-numbers (NAN)" <<endl;
	}
	
	return 0;
}