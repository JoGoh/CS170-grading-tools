/******************************************************************************/
/*!
\file   t3.cpp
\author Mohamed Haseem
\par    email: m.haseem\@digipen.edu
\par    DigiPen login: m.haseem
\par    Course: CS170
\par    Lab 08
\date   23/03/2019
\brief
    The purpose of this .cpp file is to calculate and show sum of 
    10 positive inputs by using exception mechanism. When a negative number
    or a "not a number" is entered by the user, show error message and
    suggests the user to restart the process of counting from the
    beginning or to end the program.
*/
/******************************************************************************/

#include <iostream>
using namespace std;

int main()
{
    while(1)
    {
        int input=1;
        int user=0;
        int sum=0;
        try
        {
            cout<<"\nPlease Enter 10 positive integers.\n";
            while(input!=11)
            {
                cout<<"Enter number "<<input<<":";
                cin>>user;
                if(user<0)
                    throw("You have entered a negative number.");
                else if(cin.fail())
                    throw("You have entered a Not A Number (NAN).");
                sum=sum+user;
                input++;
            }
            cout<<"The total sum is :"<<sum;
            return 0;
        }
        catch(const char* message)
        {
            cin.clear();
            cin.ignore(100000000,'\n');
            char response;
            cout<<message;
            cout<<"\nDo you want to restart the counting process? (Y/N)\t";
            cin>> response;
            while(response!='Y'&&response!='y')
            {
                if(response=='N' ||response=='n')
                    return 0;
                cin.clear();
                cin.ignore(100000000,'\n');
                cout<<"please enter a valid response : (Y/N)\t";
                cin>>response;
            }
        }
    }
        return 0;
}