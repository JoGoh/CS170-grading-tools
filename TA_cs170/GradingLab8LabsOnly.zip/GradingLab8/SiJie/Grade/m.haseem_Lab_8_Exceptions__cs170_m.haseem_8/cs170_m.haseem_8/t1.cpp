/******************************************************************************/
/*!
\file   t1.cpp
\author Mohamed Haseem
\par    email: m.haseem\@digipen.edu
\par    DigiPen login: m.haseem
\par    Course: CS170
\par    Lab 08
\date   23/03/2019
\brief
    The purpose of this .cpp file is to calculate how much memory (in MB)
    can be allocated for the program.
*/
/******************************************************************************/

#include <iostream>

int main()
{
    int size=0;
    try
    {
        while(1)
        {
            new char[1024*1000];
            size++;
        }
    }
    catch(...)
    {
        std::cout<<size<<"MB";
    }
        return 0;
}