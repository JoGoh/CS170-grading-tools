/******************************************************************************/
/*!
\file   t2.cpp
\author Mohamed Haseem
\par    email: m.haseem\@digipen.edu
\par    DigiPen login: m.haseem
\par    Course: CS170
\par    Lab 08
\date   23/03/2019
\brief
    The purpose of this .cpp file is to calculate and show sum of
    10 positive inputs by using exception mechanism. When a negative number
    or a "not a number" is entered by the user the program is terminated.
*/
/******************************************************************************/

#include <iostream>
using namespace std;

int main()
{
    int input=1;
    int user=0;
    int sum=0;
    try
    {
        cout<<"Please Enter 10 positive integers.\n";
        while(input!=11)
        {
            cout<<"Enter number "<<input<<":";
            cin>>user;
            if(user<0)
                throw("You have entered a negative number.");
            else if(cin.fail())
                throw("You have entered Not A Number (NAN).");
            sum=sum+user;
            input++;
        }
        cout<<"The total sum is :"<<sum;
    }
    catch(const char* message)
    {
        cout<<message;
        return 0;
    }
        return 0;
}