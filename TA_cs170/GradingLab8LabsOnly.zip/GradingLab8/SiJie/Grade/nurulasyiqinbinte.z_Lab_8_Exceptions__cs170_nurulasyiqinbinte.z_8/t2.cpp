/******************************************************************** 
filename   t2.cpp 
author(s)  Nurul Asyiqin Binte Zulkarnain
course     CS170  
assignment Lab 8
date   15/3/2018 
 
Brief Description: 
*This file allows the program to get the sum of 10 positive inputs.
During the input, program should use exception mechanism to display
message that negative numbers or not-a-number(NAN) is not allowed. 
If so, exit the program.
*******************************************************************/ 


#include <iostream>
#include <exception>

using namespace std;

int main()
{
    int i = 0;
    int nums[10];
    int sum(0);
    
    while(i < 10)
    {
        cout << "Enter number " << i+1 << ":";
        
        try
        {
            cin >> nums[i];
            if(nums[i] < 0)
                throw (nums[i]);
            
            if(cin.fail())
            {
                cin.clear();
                throw('a');
            }
        }
        
        catch(char y)   //if character are inputted 
        {
            cout << "Only positive integers allowed. Exiting program." << endl;
            
            cin.clear();
            cin.ignore();
            goto loop;
        }
        
        catch(int y)    //if a negative value is inputted
        {
            cout << "Negative value_comp is not allowed. Exiting program." << endl;
            
            cin.clear();
            cin.ignore();
            goto loop;
        }
        
        catch(...)
        {
            cout << "Default Exception Case. Exiting program." << endl;
            cin.clear();
            cin.ignore();
            goto loop;
        }
        
        sum += nums[i];
                
        i++;
    }
    
    cout << "Sum of " << i << " positive integers entered is: " << sum << endl;
    
    loop:
    exit(-1);
    
    return 0;
}