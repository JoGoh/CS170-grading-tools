/******************************************************************** 
filename   t3.cpp 
author(s)  Nurul Asyiqin Binte Zulkarnain
course     CS170  
assignment Lab 8
date   15/3/2018 
 
Brief Description: 
*This file allows the program to get the sum of 10 positive inputs.
During the input, program should use exception mechanism to display
message that negative numbers or not-a-number(NAN) is not allowed. 
If so, program will suggest to restart the counting process from the
beginning instead of exiting.
*******************************************************************/ 

#include <iostream>
#include <exception>

using namespace std;

int main()
{
    int i = 0;
    char c;
    int nums[10];
    int sum(0);
    
    while(i < 10)
    {
        loop:
        cout << "Enter number " << i+1 << ": ";
        try 
        {
            cin >> nums[i];
            
            if(nums[i] < 0)
            {
                i = 0;
                throw nums[i];
            }
            
            if(cin.fail())
            {
                i = 0;
                cin.clear();
                cin.ignore(100, '\n');
                throw('a');
            }
        }
        
        catch(...)
        {
            cout << "Not-a-Number (NAN) and negative numbers are not allowed. Restarting Counting.." << endl;
            
            backloop:
            cout << "Enter 'y' to restart counting or 'n' to exit: ";
            cin.clear();
            cin >> c;
            
            if(c == 'y')    //to restart count
            {
                cin.clear();
                i = 0;      //resets to get first input
                sum = 0;    //resets the total value
                cout << "Please enter the numbers again";
                goto loop;
            }
            
            if(c == 'n')    //to exit program
            {
                cin.clear();
                
                exit(-1);
            } 
            
            else
            {
                cout << "Invalid selection. Please reenter." << endl;
                i = 0;
                goto backloop;
            }

        }
        
        i++;
    }
    
    i = 0;
    
    while(i < 10)
    {
        sum += nums[i];
        
        i++;
    }
    
    cout << "Sum of " << i << " positive integers entered is: " << sum << endl;
    
    return 0;
}
