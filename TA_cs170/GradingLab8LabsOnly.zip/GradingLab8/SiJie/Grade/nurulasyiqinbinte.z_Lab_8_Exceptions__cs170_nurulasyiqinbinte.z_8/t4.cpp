/******************************************************************** 
filename   t4.cpp 
author(s)  Nurul Asyiqin Binte Zulkarnain
course     CS170  
assignment Lab 8
date   15/3/2018 
 
Brief Description: 
*This file allows the program to get the sum of 10 positive inputs.
During the input, program should use exception mechanism to display
message that negative numbers or not-a-number(NAN) is not allowed. 
If so, program will continue the counting instead of restarting.
*******************************************************************/ 

#include <iostream>
#include <exception>

using namespace std;

int main()
{
    int i = 0;
    char c; 
    int nums[10];
    int sum(0);
    
    while(i < 10)
    {
        loop: 
        cout << "Enter number " << i+1 << ": ";
        try
        {
            cin >> nums[i];
            
            if(nums[i] < 0)
                throw nums[i];
            
            if(cin.fail())
            {
                cin.clear();
                cin.ignore(100,'\n');
                throw('a');
            }
        }
        
        catch(...)
        {
            cout << "Not-a-Number (NAN) and negative numbers are not allowed. Continue Counting.." << endl;
            
            while(1)
            {
                backloop:
                cout << "Enter 'y' to continue or 'n' to exit: ";
                cin >> c;
                
                if(c == 'y')    //to continue count
                {
                    cin.clear();
                    goto loop;
                }
            
                if(c == 'n')    //to exit program
                {
                    cin.clear();
                    exit(-1);
                }

                else
                {
                    cout << "Invalid selection. Please reenter." << endl;
                    goto backloop;
                }
            }
        }
        sum += nums[i];
        
        i++;
    }
    
    cout << "Sum of positive integers entered is: " << sum << endl;
    
    return 0;
}