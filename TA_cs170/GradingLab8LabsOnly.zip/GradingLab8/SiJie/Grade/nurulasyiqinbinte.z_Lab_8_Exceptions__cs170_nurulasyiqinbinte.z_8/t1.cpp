/******************************************************************** 
filename   t1.cpp 
author(s)  Nurul Asyiqin Binte Zulkarnain
course     CS170  
assignment Lab 8
date   15/3/2018 
 
Brief Description: 
*This file allows the program to get the maximum memory allocation
in the program.
*******************************************************************/ 


#include <iostream>
#include <exception>
using namespace std;

char *count(nullptr);

inline void cntmemory()
{
    count = (new char[1024*100]);
}

int main()
{
    cout << "Counting maximum memory allocation..." << endl;
    
    unsigned int num(0);
    
    while(1)
    {
        try 
        {
            cntmemory();
            num++;
        }
        
        catch(...)
        {
            cout << "Maximum memory that can be allocated in a program is " 
            << num << " MB" << endl;
            break;
        }
    }
    
    return 0;
}