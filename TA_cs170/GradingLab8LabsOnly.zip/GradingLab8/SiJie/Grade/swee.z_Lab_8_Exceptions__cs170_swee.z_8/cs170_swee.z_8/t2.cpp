#include<iostream>
int main()
{
    int sum=0;
    int i=0;
    int count=0;
    try
    {
        while(count<10)
        {
            std::cout<<"Enter number:";
            std::cin>>i;
            
            if(std::cin.fail()||i<0)
            {
                throw 1;
            }
            sum+=i;
            count++;
            std::cout<<"sum:"<<sum<<std::endl;
        }
    }
    catch(...)
    {
        std::cout<<"negative numbers or not-a-numbers (NAN) not allowed \n";
        std::cout<<"Exiting program\n";
    }
}