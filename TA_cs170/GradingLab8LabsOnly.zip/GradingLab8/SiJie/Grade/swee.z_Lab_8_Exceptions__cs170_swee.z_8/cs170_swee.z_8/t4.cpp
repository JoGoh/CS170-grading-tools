#include<iostream>
int main()
{
    int sum=0;
    int i=0;
    int count=0;
    char YN;
    while(count<10)
    {   
        try
        {   
            std::cout<<"Enter:";
            std::cin>>i;
            if(std::cin.fail()||i<0)
            {
                throw 1;
            }
            sum+=i;
            count++;
            std::cout<<"sum["<<count<<"]:"<<sum<<std::endl;
        }
        catch(...)
        {
            std::cout<<"negative numbers or not-a-numbers (NAN) not allowed \n";
            std::cout<<"Continue counting? (Y/N)\n";            
            std::cin.clear();
            std::cin.ignore(100,'\n');
            std::cin>>YN;
            if (YN=='Y' || YN== 'y')
            {
                std::cout<<"Counting from count "<<count<<std::endl;
            }
            else if (YN=='N' || YN== 'n')
            {
                std::cout<<"Exiting program\n";
                count=10;
            }
        }
    }   
}