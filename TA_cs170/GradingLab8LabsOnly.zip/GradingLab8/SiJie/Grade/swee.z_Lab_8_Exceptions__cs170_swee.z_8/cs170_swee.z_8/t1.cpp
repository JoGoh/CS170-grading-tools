#include <iostream>
#include <exception> //bad alloc exception
int main()
{
    int i =0;//count the number of mb
    try
    {
        while(1)
        {
            new char[1000*1024];
            i++;
        }
    }
    catch(...)
    {
        std::cout<<i<<std::endl;
    }
}