/******************************************************************************/
/*!
\file t1.cpp
\author Mabel Lu See Chi
\par email: seechimabel.lu\@digipen.edu
\par DigiPen login: seechimabel.lu
\par Course: CS170C
\par Lab 08
\date 23/03/2019
\brief   
  In t1, we are to use exception mechanism to calculate how much memory (in MB) can be allocated in a program.  
*/
/******************************************************************************/
#include <iostream>

int main (void){
  int memory = 0;
  try
  {
    while(1){
      new char[1024*1000];
      memory++;
    }
  }
  catch(...)
  {
    std::cout << "The amount of memory that can be allocated is " << memory << "MB." << std::endl;
  }
  return 0;
}
