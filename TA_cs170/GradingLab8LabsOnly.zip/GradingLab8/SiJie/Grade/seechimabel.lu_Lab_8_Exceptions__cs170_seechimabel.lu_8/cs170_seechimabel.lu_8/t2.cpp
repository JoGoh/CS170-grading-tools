/******************************************************************************/
/*!
\file t1.cpp
\author Mabel Lu See Chi
\par email: seechimabel.lu\@digipen.edu
\par DigiPen login: seechimabel.lu
\par Course: CS170C
\par Lab 08
\date 23/03/2019
\brief   
  In t2, we are to calculate and show sum of 10 positive inputs.
  During the input, program should use exception mechanism to display a message that it doesnt allow 
  negative numbers or not-a-number (NAN) if so is the input and then exit the program. 
*/
/******************************************************************************/
#include <iostream>

int main (void){
  double num, sum;
  while(1){
  try
  {
    std::cout << "Please enter 10 numbers:" << std:endl;
    for (int i=0; i<10; i++)
    {
      std::cin >> num;
      if (std::cin.fail())
        throw std::cin.fail();
      if (num<0)
        throw num;
      sum += num;
    }
  }
    std::cout << "The sum of the 10 numbers is " << sum << "." << std::endl;
    
  catch (double n)
  {
    std::cout << "Error: The number entered is a negative number." << std::endl;
  }
  
  catch (...)
  {
    std::cout << "Error: The number entered is not-a-nummber (NAN)." << std::endl;
  }
  }
  return 0;
}