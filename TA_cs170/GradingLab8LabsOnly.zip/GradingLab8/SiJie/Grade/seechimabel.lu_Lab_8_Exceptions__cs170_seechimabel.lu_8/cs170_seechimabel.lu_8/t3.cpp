/******************************************************************************/
/*!
\file t1.cpp
\author Mabel Lu See Chi
\par email: seechimabel.lu\@digipen.edu
\par DigiPen login: seechimabel.lu
\par Course: CS170C
\par Lab 08
\date 23/03/2019
\brief   
  In t3, we are to calculate and show sum of 10 positive inputs.
  During the input, program should use exception mechanism to display a message that it doesnt allow negative numbers or
  not-a-number (NAN) if so is the input, suggest to restart the process of counting from the beginning.  
*/
/******************************************************************************/
#include <iostream>

int main (void){
  double num, sum;
  char ans;
  while(1){
    try
    {
    sum=0;  
    std::cout << "Please enter 10 numbers:" << std:endl;
    for (int i=0; i<10; i++)
    {
      std::cin >> num;
      if (std::cin.fail())
        throw std::cin.fail();
      if (num<0)
        throw num;
      sum += num;
    }
    std::cout << "The sum of the 10 numbers is " << sum << "." << std::endl;
      break;
    }
      
    catch (double n)
    {
      std::cout << "Error: The number entered is a negative number." << std::endl;
      std::cin.clear();
      std::cin.ignore();
      std::cout << "Would you like to restart counting? (Please enter "Y" for Yes or "N" for No)" << std::endl;
      std::cin >> ans;
      if (ans == 'N')
        break;
    }
      
    catch (...)
    {
      std::cout << "Error: The number entered is not-a-nummber (NAN)." << std::endl;
      std::cin.clear();
      std::cin.ignore();
      std::cout << "Would you like to restart counting? (Please enter "Y" for Yes or "N" for No)" << std::endl;
      std::cin >> ans;
      if (ans == 'N')
        break;
    }
  }  
  return 0;
}

