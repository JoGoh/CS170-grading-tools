/******************************************************************************/
/*!
\file t2.cpp
\author Claudia Koh
\par email: koh.c\@digipen.edu
\par DigiPen login: koh.c
\par Course: CS170-C
\par Lab 08
\date 15/3/2019
\brief
This C++ program calculates and shows sum of 10 positive inputs and exits 
the program if negative numbers or not-a-numbers (NAN) is detected as input.
*/
/******************************************************************************/
#include <iostream>

int main()
{
  double sum = 0;  // Variable to hold sum, initialize to 0
  double input;    // Variable to hold input values
  
  std::cout << "Please enter 10 positive inputs." << std::endl;
  
  try
  {
    // Loop counter, loop 10 inputs
    for(int i=1; i<11; i++)
    {
      std::cout << "Input Number #" << i << ": ";
      std::cin >> input;
      
      if(std::cin.fail()) // If NAN input detected
      {
        throw input;
      }
      else if (input <0)  // If negative number input detected
      {
        throw input;
      }
      else
      {
        sum += input;
      }
    }
    // Print out sum
    std::cout << "The sum of the inputs is " << sum << "." << std::endl;
  }
  catch(...)
  {
    std::cout<<"Not allowed. Negative number or not-a-numbers (NAN) detected." 
    << std::endl;
  }
  return 0;
}