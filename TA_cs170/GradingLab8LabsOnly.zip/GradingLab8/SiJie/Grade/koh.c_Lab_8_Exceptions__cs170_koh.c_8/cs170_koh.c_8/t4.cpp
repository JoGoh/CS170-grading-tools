/******************************************************************************/
/*!
\file t4.cpp
\author Claudia Koh
\par email: koh.c\@digipen.edu
\par DigiPen login: koh.c
\par Course: CS170-C
\par Lab 08
\date 15/3/2019
\brief
This C++ program calculates and shows sum of 10 positive inputs and suggests 
to continue the process of counting from the beginning if negative numbers 
or not-a-numbers (NAN) is detected as input.
*/
/******************************************************************************/
#include <iostream>
#include <climits>

int main()
{
  double sum = 0;  // Variable to hold sum, initialize to 0
  double input;    // Variable to hold input values
  char response;   // Variable to hold char response to suggestion
  
  std::cout << "Please enter 10 positive inputs." << std::endl;
  
  // Loop counter, loop 10 inputs
  for(int i=1; i<11; i++)
  {
    try
    {
      std::cout << "Input Number #" << i << ": ";
      std::cin >> input;
      
      if(std::cin.fail()) // If NAN input detected
      {
        std::cin.clear();               // Clear fail flag
        std::cin.ignore(INT_MAX,'\n');  // Ignore till end of line
        throw input;
      }
      else if (input <0)  // If negative number input detected
      {
        throw input;
      }
      else
      {
        sum += input;
      }
    }
    catch(...)
    {
      std::cout<<"Not allowed. Negative number or not-a-numbers (NAN) detected."
      << std::endl;
      std::cout << "Do you want to continue counting? (Y/N)" << std::endl;
      
      std::cin >> response;
      
      if(response == 'N' || response == 'n')  // If 'No' option selected
      {
        return 0;   // Exit the program
      }
      else
      {
        continue;   // Otherwise continue the counting
      }
    }
  }
  // Print out sum
  std::cout << "The sum of the inputs is " << sum << "." << std::endl;
  return 0;
}