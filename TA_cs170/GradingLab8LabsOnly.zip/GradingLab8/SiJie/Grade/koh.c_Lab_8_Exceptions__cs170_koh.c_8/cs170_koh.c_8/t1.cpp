/******************************************************************************/
/*!
\file t1.cpp
\author Claudia Koh
\par email: koh.c\@digipen.edu
\par DigiPen login: koh.c
\par Course: CS170-C
\par Lab 08
\date 15/3/2019
\brief
This C++ program calculates how much memory (in MB) can be allocated 
in a program.
*/
/******************************************************************************/
#include <iostream>

int main()
{
  int total_memory;         // Variable to store total memory count
  
  try
  {
    while(1)
    {
      new char[1024*1000];  // To count number of MB
      total_memory++;       // Increase the total memory count
    }
  }
  catch(...)
  {
    std::cout<< 
    "The amount of memory (in MB) that can be allocated in a program is " 
    << total_memory << "MB." << std::endl;
  }
  return 0;
}