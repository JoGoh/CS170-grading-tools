/******************************************************************************/
/*!
\file   t3.cpp
\author KEE Chuan Ji Malcolm
\par    email: kee.c\@digipen.edu
\par    DigiPen login: kee.c 
\par    Course: CS170
\par    Lab 8
\date   21/03/2019
\brief  
    This program sums 10 valid inputs. Valid inputs are not negative numbers nor
    not-a-number. If an invalid input is entered, the program reflects an error 
    message, and restarts the program.
*/
/******************************************************************************/

#include <exception>
#include <iostream>
#include <limits>

using namespace std;
const char* error = "Cannot input negative numbers or not-a-number.";

void sum10 (void) 
{
  try{
    int sum = 0;
    for(int i=10; i--;)
    {
      int entry;
      cout << "Enter positive number : ";
      cin >> entry;
      // Test for exception, otherwise, continue with summation.
      if ( cin.fail() || entry < 0 ) 
        throw ( error );      
      sum += entry;
    } 
    // Summation succeeded, prints sum
    cout << "Sum of last 10 inputs : " << sum << endl;
  } 
  catch ( const char* message ) 
  {
    // Restarts summation if exception is caught
    cout << message << endl << "Restarting sum of 10 numbers..." << endl << endl;
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
    sum10();
  }
}

int main (void)
{
  sum10();
  return 0;
}
