/******************************************************************************/
/*!
\file   t2.cpp
\author KEE Chuan Ji Malcolm
\par    email: kee.c\@digipen.edu
\par    DigiPen login: kee.c 
\par    Course: CS170
\par    Lab 8
\date   21/03/2019
\brief  
    This program sums 10 valid inputs. Valid inputs are not negative numbers nor
    not-a-number. If an invalid input is entered, the program reflects an error 
    message, and terminates the program.
*/
/******************************************************************************/

#include <exception>
#include <iostream>

using namespace std;
const char* error = "Cannot input negative numbers or not-a-number.";

int main (void)
{
  try
  {
    int sum = 0;
    for(int i=10; i--;)
    {
      int entry;
      cout << "Enter positive number : ";
      cin >> entry;
      // Test for exception, otherwise, continue with summation.
      if ( cin.fail() || entry < 0 ) 
        throw ( error );      
      sum += entry;
    }  
    cout << "Sum of last 10 inputs : " << sum << endl;
  } 
  catch ( const char* message ) 
  {
    // Print error message and terminates program
    cout << endl << message << endl << "Terminating program..." << endl;
    return 0;    
  }
  return 0;
}
