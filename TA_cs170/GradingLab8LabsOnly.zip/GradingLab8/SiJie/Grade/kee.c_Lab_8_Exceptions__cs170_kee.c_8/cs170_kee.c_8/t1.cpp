/******************************************************************************/
/*!
\file   t1.cpp
\author KEE Chuan Ji Malcolm
\par    email: kee.c\@digipen.edu
\par    DigiPen login: kee.c 
\par    Course: CS170
\par    Lab 8
\date   21/03/2019
\brief  
    This program determines how many Mega Byte of data the program can allocate
    before aborting by using exceptions.
*/
/******************************************************************************/

#include <exception>
#include <iostream>

using namespace std;

char* mb = nullptr;

int main (void)
{
  int size = 0;
  try
  {
    while(1)
    {
      mb = new char [1024*1000];    // Allocate 1 MB
      size++;
    }
  } 
  catch (...)   // Catches failure to allocate
  {
    // Prints current allocated MB size and terminate program.
    cout << "The program can allocate : " << size << "MB"<< endl;
    return 0;    
  }
  return 0;
}
