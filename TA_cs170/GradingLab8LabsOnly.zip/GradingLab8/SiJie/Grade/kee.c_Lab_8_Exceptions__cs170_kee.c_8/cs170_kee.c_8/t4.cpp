/******************************************************************************/
/*!
\file   t4.cpp
\author KEE Chuan Ji Malcolm
\par    email: kee.c\@digipen.edu
\par    DigiPen login: kee.c 
\par    Course: CS170
\par    Lab 8
\date   21/03/2019
\brief  
    This program sums 10 valid inputs. Valid inputs are not negative numbers nor
    not-a-number. If an invalid input is entered, the program reflects an error 
    message, and allows the summation to resume.    
*/
/******************************************************************************/

#include <exception>
#include <iostream>
#include <limits>

using namespace std;
const char* error = "Cannot input negative numbers or not-a-number.";

int main (void)
{
  int sum = 0;
  for(int i=10; i; i--)
  {
    int entry;
    cout << "Enter positive number : ";
    try
    {
      cin >> entry;
      // Test for exception, otherwise, continue with summation.
      if ( cin.fail() || entry < 0 ) 
        throw ( error );  
      sum += entry;
    } 
    catch ( const char* message ) 
    {
      // Print error and resumption message
      cout << message<< endl << "Resume summation" << endl << endl;
      cin.clear();
      cin.ignore(numeric_limits<streamsize>::max(), '\n');
      i++;      // Add one more attempt
    }
  }
  // Summation succeeded, prints sum
  cout << "Sum of last 10 inputs : " << sum << endl;
  return 0;
}
