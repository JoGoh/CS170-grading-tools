/******************************************************************************/
/*!
\file t1.cpp
\author Ang Ming Hui Rachel
\par email: minghuirachel.ang\@digipen.edu
\par DigiPen login: minghuirachel.ang
\par Course: CS170
\par Lab 08
\date 19/03/2019
\brief
This file calculates how much memory can be allocated in this program
*/
/******************************************************************************/
#include <iostream>

int main(void)
{
    int countNum = 0;
    char *point = 0;
    
    try
    {
        while(1)
        {
            
            point = new char[1024*1000];
            countNum++; //counting spaces in MB used
            *point = '0'; //using the space point is pointing to
        }
    }
    
    catch(...)
    {
        std::cout<<"The amount of memory allocated is " <<countNum<<" MB.";
    }
    
    return 0;
}