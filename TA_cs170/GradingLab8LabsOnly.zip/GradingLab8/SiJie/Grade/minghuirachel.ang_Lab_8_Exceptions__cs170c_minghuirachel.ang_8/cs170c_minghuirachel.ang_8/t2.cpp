/******************************************************************************/
/*!
\file t2.cpp
\author Ang Ming Hui Rachel
\par email: minghuirachel.ang\@digipen.edu
\par DigiPen login: minghuirachel.ang
\par Course: CS170
\par Lab 08
\date 19/03/2019
\brief
This file contains a program that requires users to input any 10 positive
 numbers.  Errors will be thrown at negative number inputs.
*/
/******************************************************************************/
#include <iostream>

int main (void)
{
    double var=0;
    double total=0;
    std::string strings {};
    
    try
    {
        std::cout<<"Please enter a positive number:"<<std::endl;
        
        for(int i=0; i!=10; i++)
        {
            std::cout<<"Enter value number" << i+1 <<std::endl;
            std::cin>>var; //user input to store in var
            
            if(var<0 || std::cin.fail()) //check if var is negative or a number.
            {
                throw var;
            }
            
            total += var; //sums up all positive number input
        }
    }
    
    catch(...)
    {
        std::cin.clear();
        std::getline(std::cin, strings);
        std::cout<<"Negative numbers and non-numerical numbers ";
        std::cout<<"are not allowed!"<<std::endl;
    }
    
    std::cout<<"The total values of the inputs is "<<total<<std::endl;
    return 0;
}