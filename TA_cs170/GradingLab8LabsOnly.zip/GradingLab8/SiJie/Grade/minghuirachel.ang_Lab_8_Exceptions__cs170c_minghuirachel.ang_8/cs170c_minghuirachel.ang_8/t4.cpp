/******************************************************************************/
/*!
\file t4.cpp
\author Ang Ming Hui Rachel
\par email: minghuirachel.ang\@digipen.edu
\par DigiPen login: minghuirachel.ang
\par Course: CS170
\par Lab 08
\date 19/03/2019
\brief
This file contains a program that requires a user to key in 10 positive numbers.
When a negetive number input is detected, the system will prompt the user to 
either continue or exit, continuing the list of 10 positive number input, And 
show the sum of the input.
*/
/******************************************************************************/
#include <iostream>

int main (void)
{
    double var=0;
    double total=0;
    int count=1;
    int choice=0;
    std::string strings {};
    
    std::cout<<"Please enter a positive number:"<<std::endl;
    
    for( ; count<=10; )
    {
        try
        {
            std::cout<<"Enter value number" << count <<std::endl;
            std::cin>>var; //user input to store in var
            
            if(var<0 || std::cin.fail()) //check if var is negative or
                                         //a number.
            {
                var=0; //set var as 0 so it is not added into total
                       //count--; //current count don't care
                throw var;
            }
            total += var;
            count++; //counts when a number is valid
        }
        
        catch(...)
        {
            std::cin.clear();
            std::getline(std::cin, strings);
            std::cout<<"Negative numbers are not allowed! Press 1 to continue,";
            std::cout<<" anything else to quit."<<std::endl;
            std::cin>>choice;
            
            if(choice)
            {
                
                continue;
            }
            else
            {
                return 0;
            }
        }
        
    }
    
    std::cout<<"The total values of the inputs is "<<total<<std::endl;
    return 0;
}