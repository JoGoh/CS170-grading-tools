/******************************************************************************/
/*!
\file t3.cpp
\author Ang Ming Hui Rachel
\par email: minghuirachel.ang\@digipen.edu
\par DigiPen login: minghuirachel.ang
\par Course: CS170
\par Lab 08
\date 19/03/2019
\brief
This file contains a programm which requires users to enter 10 positive 
numbers.  When a negative number input is detected, the system will suggest the
user to return 10 positive numbers again or exit. And show the sum of the input.
*/
/******************************************************************************/
#include <iostream>

int main (void)
{
    double var;
    int total = 0;
    int choice = 0;
    std::string strings {};
    
    while(1)
    {
        try
        {
            std::cout<<"Please enter a positive number:"<<std::endl;
            
            for(int i=0; i!=10; i++)
            {
                std::cout<<"Enter value number" << i+1 <<std::endl;
                std::cin>>var; //user input to store in var
                
                if(var<0 || std::cin.fail()) //check if var is negative or
                                             //a number.
                {
                    var=0; //set var as 0 so it is not added into total
                    throw var;
                }
                total+=var;
            }
            break;
        }
        
        catch(...)
        {
            std::cin.clear();
            std::getline(std::cin, strings);
            std::cout<<"Negative numbers are not allowed! Press 1 to restart, ";
            std::cout<<"anything else to quit."<<std::endl;
            std::cin>>choice;
            
            if(choice)
            {
                total=0;
                continue;
            }
            else
            {
                return 0;
            }
        }
    
    }
    
    std::cout<<"Your total value is :"<<total;
    return 0;
}