/******************************************************************************/
/*!
\file   t3.cpp
\author Muhammad Nadhir Bin Zulindra
\par    email: m.zulindra\@digipen.edu
\par    DigiPen login: m.zulindra
\par    Course: CS170
\par    Lab #8
\date   22/3/2019
\brief  
    This file calculates and show sum of 10 positive inputs
    If the number is a negative or not a number, it will restart the program
    
    
  Hours spent on this assignment: 1 hour

    
  
*/
/******************************************************************************/
#include <iostream>
#include <climits>

int main (void)
{
    bool running = true;
    int i;
    double input, sum=0;
    
    while (running)
    {
        std::cout<< "Please enter 10 positive inputs."<< std::endl;
        try
        {
            for(i=1; i<11; i++)
            {
                std::cout<<"Number #"<<i<< ": ";
                std::cin>>input;
                if(std::cin.fail())
                {
                    std::cin.clear(); // Clears the error flag for input
                    
                    // Read (but don't do anything) until I reach EOF
                    std::cin.ignore(INT_MAX,'\n'); 
                    throw input;
                }
                else if(input<0)
                    throw input;
                else
                    sum+=input;
            }   
        }
        
        catch (...)
        {
			char option;
            std::cout << "This program does not allow negative number " 
            "or not-a-number (NAN).\n\n";
            std::cout << "Do you want to restart? y/n\n";
			std::cin>>option;
			
			if(option == 'n')
				{
					return 0;
				}
			else if (option=='y')
			{
				std::cin.get();
				continue;
			}
             
			else
			{
				std::cout<<"Error! Cannot recognize option. Exiting program";
				return 0;
			}
        }
        
        running = false;
        if (!running){
        std::cout << "Total sum is "<< sum<< ".";
        return 0;
        }
    }
}