/******************************************************************************/
/*!
\file   t1.cpp
\author Muhammad Nadhir Bin Zulindra
\par    email: m.zulindra\@digipen.edu
\par    DigiPen login: m.zulindra
\par    Course: CS170
\par    Lab #8
\date   22/3/2019
\brief  
    This file calculates how much memory (in MB) can be allocated in a program
    
    
  Hours spent on this assignment: 1 hour

    
  
*/
/******************************************************************************/
#include <iostream>

using namespace std;

int main (void)
{
    int counter;
    
    try
    {
        while (1)
        {
            new char[1024*1000];
            counter++;
        }
    }
    catch(...)
    {
        cout<< "The amount of memory space (in MB) that can be "
        "allocated in a program is "
        << counter<< "MB."<<endl;
    }
    return 0;
}