/*****************************************************************************/
    /*!
    \file   t2.cpp
    \author Nur Afifah Zaini
    \par    email: n.zaini\@digipen.edu
    \par    Digipen login:n.zaini   
    \par    Course: CS170   
    \par    Lab 08
    \date   22/3/2019
    \brief
    This code calculates and shows the sum of 10 positive inputs. 
    It will display a message and exit the program when 
    a negative numbers or not-a-numbers (NAN) is 
    entered. 
    */
/*****************************************************************************/
#include <iostream>

int main (void) 
{
    double num=0;//input
    double sum=0;
    int count=0;
    std::cout<<"Please enter 10 inputs: "<<std::endl;
    while (count!=10)
    {
        std::cout<<"Enter: ";
        try
        {
            if(num<0)//negative
            {
                throw("Invalid input. Only positive numbers allowed");
            }
            else if(std::cin.fail())//NAN
            {
                throw("Invalid input. Characters and symbols are not allowed");
            }
            else
            {
                std::cin>>num;
                count++;//counter
                sum+=num;//total
            }
        }
        catch(const char *message)//catch string
        {
            std::cout<<message;
            return 0;
        } 
    }
    std::cout<<"Sum ="<<sum; //total sum
    return 0;
}