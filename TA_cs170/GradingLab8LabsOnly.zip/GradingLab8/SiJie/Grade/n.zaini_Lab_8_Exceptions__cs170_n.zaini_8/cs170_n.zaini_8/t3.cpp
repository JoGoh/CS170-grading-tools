/*****************************************************************************/
    /*!
    \file   t3.cpp
    \author Nur Afifah Zaini
    \par    email: n.zaini\@digipen.edu
    \par    Digipen login:n.zaini   
    \par    Course: CS170   
    \par    Lab 08
    \date   22/3/2019
    \brief
    This code calculates and shows the sum of 10 positive inputs. 
    It will display a message and suggests to restart the process of counting 
    from the beginning the program when a negative numbers or not-a-numbers 
    (NAN) is entered. 
    */
/*****************************************************************************/
#include <iostream>
#include <climits>

int main () 
{
    while(1)
    {
        double num=0;//input
        double sum=0;
        int count=0;
        char answer;
        std::cout<<"Please enter 10 inputs"<<std::endl;
        while (count!=10)
        {
            std::cout<<"Enter: ";
            try
            {
                std::cin>>num;
                if(num<0)//negative
                {
                    throw("Invalid. Only positive numbers allowed.") ;
                }
                
                else if(std::cin.fail())//NAN
                {
                    
                    throw("Invalid. Characters and symbols are not allowed");
                }
                else
                {
                    count++;
                    sum+=num;
                }
            }
            catch(const char *message)
            {
                std::cin.clear();//clears
                std::cin.ignore(INT_MAX,'\n');//ignore everything
                std::cout<<message<<std::endl;
                std::cout<<"Do you want to restart from the beginning? y/n"
                <<std::endl;
                
                std::cin>>answer;
                if(answer != 'y' && answer != 'Y' )
                {
                    return 0;
                }
                
                else 
                {
                    count=0;//restart
                    sum=0;
                }
            }   
        }
    std::cout<<"Sum ="<<sum;
    break;
    
    }
    return 0;
}