/*****************************************************************************/
    /*!
    \file   t1.cpp
    \author Nur Afifah Zaini
    \par    email: n.zaini\@digipen.edu
    \par    Digipen login:n.zaini   
    \par    Course: CS170   
    \par    Lab 08
    \date   22/3/2019
    \brief
    This program calculates how much memory (in MB) can be allocated in a 
    program. 
    */
/*****************************************************************************/
#include <iostream>

int main (void) 
{

    int num=0;
    try
    {
        while(1)
        {
            new char[1024*1000];
            num++;//counter
        }
    }
    
    catch(...) //catch any type(wild card)
    {
        std::cout<<"Done allocating memory"<<std::endl; 
        std::cout<<"Total number of allocated memory: "<<num<<"MB"; 
    }
    
    return 0;
}