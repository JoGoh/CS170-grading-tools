/******************************************************************************/
/*!
\file t2.cpp
\author Michel Shane Keh
\par email: m.keh\@digipen.edu
\par DigiPen login: m.keh
\par Course: CS170
\par Lab 08
\date 19/03/2019
\brief
This file contains addition of 10 numbers. any error terminates the program
*/
/******************************************************************************/
#include <iostream>
#include <cmath>

using namespace std;

int main (void)
{
	try
	{
		int num = 0;	//counter for inputs
		int in = 0;		//input number
		int ans = 0;	//total sum
		while(num<10)
		{
			cin >> in;
			
			if(in<0)	//if negative number
			{
				throw("No negative numbers");
			}
			else if(cin.fail())	//if not even a number
			{
				throw("No NAN");
			}
			else	//if is positive number
			{
				ans += in;
				num++;
			}
		}
		cout << "Sum of total is:" << ans << endl;
	}
	catch(const char *message)
	{
		cout << message << endl;
	}
	return 0;
}
