/******************************************************************************/
/*!
\file t1.cpp
\author Michel Shane Keh
\par email: m.keh\@digipen.edu
\par DigiPen login: m.keh
\par Course: CS170
\par Lab 08
\date 19/03/2019
\brief
This file contains counting of the program size.
*/
/******************************************************************************/
#include <iostream>

using namespace std;

int main(void)
{
	int size = 0;
	try
	{
		while(1)
		{
			new char[1024*1000];
			size ++;
		}
	}
	catch(...)
	{
		cout << "Max memory allocated in the program is : " << size << "MB";
	}
	return 0;
}