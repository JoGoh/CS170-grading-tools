/******************************************************************************/
/*!
\file t3.cpp
\author Michel Shane Keh
\par email: m.keh\@digipen.edu
\par DigiPen login: m.keh
\par Course: CS170
\par Lab 08
\date 19/03/2019
\brief
This file contains addition of 10 numbers but starting from beginning.
*/
/******************************************************************************/
#include <iostream>
#include <cmath>

using namespace std;

int main (void)
{
	while(1)
	{
		cout << "Enter 10 numbers: "<< endl;
		try
		{
			int num = 0;	//counter for inputs
			double in = 0;		//input number
			double ans = 0;	//total sum
			while(num<10)
			{
				cin >> in;
				
				if(in<0)	//if negative number
				{
					throw("No negative numbers");
				}
				else if(cin.fail())	//if not even a number
				{
					cin.clear();
					cin.ignore(1000000,'\n');
					throw("No NAN");
				}
				else	//if is positive number
				{
					ans += in;
					num++;
				}
			}
			cout << "Sum of total is: " << ans << endl;
			break;	//end of program
		}
		catch(const char *message)
		{
			char response;
			cout << message << endl;
			while(response != 'Y' || response != 'y')	//if its not y or n ask again
			{		
				cout << "Do you want to continue?(Y/N): ";	//asks if you want to continue			
				cin >> response;
				cin.clear();
				cin.ignore(1000000,'\n');
				if(response == 'N' || response == 'n')	//if no stop program
					return 0;
				else if(response == 'Y' || response == 'y')
					break;
				
			}
		}
	}
	return 0;
}
