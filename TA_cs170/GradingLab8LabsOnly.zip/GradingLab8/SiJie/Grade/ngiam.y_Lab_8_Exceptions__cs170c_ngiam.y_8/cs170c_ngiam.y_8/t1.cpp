/******************************************************************************/
/*!
\file t1.cpp
\author Ngiam Yee Tong
\par email: ngiam.y\@digipen.edu
\par DigiPen login: ngiam.y
\par Course: CS170L
\par Lab 08
\date 15/03/2019
\brief
  This file contain the functions for t1.cpp

  Hours spent on this assignment: 5

  Specific portions that gave you the most trouble: finding how to test
  cases
*/
/******************************************************************************/

#include <iostream>//cout,endl

/******************************************************************************/
/*!
  \brief
    calculate how much memory (in MB) can be allocated in a
    program

*/
/******************************************************************************/

int main(void)
{
  char *p=nullptr;
  size_t count=0;
  try
  {
    
    while(1)//loop will end once it allocated till max
    {
      p = new char[1024*1000];
      (void)(p);// prevent warning
      count++;
    }
  }
  catch(...)//exception catch any default
  {
    std::cout<<"The total memory allocated is "<< count 
    <<" MBs" << std::endl;
  }
  return 0;
}