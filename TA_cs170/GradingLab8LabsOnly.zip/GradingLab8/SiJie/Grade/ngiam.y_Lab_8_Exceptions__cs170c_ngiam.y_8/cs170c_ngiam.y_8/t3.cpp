/******************************************************************************/
/*!
\file t3.cpp
\author Ngiam Yee Tong
\par email: ngiam.y\@digipen.edu
\par DigiPen login: ngiam.y
\par Course: CS170L
\par Lab 08
\date 15/03/2019
\brief
  This file contain the functions for t3.cpp

  Hours spent on this assignment: 5

  Specific portions that gave you the most trouble: finding how to test
*/
/******************************************************************************/

#include <iostream>//cout,endl
#define INT_MAX 2147483647

/******************************************************************************/
/*!
  \brief
    calculate and show sum of 10 positive inputs.exception
    mechanism to display a message that it doesn't allow negative numbers 
    or not-a-numbers (NAN) if so is the
    input and then suggest to restart from the beginning

*/
/******************************************************************************/

int main(void)
{
  double total=0,i=0;
  int input=1;
  while(input==1)//will start again when user input 1
  {
    try
    {
      std::cout<<"Enter 10 positive inputs"<<std::endl;
      for(int t=1;t<=10;t++)
      {
        std::cout<<"Key in No."<<t<<":"<<std::endl;
        std::cin>>i;
        if(std::cin.fail()||i<0)//No Nan and when input is negative
        {
          std::cout<<"Press 1 to restart or 2 to exit"<<
          std::endl;
          throw 0;
        }
        total+=i;
      }
      std::cout<<"Total sum is " << total <<std::endl;
      return 0;
    }
    catch(...)
    {
      std::cin.clear();//clear flags
      std::cin.ignore(INT_MAX,'\n');//ignore till end line
      std::cin>>input;
      total=0;//reset the total
      if(input!=1)
      {
        std::exit(0);
      }
    }
  }
  return 0;
}