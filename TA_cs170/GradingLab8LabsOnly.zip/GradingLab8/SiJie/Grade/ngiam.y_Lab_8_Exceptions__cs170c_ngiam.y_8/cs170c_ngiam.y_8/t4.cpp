/******************************************************************************/
/*!
\file t4.cpp
\author Ngiam Yee Tong
\par email: ngiam.y\@digipen.edu
\par DigiPen login: ngiam.y
\par Course: CS170L
\par Lab 08
\date 15/03/2019
\brief
  This file contain the functions for t4.cpp

  Hours spent on this assignment: 5

  Specific portions that gave you the most trouble: finding how to test
  cases
*/
/******************************************************************************/

#include <iostream>//cout,endl
#define INT_MAX 2147483647

/******************************************************************************/
/*!
  \brief
    calculate and show sum of 10 positive inputs.exception
    mechanism to display a message that it doesn't allow negative numbers 
    or not-a-numbers (NAN) if so is the
    input and then suggest to continue the counting

*/
/******************************************************************************/

int main(void)
{
  double total=0, i=0;
  int input=0;
  int t=10;// for the 10 inputs
  while(t)//loop ends when 10 positive no. is inputted
  {
    try
    {
      std::cout<<"Enter Your ("<<t<<") Positive Number"<<std::endl;
      std::cin>>i;
      if(std::cin.fail()||i<0)//No Nan and when input is negative
      {
        std::cout<<"Press 1 to continue or 2 to exit"<<
        std::endl;
        throw 0;
      }
      t--;
      total+=i;
    }
    catch(...)
    {
      std::cin.clear();//clear flags
      std::cin.ignore(INT_MAX,'\n');//ignore all other strings till end line
      std::cin>>input;
      if(input!=1)
      {
        std::cin.clear();
        std::cin.ignore(INT_MAX,'\n');
        std::exit(0);//exit program
      }
    }
  }
  std::cout<<"Total sum is "<< total <<std::endl;
  return 0;
}