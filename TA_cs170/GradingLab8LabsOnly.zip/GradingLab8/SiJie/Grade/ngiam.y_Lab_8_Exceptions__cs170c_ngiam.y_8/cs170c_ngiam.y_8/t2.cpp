/******************************************************************************/
/*!
\file t2.cpp
\author Ngiam Yee Tong
\par email: ngiam.y\@digipen.edu
\par DigiPen login: ngiam.y
\par Course: CS170L
\par Lab 08
\date 15/03/2019
\brief
  This file contain the functions for t2.cpp

  Hours spent on this assignment: 5

  Specific portions that gave you the most trouble: finding how to test
  cases
*/
/******************************************************************************/

#include <iostream>//cout,endl

/******************************************************************************/
/*!
  \brief
    calculate and show sum of 10 positive inputs.exception
    mechanism to display a message that it doesn't allow negative numbers 
    or not-a-numbers (NAN) if so is the
    input and then exit the program.

*/
/******************************************************************************/

int main(void)
{
  int total=0,i=0;
  try
  {
    std::cout<<"Enter 10 positive inputs"<<std::endl;
    for(int t=0;t<10;t++)
    {
      std::cin>>i;
      if(std::cin.fail()||i<0)//other then int and negative numbers
      {
        throw 0;
      }
      total+=i;
    }
    std::cout<<"Total sum is " << total <<std::endl;
  }
  catch(...)
  {
    std::cout<<"Program does not allow negative numbers"
    <<"or not-a-numbers(NAN)"<<std::endl;
  }
  return 0;
}