/******************************************************************************/
/*!
\file t3.cpp
\author Ong Shi Wei
\par email: shiwei.ong\@digipen.edu
\par DigiPen login: shiwei.ong
\par Course: CS170
\par Lab 08
\date 23/03/2019
\brief
    This file calculate and show sum of 10 positive inputs. During the input, 
    program should use exception mechanism to display a message that it doesn't 
    allow negative numbers or not-a-numbers (NAN). If so, program will suggests 
    to restart the process of counting from the beginning or exit the program.
*/
/******************************************************************************/
#include <iostream>

/******************************************************************************/
/*!
  \brief
    Calculates and show sum of 10 positive inputs. During the input, 
    program should use exception mechanism to display a message that it doesn't 
    allow negative numbers or not-a-numbers (NAN). If so, program will suggests 
    to restart the process of counting from the beginning.

*/
/******************************************************************************/
int main()
{
    double i = 10;
    double sum = 0, num = 0, count = 1;
    std::string val{};
    std::cout << "*********************************************" << std::endl;
    while(i--)
    {
        std::cout << "Please enter number " << count << ":" << std::endl;
        
        try
        {
            std::cin >> num;
            throw (num);
        }
        catch(...)
        {
            if(std::cin.fail() || num < 0)
            {
                std::cin.clear();
                std::getline(std::cin, val);
                num = 0;
                int restart{};
                std::cout << "No negative numbers and non-number allowed. " 
                << std::endl;
                std::cout << "Enter 1 to restart, any other input to exit: " 
                << std::endl;
                std::cin >> restart;
                if(restart == 1)
                {
                    i = 10;
                    sum = 0, count = 0;
                    std::cin.clear();
                    std::getline(std::cin, val);
                }
                else
                {
                    std::cout << "*********************************************"  
                    << std::endl << "             Program End." << std::endl
                    << "*********************************************"
                    << std::endl;;
                    return 0;
                }
            }
        }
        sum += num;
        count++;
    }
    std::cout << "Sum of all the numbers are: " << sum << std::endl;
    return 0;
}