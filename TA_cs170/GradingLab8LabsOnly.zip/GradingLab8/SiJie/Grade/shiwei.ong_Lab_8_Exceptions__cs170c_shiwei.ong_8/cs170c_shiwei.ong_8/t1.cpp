/******************************************************************************/
/*!
\file t1.cpp
\author Ong Shi Wei
\par email: shiwei.ong\@digipen.edu
\par DigiPen login: shiwei.ong
\par Course: CS170
\par Lab 08
\date 23/03/2019
\brief
    This file calculates how much memory (in MB) can be allocated in a program.
*/
/******************************************************************************/
#include <iostream>

/******************************************************************************/
/*!
  \brief
    allocates memory

*/
/******************************************************************************/
int main()
{
    int count = 0;
    try
    {
        while(1)
        {
            char* A = new char[1024*1000];
            *A = 0;
            count++;
        }           
    }
    catch(...)
    {
        std::cout << "Number of byte is " << count << " MB." << std::endl;
    }
    return 0;
}