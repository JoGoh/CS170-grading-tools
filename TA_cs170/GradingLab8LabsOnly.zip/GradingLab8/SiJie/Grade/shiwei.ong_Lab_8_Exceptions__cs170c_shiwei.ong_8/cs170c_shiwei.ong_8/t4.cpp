/******************************************************************************/
/*!
\file t4.cpp
\author Ong Shi Wei
\par email: shiwei.ong\@digipen.edu
\par DigiPen login: shiwei.ong
\par Course: CS170
\par Lab 08
\date 23/03/2019
\brief
    This file calculate and show sum of 10 positive inputs. During the input, 
    program should use exception mechanism to display a message that it doesn't 
    allow negative numbers or not-a-numbers (NAN). If so, program will suggests 
    to continue the counting or exit the program.
*/
/******************************************************************************/
#include <iostream>

/******************************************************************************/
/*!
  \brief
    Calculates and show sum of 10 positive inputs. During the input, 
    program should use exception mechanism to display a message that it doesn't 
    allow negative numbers or not-a-numbers (NAN). If so, program will suggests 
    to continue the counting or exit the program.

*/
/******************************************************************************/
int main()
{
    double i = 10;
    double sum = 0, num = 0, count = 1;
    std::string val{};
    std::cout << "*********************************************" << std::endl;
    while(i--)
    {
        std::cout << "Please enter number " << count << ":" << std::endl;
        
        try
        {
            std::cin >> num;
            throw num;
        }
        catch(...)
        {
            if(std::cin.fail() || num < 0)
            {
                std::cin.clear();
                std::getline(std::cin, val);
                int restart{};
                std::cout << "No negative numbers and non-number allowed. " 
                << std::endl;
                std::cout << "Enter 1 to continue, any other input to end: " 
                << std::endl;
                std::cin >> restart;
                i++;
                if(restart == 1)
                {
                    std::cin.clear();
                    std::getline(std::cin, val);
                    continue;
                }
                else
                {
                    sum = 0, num = 0, count = 0;
                    std::cout << "*********************************************"  
                    << std::endl << "             Program End." << std::endl
                    << "*********************************************" 
                    << std::endl;;
                    return 0;
                }
                count--;
            }
        }
        sum += num;
        count++;
    }
    std::cout << "Sum of all the numbers are: " << sum << std::endl;
    return 0;
}