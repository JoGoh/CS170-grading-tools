/******************************************************************************/
/*!
\file	t2.cpp
\author	Muhammad Iskandar Bin Ishak
\par	email: m.ishak\@digipen.edu
\par	course: CS170
\par	lab 08
\date	23/03/2019
 
\brief
	A file that counts 10 positive int
*/
/******************************************************************************/
#include <iostream>

int main()
{
	int i=0;
	int total=0;
	int array[10];
	std::cout<<"Please enter 10 positive numbers:\n";
	
	try
	{
		while (i!=10)
		{
			std::cin>>array[i];
			
			if(array[i]<0 || std::cin.fail())
			{ 
				throw(array[i]); 
			}
			else
			{
				total+=array[i];
			}
			
			i++;
		}
		
		std:: cout << "sum is :\n" << total;
	}
	catch(...)
	{
		std::cout<<"NAN\n";
		std::cout<<"Program terminated.\n";
	}
	return 0;
}