/******************************************************************************/
/*!
\file	t1.cpp
\author	Muhammad Iskandar Bin Ishak
\par	email: m.ishak\@digipen.edu
\par	course: CS170
\par	lab 08
\date	23/03/2019
 
\brief
	The maximum amount space that is needed for a program.
*/
/******************************************************************************/

int main ()
{
	int totalsize=0;
	
	try
	{
		while (1)
		{ 
			new char[1024*1000];
			totalsize++;
		}
	}
	catch (...)
	{
		std::cout<<"Max size of program is:"<<totalsize<<"MB";
	}
	return 0;
}