/******************************************************************************/
/*!
   \file t1.cpp
   \author Jeremy Lee
   \par email: l.chunyangjeremy\@digipen.edu
   \par DigiPen login: l.chunyangjeremy
   \par Course: CS170C
   \par Lab 08
   \date 22/03/2019
   \brief
   This is a program that checks the amount of memory can be allocated.
*/
/******************************************************************************/
#include<iostream>
#include<exception>
#include<stdio.h>

int main(void)
{
   int c = 0;
   try
   {
      while(1)
      {
      /*To do memory allocation and count the size of the program*/
         char* MB = new char[1024*1000]; 
         (void)MB;
         c++;
      }
   }
   catch (...)
   {
      /*To do print the amount of size allocated for the program*/
      std::cout<< "The program allocated: " << c << " MB" << std::endl;
   }
   return 0;
}