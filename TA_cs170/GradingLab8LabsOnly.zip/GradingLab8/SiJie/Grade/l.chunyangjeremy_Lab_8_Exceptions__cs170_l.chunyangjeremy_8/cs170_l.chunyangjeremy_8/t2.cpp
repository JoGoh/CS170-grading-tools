/******************************************************************************/
/*!
   \file t2.cpp
   \author Jeremy Lee
   \par email: l.chunyangjeremy\@digipen.edu
   \par DigiPen login: l.chunyangjeremy
   \par Course: CS170C
   \par Lab 08
   \date 22/03/2019
   \brief
      This is a program that ask for a positive number and prints error if input is 
      not a positive number.
*/
/******************************************************************************/
#include<iostream>
#include<exception>
#include<stdio.h>

int main(void)
{
   double val,sum=0,c=10;
   try
   {
      while(c--)
      {
  /*To get the input from the user and crash the program if a non positive
  number or character is detected*/
         std::cout << "Enter a positive number: ";
         std::cin >> val;
         if(val<0||std::cin.fail())
            throw("This input is not allowed.");
         sum+=val;
      }
      std::cout<<"Sum of all inputs: " << sum <<std::endl;
   }
   catch(const char *fail)
   {
      /*To print error*/
      std::cout << fail <<std::endl<< "End program."<<std::endl;
   }
   return 0;
}