/******************************************************************************/
/*!
   \file t4.cpp
   \author Jeremy Lee
   \par email: l.chunyangjeremy\@digipen.edu
   \par DigiPen login: l.chunyangjeremy
   \par Course: CS170C
   \par Lab 08
   \date 22/03/2019
   \brief
   This is a program that ask for a positive number and prints error if input is 
   not a positive number. Prompts user if he wants to end or continue the
   program.
*/
/******************************************************************************/
#include<iostream>
#include<exception>
#include<stdio.h>

int main(void)
{
   int val,sum=0,c=10;
start :
   try
   {

      while(c--)
      {
 /*To get the input from the user and crash the program if a non positive
  number or character is detected*/
         std::cout << "Enter a positive number: ";
         std::cin >> val;
         if(val<0||std::cin.fail())
            throw("This number is not allowed.");
         sum+=val;
      }
      std::cout<<"Sum of all inputs: " << sum <<std::endl;
   }
   catch(const char *fail)
   {
      /*To do print and prompt to continue the program or not*/
      char respond=0;
      std::cout<< fail <<std::endl<< "Do you want to continue?(Y/N) ";
      std::cin.clear();
      std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
      std::cin >> respond;
      switch (respond)
      {
         case 'Y': goto start;
         case 'y': goto start;
         default: std::cout<< "End program";
      }
   }
   return 0;
}