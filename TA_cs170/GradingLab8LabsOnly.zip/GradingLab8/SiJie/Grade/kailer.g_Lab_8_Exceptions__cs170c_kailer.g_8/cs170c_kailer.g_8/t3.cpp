/******************************************************************************/
/*!
\file   t3.cpp
\author Gan Kai Ler
\par    email: kailer.g\@digipen.edu
\par    DigiPen login: kailer.g
\par    Course: CS170C
\par    Lab 08
\date   17/03/2019
\brief  
    This file encapsulates the main function that allows a user to input up to
    10 values, and then summates them together. However, instead of terminating
    the program outrightly, this code gives the user an option to restart the
    count from the first input all over again.
    
    Hours spent on this assignment: 1

    Specific portions that gave you the most trouble: Trying to find a fix
    for strings in the input stream causing multiple throws. In the end, I
    utilized "getline" to avoid this issue.
*/
/******************************************************************************/
#include <iostream>
#define max_input 10

/******************************************************************************/
/*!
  \brief
    This function allows the user to input up to 10 values and adds them 
    together. However, it only accepts positive integers; upon the reception of
    an invalid input (i.e, NaN's (not-a-number) or negative numbers), it throws
    an exception.
    
  \return 
    It returns an integer that represents the total value of the 10 summated
    integers. It only returns this value if all 10 values were correctly 
    inputted; otherwise, it would exit this function by throwing exceptions.
*/
/******************************************************************************/

double count(void)//definition of count function
{
    double input {};
    double totalval = 0.0;
    std::cout<<"Please input your value (ONLY positive numbers!)"<<std::endl;       
    for(int i = 0; i < max_input; i++)
    {
        std::cout<<"Value number "<<(i+1)<<":"<<std::endl;
        std::cin>>input;
        if(std::cin.fail() || input<0)
        {
            input = 0;
            throw(1);
        }
        totalval+=input;
    }
    return totalval;
}

/******************************************************************************/
/*!
  \brief
    This function allows the user to input up to 10 values and adds them 
    together. However, it only accepts positive integers; upon the reception of
    an invalid input (i.e, NaN's (not-a-number) or negative numbers), the 
    program offers the user an option to restart the count from the first
    input, all over again.
    
  \return 
    The main function returns 0, signifying a proper termination of the program
*/
/******************************************************************************/

int main (void)
{   
    double display_value = 0;
    std::string string1 {};
    while(1)
    {
        try
        {
            display_value = count();
            break; //break if code successfully reaches here without throwing exceptions.           
        }
        catch(int a)
        {
            std::cin.clear();//clear flags
            std::getline(std::cin, string1);
            std::cout<<"You have inputted an invalid value!"<<std::endl;
            std::cout<<"Enter 0 to continue. Enter anything else to exit."<<std::endl;
            int flag = 0;
            std::cin>>flag;
            if((flag) || std::cin.fail())
                return 0;
            else
                continue;
        }
    }
    std::cout<<"Your total value is: "<<display_value<<std::endl;   
    return 0;
}