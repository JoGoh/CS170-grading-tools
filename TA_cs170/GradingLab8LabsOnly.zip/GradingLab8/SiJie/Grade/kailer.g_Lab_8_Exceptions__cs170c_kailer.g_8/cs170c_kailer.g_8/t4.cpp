/******************************************************************************/
/*!
\file   t4.cpp
\author Gan Kai Ler
\par    email: kailer.g\@digipen.edu
\par    DigiPen login: kailer.g
\par    Course: CS170C
\par    Lab 08
\date   17/03/2019
\brief  
    This file encapsulates the main function that allows a user to input up to
    10 values, and then summates them together. However, instead of terminating
    the program outrightly or offering the user the option to restart the count
    all the way from 0, this code gives the user an option to resume his inputs
    wherever he left them.
    
    Hours spent on this assignment: 1

    Specific portions that gave you the most trouble: Trying to find a fix
    for strings in the input stream causing multiple throws. In the end, I
    utilized "getline" to avoid this issue, much like in the t3.cpp file.
*/
/******************************************************************************/
#include <iostream>
#define max_input 10

static int i = 0; //global iterator, as we must keep track of the count

/******************************************************************************/
/*!
  \brief
    This function allows the user to input up to 10 values and adds them 
    together. However, it only accepts positive integers; upon the reception of
    an invalid input (i.e, NaN's (not-a-number) or negative numbers), it throws
    an exception.
    
  \param in
    This function takes in a reference to an integer, representing the current
    input of the user. 
  
  \param total
    This function takes in another reference to an integer, representing the
    current total summated values of the inputted integers.
    
    
  \return 
    It returns an integer that represents the total value of the 10 summated
    integers. It only returns this value if all 10 values were correctly 
    inputted; otherwise, it would exit this function by throwing exceptions.
*/
/******************************************************************************/

void count(double& in, double& total)//definition of count function. Passes by reference.
{
    std::cout<<"Please input your value (ONLY positive numbers!)"<<std::endl;       
    for(; i < max_input; i++)
    {
        std::cout<<"Value number "<<(i+1)<<":"<<std::endl;
        std::cin>>in;
        if(std::cin.fail() || in<0)
        {
            in=0;
            throw (1); 
        }
        total+=in; //"in" is not added to "total" if an exception is thrown.
    }
    i = 0; //resets the global iterator
    return;
}

/******************************************************************************/
/*!
  \brief
    This function allows the user to input up to 10 values and adds them 
    together. However, it only accepts positive integers; upon the reception of
    an invalid input (i.e, NaN's (not-a-number) or negative numbers), the 
    program offers the user an option to continue where he left off, with the
    values of the summated integers so far already computed.
    
  \return 
    The main function returns 0, signifying a proper termination of the program
*/
/******************************************************************************/

int main(void)
{
    double input = 0;
    double totalval = 0;
    std::string str {};
    while(1)
    {
        try
        {
            count(input, totalval);
            break; //break from while loop if code can reach here successfully.
        }
        catch(int a)
        {
                std::cin.clear();//clear flags
                std::getline(std::cin, str);//shove everything until \n to str
                //std::cout<<str<<std::endl;
                std::cout<<"You have entered a value that is invalid!"<<std::endl;
                std::cout<<"Enter 0 to try again. Enter anything else to exit."<<std::endl;
                int flag = 0;
                std::cin>>flag;
                if((flag) || std::cin.fail())
                    return 0;
                else
                    continue;
        }
    }
    std::cout<<"Your total value is: "<<totalval;
    return 0;
}