/******************************************************************************/
/*!
\file   t2.cpp
\author Gan Kai Ler
\par    email: kailer.g\@digipen.edu
\par    DigiPen login: kailer.g
\par    Course: CS170C
\par    Lab 08
\date   17/03/2019
\brief  
    This file encapsulates the main function that allows a user to input up to
    10 values, and summates them together. However, the program will cease 
    should the user input a value that is either not a number or a negative
    number.
    
    Hours spent on this assignment: 0.5

    Specific portions that gave you the most trouble: None
*/
/******************************************************************************/
#include <iostream>
#define max_input 10

/******************************************************************************/
/*!
  \brief
    This function allows the user to input up to 10 values and adds them 
    together. However, it only accepts positive integers; upon the reception of
    an invalid input (i.e, NaN's (not-a-number) or negative numbers), the 
    program terminates.
    
  \return 
    The main function returns 0, signifying a proper termination of the program
*/
/******************************************************************************/

int main (void)
{
    try
    {
        int input;
        int totalval = 0;
        for(int i = 0; i < max_input; i++)
        {
            std::cout<<"Value number "<<(i+1)<<":"<<std::endl;
            std::cin>>input;
            if(std::cin.fail())
                throw(1); //throws 1 if user entered a NaN value.
            if(input <0)
                throw(2); //throws 2 if user entered a negative value.
            totalval+=input;
        }
        std::cout<<"Your total sum is: "<<totalval;
        return 0;
    }
    catch(int e)
    {

        if(e==1)
            std::cout<<"You have inputted something that is not a number. The program will now terminate.";
        if(e==2)
            std::cout<<"You have inputted a negative number. The program will now terminate.";
        return 0;
    }
    
    return 0;
}