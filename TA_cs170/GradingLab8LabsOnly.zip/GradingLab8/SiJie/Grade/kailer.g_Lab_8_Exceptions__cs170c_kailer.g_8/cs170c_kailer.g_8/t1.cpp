/******************************************************************************/
/*!
\file   t1.cpp
\author Gan Kai Ler
\par    email: kailer.g\@digipen.edu
\par    DigiPen login: kailer.g
\par    Course: CS170C
\par    Lab 08
\date   17/03/2019
\brief  
    This file encapsulates the main function that allocates memory until there
    is no memory left to be allocated, which subsequently throws an exception
    that will be handled by printing the amount of successfully allocated
    memory.
    
    Hours spent on this assignment: 0.5

    Specific portions that gave you the most trouble: None
*/
/******************************************************************************/
#include <iostream> //cout, cin

/******************************************************************************/
/*!
  \brief
    This function iterates endlessly, allocating 1mb of memory per iteration.
    This continues until it cannot allocate any more memory, after which it
    throws an exception, and terminates.
    
  \return 
    The main function returns 0, signifying a proper termination of the program
*/
/******************************************************************************/

int main(void)
{
    int megs = 0; //counter to count number of megs
    char *p = nullptr; //initialized to avoid dangling ptr
    try //auto throw exception when alloc fails
    {   
        while(1)
        {
            p = new char[1024*1000]; //allocates a megabyte of space
            p++; //just to avoid -Werror's unused ptr
            megs++; //increase the meg counter

        }
    }
    
    catch(std::bad_alloc)//catch exceptions thrown via failed allocs
    {
        if(!megs)
            std::cout<< "You failed to allocate ANY memory!";
        else
            std::cout<< "You have allocated " <<megs<< "MB of memory before failure.";
        return 0;
    }

    return 0;
}